import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AppShell } from './components/layout/AppShell';
import { AuthScreen } from './components/auth/AuthScreen';
import ConstellationBackground from './components/ConstellationBackground';

const MainApp: React.FC = () => {
  const { sessionUnlocked, unlockSession } = useApp();

  // On launch or when reopening the app, authenticate session
  if (!sessionUnlocked) {
    return <AuthScreen onUnlock={unlockSession} />;
  }

  return (
    <div className="relative min-h-screen">
      <ConstellationBackground className="fixed inset-0 -z-10 w-full h-full" />
      <AppShell />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
};

export default App;