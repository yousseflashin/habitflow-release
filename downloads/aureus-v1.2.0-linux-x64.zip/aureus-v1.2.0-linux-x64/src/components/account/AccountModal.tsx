// Aureus Account & Cloud Sync Modal — User Profile, Multi-Device Sync & Credentials

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  LogIn,
  UserPlus,
  LogOut,
  X,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Database,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Cloud,
  HardDrive,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Settings,
} from 'lucide-react';

interface AccountModalProps {
  fullScreen?: boolean;
}

export const AccountModal: React.FC<AccountModalProps> = ({ fullScreen = false }) => {
  const {
    syncManager,
    setIsAccountModalOpen,
    setActiveView,
    loginUser,
    registerUser,
    logoutUser,
    lockSession,
  } = useApp();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const isAuthenticated = syncManager.dbClient.isAuthenticated();
  const currentUserId = syncManager.dbClient.getUserId();

  useEffect(() => {
    setEmail('');
    setPassword('');
    setMessage(null);
  }, [mode]);

  const handleClose = () => {
    setIsAccountModalOpen(false);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;
    setIsLoading(true);
    setMessage(null);

    const res = await loginUser(email.trim(), password);
    setIsLoading(false);

    if (res.success) {
      setMessage({ text: 'Connected to Cloud Sync.', type: 'success' });
      setTimeout(() => {
        setIsAccountModalOpen(false);
      }, 700);
    } else {
      setMessage({ text: res.error || 'Authentication failed. Please verify credentials.', type: 'error' });
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;
    setIsLoading(true);
    setMessage(null);

    const res = await registerUser(email.trim(), password);
    setIsLoading(false);

    if (res.success) {
      setMessage({ text: 'Account created. Cloud database synced.', type: 'success' });
      setTimeout(() => {
        setIsAccountModalOpen(false);
      }, 700);
    } else {
      setMessage({ text: res.error || 'Registration failed', type: 'error' });
    }
  };

  const handleLogout = () => {
    logoutUser();
    setIsAccountModalOpen(false);
  };

  const handleLockSession = () => {
    lockSession();
    setIsAccountModalOpen(false);
  };

  const handleForceSync = async () => {
    setIsSyncing(true);
    try {
      await syncManager.triggerDbSync();
      setMessage({ text: 'Cloud synchronization complete.', type: 'success' });
    } catch (e: any) {
      setMessage({ text: e?.message || 'Sync encountered a problem', type: 'error' });
    } finally {
      setIsSyncing(false);
    }
  };

  // 1. Authenticated User Profile View
  if (isAuthenticated && !fullScreen) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
        <div className="rounded-3xl bg-[#0c0e14] border border-white/[0.1] w-full max-w-md shadow-2xl overflow-hidden my-auto relative">
          {/* Header */}
          <div className="p-6 border-b border-white/[0.07] flex items-center justify-between bg-white/[0.01]">
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-cyan-400/10 border border-cyan-400/25 flex items-center justify-center text-cyan-300">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-black text-white tracking-tight">Cloud Sync &amp; Account</h2>
                <div className="flex items-center gap-1.5 text-xs text-cyan-300 font-semibold mt-0.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span>MonsterASP SQL Connected</span>
                </div>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-5">
            {/* User Profile Card */}
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-2.5">
              <div className="flex items-center justify-between text-xs text-slate-400 uppercase tracking-wider font-bold">
                <span>Active Profile</span>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-300 font-bold">
                  Verified
                </span>
              </div>
              <div className="text-sm font-bold text-white break-all flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{currentUserId || 'Authenticated User'}</span>
              </div>
              <div className="text-[11px] text-slate-400 flex items-center gap-2 pt-2 border-t border-white/[0.05]">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>End-to-end CRDT conflict-free resolution</span>
              </div>
            </div>

            {/* Sync Status Banner */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <HardDrive className="w-3.5 h-3.5 text-amber-400" />
                  <span>Local Store</span>
                </div>
                <div className="text-sm font-bold text-white">IndexedDB</div>
                <div className="text-[10px] text-emerald-400 font-mono">ACID cache active</div>
              </div>
              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <Cloud className="w-3.5 h-3.5 text-sky-400" />
                  <span>Remote Node</span>
                </div>
                <div className="text-sm font-bold text-white">MonsterASP</div>
                <div className="text-[10px] text-sky-400 font-mono">Encrypted sync</div>
              </div>
            </div>

            {/* Message alert */}
            {message && (
              <div
                className={`p-3 rounded-2xl text-xs font-semibold flex items-center gap-2 ${
                  message.type === 'success'
                    ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                    : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'
                }`}
              >
                {message.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                )}
                <span>{message.text}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-1">
              <button
                onClick={handleForceSync}
                disabled={isSyncing}
                className="btn-primary !w-full !py-3 !text-xs !rounded-xl !shadow-glow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Synchronizing Data...' : 'Sync Now with Cloud'}</span>
              </button>

              <button
                onClick={() => {
                  setIsAccountModalOpen(false);
                  setActiveView('settings');
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-slate-200 border border-white/10 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Settings className="w-3.5 h-3.5 text-cyan-400" />
                <span>Open Full Settings &amp; Updates</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleLockSession}
                  className="py-2.5 px-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-slate-200 border border-white/10 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Lock Session</span>
                </button>

                <button
                  onClick={handleLogout}
                  className="py-2.5 px-3 rounded-xl bg-white/[0.04] hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 border border-white/10 hover:border-rose-500/30 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. Unauthenticated Form View
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="rounded-3xl bg-[#0c0e14] border border-white/[0.1] w-full max-w-md shadow-2xl p-6 sm:p-8 space-y-6 relative">
        <div className="flex justify-between items-center pb-2 border-b border-white/[0.07]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-400/10 border border-cyan-400/25 flex items-center justify-center text-cyan-300 font-black">
              A
            </div>
            <div>
              <h2 className="text-base font-black text-white">Aureus Cloud Sync</h2>
              <p className="text-[10px] text-slate-400">Multi-device synchronization</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="grid grid-cols-2 gap-1 p-1 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`py-2 text-center text-xs font-bold rounded-xl transition-all cursor-pointer ${
              mode === 'login'
                ? 'bg-amber-400/15 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-white border border-transparent'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => setMode('register')}
            className={`py-2 text-center text-xs font-bold rounded-xl transition-all cursor-pointer ${
              mode === 'register'
                ? 'bg-amber-400/15 text-amber-300 border border-amber-400/30'
                : 'text-slate-400 hover:text-white border border-transparent'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Message Alert */}
        {message && (
          <div
            className={`p-3 rounded-2xl text-xs font-semibold flex items-center gap-2 ${
              message.type === 'success'
                ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            )}
            <span>{message.text}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={mode === 'login' ? handleLogin : handleRegister} className="space-y-4">
          <div className="space-y-1.5">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Account Email
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@domain.com"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 transition-all"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full pl-10 pr-11 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 transition-all font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white p-1 transition-colors cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="btn-primary !w-full !py-3 !text-xs !rounded-xl !shadow-glow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-1"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>{mode === 'login' ? 'Connecting to Cloud...' : 'Creating Account...'}</span>
              </>
            ) : (
              <>
                {mode === 'login' ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                <span>{mode === 'login' ? 'Sign In & Sync' : 'Create Synced Account'}</span>
              </>
            )}
          </button>
        </form>

        <div className="pt-3 border-t border-white/[0.06] text-center">
          <button
            type="button"
            onClick={handleClose}
            className="w-full py-2.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Continue in Local Offline Mode</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AccountModal;