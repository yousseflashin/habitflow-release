// Aureus — Floating In-App Update Alert Banner
// Alerts the user whenever a newer version is discovered in the release manifest.

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  updateChecker,
  AppUpdateCheckResult,
  detectPlatform,
  packageFor,
} from '../../domain/releaseService';
import {
  Sparkles,
  Download,
  X,
  ExternalLink,
  ArrowRight,
  ShieldAlert,
  Clock,
} from 'lucide-react';

export const UpdateAlertBanner: React.FC = () => {
  const { setActiveView } = useApp();
  const [updateInfo, setUpdateInfo] = useState<AppUpdateCheckResult | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Start periodic background checks
    updateChecker.startPeriodicCheck(20 * 60 * 1000); // Check every 20 minutes

    const unsubscribe = updateChecker.subscribe((res) => {
      if (res.updateAvailable && res.latestVersion) {
        // Check if user permanently dismissed this exact version
        const lastDismissed = typeof localStorage !== 'undefined'
          ? localStorage.getItem('aureus_dismissed_update_v')
          : null;

        if (lastDismissed !== res.latestVersion) {
          setUpdateInfo(res);
          setDismissed(false);
        }
      } else {
        setUpdateInfo(null);
      }
    });

    return unsubscribe;
  }, []);

  if (!updateInfo || !updateInfo.updateAvailable || dismissed) {
    return null;
  }

  const latest = updateInfo.release;
  const version = updateInfo.latestVersion || 'Latest';
  const thisPlatform = detectPlatform();
  const matchedPkg = packageFor(updateInfo.manifest, version, thisPlatform);

  const handleDismissSession = () => {
    setDismissed(true);
  };

  const handleDismissForever = () => {
    if (typeof localStorage !== 'undefined' && updateInfo.latestVersion) {
      localStorage.setItem('aureus_dismissed_update_v', updateInfo.latestVersion);
    }
    setDismissed(true);
  };

  const handleOpenSettings = () => {
    setActiveView('settings');
    setDismissed(true);
  };

  return (
    <aside
      aria-label="Software Update Alert"
      className="fixed bottom-20 sm:bottom-6 right-4 left-4 sm:left-auto sm:w-[440px] z-[9998] pointer-events-none animate-bounceIn"
    >
      <div className="pointer-events-auto rounded-[28px] bg-[#0c101a]/95 border border-cyan-400/30 p-5 shadow-2xl backdrop-blur-2xl ring-1 ring-cyan-400/20 text-white flex flex-col gap-3.5">
        {/* Header: Icon, Version Badge & Dismiss */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-cyan-400/15 border border-cyan-400/30 text-cyan-300 flex items-center justify-center shrink-0 shadow-cyan-glow">
              <Sparkles className="w-5 h-5 animate-pulse text-cyan-400" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-cyan-400/15 text-cyan-300 border border-cyan-400/30">
                  Update Ready
                </span>
                <span className="text-[11px] text-zinc-400 font-mono">
                  v{updateInfo.installedVersion} → v{version}
                </span>
              </div>
              <h4 className="text-sm font-black text-white truncate mt-0.5">
                Aureus v{version} is Live
              </h4>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDismissSession}
            className="p-1.5 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Dismiss for now"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Highlight Summary */}
        <p className="text-xs text-zinc-300 leading-relaxed">
          {latest?.highlight || 'A new build with enhanced features, security improvements, and optimizations is ready.'}
        </p>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/[0.08]">
          <button
            type="button"
            onClick={handleDismissForever}
            className="text-[11px] text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
          >
            Skip this version
          </button>

          <div className="flex items-center gap-2">
            {matchedPkg && (
              <a
                href={matchedPkg.downloadUrl}
                download
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-400 hover:to-cyan-400 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-brand-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download ({thisPlatform === 'android' ? 'APK' : 'Linux'})</span>
              </a>
            )}

            <button
              type="button"
              onClick={handleOpenSettings}
              className="px-3 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-zinc-200 font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <span>Details</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default UpdateAlertBanner;
