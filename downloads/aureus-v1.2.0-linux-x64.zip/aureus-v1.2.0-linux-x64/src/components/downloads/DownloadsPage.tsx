// Aureus Distribution Center — Official Client Builds & Release Discovery
// All builds operate offline with zero data lock-in.

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Download,
  Package,
  Smartphone,
  Monitor,
  CheckCircle,
  AlertCircle,
  Clock,
  FileText,
  ArrowRight,
  Shield,
  Sparkles,
  Terminal,
  History,
  RefreshCw,
  ExternalLink,
  Info,
  HardDriveDownload,
  ChevronDown,
} from 'lucide-react';
import {
  ChangelogEntry,
  DownloadPackage,
  ReleaseManifest,
  compareSemver,
  detectPlatform,
  currentAppVersion,
} from '../../domain/releaseService';

const PLATFORM_META = {
  android: {
    label: 'Android',
    Icon: Smartphone,
    accent: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
    ring: 'border-white/[0.08]',
    hint: 'Requires Android 7.0 (API 24) or newer. Allow "Install unknown apps" when prompted.',
  },
  windows: {
    label: 'Windows',
    Icon: Monitor,
    accent: 'bg-sky-500/10 border-sky-500/30 text-sky-400',
    ring: 'border-white/[0.08]',
    hint: 'Extract the .zip and run the bundled executable. Windows SmartScreen may prompt on first launch — choose "More info > Run anyway".',
  },
  linux: {
    label: 'Fedora / Linux',
    Icon: Terminal,
    accent: 'bg-amber-400/10 border-amber-400/30 text-amber-300',
    ring: 'border-amber-400/30',
    hint: 'Extract the archive, then execute ./habitflow.sh (chmod +x habitflow.sh if needed).',
  },
} as const;

type PlatformKey = keyof typeof PLATFORM_META;

export const DownloadsPage: React.FC = () => {
  const [manifest, setManifest] = useState<ReleaseManifest | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [installedVersion, setInstalledVersion] = useState<string>(currentAppVersion());
  const [expandedVersion, setExpandedVersion] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoadError(null);
    try {
      const res = await fetch('/releases.json', { cache: 'no-cache' });
      if (!res.ok) throw new Error(`manifest unavailable (HTTP ${res.status})`);
      const data = (await res.json()) as ReleaseManifest;
      if (!data || !Array.isArray(data.releases)) throw new Error('manifest is malformed');
      setManifest(data);
      setExpandedVersion(data.releases[0]?.version ?? null);
    } catch (err) {
      setLoadError(
        err instanceof Error
          ? err.message
          : 'Could not reach the release manifest. Check your connection and try again.'
      );
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const native = (window as any).aureusVersion as string | undefined;
    if (typeof native === 'string' && native.length > 0) setInstalledVersion(native);
  }, []);

  const latest: ChangelogEntry | null = manifest?.releases?.[0] ?? null;
  const updateAvailable = useMemo(() => {
    if (!latest) return false;
    return compareSemver(latest.version, installedVersion) > 0;
  }, [latest, installedVersion]);

  const packagesByVersion = useMemo(() => {
    const map = new Map<string, DownloadPackage[]>();
    manifest?.releases?.forEach((r) => map.set(r.version, r.downloads ?? []));
    return map;
  }, [manifest]);

  const thisPlatform = useMemo<PlatformKey | 'unknown'>(() => detectPlatform(), []);
  const thisPlatformMeta =
    thisPlatform === 'unknown' ? undefined : PLATFORM_META[thisPlatform as PlatformKey];

  const preferredPackage = useMemo(() => {
    const pkgs = latest?.downloads ?? [];
    return pkgs.find((p) => p.platform === thisPlatform) ?? pkgs[0] ?? null;
  }, [latest, thisPlatform]);

  const checkForUpdates = async () => {
    setIsChecking(true);
    await load();
    await new Promise((r) => setTimeout(r, 400));
    setIsChecking(false);
  };

  if (!manifest && !loadError) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4 text-slate-400">
        <RefreshCw className="w-8 h-8 animate-spin text-amber-400" />
        <p className="text-sm font-mono">Querying release repository...</p>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="max-w-2xl mx-auto px-6 py-20 text-center space-y-4">
        <AlertCircle className="w-12 h-12 text-amber-400 mx-auto" />
        <h2 className="text-2xl font-black text-white">Repository Offline</h2>
        <p className="text-sm text-slate-400">{loadError}</p>
        <button
          onClick={checkForUpdates}
          className="btn-primary !px-6 !py-2.5 !text-xs inline-flex items-center gap-2 cursor-pointer"
        >
          <RefreshCw className={`w-4 h-4 ${isChecking ? 'animate-spin' : ''}`} />
          <span>Retry Discovery</span>
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-24 animate-fadeIn">
      {/* ── Header ─────────────────────────────────────────────── */}
      <header className="text-center space-y-3 pt-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-400/10 border border-cyan-400/25 text-cyan-300 text-[11px] font-bold uppercase tracking-widest">
          <HardDriveDownload className="w-3.5 h-3.5" />
          <span>Distribution Center</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight">
          Official Aureus Builds
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl mx-auto">
          High-performance native clients for Android and Linux. Fully offline-capable database storage with cloud sync.
        </p>
      </header>

      {/* ── Status Matrix ───────────────────────────────────────── */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-xl space-y-1">
          <div className="flex items-center gap-2 text-slate-400 text-[11px] font-bold uppercase tracking-widest">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>Installed Client</span>
          </div>
          <div className="text-3xl font-black text-white font-mono tracking-tight">
            v{installedVersion}
          </div>
          <p className="text-xs text-slate-500">Current running build</p>
        </div>

        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-xl space-y-1">
          <div className="flex items-center gap-2 text-slate-400 text-[11px] font-bold uppercase tracking-widest">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Latest Publication</span>
          </div>
          <div className="text-3xl font-black text-amber-300 font-mono tracking-tight">
            v{latest?.version ?? '—'}
          </div>
          <p className="text-xs text-slate-500">
            {latest ? `Published on ${latest.date}` : 'No releases'}
          </p>
        </div>

        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-xl space-y-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-slate-400 text-[11px] font-bold uppercase tracking-widest">
              <RefreshCw className="w-4 h-4 text-sky-400" />
              <span>Update Status</span>
            </div>
            <div
              className={`text-2xl font-black tracking-tight ${
                updateAvailable ? 'text-amber-300' : 'text-emerald-400'
              }`}
            >
              {updateAvailable ? 'Upgrade Available' : 'Client Up to Date'}
            </div>
          </div>
          <button
            onClick={checkForUpdates}
            disabled={isChecking}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 transition-colors inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer pt-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
            <span>Check Repository</span>
          </button>
        </div>
      </section>

      {/* ── Latest release packages ─────────────────────────────── */}
      {latest && (
        <section className="space-y-5">
          <div className="flex items-end justify-between gap-4 flex-wrap">
            <div>
              <h2 className="text-2xl font-black text-white flex items-center gap-3">
                <span>Release v{latest.version}</span>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-300 text-[10px] font-black uppercase tracking-wider">
                  Latest Stable
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>{latest.date} · {latest.highlight}</span>
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              Targeting: <span className="text-white font-bold capitalize">{thisPlatform}</span>
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {(latest.downloads ?? []).map((pkg) => {
              const meta = PLATFORM_META[pkg.platform as PlatformKey];
              if (!meta) return null;
              const Icon = meta.Icon;
              const isThisDevice = pkg.platform === thisPlatform;

              return (
                <article
                  key={`${latest.version}-${pkg.platform}`}
                  className={`rounded-3xl bg-[#0c0e14]/90 border p-6 flex flex-col justify-between gap-5 transition-all duration-200 hover:-translate-y-1 shadow-2xl ${
                    isThisDevice ? 'border-amber-400/40' : 'border-white/[0.08]'
                  }`}
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className={`p-3 rounded-2xl border ${meta.accent}`}>
                        <Icon className="w-6 h-6" />
                      </div>
                      {isThisDevice && (
                        <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full bg-amber-400/15 text-amber-300 border border-amber-400/30">
                          Detected Device
                        </span>
                      )}
                    </div>

                    <div>
                      <h3 className="font-black text-white text-lg">{meta.label}</h3>
                      <p className="text-xs text-slate-400 font-mono mt-0.5 truncate">{pkg.fileName}</p>
                      <p className="text-xs text-slate-500 font-mono mt-1">{pkg.fileSize}</p>
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed">
                      {pkg.installHint || meta.hint}
                    </p>
                  </div>

                  <div className="space-y-2 w-full pt-2 border-t border-white/[0.06]">
                    <a
                      href={pkg.downloadUrl}
                      download
                      className={`w-full py-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        isThisDevice
                          ? 'btn-primary !shadow-glow-sm'
                          : 'bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-white'
                      }`}
                    >
                      <Download className="w-4 h-4" />
                      <span>Download Package</span>
                    </a>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 px-1 pt-1">
                      <span>Official CDN</span>
                      <a
                        href={`/downloads/${pkg.fileName}`}
                        download
                        className="text-amber-400/90 hover:text-amber-300 font-mono underline hover:no-underline flex items-center gap-1 transition-colors"
                        title="Download directly from website server mirror"
                      >
                        <HardDriveDownload className="w-3 h-3" />
                        <span>Web Mirror</span>
                      </a>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>

          {/* Release Highlights Notes */}
          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-xl space-y-3">
            <h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
              <FileText className="w-4 h-4" />
              <span>Release Notes for v{latest.version}</span>
            </h3>
            <ul className="space-y-2 pt-1">
              {latest.notes.map((note, i) => (
                <li key={i} className="flex gap-2.5 text-xs text-slate-300 leading-relaxed">
                  <span className="text-amber-400 font-bold">▸</span>
                  <span>{note}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {/* ── Changelog History ───────────────────────────────────── */}
      <section className="space-y-4">
        <h2 className="text-xl font-black text-white flex items-center gap-2.5">
          <History className="w-5 h-5 text-amber-400" />
          <span>Release Archives</span>
        </h2>

        <div className="space-y-3">
          {manifest?.releases?.map((rel, idx) => {
            const isOpen = expandedVersion === rel.version;
            const isInstalled = rel.version === installedVersion;

            return (
              <div key={rel.version} className="rounded-2xl bg-[#0c0e14]/90 border border-white/[0.08] overflow-hidden">
                <button
                  onClick={() => setExpandedVersion(isOpen ? null : rel.version)}
                  className="w-full flex items-center justify-between gap-4 px-6 py-4 text-left hover:bg-white/[0.02] transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="font-mono font-bold text-white text-sm">v{rel.version}</span>
                    {idx === 0 && (
                      <span className="px-2 py-0.5 rounded-full bg-amber-400/15 border border-amber-400/25 text-amber-300 text-[10px] font-bold uppercase">
                        Current
                      </span>
                    )}
                    {isInstalled && (
                      <span className="px-2 py-0.5 rounded-full bg-white/10 text-slate-300 text-[10px] font-bold uppercase">
                        Active
                      </span>
                    )}
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{rel.date}</span>
                    </span>
                  </div>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`}
                  />
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 border-t border-white/[0.05] pt-4 space-y-3">
                    <p className="text-xs text-slate-300 font-medium">{rel.highlight}</p>
                    <ul className="space-y-1.5">
                      {rel.notes.map((n, i) => (
                        <li key={i} className="flex gap-2 text-xs text-slate-400">
                          <span className="text-slate-600">•</span>
                          <span>{n}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="flex flex-wrap gap-2 pt-2">
                      {(packagesByVersion.get(rel.version) ?? []).map((p) => (
                        <a
                          key={`${rel.version}-${p.platform}-changelog`}
                          href={p.downloadUrl}
                          download
                          className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white transition-colors"
                        >
                          <span>{PLATFORM_META[p.platform as PlatformKey]?.label ?? p.platform}</span>
                          <Download className="w-3 h-3" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* ── Trust Footer ────────────────────────────────────────── */}
      <footer className="text-center pt-2">
        <div className="inline-flex items-center gap-2 text-xs text-slate-400 bg-white/[0.02] border border-white/[0.06] rounded-full px-5 py-2.5">
          <Shield className="w-4 h-4 text-cyan-400" />
          <span>Zero telemetry architecture. Your data stays on your devices.</span>
        </div>
      </footer>
    </div>
  );
};

export default DownloadsPage;