// Aureus — System Settings, Update Tracking & Vault Center
// Integrates Live Release Discovery, MonsterASP Cloud Vault, Preferences & Local-First Diagnostics

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import {
  updateChecker,
  AppUpdateCheckResult,
  currentAppVersion,
  detectPlatform,
  packageFor,
  compareSemver,
} from '../../domain/releaseService';
import { soundFx } from '../../utils/soundEffects';
import { notificationManager } from '../../native/notificationService';
import {
  Settings,
  Sparkles,
  Download,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Cloud,
  HardDrive,
  Lock,
  LogOut,
  User,
  ShieldCheck,
  Bell,
  Volume2,
  VolumeX,
  FileText,
  ExternalLink,
  ChevronRight,
  Database,
  ArrowRight,
  Sliders,
  Info,
  Calendar,
  Layers,
  Radio,
  FileDown,
  Terminal,
  Smartphone,
  Check,
} from 'lucide-react';

type SettingsTab = 'updates' | 'vault' | 'preferences' | 'storage' | 'about';

export const SettingsPage: React.FC = () => {
  const {
    tasks,
    habits,
    meetings,
    projects,
    syncManager,
    loginUser,
    registerUser,
    logoutUser,
    lockSession,
    theme,
    toggleTheme,
    setActiveView,
  } = useApp();

  const [activeTab, setActiveTab] = useState<SettingsTab>('updates');
  const [updateInfo, setUpdateInfo] = useState<AppUpdateCheckResult | null>(null);
  const [isCheckingUpdates, setIsCheckingUpdates] = useState(false);
  const [checkMessage, setCheckMessage] = useState<string | null>(null);

  // Auth form states (for unauthenticated vault tab)
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [authMessage, setAuthMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Sync state
  const [isSyncing, setIsSyncing] = useState(false);

  // Audio testing state
  const [isChimeTesting, setIsChimeTesting] = useState(false);

  const installedVersion = useMemo(() => currentAppVersion(), []);
  const thisPlatform = useMemo(() => detectPlatform(), []);
  const isAuthenticated = syncManager.dbClient.isAuthenticated();
  const currentUserId = syncManager.dbClient.getUserId();

  // Listen to live update events
  useEffect(() => {
    const unsubscribe = updateChecker.subscribe((res) => {
      setUpdateInfo(res);
    });

    // Check updates on mount
    void handleCheckUpdates();

    return unsubscribe;
  }, []);

  const handleCheckUpdates = async () => {
    setIsCheckingUpdates(true);
    setCheckMessage(null);
    try {
      const res = await updateChecker.checkNow();
      setUpdateInfo(res);
      if (res.updateAvailable) {
        setCheckMessage(`New release found: v${res.latestVersion}!`);
      } else {
        setCheckMessage('Aureus is up to date.');
      }
    } catch (e: any) {
      setCheckMessage(e?.message || 'Could not reach update server.');
    } finally {
      setIsCheckingUpdates(false);
    }
  };

  const handleForceSync = async () => {
    setIsSyncing(true);
    try {
      await syncManager.triggerDbSync();
      setAuthMessage({ text: 'Cloud Vault successfully synchronized.', type: 'success' });
    } catch (e: any) {
      setAuthMessage({ text: e?.message || 'Synchronization encountered an error', type: 'error' });
    } finally {
      setIsSyncing(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;
    setIsAuthLoading(true);
    setAuthMessage(null);
    const res = await loginUser(email.trim(), password);
    setIsAuthLoading(false);
    if (res.success) {
      setAuthMessage({ text: 'Connected to Cloud Vault.', type: 'success' });
      setEmail('');
      setPassword('');
    } else {
      setAuthMessage({ text: res.error || 'Authentication failed. Please verify credentials.', type: 'error' });
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;
    setIsAuthLoading(true);
    setAuthMessage(null);
    const res = await registerUser(email.trim(), password);
    setIsAuthLoading(false);
    if (res.success) {
      setAuthMessage({ text: 'Account created. Cloud database synced.', type: 'success' });
      setEmail('');
      setPassword('');
    } else {
      setAuthMessage({ text: res.error || 'Registration failed', type: 'error' });
    }
  };

  const handleExportBackup = () => {
    const backup = {
      appName: 'Aureus Whole-Life OS',
      version: installedVersion,
      exportedAt: new Date().toISOString(),
      counts: {
        tasks: tasks.length,
        habits: habits.length,
        meetings: meetings.length,
        projects: projects.length,
      },
      data: {
        tasks,
        habits,
        meetings,
        projects,
      },
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aureus-backup-v${installedVersion}-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleTestChime = () => {
    setIsChimeTesting(true);
    soundFx.playMeetingChime();
    setTimeout(() => setIsChimeTesting(false), 1200);
  };

  const handleTestNotification = async () => {
    if (typeof Notification !== 'undefined') {
      if (Notification.permission !== 'granted') {
        await Notification.requestPermission();
      }
      if (Notification.permission === 'granted') {
        new Notification('Aureus Update & Meeting System', {
          body: 'System notifications are verified and active.',
          icon: '/favicon.ico',
        });
      }
    }
  };

  const latestRelease = updateInfo?.release;
  const updateAvailable = !!updateInfo?.updateAvailable;
  const matchedPkg = updateInfo?.manifest
    ? packageFor(updateInfo.manifest, updateInfo.latestVersion || installedVersion, thisPlatform)
    : null;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-24 animate-fadeIn">
      {/* ── Executive Settings Header ──────────────────────────────── */}
      <div className="stagger-1 rounded-[28px] bg-gradient-to-b from-[#131722] to-[#0a0d14] border border-white/[0.08] p-6 sm:p-8 shadow-2xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative shrink-0">
              <img
                src="/avatar.png"
                alt="Profile Avatar"
                className="w-14 h-14 rounded-2xl object-cover border border-cyan-400/40 ring-4 ring-indigo-500/15 shadow-brand-md"
              />
              <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-[#090d16] ${
                isAuthenticated ? 'bg-emerald-400 shadow-[0_0_8px_#10b981]' : 'bg-cyan-400'
              }`} />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-cyan-300 uppercase tracking-widest mb-0.5">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                <span>Executive Command &amp; Updates</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                System &amp; Workspace Settings
              </h1>
              <p className="text-xs text-zinc-400">
                Track releases, manage MonsterASP cloud synchronization, configure notifications and local ACID storage.
              </p>
            </div>
          </div>

          {/* Quick Beacon Badges */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Version Badge */}
            <div
              className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-bold flex items-center gap-1.5 ${
                updateAvailable
                  ? 'bg-cyan-400/15 border-cyan-400/40 text-cyan-300 animate-pulse'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${updateAvailable ? 'bg-cyan-400 shadow-[0_0_6px_#38bdf8]' : 'bg-emerald-400'}`} />
              <span>v{installedVersion}</span>
              {updateAvailable && <span className="text-[10px] uppercase font-black font-sans ml-1 text-cyan-200">Update Ready</span>}
            </div>

            {/* Cloud Status */}
            <div className="px-3 py-1.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs font-mono text-zinc-300 flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${isAuthenticated ? 'bg-emerald-400' : 'bg-zinc-500'}`} />
              <span>{isAuthenticated ? 'Cloud Synced' : 'Local Only'}</span>
            </div>
          </div>
        </div>

        {/* ── Sub Navigation Tabs (Material 3 Expressive Filter Chips) ────────────────── */}
        <div className="pt-4 border-t border-white/[0.07] flex items-center gap-2 flex-wrap">
          {[
            { id: 'updates', label: 'Updates & Versions', icon: Sparkles, badge: updateAvailable },
            { id: 'vault', label: 'Cloud Vault & Sync', icon: Cloud },
            { id: 'preferences', label: 'Preferences & Audio', icon: Sliders },
            { id: 'storage', label: 'Storage & Backup', icon: HardDrive },
            { id: 'about', label: 'About Aureus', icon: Info },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as SettingsTab)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-black shadow-brand-sm'
                    : 'bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.07] text-zinc-300'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── TAB 1: UPDATES & VERSION TRACKING ───────────────────────── */}
      {activeTab === 'updates' && (
        <div className="space-y-6 stagger-2">
          {/* Main Version Tracker Bento */}
          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.07] pb-5">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                  Release Discovery Engine
                </span>
                <h2 className="text-xl font-black text-white mt-0.5">Software Version &amp; Channel</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Synchronized with official repository:{' '}
                  <a
                    href="https://github.com/yousseflashin/habitflow-release"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-300 hover:underline font-mono"
                  >
                    yousseflashin/habitflow-release
                  </a>
                </p>
              </div>

              <button
                onClick={handleCheckUpdates}
                disabled={isCheckingUpdates}
                className="px-4 py-2.5 rounded-xl bg-amber-400/15 hover:bg-amber-400/25 border border-amber-400/30 text-amber-300 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isCheckingUpdates ? 'animate-spin text-amber-400' : ''}`} />
                <span>{isCheckingUpdates ? 'Checking Repository...' : 'Check for Updates Now'}</span>
              </button>
            </div>

            {/* Check Feedback Message */}
            {checkMessage && (
              <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/[0.08] text-xs font-mono flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  <span>{checkMessage}</span>
                </span>
                <span className="text-[10px] text-slate-500">
                  {updateInfo?.checkedAt ? new Date(updateInfo.checkedAt).toLocaleTimeString() : 'Just now'}
                </span>
              </div>
            )}

            {/* If an update IS available */}
            {updateAvailable && latestRelease ? (
              <div className="rounded-2xl border border-amber-400/40 bg-amber-400/[0.04] p-5 sm:p-6 space-y-4 shadow-glow-sm">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-300 flex items-center justify-center shrink-0 shadow-sm">
                      <Sparkles className="w-5 h-5 animate-pulse" />
                    </div>
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                        New Release Available
                      </span>
                      <h3 className="text-lg font-black text-white">
                        Aureus Release v{latestRelease.version}
                      </h3>
                      <span className="text-xs text-slate-400 font-mono">
                        Published {latestRelease.date} · Upgrading from v{installedVersion}
                      </span>
                    </div>
                  </div>

                  <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    Ready to Install
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-medium">
                  {latestRelease.highlight}
                </p>

                {/* Release Notes */}
                {latestRelease.notes && latestRelease.notes.length > 0 && (
                  <div className="pt-3 border-t border-white/[0.08] space-y-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Changelog &amp; Highlights:
                    </span>
                    <ul className="space-y-1">
                      {latestRelease.notes.map((note, i) => (
                        <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                          <span className="text-amber-400 font-bold">▸</span>
                          <span>{note}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Direct Download Actions */}
                <div className="pt-4 border-t border-white/[0.08] flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2">
                    {matchedPkg && (
                      <a
                        href={matchedPkg.downloadUrl}
                        download
                        className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-xs flex items-center gap-2 shadow-glow-sm transition-all cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download {matchedPkg.fileName} ({matchedPkg.fileSize})</span>
                      </a>
                    )}

                    <a
                      href={`/downloads/${matchedPkg?.fileName || 'aureus-v' + latestRelease.version + '-android.apk'}`}
                      download
                      className="px-3.5 py-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 text-xs font-bold transition-all cursor-pointer"
                      title="Direct Website Mirror Download"
                    >
                      Web Mirror
                    </a>
                  </div>

                  <button
                    onClick={() => setActiveView('downloads')}
                    className="text-xs font-bold text-amber-300 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>Open Complete Downloads Center</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ) : (
              /* If up to date */
              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/[0.04] p-5 sm:p-6 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white">
                      Aureus is Up to Date (v{installedVersion})
                    </h3>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">
                      Targeting {thisPlatform.toUpperCase()} · No newer release found on repository.
                    </p>
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Your client contains all current security updates, multi-range wallet features, and Google Calendar scheduling.
                </p>
              </div>
            )}

            {/* Platform & Build Information */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">
                  Current Client Version
                </span>
                <div className="text-lg font-black text-white font-mono">v{installedVersion}</div>
                <span className="text-[11px] text-slate-400">Production Build</span>
              </div>

              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">
                  Runtime Environment
                </span>
                <div className="text-lg font-black text-amber-300 font-mono capitalize">
                  {thisPlatform}
                </div>
                <span className="text-[11px] text-slate-400">Offline-first sandbox</span>
              </div>

              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">
                  Release Channel
                </span>
                <div className="text-lg font-black text-emerald-400 font-mono">Stable / Main</div>
                <span className="text-[11px] text-slate-400">Official distribution</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 2: CLOUD VAULT & ACCOUNT ───────────────────────────── */}
      {activeTab === 'vault' && (
        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-8 shadow-2xl space-y-6 stagger-2">
          <div className="border-b border-white/[0.07] pb-4">
            <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
              Cloud Infrastructure
            </span>
            <h2 className="text-xl font-black text-white mt-0.5">
              MonsterASP SQL Cloud Sync &amp; Multi-Device Storage
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              End-to-end CRDT deterministic conflict resolution across desktop, mobile, and web.
            </p>
          </div>

          {authMessage && (
            <div
              className={`p-3.5 rounded-2xl text-xs font-semibold flex items-center gap-2.5 ${
                authMessage.type === 'success'
                  ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                  : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'
              }`}
            >
              {authMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              )}
              <span>{authMessage.text}</span>
            </div>
          )}

          {isAuthenticated ? (
            /* Authenticated Account Dashboard */
            <div className="space-y-6">
              <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-wider font-bold text-slate-400">
                    Connected Profile
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                    Active Session
                  </span>
                </div>
                <div className="text-base font-black text-white flex items-center gap-2.5 break-all">
                  <User className="w-5 h-5 text-cyan-400 shrink-0" />
                  <span>{currentUserId || 'Authenticated User'}</span>
                </div>
                <div className="text-xs text-slate-400 flex items-center gap-2 pt-2 border-t border-white/[0.05]">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Encrypted session token stored securely</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Cloud className="w-4 h-4 text-sky-400" />
                    <span>Remote Cloud Database</span>
                  </div>
                  <div className="text-sm font-bold text-white">MonsterASP SQL Server</div>
                  <div className="text-[11px] text-emerald-400 font-mono">Live bi-directional sync</div>
                </div>

                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <HardDrive className="w-4 h-4 text-cyan-400" />
                    <span>Local Database Cache</span>
                  </div>
                  <div className="text-sm font-bold text-white">IndexedDB ACID Store</div>
                  <div className="text-[11px] text-emerald-400 font-mono">Instant device reads</div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3 flex-wrap pt-2">
                <button
                  onClick={handleForceSync}
                  disabled={isSyncing}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-bold text-xs flex items-center gap-2 shadow-brand-sm cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Synchronizing...' : 'Force Sync Now'}</span>
                </button>

                <button
                  onClick={lockSession}
                  className="px-4 py-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-200 font-bold text-xs flex items-center gap-2 cursor-pointer transition-all"
                >
                  <Lock className="w-4 h-4 text-cyan-400" />
                  <span>Lock Session</span>
                </button>

                <button
                  onClick={logoutUser}
                  className="px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 text-rose-400 font-bold text-xs flex items-center gap-2 cursor-pointer transition-all ml-auto"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          ) : (
            /* Unauthenticated Login & Register Tabs */
            <div className="max-w-md mx-auto space-y-5">
              <div className="flex items-center p-1 rounded-2xl bg-white/[0.03] border border-white/[0.08]">
                <button
                  onClick={() => setAuthMode('login')}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    authMode === 'login'
                      ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Sign In
                </button>
                <button
                  onClick={() => setAuthMode('register')}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    authMode === 'register'
                      ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Create Account
                </button>
              </div>

              <form onSubmit={authMode === 'login' ? handleLogin : handleRegister} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 block">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="user@example.com"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 block">Password</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isAuthLoading}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-bold text-xs shadow-brand-sm transition-all cursor-pointer disabled:opacity-50 mt-2"
                >
                  {isAuthLoading ? 'Connecting...' : authMode === 'login' ? 'Connect to Cloud Sync' : 'Register Account'}
                </button>
              </form>
            </div>
          )}
        </div>
      )}

      {/* ── TAB 3: PREFERENCES & AUDIO / NOTIFICATIONS ─────────────── */}
      {activeTab === 'preferences' && (
        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-8 shadow-2xl space-y-6 stagger-2">
          <div className="border-b border-white/[0.07] pb-4">
            <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
              User Experience
            </span>
            <h2 className="text-xl font-black text-white mt-0.5">Preferences, Audio &amp; Notifications</h2>
          </div>

          <div className="space-y-4">
            {/* Audio Feedback Section */}
            <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/[0.06] flex items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-400/15 text-amber-400 flex items-center justify-center shrink-0">
                  <Volume2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Executive Audio Chimes</h4>
                  <p className="text-xs text-slate-400">
                    Synthesizes harmonic two-tone chimes on meeting reminders and habit completions.
                  </p>
                </div>
              </div>

              <button
                onClick={handleTestChime}
                disabled={isChimeTesting}
                className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-white font-bold text-xs flex items-center gap-2 cursor-pointer transition-colors"
              >
                <span>{isChimeTesting ? 'Playing Chime...' : 'Test Audio Chime'}</span>
              </button>
            </div>

            {/* Notification Permissions */}
            <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/[0.06] flex items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/15 text-blue-400 flex items-center justify-center shrink-0">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">System Push Notifications</h4>
                  <p className="text-xs text-slate-400">
                    Dispatches native alerts on Android and Linux notify-send even when window is minimized.
                  </p>
                </div>
              </div>

              <button
                onClick={handleTestNotification}
                className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-white font-bold text-xs flex items-center gap-2 cursor-pointer transition-colors"
              >
                <span>Test Notification</span>
              </button>
            </div>

            {/* Theme Preference */}
            <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/[0.06] flex items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-purple-500/15 text-purple-400 flex items-center justify-center shrink-0">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Aureus Aesthetic Palette</h4>
                  <p className="text-xs text-slate-400">
                    Current active appearance: <span className="text-amber-300 font-bold capitalize">{theme}</span>.
                  </p>
                </div>
              </div>

              <button
                onClick={toggleTheme}
                className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-white font-bold text-xs cursor-pointer transition-colors"
              >
                Toggle Theme
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 4: STORAGE DIAGNOSTICS & BACKUP ─────────────────────── */}
      {activeTab === 'storage' && (
        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-8 shadow-2xl space-y-6 stagger-2">
          <div className="flex items-center justify-between border-b border-white/[0.07] pb-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
                Data Reliability &amp; Offline Cache
              </span>
              <h2 className="text-xl font-black text-white mt-0.5">Database Diagnostics &amp; Snapshots</h2>
            </div>

            <button
              onClick={handleExportBackup}
              className="px-4 py-2 rounded-xl bg-cyan-400/15 hover:bg-cyan-400/25 border border-cyan-400/30 text-cyan-300 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-brand-sm"
            >
              <FileDown className="w-4 h-4" />
              <span>Export Full JSON Backup</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">Tasks Stored</span>
              <div className="text-2xl font-black text-white font-mono">{tasks.length}</div>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">Habits Tracked</span>
              <div className="text-2xl font-black text-white font-mono">{habits.length}</div>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">Meetings Stored</span>
              <div className="text-2xl font-black text-white font-mono">{meetings.length}</div>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">Projects Logged</span>
              <div className="text-2xl font-black text-white font-mono">{projects.length}</div>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 5: ABOUT AUREUS ───────────────────────────────────── */}
      {activeTab === 'about' && (
        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-8 shadow-2xl space-y-6 stagger-2">
          <div className="border-b border-white/[0.07] pb-4">
            <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
              Architecture &amp; Mission
            </span>
            <h2 className="text-xl font-black text-white mt-0.5">Aureus Whole-Life Operating System</h2>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
            Aureus is a private executive dashboard for tasks, habit consistency, Google Calendar meetings, and wealth cashflow. Built with zero cloud lock-in: every piece of data is stored in your device database and synchronizes deterministically over CRDT with your personal database.
          </p>

          <div className="pt-2 flex items-center gap-3">
            <a
              href="https://github.com/yousseflashin/habitflow-release"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-white font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
            >
              <ExternalLink className="w-4 h-4 text-amber-400" />
              <span>Official Release Repository</span>
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsPage;
