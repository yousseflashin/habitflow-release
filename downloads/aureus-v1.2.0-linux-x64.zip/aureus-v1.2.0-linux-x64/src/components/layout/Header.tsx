import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import type { AppView } from '../../types';
import { updateChecker } from '../../domain/releaseService';
import {
  Search,
  RefreshCw,
  Flame,
  CheckSquare,
  Moon,
  Sun,
  Settings,
  Sparkles,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    activeView,
    setActiveView,
    setIsCommandPaletteOpen,
    setIsTaskModalOpen,
    setIsHabitModalOpen,
    setEditingTask,
    setEditingHabit,
    theme,
    toggleTheme,
    syncStatus,
    reloadData,
  } = useApp();

  const [hasUpdate, setHasUpdate] = useState(false);

  useEffect(() => {
    return updateChecker.subscribe((res) => {
      setHasUpdate(res.updateAvailable);
    });
  }, []);

  const isReloading = syncStatus.state === 'syncing';
  const lastChecked = syncStatus.lastCloudSyncTime
    ? new Date(syncStatus.lastCloudSyncTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : 'Live';

  const viewTitles: Record<AppView, string> = {
    today: 'Today',
    tasks: 'Tasks',
    habits: 'Habits',
    calendar: 'Calendar',
    projects: 'Projects',
    stats: 'Intelligence',
    account: 'Settings',
    settings: 'Settings',
    lifestyle: 'Life Pulse',
    money: 'Wealth Matrix',
    downloads: 'Downloads',
  };

  // Scroll progress — subtle hairline indicator at header bottom edge
  const [scrollPct, setScrollPct] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const el = document.querySelector('main');
      if (!el) return;
      const max = el.scrollHeight - el.clientHeight;
      setScrollPct(max > 0 ? Math.min(100, (el.scrollTop / max) * 100) : 0);
    };
    onScroll();
    const main = document.querySelector('main');
    main?.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      main?.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, [activeView]);

  return (
    <header className="sticky top-0 z-30 glass border-b border-white/[0.07] px-4 sm:px-6 py-2.5 transition-colors relative backdrop-blur-2xl">
      {/* Hairline subtle cyan-indigo progress bar */}
      <div
        className="absolute bottom-0 left-0 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400 to-indigo-500 opacity-90 transition-[width] duration-100 ease-out"
        style={{ width: `${scrollPct}%` }}
      />

      <div className="flex items-center justify-between gap-4 max-w-7xl mx-auto">
        {/* Left: Mobile Profile Avatar & Desktop View Title */}
        <div className="flex items-center gap-3">
          {/* Mobile Profile Avatar & Brand Hub */}
          <button
            type="button"
            onClick={() => setActiveView('settings')}
            className="flex md:hidden items-center gap-2.5 group cursor-pointer text-left focus:outline-none"
            title="Open Account & Settings"
          >
            <div className="relative">
              <img
                src="/avatar.png"
                alt="Profile Avatar"
                className="w-9 h-9 rounded-full object-cover border border-cyan-400/40 ring-2 ring-indigo-500/20 group-hover:ring-cyan-400/40 transition-all shadow-brand-sm"
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#090d16] shadow-[0_0_6px_#10b981]" />
            </div>
            <div>
              <span className="font-display font-black text-white text-sm tracking-tight block leading-tight group-hover:text-cyan-300 transition-colors">
                HabitFlow
              </span>
              <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider block">
                {viewTitles[activeView]}
              </span>
            </div>
          </button>

          <div className="hidden md:flex items-center gap-2.5">
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#38bdf8]" />
            <div>
              <h1 className="text-sm font-bold text-white tracking-tight leading-none">
                {viewTitles[activeView]}
              </h1>
              <p className="text-[10px] text-zinc-500 font-semibold tracking-widest uppercase mt-0.5">
                Executive Workspace
              </p>
            </div>
          </div>
        </div>

        {/* Middle: Command Search Bar (Linear/Raycast aesthetic) */}
        <div className="flex-1 max-w-md hidden sm:block">
          <button
            type="button"
            onClick={() => setIsCommandPaletteOpen(true)}
            className="w-full flex items-center justify-between px-3 py-1.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.07] hover:border-white/[0.14] text-zinc-400 hover:text-zinc-200 transition-all text-xs cursor-pointer group shadow-brand-sm"
          >
            <span className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-zinc-400 group-hover:text-cyan-400 transition-colors" />
              <span className="text-zinc-400 group-hover:text-zinc-200 text-xs font-normal">
                Quick jump, search tasks, habits...
              </span>
            </span>
            <kbd className="px-1.5 py-0.5 rounded-md bg-white/[0.05] border border-white/[0.08] text-[10px] font-mono text-zinc-400 font-semibold">
              Ctrl+K
            </kbd>
          </button>
        </div>

        {/* Right: Quick Actions + Status Beacon + Theme */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Refresh trigger */}
          <button
            onClick={() => reloadData()}
            disabled={isReloading}
            className="p-1.5 rounded-xl text-zinc-400 hover:text-white hover:bg-white/[0.05] transition-colors cursor-pointer"
            title="Sync latest local state"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isReloading ? 'animate-spin text-cyan-400' : ''}`} />
          </button>

          {/* Sync status beacon */}
          <div
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white/[0.03] border border-white/[0.06] text-[11px] font-medium text-zinc-400"
            title={`Database status: ${syncStatus.state} (${lastChecked})`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#10b981]" />
            <span>Cloud Synced</span>
          </div>

          {/* Update Available Indicator Badge */}
          {hasUpdate && (
            <button
              onClick={() => setActiveView('settings')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-cyan-400/15 hover:bg-cyan-400/25 border border-cyan-400/35 text-cyan-300 text-xs font-bold animate-pulse cursor-pointer shadow-cyan-glow transition-all"
              title="New software update available — click to view"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Update Ready</span>
            </button>
          )}

          {/* + Task Action */}
          <button
            onClick={() => {
              setEditingTask(null);
              setIsTaskModalOpen(true);
            }}
            className="btn-primary hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs shadow-brand-sm"
            title="Create new task (N)"
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>+ Task</span>
          </button>

          {/* + Habit Action */}
          <button
            onClick={() => {
              setEditingHabit(null);
              setIsHabitModalOpen(true);
            }}
            className="btn-secondary hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs"
            title="Create new habit (H)"
          >
            <Flame className="w-3.5 h-3.5 text-cyan-400" />
            <span>+ Habit</span>
          </button>

          {/* Theme Switcher */}
          <button
            onClick={toggleTheme}
            className="p-1.5 rounded-xl text-zinc-400 hover:text-white hover:bg-white/[0.05] transition-colors cursor-pointer"
            title="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-cyan-400" /> : <Moon className="w-4 h-4 text-zinc-400" />}
          </button>

          {/* Settings Trigger */}
          <button
            onClick={() => setActiveView('settings')}
            className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
              activeView === 'settings'
                ? 'bg-indigo-500/20 text-cyan-300 border border-indigo-500/30'
                : 'text-zinc-400 hover:text-white hover:bg-white/[0.05]'
            }`}
            title="Open Settings & Updates"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
