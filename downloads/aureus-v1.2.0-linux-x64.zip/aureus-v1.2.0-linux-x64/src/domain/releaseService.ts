// Release / download-center domain logic.
//
// Single source of truth: public/releases.json (see ReleasesPage data contract).
// The app NEVER hardcodes release data — it reads the manifest at runtime so shipping
// a new APK or desktop package is a file swap, not a code change.

/** One downloadable artifact for one platform at one version. */
export interface DownloadPackage {
  platform: 'android' | 'windows' | 'linux';
  fileName: string;
  downloadUrl: string;
  fileSize: string;
  sha256?: string;
  /** Optional install note shown when this specific package is selected. */
  installHint?: string;
}

/** One published version: metadata + the packages that were built for it. */
export interface ChangelogEntry {
  version: string;
  date: string; // 'YYYY-MM-DD'
  highlight: string; // one-line summary for the banner
  notes: string[];
  downloads: DownloadPackage[];
}

/** Top-level shape of public/releases.json. */
export interface ReleaseManifest {
  appName: string;
  /** Newest first. The renderer trusts index 0 as "latest". */
  releases: ChangelogEntry[];
}

/**
 * Compare two dotted version strings.
 * Returns  1 if a > b, -1 if a < b, 0 if equal.
 * Pre-release suffixes ("1.2.0-beta.1") sort BEFORE their release ("1.2.0").
 */
export function compareSemver(a: string, b: string): number {
  const parse = (v: string) => {
    const [core = '', pre = ''] = String(v).trim().replace(/^v/i, '').split('-');
    const nums = core.split('.').map((n) => {
      const parsed = parseInt(n, 10);
      return Number.isFinite(parsed) ? parsed : 0;
    });
    // Pad to 4 segments so 1.2 and 1.2.0.0 compare equal
    while (nums.length < 4) nums.push(0);
    return { nums, pre };
  };

  const A = parse(a);
  const B = parse(b);

  for (let i = 0; i < A.nums.length; i++) {
    if (A.nums[i] !== B.nums[i]) return A.nums[i] > B.nums[i] ? 1 : -1;
  }

  // Same core: a version with a pre-release tag is older than the plain release
  if (A.pre === B.pre) return 0;
  if (A.pre === '') return 1;
  if (B.pre === '') return -1;
  return A.pre > B.pre ? 1 : -1;
}

/** Best-effort platform detection so we can label "This device" and default the download CTA. */
export function detectPlatform(): 'android' | 'windows' | 'linux' | 'unknown' {
  if (typeof navigator === 'undefined') return 'unknown';

  const ua = navigator.userAgent || '';
  const haystack = `${ua} ${(navigator as any).userAgentData?.platform ?? ''}`.toLowerCase();

  if (/android|iphone|ipad|ipod|capacitor/.test(haystack)) return 'android';

  const nav = (navigator as any).userAgentData;
  if (nav?.platform) {
    if (/win/.test(nav.platform)) return 'windows';
    if (/mac/.test(nav.platform)) return 'linux'; // no mac build shipped
  }

  if (/win/.test(haystack)) return 'windows';
  if (/linux|x11|ubuntu|fedora|arch/.test(haystack)) return 'linux';

  return 'unknown';
}

/**
 * Installed version of the running build.
 * Order of truth: a native build stamp injected on window.aureusVersion, else the
 * Vite build-time constant, else "0.0.0". Native shells (Capacitor/Electron) should
 * set window.aureusVersion from package.json at boot.
 */
export function currentAppVersion(): string {
  if (typeof window !== 'undefined') {
    const native = (window as any).aureusVersion;
    if (typeof native === 'string' && native.trim().length > 0) return native.trim();
  }
  const build = (import.meta as any).env?.VITE_APP_VERSION;
  if (typeof build === 'string' && build.length > 0) return build;
  return '0.0.0';
}

/** Convenience: the newest version in a manifest, or null. */
export function latestRelease(manifest: ReleaseManifest | null): ChangelogEntry | null {
  if (!manifest || manifest.releases.length === 0) return null;
  // Defensive: don't blindly trust ordering — pick max by semver.
  return [...manifest.releases].sort((a, b) => compareSemver(b.version, a.version))[0];
}

/** Find the artifact for a given version+platform. */
export function packageFor(
  manifest: ReleaseManifest | null,
  version: string,
  platform: string
): DownloadPackage | null {
  const rel = manifest?.releases?.find((r) => r.version === version);
  return rel?.downloads?.find((d) => d.platform === platform) ?? null;
}

/** Human-readable "3 releases ago" style summary for the update banner. */
export function summarizeGap(installed: string, latest: string): string {
  const cmp = compareSemver(latest, installed);
  if (cmp === 0) return 'You are on the latest version.';
  if (cmp < 0) return `You are running a newer build (v${installed}) than the latest published (v${latest}).`;
  return `Update from v${installed} to v${latest}.`;
}

export interface AppUpdateCheckResult {
  updateAvailable: boolean;
  installedVersion: string;
  latestVersion: string | null;
  release: ChangelogEntry | null;
  manifest: ReleaseManifest | null;
  checkedAt: string;
  error?: string;
}

/** Canonical remote release manifests to ensure mobile (Capacitor) and desktop (Electron) always see real live updates */
const REMOTE_MANIFEST_URL = 'https://raw.githubusercontent.com/yousseflashin/habitflow-release/main/releases.json';
const GITHUB_LATEST_RELEASE_API = 'https://api.github.com/repos/yousseflashin/habitflow-release/releases/latest';

/** Queries the public release manifest and compares against installed version */
export async function checkForAppUpdates(): Promise<AppUpdateCheckResult> {
  const installed = currentAppVersion();
  const checkedAt = new Date().toISOString();

  let manifest: ReleaseManifest | null = null;
  let queryError: string | null = null;

  // 1. Try remote raw GitHub manifest first (ensures native mobile/desktop detect new updates published to repo)
  try {
    const remoteRes = await fetch(`${REMOTE_MANIFEST_URL}?t=${Date.now()}`, {
      cache: 'no-cache',
      headers: { 'Accept': 'application/json' },
    });
    if (remoteRes.ok) {
      manifest = (await remoteRes.json()) as ReleaseManifest;
    }
  } catch (err: any) {
    queryError = err?.message;
  }

  // 2. Fall back to local bundled / web manifest if remote is unreachable
  if (!manifest) {
    try {
      const localRes = await fetch(`/releases.json?t=${Date.now()}`, { cache: 'no-cache' });
      if (localRes.ok) {
        manifest = (await localRes.json()) as ReleaseManifest;
      }
    } catch (err: any) {
      queryError = queryError || err?.message;
    }
  }

  // 3. Optional fallback directly to GitHub Releases API if manifest format failed
  if (!manifest) {
    try {
      const apiRes = await fetch(GITHUB_LATEST_RELEASE_API, {
        headers: { 'Accept': 'application/vnd.github.v3+json' },
      });
      if (apiRes.ok) {
        const ghRelease = await apiRes.json();
        const tagVer = (ghRelease.tag_name || '').replace(/^v/i, '');
        if (tagVer) {
          const apkAsset = ghRelease.assets?.find((a: any) => a.name.endsWith('.apk'));
          const linuxAsset = ghRelease.assets?.find((a: any) => a.name.endsWith('.zip'));
          const downloads: DownloadPackage[] = [];
          if (apkAsset) {
            downloads.push({
              platform: 'android',
              fileName: apkAsset.name,
              downloadUrl: apkAsset.browser_download_url,
              fileSize: `${(apkAsset.size / 1024 / 1024).toFixed(1)} MB`,
            });
          }
          if (linuxAsset) {
            downloads.push({
              platform: 'linux',
              fileName: linuxAsset.name,
              downloadUrl: linuxAsset.browser_download_url,
              fileSize: `${(linuxAsset.size / 1024 / 1024).toFixed(1)} MB`,
            });
          }
          manifest = {
            appName: 'Aureus — Whole-Life Manager',
            releases: [
              {
                version: tagVer,
                date: (ghRelease.published_at || '').slice(0, 10),
                highlight: ghRelease.name || `Release v${tagVer}`,
                notes: ghRelease.body ? ghRelease.body.split('\n').filter((l: string) => l.trim().startsWith('-')).map((l: string) => l.replace(/^-\s*/, '')) : ['Performance and security improvements.'],
                downloads,
              },
            ],
          };
        }
      }
    } catch {}
  }

  if (!manifest || !Array.isArray(manifest.releases) || manifest.releases.length === 0) {
    return {
      updateAvailable: false,
      installedVersion: installed,
      latestVersion: null,
      release: null,
      manifest: null,
      checkedAt,
      error: queryError || 'Unable to reach release repository',
    };
  }

  const latest = latestRelease(manifest);
  if (!latest) {
    return {
      updateAvailable: false,
      installedVersion: installed,
      latestVersion: null,
      release: null,
      manifest,
      checkedAt,
    };
  }

  const updateAvailable = compareSemver(latest.version, installed) > 0;
  return {
    updateAvailable,
    installedVersion: installed,
    latestVersion: latest.version,
    release: latest,
    manifest,
    checkedAt,
  };
}

type UpdateListener = (result: AppUpdateCheckResult) => void;

class UpdateCheckerManager {
  private listeners: UpdateListener[] = [];
  private lastResult: AppUpdateCheckResult | null = null;
  private intervalTimer: any = null;

  public subscribe(listener: UpdateListener): () => void {
    this.listeners.push(listener);
    if (this.lastResult) listener(this.lastResult);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  public async checkNow(): Promise<AppUpdateCheckResult> {
    const result = await checkForAppUpdates();
    this.lastResult = result;
    this.notifyAll(result);
    return result;
  }

  public startPeriodicCheck(intervalMs = 30 * 60 * 1000): void {
    if (typeof window === 'undefined') return;
    if (this.intervalTimer) return;
    void this.checkNow();
    this.intervalTimer = setInterval(() => {
      void this.checkNow();
    }, intervalMs);
  }

  public getLastResult(): AppUpdateCheckResult | null {
    return this.lastResult;
  }

  private notifyAll(result: AppUpdateCheckResult): void {
    for (const listener of this.listeners) {
      try {
        listener(result);
      } catch (e) {
        console.error('Update listener error:', e);
      }
    }
  }
}

export const updateChecker = new UpdateCheckerManager();