#!/usr/bin/env node

/**
 * Aureus Fedora Desktop Native Notification & Alarm Daemon
 *
 * Runs independently in the background on Fedora Linux. It watches a small JSON
 * "inbox" file that the running app writes each time it (re)schedules reminders,
 * and fires native Linux desktop notifications via notify-send at the scheduled
 * times — even when no app window / browser tab is open.
 *
 * Design intent (local-first, per requirements): reminders are scheduled by the
 * LOCAL app on each device. This daemon is a local delivery mechanism only; it
 * never depends on the cloud.
 *
 * Idempotency: a sidecar "fired" file records every reminder id already delivered.
 * The daemon may be (re)started freely — crash recovery and restarts never
 * double-fire a reminder.
 */

import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';

const DATA_DIR = process.env.AUREUS_DATA_DIR || path.join(os.homedir(), '.aureus');
const INBOX_PATH = process.env.AUREUS_NOTIFY_INBOX || path.join(DATA_DIR, 'reminder-inbox.json');
const FIRED_PATH = process.env.AUREUS_FIRED_FILE || path.join(DATA_DIR, 'reminder-fired.json');

// Load persisted fired ids so a daemon restart does not re-deliver.
let fired = new Set(loadFired());

function loadFired() {
  try {
    if (!fs.existsSync(FIRED_PATH)) return [];
    return JSON.parse(fs.readFileSync(FIRED_PATH, 'utf-8'));
  } catch (e) {
    return [];
  }
}

function persistFired() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(FIRED_PATH, JSON.stringify(Array.from(fired)));
  } catch (e) {
    // best-effort; losing the durable set only risks a rare duplicate after crash
  }
}

function sendLinuxNotification(title, body) {
  const safeTitle = (title || 'Aureus Reminder').replace(/"/g, '\\"');
  const safeBody = (body || '').replace(/"/g, '\\"');
  exec(`notify-send "${safeTitle}" "${safeBody}" -a "Aureus" -u normal`, (err) => {
    if (err) {
      console.error('Failed to dispatch desktop notification:', err.message);
    } else {
      console.log(`[NOTIFY] ${safeTitle}: ${safeBody}`);
    }
  });
}

function loadReminders() {
  try {
    if (!fs.existsSync(INBOX_PATH)) return [];
    const raw = fs.readFileSync(INBOX_PATH, 'utf-8');
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : (data.reminders || []);
  } catch (e) {
    return []; // not parseable yet or first run
  }
}

function sweep() {
  const now = Date.now();
  let changed = false;

  for (const item of loadReminders()) {
    if (!item || !item.id) continue;
    const id = String(item.id);
    if (fired.has(id)) continue; // already delivered (durable set)

    let t = NaN;
    if (typeof item.scheduleTime === 'string') t = Date.parse(item.scheduleTime);
    else if (typeof item.scheduleTime === 'number') t = item.scheduleTime;
    if (isNaN(t)) continue;

    // Fire once the scheduled moment has arrived (within a 30s window).
    if (t <= now + 30_000) {
      fired.add(id);
      changed = true;
      sendLinuxNotification(item.title || 'Aureus Reminder', item.body || '');
    }
  }

  if (changed) persistFired();
}

// Check every 15 seconds; first sweep shortly after start.
sweep();
setInterval(sweep, 15000);

console.log('[AUREUS] Fedora Desktop Native Notification Daemon active.');

/* Exported for reuse in tests / IPC bridges. */
export { sendLinuxNotification };