const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  sendNotification: (data) => ipcRenderer.send('notify', data),
  writeDaemonInbox: (items) => ipcRenderer.send('write-daemon-inbox', items),
  triggerSync: () => ipcRenderer.send('trigger-sync'),
  onSyncRequested: (callback) => ipcRenderer.on('sync-requested', () => callback()),
  platform: process.platform,
});
