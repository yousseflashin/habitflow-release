/**
 * Aureus Direct DB Sync API — standalone for Electron embedding.
 * Serves HTTP gateway to MonsterASP SQL Server. No Next.js.
 *
 * Conflict resolution:
 *   Last-Write-Wins (LWW) on `updatedAt` (ISO 8601, lexicographic).
 *   Tie-break: `deviceId` lexicographic. Deletes: soft-delete with `deletedBy`.
 *
 * Auth: POST /api/auth/register, POST /api/auth/login, GET /api/health
 * Sync: POST /api/sync (bidirectional), /api/sync/push, /api/sync/pull
 */
const http = require('http');
const crypto = require('crypto');
const sql = require('mssql');

const sqlConfig = {
  user:       process.env.MONSTERASP_USER     || 'db67950',
  password:   process.env.MONSTERASP_PASSWORD || 'Fn6!-Zc5a9D%',
  database:   process.env.MONSTERASP_DATABASE || 'db67950',
  server:     process.env.MONSTERASP_HOST     || 'db67950.public.databaseasp.net',
  port:       parseInt(process.env.MONSTERASP_PORT || '1433', 10),
  pool:       { max: 10, min: 0, idleTimeoutMillis: 30000 },
  options:    { encrypt: true, trustServerCertificate: true },
  connectionTimeout: 20000,
};

let pool = null;
async function getPool() {
  if (pool) return pool;
  pool = await new sql.ConnectionPool(sqlConfig).connect();
  console.log('[aureus-api] Connected to MonsterASP SQL Server');
  await migrateSchema(pool);
  return pool;
}

// ─── Schema migration: add missing columns on existing tables ──────────────
async function migrateSchema(client) {
  const alters = [
    // Tasks
    `IF COL_LENGTH('Tasks','DeviceId') IS NULL ALTER TABLE Tasks ADD DeviceId VARCHAR(64) NOT NULL DEFAULT 'unknown'`,
    `IF COL_LENGTH('Tasks','DeletedBy') IS NULL ALTER TABLE Tasks ADD DeletedBy VARCHAR(64) NULL`,
    `IF COL_LENGTH('Tasks','Tags') IS NULL ALTER TABLE Tasks ADD Tags NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Tasks','StartDate') IS NULL ALTER TABLE Tasks ADD StartDate VARCHAR(32) NULL`,
    `IF COL_LENGTH('Tasks','ReminderTime') IS NULL ALTER TABLE Tasks ADD ReminderTime VARCHAR(32) NULL`,
    `IF COL_LENGTH('Tasks','Reminders') IS NULL ALTER TABLE Tasks ADD Reminders NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Tasks','Alarms') IS NULL ALTER TABLE Tasks ADD Alarms NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Tasks','Recurrence') IS NULL ALTER TABLE Tasks ADD Recurrence NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Tasks','Subtasks') IS NULL ALTER TABLE Tasks ADD Subtasks NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Tasks','[Order]') IS NULL ALTER TABLE Tasks ADD [Order] INT NOT NULL DEFAULT 0`,
    `IF COL_LENGTH('Tasks','CreatedAt') IS NULL ALTER TABLE Tasks ADD CreatedAt NVARCHAR(32) NOT NULL DEFAULT ''`,
    `IF COL_LENGTH('Tasks','Version') IS NULL ALTER TABLE Tasks ADD Version INT NOT NULL DEFAULT 1`,
    // Habits
    `IF COL_LENGTH('Habits','DeviceId') IS NULL ALTER TABLE Habits ADD DeviceId VARCHAR(64) NOT NULL DEFAULT 'unknown'`,
    `IF COL_LENGTH('Habits','DeletedBy') IS NULL ALTER TABLE Habits ADD DeletedBy VARCHAR(64) NULL`,
    `IF COL_LENGTH('Habits','Description') IS NULL ALTER TABLE Habits ADD Description NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Habits','TargetUnit') IS NULL ALTER TABLE Habits ADD TargetUnit VARCHAR(32) NOT NULL DEFAULT 'times'`,
    `IF COL_LENGTH('Habits','Frequency') IS NULL ALTER TABLE Habits ADD Frequency NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Habits','Reminders') IS NULL ALTER TABLE Habits ADD Reminders NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Habits','StartDate') IS NULL ALTER TABLE Habits ADD StartDate VARCHAR(32) NOT NULL DEFAULT ''`,
    `IF COL_LENGTH('Habits','QuitDetails') IS NULL ALTER TABLE Habits ADD QuitDetails NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Habits','Archived') IS NULL ALTER TABLE Habits ADD Archived BIT NOT NULL DEFAULT 0`,
    `IF COL_LENGTH('Habits','[Order]') IS NULL ALTER TABLE Habits ADD [Order] INT NOT NULL DEFAULT 0`,
    `IF COL_LENGTH('Habits','CreatedAt') IS NULL ALTER TABLE Habits ADD CreatedAt NVARCHAR(32) NOT NULL DEFAULT ''`,
    `IF COL_LENGTH('Habits','Version') IS NULL ALTER TABLE Habits ADD Version INT NOT NULL DEFAULT 1`,
    // HabitLogs
    `IF COL_LENGTH('HabitLogs','DeviceId') IS NULL ALTER TABLE HabitLogs ADD DeviceId VARCHAR(64) NOT NULL DEFAULT 'unknown'`,
    `IF COL_LENGTH('HabitLogs','DeletedBy') IS NULL ALTER TABLE HabitLogs ADD DeletedBy VARCHAR(64) NULL`,
    `IF COL_LENGTH('HabitLogs','Notes') IS NULL ALTER TABLE HabitLogs ADD Notes NVARCHAR(MAX) NULL`,
    // HabitRelapses
    `IF COL_LENGTH('HabitRelapses','DeviceId') IS NULL ALTER TABLE HabitRelapses ADD DeviceId VARCHAR(64) NOT NULL DEFAULT 'unknown'`,
    `IF COL_LENGTH('HabitRelapses','DeletedBy') IS NULL ALTER TABLE HabitRelapses ADD DeletedBy VARCHAR(64) NULL`,
    // Tags
    `IF COL_LENGTH('Tags','DeviceId') IS NULL ALTER TABLE Tags ADD DeviceId VARCHAR(64) NOT NULL DEFAULT 'unknown'`,
    `IF COL_LENGTH('Tags','DeletedBy') IS NULL ALTER TABLE Tags ADD DeletedBy VARCHAR(64) NULL`,
    // Projects
    `IF COL_LENGTH('Projects','DeviceId') IS NULL ALTER TABLE Projects ADD DeviceId VARCHAR(64) NOT NULL DEFAULT 'unknown'`,
    `IF COL_LENGTH('Projects','DeletedBy') IS NULL ALTER TABLE Projects ADD DeletedBy VARCHAR(64) NULL`,
    // Relax legacy NOT NULL metadata columns that the new schema doesn't use
    `IF COL_LENGTH('Tasks','TaskJson') IS NOT NULL ALTER TABLE Tasks ALTER COLUMN TaskJson NVARCHAR(MAX) NULL`,
    `IF COL_LENGTH('Habits','HabitJson') IS NOT NULL ALTER TABLE Habits ALTER COLUMN HabitJson NVARCHAR(MAX) NULL`,
  ];
  for (const stmt of alters) {
    try { await client.request().query(stmt); }
    catch (e) { console.warn('[aureus-api] migrate skip:', e.message); }
  }
  await ensureMoneyTables(client);
  console.log('[aureus-api] Schema migration complete');
}

// Money tables are created here (not just in schema.sql) so a fresh
// deployment gets them on first connect.
async function ensureMoneyTables(client) {
  const tables = [
    `IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'MoneyAccounts')
     CREATE TABLE MoneyAccounts (
       AccountId VARCHAR(64) PRIMARY KEY,
       UserId VARCHAR(64) NOT NULL,
       Name NVARCHAR(256) NOT NULL,
       Type VARCHAR(32) NOT NULL,
       Balance DECIMAL(19, 4) NOT NULL,
       Currency CHAR(3) NOT NULL,
       Color VARCHAR(7) NOT NULL,
       CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
       UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
       Deleted BIT NOT NULL DEFAULT 0
     )`,
    `IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'MoneyAssets')
     CREATE TABLE MoneyAssets (
       AssetId VARCHAR(64) PRIMARY KEY,
       UserId VARCHAR(64) NOT NULL,
       Symbol VARCHAR(16) NOT NULL,
       Name NVARCHAR(256) NOT NULL,
       Type VARCHAR(32) NOT NULL,
       Quantity DECIMAL(19, 8) NOT NULL,
       AvgCost DECIMAL(19, 4) NOT NULL,
       CurrentPrice DECIMAL(19, 4) NOT NULL,
       Currency CHAR(3) NOT NULL,
       CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
       UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
       Deleted BIT NOT NULL DEFAULT 0
     )`,
    `IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'MoneyTransactions')
     CREATE TABLE MoneyTransactions (
       TransactionId VARCHAR(64) PRIMARY KEY,
       UserId VARCHAR(64) NOT NULL,
       AccountId VARCHAR(64) NOT NULL,
       Type VARCHAR(32) NOT NULL,
       Amount DECIMAL(19, 4) NOT NULL,
       Currency CHAR(3) NOT NULL,
       TransactionDate DATE NOT NULL,
       Note NVARCHAR(MAX),
       AssetId VARCHAR(64),
       AssetQuantity DECIMAL(19, 8),
       CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
       UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
       Deleted BIT NOT NULL DEFAULT 0
     )`,
  ];
  for (const stmt of tables) {
    try { await client.request().query(stmt); }
    catch (e) { console.warn('[aureus-api] money table skip:', e.message); }
  }
}

const ENTITY_TABLES = {
  task: {
    table: 'Tasks', idColumn: 'TaskId',
    jsonColumns: ['Tags', 'Reminders', 'Alarms', 'Recurrence', 'Subtasks'],
    boolColumns: ['Completed', 'IsArchived', 'Deleted'],
  },
  habit: {
    table: 'Habits', idColumn: 'HabitId',
    jsonColumns: ['Frequency', 'Reminders', 'QuitDetails'],
    boolColumns: ['Archived', 'Deleted'],
  },
  habit_log: {
    table: 'HabitLogs', idColumn: 'LogId',
    jsonColumns: [], boolColumns: ['Completed', 'Deleted'],
  },
  habit_relapse_log: {
    table: 'HabitRelapses', idColumn: 'RelapseId',
    jsonColumns: [], boolColumns: ['Deleted'],
  },
  project: {
    table: 'Projects', idColumn: 'ProjectId',
    jsonColumns: [], boolColumns: ['IsFavorite', 'Archived', 'Deleted'],
  },
  tag: {
    table: 'Tags', idColumn: 'TagId',
    jsonColumns: [], boolColumns: ['Deleted'],
  },
  setting: {
    table: 'Settings', idColumn: 'SettingKey',
    jsonColumns: [], boolColumns: [],
  },
  reminder: {
    table: 'Reminders', idColumn: 'ReminderId',
    jsonColumns: [], boolColumns: ['Enabled', 'Deleted'],
  },
  money_account: {
    table: 'MoneyAccounts', idColumn: 'AccountId',
    jsonColumns: [], boolColumns: ['Deleted'],
  },
  money_asset: {
    table: 'MoneyAssets', idColumn: 'AssetId',
    jsonColumns: [], boolColumns: ['Deleted'],
  },
  money_transaction: {
    table: 'MoneyTransactions', idColumn: 'TransactionId',
    jsonColumns: [], boolColumns: ['Deleted'],
  },
};

function lwwWins(incoming, existing) {
  if (!existing) return true;
  const incUp  = incoming.updatedAt || incoming.UpdatedAt || '';
  const exUp   = existing.updatedAt || existing.UpdatedAt || '';
  if (incUp > exUp) return true;
  if (incUp < exUp) return false;
  const incDev  = (incoming.deviceId || incoming.DeviceId || '').toLowerCase();
  const exDev   = (existing.deviceId || existing.DeviceId || '').toLowerCase();
  return incDev >= exDev;
}

function jsToSql(entityType, entity) {
  const meta = ENTITY_TABLES[entityType];
  if (!meta) return null;
  const row = {};
  row[meta.idColumn] = entity.id || entity[meta.idColumn];
  for (const [jsKey, val] of Object.entries(entity)) {
    if (jsKey === 'id') continue;
    const sqlKey = jsKey.charAt(0).toUpperCase() + jsKey.slice(1);
    if (meta.jsonColumns.includes(sqlKey)) {
      row[sqlKey] = typeof val === 'string' ? val : JSON.stringify(val ?? null);
    } else if (meta.boolColumns.includes(sqlKey)) {
      row[sqlKey] = val ? 1 : 0;
    } else {
      row[sqlKey] = val;
    }
  }
  if (!row.UserId && entity.userId) row.UserId = entity.userId;
  return row;
}

function sqlToJs(entityType, row) {
  if (!row) return null;
  const meta = ENTITY_TABLES[entityType];
  if (!meta) return null;
  const entity = { id: row[meta.idColumn] };
  for (const [sqlKey, val] of Object.entries(row)) {
    if (sqlKey === meta.idColumn) continue;
    const jsKey = sqlKey.charAt(0).toLowerCase() + sqlKey.slice(1);
    if (meta.jsonColumns.includes(sqlKey)) {
      try { entity[jsKey] = typeof val === 'string' ? JSON.parse(val) : val; } catch { entity[jsKey] = val; }
    } else if (meta.boolColumns.includes(sqlKey)) {
      entity[jsKey] = !!val;
    } else {
      entity[jsKey] = val;
    }
  }
  return entity;
}

async function upsertEntity(client, entityType, entity, userId, deviceId) {
  const meta = ENTITY_TABLES[entityType];
  if (!meta) return { action: 'skipped', reason: 'unknown_entity_type' };
  const row = jsToSql(entityType, entity);
  if (!row) return { action: 'skipped', reason: 'mapping_failed' };
  row.UserId = userId;
  row.DeviceId = deviceId;
  const idVal = row[meta.idColumn];

  const existReq = client.request();
  existReq.input('id', idVal);
  existReq.input('userId', userId);
  const existResult = await existReq.query(`SELECT * FROM [${meta.table}] WHERE [${meta.idColumn}] = @id AND UserId = @userId`);
  const existing = existResult.recordset[0] || null;

  if (existing && !lwwWins(row, existing)) {
    return { action: 'skipped', reason: 'remote_newer', entityId: idVal };
  }

  if (existing) {
    const setClauses = [];
    const updateReq = client.request();
    updateReq.input('id', idVal);
    updateReq.input('userId', userId);
    for (const [col, val] of Object.entries(row)) {
      if (col === meta.idColumn || col === 'UserId') continue;
      setClauses.push(`[${col}] = @${col}`);
      updateReq.input(col, val ?? null);
    }
    if (setClauses.length === 0) return { action: 'skipped', reason: 'no_columns', entityId: idVal };
    await updateReq.query(`UPDATE [${meta.table}] SET ${setClauses.join(', ')} WHERE [${meta.idColumn}] = @id AND UserId = @userId`);
    return { action: 'updated', entityId: idVal };
  } else {
    const cols = Object.keys(row);
    const insertReq = client.request();
    cols.forEach((col, i) => insertReq.input(`c${i}`, row[col] ?? null));
    await insertReq.query(`INSERT INTO [${meta.table}] (${cols.map(c => `[${c}]`).join(', ')}) VALUES (${cols.map((_, i) => `@c${i}`).join(', ')})`);
    return { action: 'created', entityId: idVal };
  }
}

async function pullEntities(client, entityType, userId, since) {
  const meta = ENTITY_TABLES[entityType];
  if (!meta) return [];
  const req = client.request();
  req.input('userId', userId);
  let where = 'UserId = @userId';
  if (since && meta.table !== 'Settings') {
    where += ' AND UpdatedAt > @since';
    req.input('since', since);
  }
  const result = await req.query(`SELECT * FROM [${meta.table}] WHERE ${where}`);
  return result.recordset.map(row => sqlToJs(entityType, row));
}

// ─── Auth (pbkdf2, no extra deps) ──────────────────────────────────────────
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256').toString('hex');
  return `${salt}:${hash}`;
}
// Accepts both PBKDF2 (`salt:hash`, canonical) and legacy HMAC (`salt.hash`).
function verifyPassword(password, stored) {
  const s = String(stored || '');
  if (s.includes(':')) {
    const [salt, hash] = s.split(':');
    if (!salt || !hash) return false;
    const check = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256').toString('hex');
    try { return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(check, 'hex')); }
    catch { return false; }
  }
  const [salt, hash] = s.split('.');
  if (!salt || !hash) return false;
  const calc = crypto.createHmac('sha256', salt).update(password).digest('hex');
  return calc === hash;
}
function makeToken(userId, email) {
  const payload = Buffer.from(JSON.stringify({ userId, email, iat: Date.now() })).toString('base64url');
  const sig = crypto.createHmac('sha256', process.env.JWT_SECRET || 'aureus_super_secure_jwt_secret_2026_nous')
    .update(payload).digest('base64url');
  return `${payload}.${sig}`;
}
function verifyToken(token) {
  try {
    const [payload, sig] = token.split('.');
    const expected = crypto.createHmac('sha256', process.env.JWT_SECRET || 'aureus_super_secure_jwt_secret_2026_nous')
      .update(payload).digest('base64url');
    if (sig !== expected) return null;
    return JSON.parse(Buffer.from(payload, 'base64url').toString());
  } catch { return null; }
}

async function handleRegister(client, body) {
  const { email, password, deviceId, deviceName, deviceType } = body;
  if (!email || !password) return { success: false, error: 'email and password required' };
  const emailNorm = String(email).toLowerCase().trim();
  const check = client.request();
  check.input('email', emailNorm);
  const existing = await check.query('SELECT UserId FROM Users WHERE Email = @email');
  if (existing.recordset.length > 0) return { success: false, error: 'User already exists with this email' };

  const userId = 'usr_' + crypto.randomBytes(8).toString('hex');
  const ins = client.request();
  ins.input('userId', userId);
  ins.input('email', emailNorm);
  ins.input('passwordHash', hashPassword(password));
  await ins.query('INSERT INTO Users (UserId, Email, PasswordHash) VALUES (@userId, @email, @passwordHash)');

  if (deviceId) {
    const dev = client.request();
    dev.input('deviceId', deviceId);
    dev.input('userId', userId);
    dev.input('deviceName', deviceName || 'Unknown');
    dev.input('deviceType', deviceType || 'desktop');
    await dev.query(`
      IF NOT EXISTS (SELECT 1 FROM Devices WHERE DeviceId = @deviceId)
        INSERT INTO Devices (DeviceId, UserId, DeviceName, DeviceType) VALUES (@deviceId, @userId, @deviceName, @deviceType)
    `);
  }
  return { success: true, token: makeToken(userId, emailNorm), user: { userId, email: emailNorm } };
}

async function handleLogin(client, body) {
  const { email, password, deviceId, deviceName, deviceType } = body;
  if (!email || !password) return { success: false, error: 'email and password required' };
  const emailNorm = String(email).toLowerCase().trim();
  const q = client.request();
  q.input('email', emailNorm);
  const rows = await q.query('SELECT UserId, Email, PasswordHash FROM Users WHERE Email = @email');
  if (rows.recordset.length === 0) return { success: false, error: 'Invalid email or password' };
  const user = rows.recordset[0];
  if (!verifyPassword(password, user.PasswordHash)) return { success: false, error: 'Invalid email or password' };

  if (deviceId) {
    const dev = client.request();
    dev.input('deviceId', deviceId);
    dev.input('userId', user.UserId);
    dev.input('deviceName', deviceName || 'Unknown');
    dev.input('deviceType', deviceType || 'desktop');
    await dev.query(`
      IF NOT EXISTS (SELECT 1 FROM Devices WHERE DeviceId = @deviceId)
        INSERT INTO Devices (DeviceId, UserId, DeviceName, DeviceType) VALUES (@deviceId, @userId, @deviceName, @deviceType)
      ELSE
        UPDATE Devices SET LastSyncAt = SYSUTCDATETIME(), DeviceName = @deviceName WHERE DeviceId = @deviceId
    `);
  }
  return { success: true, token: makeToken(user.UserId, user.Email), user: { userId: user.UserId, email: user.Email } };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}
function send(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Device-Id, X-User-Id',
  });
  res.end(JSON.stringify(data));
}

async function handleSync(client, body) {
  const { userId, deviceId, entities, since } = body;
  if (!userId || !deviceId) return { success: false, error: 'userId and deviceId required' };
  const results = { pushed: {}, pulled: {}, serverTime: new Date().toISOString() };
  if (entities && typeof entities === 'object') {
    for (const [entityType, list] of Object.entries(entities)) {
      if (!ENTITY_TABLES[entityType] || !Array.isArray(list)) continue;
      const stats = { created: 0, updated: 0, skipped: 0 };
      for (const entity of list) {
        const r = await upsertEntity(client, entityType, entity, userId, deviceId);
        if (r.action === 'created') stats.created++;
        else if (r.action === 'updated') stats.updated++;
        else stats.skipped++;
      }
      results.pushed[entityType] = stats;
    }
  }
  for (const entityType of Object.keys(ENTITY_TABLES)) {
    const list = await pullEntities(client, entityType, userId, since);
    if (list.length > 0) results.pulled[entityType] = list;
  }
  return { success: true, ...results };
}

async function handler(req, res) {
  if (req.method === 'OPTIONS') { send(res, 200, { ok: true }); return; }
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    const client = await getPool();
    if (url.pathname === '/api/health' && req.method === 'GET') {
      send(res, 200, { service: 'aureus-sync-api', status: 'healthy', database: 'monsterasp_direct', timestamp: new Date().toISOString() });
      return;
    }
    if (url.pathname === '/api/auth/register' && req.method === 'POST') {
      const body = await readBody(req);
      const result = await handleRegister(client, body);
      send(res, result.success ? 200 : 400, result);
      return;
    }
    if (url.pathname === '/api/auth/login' && req.method === 'POST') {
      const body = await readBody(req);
      const result = await handleLogin(client, body);
      send(res, result.success ? 200 : 401, result);
      return;
    }
    if (url.pathname === '/api/sync' && req.method === 'POST') {
      send(res, 200, await handleSync(client, await readBody(req)));
      return;
    }
    if (url.pathname === '/api/sync/push' && req.method === 'POST') {
      send(res, 200, await handleSync(client, await readBody(req)));
      return;
    }
    if (url.pathname === '/api/sync/pull' && req.method === 'POST') {
      send(res, 200, await handleSync(client, await readBody(req)));
      return;
    }
    send(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('[aureus-api] Error:', err.message);
    send(res, 500, { error: err.message });
  }
}

const PORT = parseInt(process.env.AUREUS_API_PORT || '3456', 10);
const server = http.createServer(handler);
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[aureus-api] Aureus Sync API on http://0.0.0.0:${PORT}`);
});
process.on('SIGTERM', async () => {
  server.close();
  if (pool) await pool.close();
  process.exit(0);
});
