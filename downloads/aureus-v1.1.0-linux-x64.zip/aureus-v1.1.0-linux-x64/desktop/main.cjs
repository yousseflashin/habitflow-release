/**
 * Aureus Desktop — Electron main that opens the app window.
 * All sync happens automatically through the deployed Next.js backend
 * (VITE_API_URL at build time); no embedded API server is needed.
 */
const { app, BrowserWindow, ipcMain, Notification, Tray, Menu } = require('electron');
const path = require('path');
const os = require('os');
const { exec } = require('child_process');
const { writeFile, mkdir } = require('fs/promises');

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    backgroundColor: '#090d16',
    titleBarStyle: 'hiddenInset',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  // Load built frontend bundle (file://), same as before — no server needed.
  const url = process.env.VITE_DEV_SERVER_URL || `file://${path.join(__dirname, '../dist/index.html')}`;
  mainWindow.loadURL(url);

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Native Linux Notification Handler (both Electron Notification and notify-send)
ipcMain.on('notify', (event, { title, body, url }) => {
  if (Notification.isSupported()) {
    const notif = new Notification({
      title: title || 'Aureus',
      body: body || '',
      urgency: 'normal',
    });
    if (url) {
      notif.on('click', () => {
        const { shell } = require('electron');
        shell.openExternal(url);
      });
    }
    notif.show();
  } else {
    exec(`notify-send "${(title || '').replace(/"/g, '\\"')}" "${(body || '').replace(/"/g, '\\"')}" -a "Aureus"`);
  }
});

// Persist scheduled reminders to daemon inbox (background notifier)
ipcMain.on('write-daemon-inbox', async (event, items) => {
  try {
    const dir = path.join(os.homedir(), '.aureus');
    const inboxPath = path.join(dir, 'reminder-inbox.json');
    await mkdir(dir, { recursive: true });
    await writeFile(inboxPath, JSON.stringify({ reminders: items || [] }, null, 2));
  } catch (e) {
    console.error('Failed to write daemon inbox:', e.message);
  }
});

app.whenReady().then(() => {
  // Sync happens automatically via the deployed Next.js backend
  // (VITE_API_URL at build time) — no embedded API server needed.
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});