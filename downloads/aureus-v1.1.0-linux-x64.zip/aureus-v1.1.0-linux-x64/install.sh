#!/usr/bin/env bash
# Aureus Desktop v1.1.0 — Linux installer
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
echo "Installing Aureus Desktop v1.1.0…"
[ -d node_modules ] || npm install --no-audit --no-fund
# Ensure a fresh production build
npm run build
# Optional: start the native reminder daemon
if [ -f desktop/scheduler-daemon.js ]; then
  nohup node desktop/scheduler-daemon.js >/dev/null 2>&1 &
fi
echo ""
echo "✓ Installed. Launch with:  ./habitflow.sh"
echo "  (or add a desktop entry — see README)"
