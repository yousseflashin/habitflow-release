// Direct MonsterASP DB Sync Client — no Next.js, no event sourcing.
// Both desktop (Electron) and Android (Capacitor) call this same HTTP API
// served by the embedded Express server in Electron, or by the shared API.

import { Task, Habit, HabitLog, HabitRelapseLog, Project, Tag, UserSettings } from '../types';

export type SyncEntityType =
  | 'task' | 'habit' | 'habit_log' | 'habit_relapse_log'
  | 'project' | 'tag' | 'setting' | 'reminder'
  | 'money_account' | 'money_asset' | 'money_transaction';

export interface EntityBundle {
  tasks?: Task[];
  habits?: Habit[];
  habit_logs?: HabitLog[];
  habit_relapse_logs?: HabitRelapseLog[];
  projects?: Project[];
  tags?: Tag[];
  settings?: UserSettings[];
  reminders?: any[];
}

export interface SyncResult {
  success: boolean;
  pushed: Record<string, { created: number; updated: number; skipped: number }>;
  pulled: Record<string, any[]>;
  serverTime: string;
  error?: string;
}

const BUILD_API_URL = (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, '') || '';
const DEFAULT_API_URL = BUILD_API_URL ||
  (typeof window !== 'undefined' && /^https?:$/.test(window.location.protocol) ? window.location.origin : 'http://localhost:3456');

export class DirectDbSyncClient {
  private apiUrl: string;
  private token: string | null = null;
  private userId: string | null = null;
  private deviceId: string;
  private deviceName: string;
  private deviceType: 'desktop' | 'mobile';

  constructor(deviceId: string, deviceName: string, deviceType: 'desktop' | 'mobile') {
    this.deviceId = deviceId;
    this.deviceName = deviceName;
    this.deviceType = deviceType;
    this.apiUrl = DEFAULT_API_URL;
    this.loadAuth();
  }

  private loadAuth(): void {
    if (typeof localStorage !== 'undefined') {
      this.userId = localStorage.getItem('aureus_user_id');
      this.token = localStorage.getItem('aureus_auth_token');
    }
  }

  public setCredentials(userId: string): void {
    this.userId = userId;
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('aureus_user_id', userId);
    }
  }

  public setApiUrl(url: string): void {
    const clean = url.replace(/\/$/, '');
    this.apiUrl = clean;
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('aureus_db_api_url_override', clean);
    }
  }

  public getApiUrl(): string {
    const override = typeof localStorage !== 'undefined'
      ? localStorage.getItem('aureus_db_api_url_override')
      : null;

    if (override && override !== DEFAULT_API_URL) {
      return override.replace(/\/$/, '');
    }
    if (this.apiUrl !== DEFAULT_API_URL && this.apiUrl) {
      return this.apiUrl.replace(/\/$/, '');
    }
    return DEFAULT_API_URL;
  }

  public isAuthenticated(): boolean {
    return !!this.userId;
  }

  public getUserId(): string | null {
    return this.userId;
  }

  /**
   * Bidirectional sync: push local entities + pull remote changes in ONE request.
   * Each entity's `updatedAt` drives Last-Write-Wins conflict resolution server-side.
   * `deleted` entities are soft-deleted; `deletedAt`/`deletedBy` prevent
   * "resurrection" collisions.
   */
  public async syncAll(entities: EntityBundle = {}): Promise<SyncResult> {
    if (!this.userId) {
      return { success: false, pushed: {}, pulled: {}, serverTime: '', error: 'Not authenticated' };
    }

    try {
      // Normalize client collection names to the singular API entity names.
      const normalized: Record<string, any[]> = {};
      for (const [key, list] of Object.entries(entities)) {
        const serverKey = {
          tasks: 'task',
          habits: 'habit',
          habit_logs: 'habit_log',
          habit_relapse_logs: 'habit_relapse_log',
          projects: 'project',
          tags: 'tag',
          settings: 'setting',
          reminders: 'reminder',
          money_accounts: 'money_account',
          money_assets: 'money_asset',
          money_transactions: 'money_transaction',
        }[key] || key;
        normalized[serverKey] = list || [];
      }

      const res = await fetch(`${this.getApiUrl()}/api/sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-Id': this.userId,
          'X-Device-Id': this.deviceId,
        },
        body: JSON.stringify({
          userId: this.userId,
          deviceId: this.deviceId,
          entities: normalized,
        }),
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`Sync API returned ${res.status}: ${errText.substring(0, 200)}`);
      }

      return (await res.json()) as SyncResult;
    } catch (err: any) {
      console.warn('[direct-db-sync] Sync failed:', err.message);
      return { success: false, pushed: {}, pulled: {}, serverTime: '', error: err.message };
    }
  }

  /**
   * Push-only: send local changes up.
   */
  public async pushAll(entities: EntityBundle = {}): Promise<SyncResult> {
    if (!this.userId) {
      return { success: false, pushed: {}, pulled: {}, serverTime: '', error: 'Not authenticated' };
    }

    try {
      const res = await fetch(`${this.getApiUrl()}/api/sync/push`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-Id': this.userId,
          'X-Device-Id': this.deviceId,
        },
        body: JSON.stringify({
          userId: this.userId,
          deviceId: this.deviceId,
          entities,
        }),
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`Push API returned ${res.status}: ${errText.substring(0, 200)}`);
      }

      return (await res.json()) as SyncResult;
    } catch (err: any) {
      console.warn('[direct-db-sync] Push failed:', err.message);
      return { success: false, pushed: {}, pulled: {}, serverTime: '', error: err.message };
    }
  }

  /**
   * Pull-only: fetch remote changes since last sync.
   */
  public async pullAll(since?: string): Promise<SyncResult> {
    if (!this.userId) {
      return { success: false, pushed: {}, pulled: {}, serverTime: '', error: 'Not authenticated' };
    }

    try {
      const res = await fetch(`${this.getApiUrl()}/api/sync/pull`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-Id': this.userId,
          'X-Device-Id': this.deviceId,
        },
        body: JSON.stringify({
          userId: this.userId,
          deviceId: this.deviceId,
          since,
        }),
      });

      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`Pull API returned ${res.status}: ${errText.substring(0, 200)}`);
      }

      return (await res.json()) as SyncResult;
    } catch (err: any) {
      console.warn('[direct-db-sync] Pull failed:', err.message);
      return { success: false, pushed: {}, pulled: {}, serverTime: '', error: err.message };
    }
  }

  public async checkHealth(): Promise<boolean> {
    try {
      const res = await fetch(`${this.getApiUrl()}/api/health`);
      if (!res.ok) return false;
      const data = await res.json();
      return data.status === 'healthy';
    } catch {
      return false;
    }
  }

  public async register(
    email: string,
    password: string,
    deviceName?: string
  ): Promise<{ success: boolean; token?: string; user?: any; error?: string }> {
    try {
      const res = await fetch(`${this.getApiUrl()}/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          deviceId: this.deviceId,
          deviceName: deviceName || this.deviceName,
          deviceType: this.deviceType,
        }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error || 'Registration failed' };
      this.userId = data.user?.userId || null;
      this.token = data.token || null;
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('aureus_user_id', this.userId || '');
        localStorage.setItem('aureus_auth_token', this.token || '');
      }
      return { success: true, token: data.token, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async login(
    email: string,
    password: string,
    deviceName?: string
  ): Promise<{ success: boolean; token?: string; user?: any; error?: string }> {
    try {
      const res = await fetch(`${this.getApiUrl()}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          deviceId: this.deviceId,
          deviceName: deviceName || this.deviceName,
          deviceType: this.deviceType,
        }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error || 'Login failed' };
      this.userId = data.user?.userId || null;
      this.token = data.token || null;
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('aureus_user_id', this.userId || '');
        localStorage.setItem('aureus_auth_token', this.token || '');
      }
      return { success: true, token: data.token, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }
}

export const directDbSyncClient = new DirectDbSyncClient('', '', 'desktop');