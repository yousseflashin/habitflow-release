// CRDT Deterministic State Materializer and LWW Conflict Resolver

import { Task, Habit, HabitLog, HabitRelapseLog, Project, Tag, Meeting } from '../types';
import { SyncOperation, ConflictRecord } from './types';
import { HybridLogicalClock } from './hlc';
import { localDb } from '../db/indexedDb';

export interface EntityMetadata {
  timestamp: string;
  hlcCounter: number;
  deviceId: string;
  operationId: string;
}

export class CrdtStore {
  public tasks: Map<string, Task> = new Map();
  public habits: Map<string, Habit> = new Map();
  public habitLogs: Map<string, HabitLog> = new Map(); // Key: `${habitId}_${date}`
  public habitRelapses: Map<string, HabitRelapseLog> = new Map(); // Key: `${habitId}_relapse_${timestamp}`
  public projects: Map<string, Project> = new Map();
  public tags: Map<string, Tag> = new Map();
  public meetings: Map<string, Meeting> = new Map();

  // Tracks the winning operation metadata per entity ID for deterministic LWW resolution
  private entityMetadata: Map<string, EntityMetadata> = new Map();
  public conflictAuditLog: ConflictRecord[] = [];

  public async init(): Promise<void> {
    const [tasks, habits, habitLogs, habitRelapses, projects, tags, meetings, conflicts] = await Promise.all([
      localDb.getAll<Task>('tasks'),
      localDb.getAll<Habit>('habits'),
      localDb.getAll<HabitLog>('habit_logs'),
      localDb.getAll<HabitRelapseLog>('habit_relapses'),
      localDb.getAll<Project>('projects'),
      localDb.getAll<Tag>('tags'),
      localDb.getAll<Meeting>('meetings'),
      localDb.getAll<ConflictRecord>('meta'),
    ]);

    for (const t of tasks) this.tasks.set(t.id, t);
    for (const h of habits) this.habits.set(h.id, h);
    for (const hl of habitLogs) this.habitLogs.set(hl.id, hl);
    for (const hr of habitRelapses) this.habitRelapses.set(hr.id, hr);
    for (const p of projects) this.projects.set(p.id, p);
    for (const tg of tags) this.tags.set(tg.id, tg);
    for (const m of meetings) this.meetings.set(m.id, m);

    // Initialize metadata tracker from stored updatedAts
    for (const t of tasks) {
      this.entityMetadata.set(t.id, {
        timestamp: t.updatedAt,
        hlcCounter: 0,
        deviceId: 'init',
        operationId: 'init_' + t.id,
      });
    }
    for (const h of habits) {
      this.entityMetadata.set(h.id, {
        timestamp: h.updatedAt,
        hlcCounter: 0,
        deviceId: 'init',
        operationId: 'init_' + h.id,
      });
    }
    for (const hl of habitLogs) {
      this.entityMetadata.set(hl.id, {
        timestamp: hl.updatedAt,
        hlcCounter: 0,
        deviceId: 'init',
        operationId: 'init_' + hl.id,
      });
    }
    for (const hr of habitRelapses) {
      this.entityMetadata.set(hr.id, {
        timestamp: hr.updatedAt,
        hlcCounter: 0,
        deviceId: 'init',
        operationId: 'init_' + hr.id,
      });
    }
    for (const p of projects) {
      this.entityMetadata.set(p.id, {
        timestamp: p.updatedAt,
        hlcCounter: 0,
        deviceId: 'init',
        operationId: 'init_' + p.id,
      });
    }
    for (const tg of tags) {
      this.entityMetadata.set(tg.id, {
        timestamp: tg.createdAt,
        hlcCounter: 0,
        deviceId: 'init',
        operationId: 'init_' + tg.id,
      });
    }
    for (const m of meetings) {
      this.entityMetadata.set(m.id, {
        timestamp: m.updatedAt || m.createdAt,
        hlcCounter: 0,
        deviceId: 'init',
        operationId: 'init_' + m.id,
      });
    }
  }

  /**
   * Applies an operation to the in-memory state and persists to IndexedDB if it wins.
   * Returns true if the operation caused a state change.
   */
  public async applyOperation(op: SyncOperation, persist: boolean = true): Promise<boolean> {
    const existingMeta = this.entityMetadata.get(op.entityId);

    if (existingMeta) {
      const cmp = HybridLogicalClock.compare(
        op.timestamp,
        op.hlcCounter,
        op.deviceId,
        existingMeta.timestamp,
        existingMeta.hlcCounter,
        existingMeta.deviceId
      );

      if (cmp < 0) {
        // Incoming operation is older than current state; reject state update (preserve winner)
        this.recordConflict({
          id: 'conf_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
          entityType: op.entityType,
          entityId: op.entityId,
          winningOpId: existingMeta.operationId,
          losingOpId: op.operationId,
          winningDeviceId: existingMeta.deviceId,
          losingDeviceId: op.deviceId,
          resolvedAt: new Date().toISOString(),
          reason: `Stale remote operation ignored (LWW: ${existingMeta.timestamp} > ${op.timestamp})`,
          appliedPayload: op.payload,
        });
        return false;
      }

      if (cmp === 0 && op.operationId !== existingMeta.operationId) {
        // Perfect tie; deterministic deviceId tie-breaker already handled by compare
        return false;
      }
    }

    // This operation is the new winner
    this.entityMetadata.set(op.entityId, {
      timestamp: op.timestamp,
      hlcCounter: op.hlcCounter,
      deviceId: op.deviceId,
      operationId: op.operationId,
    });

    let modified = false;

    switch (op.entityType) {
      case 'task': {
        const existing = this.tasks.get(op.entityId);
        if (op.operationType === 'delete' || op.payload.deleted === true) {
          if (existing) {
            existing.deleted = true;
            existing.updatedAt = op.timestamp;
            if (persist) await localDb.put('tasks', existing);
            modified = true;
          }
        } else {
          const updated: Task = {
            id: op.entityId,
            title: op.payload.title ?? existing?.title ?? '',
            description: op.payload.description ?? existing?.description ?? '',
            priority: op.payload.priority ?? existing?.priority ?? 'p4',
            projectId: op.payload.projectId ?? existing?.projectId ?? 'inbox',
            tags: op.payload.tags ?? existing?.tags ?? [],
            startDate: op.payload.startDate !== undefined ? op.payload.startDate : existing?.startDate ?? null,
            dueDate: op.payload.dueDate !== undefined ? op.payload.dueDate : existing?.dueDate ?? null,
            reminderTime: op.payload.reminderTime !== undefined ? op.payload.reminderTime : existing?.reminderTime ?? null,
            reminders: op.payload.reminders ?? existing?.reminders ?? [],
            alarms: op.payload.alarms ?? existing?.alarms ?? [],
            recurrence: op.payload.recurrence ?? existing?.recurrence ?? { type: 'none' },
            subtasks: op.payload.subtasks ?? existing?.subtasks ?? [],
            completed: op.payload.completed !== undefined ? op.payload.completed : existing?.completed ?? false,
            completedAt: op.payload.completedAt !== undefined ? op.payload.completedAt : existing?.completedAt ?? null,
            isArchived: op.payload.isArchived !== undefined ? op.payload.isArchived : existing?.isArchived ?? false,
            order: op.payload.order ?? existing?.order ?? 0,
            createdAt: op.payload.createdAt ?? existing?.createdAt ?? op.timestamp,
            updatedAt: op.timestamp,
            deleted: false,
            version: (existing?.version || 0) + 1,
          };
          this.tasks.set(op.entityId, updated);
          if (persist) await localDb.put('tasks', updated);
          modified = true;
        }
        break;
      }

      case 'habit': {
        const existing = this.habits.get(op.entityId);
        if (op.operationType === 'delete' || op.payload.deleted === true) {
          if (existing) {
            existing.deleted = true;
            existing.updatedAt = op.timestamp;
            if (persist) await localDb.put('habits', existing);
            modified = true;
          }
        } else {
          const updated: Habit = {
            id: op.entityId,
            name: op.payload.name ?? existing?.name ?? '',
            description: op.payload.description ?? existing?.description ?? '',
            category: op.payload.category ?? existing?.category ?? 'gain',
            icon: op.payload.icon ?? existing?.icon ?? (op.payload.category === 'quit' ? 'shield' : 'flame'),
            color: op.payload.color ?? existing?.color ?? (op.payload.category === 'quit' ? '#EF4444' : '#10B981'),
            frequency: op.payload.frequency ?? existing?.frequency ?? { type: 'daily' },
            targetCount: op.payload.targetCount ?? existing?.targetCount ?? 1,
            targetUnit: op.payload.targetUnit ?? existing?.targetUnit ?? 'times',
            reminderTime: op.payload.reminderTime !== undefined ? op.payload.reminderTime : existing?.reminderTime ?? null,
            reminders: op.payload.reminders ?? existing?.reminders ?? [],
            startDate: op.payload.startDate ?? existing?.startDate ?? op.timestamp.substring(0, 10),
            quitDetails: op.payload.quitDetails ?? existing?.quitDetails,
            archived: op.payload.archived !== undefined ? op.payload.archived : existing?.archived ?? false,
            order: op.payload.order ?? existing?.order ?? 0,
            createdAt: op.payload.createdAt ?? existing?.createdAt ?? op.timestamp,
            updatedAt: op.timestamp,
            deleted: false,
            version: (existing?.version || 0) + 1,
          };
          this.habits.set(op.entityId, updated);
          if (persist) await localDb.put('habits', updated);
          modified = true;
        }
        break;
      }

      case 'habit_log': {
        // entityId is `${habitId}_${date}`
        const existing = this.habitLogs.get(op.entityId);
        if (op.operationType === 'delete' || op.payload.deleted === true) {
          if (existing) {
            existing.deleted = true;
            existing.updatedAt = op.timestamp;
            if (persist) await localDb.put('habit_logs', existing);
            modified = true;
          }
        } else {
          const target = op.payload.target ?? existing?.target ?? 1;
          const count = op.payload.count !== undefined ? op.payload.count : existing?.count ?? 1;
          const completed = op.payload.completed !== undefined ? op.payload.completed : count >= target;

          const updated: HabitLog = {
            id: op.entityId,
            habitId: op.payload.habitId ?? existing?.habitId ?? op.entityId.split('_')[0],
            date: op.payload.date ?? existing?.date ?? op.entityId.split('_')[1],
            count: count,
            target: target,
            completed: completed,
            notes: op.payload.notes ?? existing?.notes,
            updatedAt: op.timestamp,
            deleted: false,
          };
          this.habitLogs.set(op.entityId, updated);
          if (persist) await localDb.put('habit_logs', updated);
          modified = true;
        }
        break;
      }

      case 'habit_relapse_log': {
        // entityId is `${habitId}_relapse_${timestamp}`
        const existing = this.habitRelapses.get(op.entityId);
        if (op.operationType === 'delete' || op.payload.deleted === true) {
          if (existing) {
            existing.deleted = true;
            existing.updatedAt = op.timestamp;
            if (persist) await localDb.put('habit_relapses', existing);
            modified = true;
          }
        } else {
          const updated: HabitRelapseLog = {
            id: op.entityId,
            habitId: op.payload.habitId ?? existing?.habitId ?? '',
            date: op.payload.date ?? existing?.date ?? op.timestamp.substring(0, 10),
            timestamp: op.payload.timestamp ?? existing?.timestamp ?? op.timestamp,
            notes: op.payload.notes ?? existing?.notes,
            trigger: op.payload.trigger ?? existing?.trigger,
            updatedAt: op.timestamp,
            deleted: false,
          };
          this.habitRelapses.set(op.entityId, updated);
          if (persist) await localDb.put('habit_relapses', updated);
          modified = true;
        }
        break;
      }

      case 'project': {
        const existing = this.projects.get(op.entityId);
        if (op.operationType === 'delete' || op.payload.deleted === true) {
          if (existing) {
            existing.deleted = true;
            existing.updatedAt = op.timestamp;
            if (persist) await localDb.put('projects', existing);
            modified = true;
          }
        } else {
          const updated: Project = {
            id: op.entityId,
            name: op.payload.name ?? existing?.name ?? '',
            color: op.payload.color ?? existing?.color ?? '#3B82F6',
            icon: op.payload.icon ?? existing?.icon ?? 'folder',
            isFavorite: op.payload.isFavorite !== undefined ? op.payload.isFavorite : existing?.isFavorite ?? false,
            archived: op.payload.archived !== undefined ? op.payload.archived : existing?.archived ?? false,
            order: op.payload.order ?? existing?.order ?? 0,
            createdAt: op.payload.createdAt ?? existing?.createdAt ?? op.timestamp,
            updatedAt: op.timestamp,
            deleted: false,
          };
          this.projects.set(op.entityId, updated);
          if (persist) await localDb.put('projects', updated);
          modified = true;
        }
        break;
      }

      case 'tag': {
        const existing = this.tags.get(op.entityId);
        if (op.operationType === 'delete' || op.payload.deleted === true) {
          if (existing) {
            existing.deleted = true;
            if (persist) await localDb.put('tags', existing);
            modified = true;
          }
        } else {
          const updated: Tag = {
            id: op.entityId,
            name: op.payload.name ?? existing?.name ?? '',
            color: op.payload.color ?? existing?.color ?? '#10B981',
            createdAt: op.payload.createdAt ?? existing?.createdAt ?? op.timestamp,
            deleted: false,
          };
          this.tags.set(op.entityId, updated);
          if (persist) await localDb.put('tags', updated);
          modified = true;
        }
        break;
      }

      case 'meeting': {
        const existing = this.meetings.get(op.entityId);
        if (op.operationType === 'delete' || op.payload.deleted === true) {
          if (existing) {
            existing.deleted = true;
            existing.updatedAt = op.timestamp;
            if (persist) await localDb.put('meetings', existing);
            modified = true;
          }
        } else {
          const updated: Meeting = {
            id: op.entityId,
            title: op.payload.title ?? existing?.title ?? 'Untitled Meeting',
            description: op.payload.description ?? existing?.description ?? '',
            date: op.payload.date ?? existing?.date ?? op.timestamp.substring(0, 10),
            startTime: op.payload.startTime ?? existing?.startTime ?? '09:00',
            endTime: op.payload.endTime ?? existing?.endTime ?? '10:00',
            allDay: op.payload.allDay !== undefined ? op.payload.allDay : existing?.allDay ?? false,
            location: op.payload.location ?? existing?.location ?? '',
            color: op.payload.color ?? existing?.color ?? '#3B82F6',
            reminders: op.payload.reminders ?? existing?.reminders ?? [{ id: 'rem_0', minutesBefore: 10, enabled: true }],
            attendees: op.payload.attendees ?? existing?.attendees ?? [],
            createdAt: op.payload.createdAt ?? existing?.createdAt ?? op.timestamp,
            updatedAt: op.timestamp,
            deleted: false,
            version: (existing?.version || 0) + 1,
          };
          this.meetings.set(op.entityId, updated);
          if (persist) await localDb.put('meetings', updated);
          modified = true;
        }
        break;
      }
    }

    return modified;
  }

  private recordConflict(conflict: ConflictRecord) {
    this.conflictAuditLog.unshift(conflict);
    if (this.conflictAuditLog.length > 100) {
      this.conflictAuditLog.pop();
    }
  }

  /**
   * Replays an array of operations in canonical total order to rebuild state deterministically.
   */
  public async rebuildFromLog(operations: SyncOperation[]): Promise<void> {
    this.tasks.clear();
    this.habits.clear();
    this.habitLogs.clear();
    this.habitRelapses.clear();
    this.projects.clear();
    this.tags.clear();
    this.meetings.clear();
    this.entityMetadata.clear();

    // Sort operations by deterministic total ordering
    const sorted = [...operations].sort((a, b) => {
      const cmp = HybridLogicalClock.compare(
        a.timestamp,
        a.hlcCounter,
        a.deviceId,
        b.timestamp,
        b.hlcCounter,
        b.deviceId
      );
      return cmp;
    });

    for (const op of sorted) {
      await this.applyOperation(op, false);
    }

    // Persist rebuilt tables
    await Promise.all([
      localDb.putBatch('tasks', Array.from(this.tasks.values())),
      localDb.putBatch('habits', Array.from(this.habits.values())),
      localDb.putBatch('habit_logs', Array.from(this.habitLogs.values())),
      localDb.putBatch('habit_relapses', Array.from(this.habitRelapses.values())),
      localDb.putBatch('projects', Array.from(this.projects.values())),
      localDb.putBatch('tags', Array.from(this.tags.values())),
      localDb.putBatch('meetings', Array.from(this.meetings.values())),
    ]);
  }
}
