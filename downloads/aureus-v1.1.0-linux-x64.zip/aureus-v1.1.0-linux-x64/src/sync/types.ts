// Synchronization, CRDT, and Transport Schema Specifications

export type EntityType = 'task' | 'habit' | 'habit_log' | 'habit_relapse_log' | 'project' | 'tag' | 'setting' | 'reminder' | 'meeting';

export type OperationType = 'create' | 'update' | 'delete' | 'patch';

export interface SyncOperation {
  operationId: string;       // Unique UUID v4
  userId?: string;           // Authenticated user ID (for cloud multi-user isolation)
  deviceId: string;          // Source device UUID/name
  entityType: EntityType;
  entityId: string;          // Target entity unique ID
  operationType: OperationType;
  payload: Record<string, any>; // Partial or complete attributes
  timestamp: string;         // ISO 8601 UTC timestamp from HLC
  hlcCounter: number;        // Monotonic sub-millisecond counter
  revision: number;          // Lamport sequential revision index on source device
  logicalVersion?: number;   // Server-assigned monotonic sequence
  signature?: string;        // Optional hash for payload integrity verification
}

export type VectorClock = Record<string, number>; // { [deviceId: string]: highestAppliedRevision }

export interface DeviceMetadata {
  deviceId: string;
  userId?: string;
  deviceName: string;
  deviceType: 'desktop' | 'mobile';
  lastSeen: string;
  highestRevision: number;
}

export interface SyncBundle {
  formatVersion: number;
  bundleId: string;
  userId?: string;
  sourceDeviceId: string;
  sourceDeviceName: string;
  exportedAt: string;
  vectorClock: VectorClock;
  operations: SyncOperation[];
  entityCounts: {
    tasks: number;
    habits: number;
    habitLogs: number;
    habitRelapses?: number;
    projects: number;
    tags: number;
  };
}

export interface ConflictRecord {
  id: string;
  entityType: EntityType;
  entityId: string;
  winningOpId: string;
  losingOpId: string;
  winningDeviceId: string;
  losingDeviceId: string;
  resolvedAt: string;
  reason: string;
  appliedPayload: Record<string, any>;
}

export type SyncStateStatus = 'synced' | 'syncing' | 'offline' | 'conflict' | 'error';

export interface SyncStatusInfo {
  state: SyncStateStatus;
  lastSyncTime: string | null;
  lastCloudSyncTime?: string | null;
  pendingOperationsCount: number;
  totalLocalOperations: number;
  connectedPeers: number;
  cloudSyncEnabled: boolean;
  cloudStatus: 'connected' | 'offline' | 'unauthenticated' | 'error';
  lastErrorMessage?: string;
  /** REQ 19 debug surface */
  totalSyncedOperations?: number;     // ops successfully pushed/acked to cloud
  failedOperations?: number;          // ops that failed to push
  syncErrorCount?: number;            // cumulative sync error events
  lastFailedPushTime?: string | null; // ISO timestamp of last failed push
}

export interface CloudPushRequest {
  deviceId: string;
  operations: SyncOperation[];
  vectorClock: VectorClock;
}

export interface CloudPushResponse {
  success: boolean;
  appliedCount: number;
  serverTimestamp: string;
  serverVectorClock: VectorClock;
}

export interface CloudPullRequest {
  deviceId: string;
  clientVectorClock: VectorClock;
}

export interface CloudPullResponse {
  success: boolean;
  operations: SyncOperation[];
  serverVectorClock: VectorClock;
  hasMore: boolean;
}
