// Hybrid Logical Clock (HLC) for Causality and Deterministic Total Ordering

export interface HLCTimestamp {
  millis: number;    // UTC milliseconds
  counter: number;   // Logical counter for identical milliseconds
  nodeId: string;    // Device ID tie-breaker
}

export class HybridLogicalClock {
  private lastMillis: number = 0;
  private counter: number = 0;
  private readonly nodeId: string;

  constructor(nodeId: string, initialMillis: number = Date.now()) {
    this.nodeId = nodeId;
    this.lastMillis = initialMillis;
    this.counter = 0;
  }

  /**
   * Generates a new monotonically increasing timestamp for a local event.
   */
  public now(): HLCTimestamp {
    const physicalNow = Date.now();

    if (physicalNow > this.lastMillis) {
      this.lastMillis = physicalNow;
      this.counter = 0;
    } else {
      // Clock hasn't ticked or drifted backwards; increment logical counter
      this.counter += 1;
    }

    return {
      millis: this.lastMillis,
      counter: this.counter,
      nodeId: this.nodeId,
    };
  }

  /**
   * Updates local clock upon receiving a remote timestamp (causal progression).
   */
  public update(remote: HLCTimestamp): HLCTimestamp {
    const physicalNow = Date.now();

    const maxMillis = Math.max(physicalNow, this.lastMillis, remote.millis);

    if (maxMillis === this.lastMillis && maxMillis === remote.millis) {
      this.counter = Math.max(this.counter, remote.counter) + 1;
    } else if (maxMillis === this.lastMillis) {
      this.counter += 1;
    } else if (maxMillis === remote.millis) {
      this.counter = remote.counter + 1;
    } else {
      this.counter = 0;
    }

    this.lastMillis = maxMillis;

    return {
      millis: this.lastMillis,
      counter: this.counter,
      nodeId: this.nodeId,
    };
  }

  public getNodeId(): string {
    return this.nodeId;
  }

  /**
   * Converts HLCTimestamp to standard ISO string and counter.
   */
  public static toISO(ts: HLCTimestamp): string {
    return new Date(ts.millis).toISOString();
  }

  /**
   * Deterministic comparison: Returns > 0 if A is strictly newer than B,
   * < 0 if B is strictly newer than A, or 0 if identical.
   */
  public static compare(
    aMillis: number | string,
    aCounter: number,
    aNodeId: string,
    bMillis: number | string,
    bCounter: number,
    bNodeId: string
  ): number {
    const aTime = typeof aMillis === 'string' ? new Date(aMillis).getTime() : aMillis;
    const bTime = typeof bMillis === 'string' ? new Date(bMillis).getTime() : bMillis;

    if (aTime !== bTime) {
      return aTime - bTime;
    }
    if (aCounter !== bCounter) {
      return aCounter - bCounter;
    }
    if (aNodeId < bNodeId) return -1;
    if (aNodeId > bNodeId) return 1;
    return 0;
  }
}
