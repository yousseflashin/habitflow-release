// Append-Only Operation Journal & Delta Extractor

import { SyncOperation, VectorClock } from './types';
import { localDb } from '../db/indexedDb';

export class OperationLog {
  private localDeviceId: string;
  private localRevision: number = 0;
  private vectorClock: VectorClock = {};
  private inMemoryOps: Map<string, SyncOperation> = new Map();

  constructor(localDeviceId: string) {
    this.localDeviceId = localDeviceId;
  }

  public async init(): Promise<void> {
    const ops = await localDb.getAll<SyncOperation>('operations');
    for (const op of ops) {
      this.inMemoryOps.set(op.operationId, op);
      const currentHighest = this.vectorClock[op.deviceId] || 0;
      if (op.revision > currentHighest) {
        this.vectorClock[op.deviceId] = op.revision;
      }
    }
    this.localRevision = this.vectorClock[this.localDeviceId] || 0;
  }

  public getLocalDeviceId(): string {
    return this.localDeviceId;
  }

  public getNextRevision(): number {
    this.localRevision += 1;
    this.vectorClock[this.localDeviceId] = this.localRevision;
    return this.localRevision;
  }

  public getVectorClock(): VectorClock {
    return { ...this.vectorClock };
  }

  public hasOperation(operationId: string): boolean {
    return this.inMemoryOps.has(operationId);
  }

  public getOperation(operationId: string): SyncOperation | undefined {
    return this.inMemoryOps.get(operationId);
  }

  public getAllOperations(): SyncOperation[] {
    return Array.from(this.inMemoryOps.values()).sort((a, b) => {
      const timeDiff = new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
      if (timeDiff !== 0) return timeDiff;
      if (a.hlcCounter !== b.hlcCounter) return a.hlcCounter - b.hlcCounter;
      return a.deviceId.localeCompare(b.deviceId);
    });
  }

  public async appendLocalOperation(op: SyncOperation): Promise<void> {
    this.inMemoryOps.set(op.operationId, op);
    this.vectorClock[op.deviceId] = Math.max(this.vectorClock[op.deviceId] || 0, op.revision);
    await localDb.put('operations', op);
  }

  public async appendRemoteOperations(ops: SyncOperation[]): Promise<SyncOperation[]> {
    const newlyApplied: SyncOperation[] = [];
    const opsToPersist: SyncOperation[] = [];

    for (const op of ops) {
      if (this.inMemoryOps.has(op.operationId)) {
        continue; // Idempotent: ignore duplicate
      }
      this.inMemoryOps.set(op.operationId, op);
      this.vectorClock[op.deviceId] = Math.max(this.vectorClock[op.deviceId] || 0, op.revision);
      opsToPersist.push(op);
      newlyApplied.push(op);
    }

    if (opsToPersist.length > 0) {
      await localDb.putBatch('operations', opsToPersist);
    }

    return newlyApplied;
  }

  /**
   * Delta calculation: Returns all operations newer than the remote peer's vector clock.
   */
  public getDeltaSince(peerVectorClock: VectorClock): SyncOperation[] {
    const delta: SyncOperation[] = [];
    for (const op of this.inMemoryOps.values()) {
      const peerRevision = peerVectorClock[op.deviceId] || 0;
      if (op.revision > peerRevision) {
        delta.push(op);
      }
    }
    return delta.sort((a, b) => {
      const timeDiff = new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
      if (timeDiff !== 0) return timeDiff;
      return a.hlcCounter - b.hlcCounter;
    });
  }

  public getTotalOperationsCount(): number {
    return this.inMemoryOps.size;
  }

  /**
   * Removes an operation locally (used to scrub legacy seed/demo data from the journal).
   */
  public async removeOperation(operationId: string): Promise<void> {
    this.inMemoryOps.delete(operationId);
    await localDb.delete('operations', operationId);
  }
}
