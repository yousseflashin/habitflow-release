// Local persistence and automatic direct MonsterASP database communication.

import { HybridLogicalClock, HLCTimestamp } from './hlc';
import { OperationLog } from './operationLog';
import { CrdtStore } from './crdtStore';
import { SyncOperation, VectorClock, SyncStatusInfo, EntityType, OperationType } from './types';
import { DirectDbSyncClient } from './directDbSyncClient';
import { localDb } from '../db/indexedDb';

export class SyncManager {
  private static readonly CLOUD_POLL_INTERVAL_MS = 5 * 60 * 1000;
  public hlc: HybridLogicalClock;
  public operationLog: OperationLog;
  public crdtStore: CrdtStore;
  public dbClient: DirectDbSyncClient;

  public deviceId: string;
  public deviceName: string;
  public deviceType: 'desktop' | 'mobile';

  private status: SyncStatusInfo;
  private changeListeners: Set<() => void> = new Set();
  private statusListeners: Set<(status: SyncStatusInfo) => void> = new Set();
  private cloudSyncTimer: any = null;

  constructor() {
    this.deviceId = this.getOrGenerateDeviceId();
    this.deviceName = this.getOrGenerateDeviceName();
    this.deviceType = this.detectDeviceType();

    this.hlc = new HybridLogicalClock(this.deviceId);
    this.operationLog = new OperationLog(this.deviceId);
    this.crdtStore = new CrdtStore();
    this.dbClient = new DirectDbSyncClient(this.deviceId, this.deviceName, this.deviceType);

    this.status = {
      state: 'synced',
      lastSyncTime: null,
      lastCloudSyncTime: null,
      pendingOperationsCount: 0,
      totalLocalOperations: 0,
      connectedPeers: 0,
      cloudSyncEnabled: true,
      cloudStatus: this.dbClient.isAuthenticated() ? 'connected' : 'unauthenticated',
    };
  }

  public async init(): Promise<void> {
    await localDb.init();
    await this.operationLog.init();
    await this.crdtStore.init();

    // One-time purge of legacy demo/seed data (references pre-existing seeded IDs)
    await this.purgeSeedData();

    this.updateStatus({
      totalLocalOperations: this.operationLog.getTotalOperationsCount(),
      cloudStatus: this.dbClient.isAuthenticated() ? 'connected' : 'unauthenticated',
    });

    // Start the background database polling loop.
    this.startCloudSyncLoop();

    if (this.dbClient.isAuthenticated()) {
      await this.triggerDbSync(false);
    }

    if (typeof window !== 'undefined') {
      window.addEventListener('pagehide', this.handlePageHide);
      document.addEventListener('visibilitychange', this.handleVisibilityChange);
    }
  }

  private getOrGenerateDeviceId(): string {
    const key = 'aureus_device_id';
    let id = typeof localStorage !== 'undefined' ? localStorage.getItem(key) : null;
    if (!id) {
      const isLinux = typeof navigator !== 'undefined' && /Linux/i.test(navigator.userAgent);
      const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
      const prefix = isAndroid ? 'android' : isLinux ? 'fedora' : 'node';
      id = `${prefix}_${Math.random().toString(36).substring(2, 8)}`;
      if (typeof localStorage !== 'undefined') {
        try {
          localStorage.setItem(key, id);
        } catch (e) {}
      }
    }
    return id;
  }

  private getOrGenerateDeviceName(): string {
    const key = 'aureus_device_name';
    let name = typeof localStorage !== 'undefined' ? localStorage.getItem(key) : null;
    if (!name) {
      const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
      name = isAndroid ? 'Android Mobile' : 'Fedora Workstation';
      if (typeof localStorage !== 'undefined') {
        try {
          localStorage.setItem(key, name);
        } catch (e) {}
      }
    }
    return name;
  }

  public setDeviceName(name: string): void {
    this.deviceName = name;
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem('aureus_device_name', name);
      } catch (e) {}
    }
  }

  private detectDeviceType(): 'desktop' | 'mobile' {
    if (typeof navigator === 'undefined') return 'desktop';
    return /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) ? 'mobile' : 'desktop';
  }

  /**
   * Applies an intentional local user mutation, writes to journal, and syncs.
   */
  public async recordMutation(
    entityType: EntityType,
    entityId: string,
    operationType: OperationType,
    payload: Record<string, any>
  ): Promise<SyncOperation> {
    const ts: HLCTimestamp = this.hlc.now();
    const revision = this.operationLog.getNextRevision();

    const op: SyncOperation = {
      operationId: 'op_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8),
      userId: this.dbClient.getUserId() || undefined,
      deviceId: this.deviceId,
      entityType,
      entityId,
      operationType,
      payload,
      timestamp: HybridLogicalClock.toISO(ts),
      hlcCounter: ts.counter,
      revision,
    };

    // 1. Commit locally first (100% offline resilience)
    await this.operationLog.appendLocalOperation(op);
    await this.crdtStore.applyOperation(op, true);

    // Push local changes and pull remote changes in the background.
    if (this.dbClient.isAuthenticated()) {
      this.triggerDbSync().catch(() => {});
    }

    this.updateStatus({
      totalLocalOperations: this.operationLog.getTotalOperationsCount(),
      lastSyncTime: new Date().toISOString(),
    });

    this.notifyChange();
    return op;
  }

  private startCloudSyncLoop(): void {
    if (this.cloudSyncTimer) clearInterval(this.cloudSyncTimer);

    // Background sync is intentionally slow; Reload remains the explicit fast path.
    this.cloudSyncTimer = setInterval(() => {
      if (this.dbClient.isAuthenticated() && typeof navigator !== 'undefined' && navigator.onLine) {
        this.triggerDbSync().catch(() => {});
      }
    }, SyncManager.CLOUD_POLL_INTERVAL_MS);
  }

  private handlePageHide = (): void => {
    if (this.dbClient.isAuthenticated()) {
      this.triggerDbSync().catch(() => {});
    }
  };

  private handleVisibilityChange = (): void => {
    if (document.visibilityState === 'visible' && this.dbClient.isAuthenticated()) {
      this.triggerDbSync(false).catch(() => {});
    }
  };

  /**
   * Performs a 2-way sync with the central MonsterASP database via the embedded
   * HTTP API (no Next.js). Pushes local CRDT state, pulls remote state, merges
   * via LWW conflict resolution on `updatedAt`.
   */
  public async triggerDbSync(pushLocal: boolean = true): Promise<{ pushed: number; pulled: number }> {
    if (!this.dbClient.isAuthenticated()) return { pushed: 0, pulled: 0 };

    this.updateStatus({ state: 'syncing', cloudStatus: 'connected' });

    try {
      // Build entity bundle from local CRDT state
      const entities: Record<string, any[]> = pushLocal ? {
        tasks: Array.from(this.crdtStore.tasks.values()),
        habits: Array.from(this.crdtStore.habits.values()),
        habit_logs: Array.from(this.crdtStore.habitLogs.values()),
        habit_relapse_logs: Array.from(this.crdtStore.habitRelapses.values()),
        projects: Array.from(this.crdtStore.projects.values()),
        tags: Array.from(this.crdtStore.tags.values()),
      } : {};

      const result = await this.dbClient.syncAll(entities);

      if (!result.success) {
        this.updateStatus({ state: 'error', cloudStatus: 'error', lastErrorMessage: result.error || 'Unknown sync error' });
        return { pushed: 0, pulled: 0 };
      }

      let appliedCount = 0;

      // Merge remote entities into local CRDT store
      for (const [type, list] of Object.entries(result.pulled || {})) {
        if (!Array.isArray(list) || list.length === 0) continue;
        for (const remote of list) {
          // Convert DB row back to local entity shape and apply with LWW
          const applied = await this.applyRemoteEntity(type, remote);
          if (applied) appliedCount++;
        }
      }

      this.updateStatus({
        state: 'synced',
        cloudStatus: 'connected',
        lastCloudSyncTime: new Date().toISOString(),
        totalSyncedOperations: (this.status.totalSyncedOperations || 0) + appliedCount,
      });

      if (appliedCount > 0) this.notifyChange();

      return { pushed: appliedCount, pulled: appliedCount };
    } catch (err: any) {
      console.warn('Direct DB sync error:', err.message);
      this.updateStatus({
        state: 'error',
        cloudStatus: 'error',
        lastErrorMessage: err.message,
        syncErrorCount: (this.status.syncErrorCount || 0) + 1,
      });
      return { pushed: 0, pulled: 0 };
    }
  }

  /**
   * Applies a remote entity fetched from MonsterASP into the local CRDT store,
   * respecting Last-Write-Wins conflict resolution.
   */
  private async applyRemoteEntity(type: string, remote: any): Promise<boolean> {
    const id = String(remote.id || '');
    const legacySeed = type === 'project' && ['proj_personal', 'proj_work', 'proj_health'].includes(id)
      || type === 'tag' && ['tag_urgent', 'tag_quick', 'tag_deep', 'tag_reading'].includes(id)
      || type === 'habit' && ['habit_water', 'habit_read', 'habit_exercise', 'habit_code', 'habit_meditate'].includes(id)
      || type === 'task' && ['task_review_sync', 'task_groceries', 'task_setup_backup', 'task_completed_sample'].includes(id)
      || type === 'habit_log' && ['habit_water', 'habit_read', 'habit_exercise', 'habit_code', 'habit_meditate'].some(seed => id.startsWith(`${seed}_`));
    if (legacySeed) return false;

    const localForKey = (entityType: string, id: string) => {
      switch (entityType) {
        case 'task': return this.crdtStore.tasks.get(id);
        case 'habit': return this.crdtStore.habits.get(id);
        case 'habit_log': return this.crdtStore.habitLogs.get(id);
        case 'habit_relapse_log': return this.crdtStore.habitRelapses.get(id);
        case 'project': return this.crdtStore.projects.get(id);
        case 'tag': return this.crdtStore.tags.get(id);
        default: return undefined;
      }
    };

    const existing = localForKey(type, id) as any;

    // LWW: remote wins if it's newer, or tiebreak by deviceId
    const remoteTs = (remote as any).updatedAt || '';
    const localTs = existing?.updatedAt || existing?.createdAt || '';
    if (remoteTs < localTs) return false;
    if (remoteTs === localTs && existing && ((remote as any).deviceId || '') < (existing.deviceId || '')) return false;

    // Apply to CRDT store (in-memory + IndexedDB persist)
    const op = {
      operationId: `remote_${type}_${id}_${Date.now()}`,
      deviceId: remote.deviceId || 'remote',
      entityType: type,
      entityId: id,
      operationType: remote.deleted ? 'delete' : 'update',
      payload: remote,
      timestamp: remote.updatedAt || remote.createdAt || new Date().toISOString(),
      hlcCounter: 0,
      revision: 1,
    };

    await this.crdtStore.applyOperation(op as any, true);
    return true;
  }

  /**
   * One-time purge of legacy demo/seed data from local + remote stores.
   * The classic demo bundle used fixed IDs (proj_personal, habit_water, task_review_sync, ...)
   * plus date-keyed habit logs (habit_water_2026-09-01). These should never appear
   * for a real user. Soft-deletes them so they don't resurrect.
   */
  private async purgeSeedData(): Promise<void> {
    const flagKey = 'aureus_seed_purged_v2';
    try {
      if (typeof localStorage !== 'undefined' && localStorage.getItem(flagKey)) {
        return;
      }
    } catch {}

    const seedProjectIds = ['proj_personal', 'proj_work', 'proj_health'];
    const seedTagIds = ['tag_urgent', 'tag_quick', 'tag_deep', 'tag_reading'];
    const seedHabitIds = ['habit_water', 'habit_read', 'habit_exercise', 'habit_code', 'habit_meditate'];
    const seedTaskIds = ['task_review_sync', 'task_groceries', 'task_setup_backup', 'task_completed_sample'];
    const seedLogPrefixes = seedHabitIds.map(h => h + '_');

    const isSeedId = (entityType: string, id: string): boolean => {
      if (entityType === 'project') return seedProjectIds.includes(id);
      if (entityType === 'tag') return seedTagIds.includes(id);
      if (entityType === 'habit') return seedHabitIds.includes(id);
      if (entityType === 'task') return seedTaskIds.includes(id);
      if (entityType === 'habit_log') return seedLogPrefixes.some(prefix => id.startsWith(prefix));
      return false;
    };

    // Remove legacy examples from persistent storage and the already-loaded CRDT maps.
    const purgeStore = async (store: string, match: (e: any) => boolean) => {
      const all = await localDb.getAll<any>(store);
      for (const entity of all) {
        if (match(entity)) {
          await localDb.delete(store, entity.id || entity.operationId || entity.key);
        }
      }
    };

    await purgeStore('projects', (e) => seedProjectIds.includes(e.id));
    await purgeStore('tags', (e) => seedTagIds.includes(e.id));
    await purgeStore('habits', (e) => seedHabitIds.includes(e.id));
    await purgeStore('tasks', (e) => seedTaskIds.includes(e.id));
    await purgeStore('habit_logs', (e) => seedLogPrefixes.some(p => String(e.id || '').startsWith(p)));

    for (const id of seedProjectIds) this.crdtStore.projects.delete(id);
    for (const id of seedTagIds) this.crdtStore.tags.delete(id);
    for (const id of seedHabitIds) this.crdtStore.habits.delete(id);
    for (const id of seedTaskIds) this.crdtStore.tasks.delete(id);
    for (const id of Array.from(this.crdtStore.habitLogs.keys())) {
      if (isSeedId('habit_log', id)) this.crdtStore.habitLogs.delete(id);
    }

    // Remove the corresponding operations so they don't re-sync / resurrect
    const ops = await this.operationLog.getAllOperations();
    const seedIds = new Set([...seedProjectIds, ...seedTagIds, ...seedHabitIds, ...seedTaskIds]);
    const seedOp = ops.filter(op => seedIds.has(op.entityId) || seedLogPrefixes.some(p => String(op.entityId || '').startsWith(p)));
    for (const op of seedOp) {
      await this.operationLog.removeOperation(op.operationId);
    }

    try {
      if (typeof localStorage !== 'undefined') localStorage.setItem(flagKey, '1');
    } catch {}
  }

  public subscribe(listener: () => void): () => void {
    this.changeListeners.add(listener);
    return () => this.changeListeners.delete(listener);
  }

  public subscribeStatus(listener: (status: SyncStatusInfo) => void): () => void {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }

  private notifyChange(): void {
    for (const listener of this.changeListeners) {
      try { listener(); } catch (e) { console.error(e); }
    }
  }

  private updateStatus(partial: Partial<SyncStatusInfo>): void {
    this.status = { ...this.status, ...partial };
    for (const listener of this.statusListeners) {
      try { listener(this.status); } catch (e) { console.error(e); }
    }
  }

  public getStatus(): SyncStatusInfo {
    return { ...this.status };
  }
}

export const syncManager = new SyncManager();
