// Unified Application Context & Reactive State Provider

import React, { createContext, useContext, useEffect, useState, useMemo, useCallback } from 'react';
import {
  Task,
  Habit,
  HabitLog,
  HabitRelapseLog,
  Project,
  Tag,
  Meeting,
  AppView,
  Priority,
  HabitCategory,
  HabitTimeframeView,
  Reminder,
  TaskAlarm,
  LifestyleArea,
  LifestyleMetric,
  UserXP,
  TimelineEvent,
} from '../types';
import { syncManager, SyncManager } from '../sync/syncManager';
import { SyncStatusInfo } from '../sync/types';
import { TaskService } from '../domain/taskService';
import { HabitService } from '../domain/habitService';
import { notificationManager } from '../native/notificationService';
import { soundFx } from '../utils/soundEffects';
import { fireConfettiBurst, fireMilestoneConfetti } from '../utils/confetti';
import { format } from 'date-fns';

interface AppContextType {
  // Data
  tasks: Task[];
  habits: Habit[];
  meetings: Meeting[];
  habitLogs: Map<string, HabitLog>;
  habitRelapses: Map<string, HabitRelapseLog>;
  projects: Project[];
  tags: Tag[];
  syncManager: SyncManager;
  syncStatus: SyncStatusInfo;
  reloadData: () => Promise<void>;

  // View & UI Navigation
  activeView: AppView;
  setActiveView: (view: AppView) => void;
  habitTimeframeView: HabitTimeframeView;
  setHabitTimeframeView: (view: HabitTimeframeView) => void;
  selectedProjectId: string | null;
  setSelectedProjectId: (id: string | null) => void;
  selectedPriority: Priority | null;
  setSelectedPriority: (p: Priority | null) => void;
  selectedTagId: string | null;
  setSelectedTagId: (id: string | null) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
  toggleTheme: () => void;

  // Modals & Drawers
  isAccountModalOpen: boolean;
  setIsAccountModalOpen: (open: boolean) => void;
  isCommandPaletteOpen: boolean;
  setIsCommandPaletteOpen: (open: boolean) => void;
  isTaskModalOpen: boolean;
  setIsTaskModalOpen: (open: boolean) => void;
  isHabitModalOpen: boolean;
  setIsHabitModalOpen: (open: boolean) => void;
  isProjectModalOpen: boolean;
  setIsProjectModalOpen: (open: boolean) => void;
  isMeetingModalOpen: boolean;
  setIsMeetingModalOpen: (open: boolean) => void;

  editingTask: Task | null;
  setEditingTask: (t: Task | null) => void;
  editingHabit: Habit | null;
  setEditingHabit: (h: Habit | null) => void;
  viewingHabitDetail: Habit | null;
  setViewingHabitDetail: (h: Habit | null) => void;
  editingProject: Project | null;
  setEditingProject: (p: Project | null) => void;
  editingMeeting: Meeting | null;
  setEditingMeeting: (m: Meeting | null) => void;

  addBodyMeasurement: (data: Partial<{
    id: string;
    userId: string;
    date: string;
    value: number;
    unit: string;
    label: string;
    muscleGroupId?: string;
    createdAt: string;
    updatedAt: string;
  }>) => Promise<{
    id: string;
    userId: string;
    date: string;
    value: number;
    unit: string;
    label: string;
    muscleGroupId?: string;
    createdAt: string;
    updatedAt: string;
  }>;

  // Lifestyle OS Extension
  lifestyleAreas: LifestyleArea[];
  userMetrics: Map<string, LifestyleMetric>;
  metricScores: Map<string, number>;
  userXP: UserXP;
  timelineEvents: TimelineEvent[];

  // Mutations
  createTask: (data: Partial<Task>) => Promise<Task>;
  updateTask: (taskId: string, data: Partial<Task>) => Promise<void>;
  toggleTaskComplete: (taskId: string) => Promise<void>;
  deleteTask: (taskId: string) => Promise<void>;

  createHabit: (data: Partial<Habit>) => Promise<Habit>;
  updateHabit: (habitId: string, data: Partial<Habit>) => Promise<void>;
  deleteHabit: (habitId: string) => Promise<void>;
  toggleHabitDay: (habitId: string, dateStr: string) => Promise<void>;
  incrementHabitDay: (habitId: string, dateStr: string) => Promise<void>;
  decrementHabitDay: (habitId: string, dateStr: string) => Promise<void>;
  setHabitDayCount: (habitId: string, dateStr: string, count: number, notes?: string) => Promise<void>;
  recordHabitRelapse: (habitId: string, trigger?: string, notes?: string) => Promise<void>;
  clearHabitRelapse: (habitId: string, date: string) => Promise<void>;

  createProject: (data: Partial<Project>) => Promise<Project>;
  updateProject: (projectId: string, data: Partial<Project>) => Promise<void>;
  deleteProject: (projectId: string) => Promise<void>;

  createTag: (name: string, color?: string) => Promise<Tag>;
  deleteTag: (tagId: string) => Promise<void>;

  createMeeting: (data: Partial<Meeting>) => Promise<Meeting>;
  updateMeeting: (meetingId: string, data: Partial<Meeting>) => Promise<void>;
  deleteMeeting: (meetingId: string) => Promise<void>;

  // Cloud Authentication & Sync
  isAuthenticated: boolean;
  sessionUnlocked: boolean;
  unlockSession: () => void;
  lockSession: () => void;
  loginUser: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  registerUser: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logoutUser: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isReady, setIsReady] = useState(false);
  const [version, setVersion] = useState(0);
  const [syncStatus, setSyncStatus] = useState<SyncStatusInfo>(syncManager.getStatus());

  // View & Navigation states
  const [sessionUnlocked, setSessionUnlocked] = useState<boolean>(() => {
    if (typeof sessionStorage !== 'undefined') {
      return sessionStorage.getItem('aureus_session_unlocked') === 'true';
    }
    return false;
  });

  const unlockSession = useCallback(() => {
    setSessionUnlocked(true);
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem('aureus_session_unlocked', 'true');
    }
  }, []);

  const lockSession = useCallback(() => {
    setSessionUnlocked(false);
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.removeItem('aureus_session_unlocked');
    }
  }, []);

  const isAuthenticated = syncManager.dbClient.isAuthenticated();

  const [activeView, setActiveView] = useState<AppView>('lifestyle');
  const [habitTimeframeView, setHabitTimeframeView] = useState<HabitTimeframeView>('yearly');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedPriority, setSelectedPriority] = useState<Priority | null>(null);
  const [selectedTagId, setSelectedTagId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const [theme, setThemeState] = useState<'dark' | 'light'>(() => {
    if (typeof localStorage !== 'undefined') {
      const saved = localStorage.getItem('aureus_theme');
      if (saved === 'light' || saved === 'dark') return saved;
    }
    return 'dark';
  });

  // Modal states
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isHabitModalOpen, setIsHabitModalOpen] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isMeetingModalOpen, setIsMeetingModalOpen] = useState(false);

  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  const [viewingHabitDetail, setViewingHabitDetail] = useState<Habit | null>(null);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [editingMeeting, setEditingMeeting] = useState<Meeting | null>(null);

  // Lifestyle Extension State
  const [lifestyleAreas, setLifestyleAreas] = useState<LifestyleArea[]>([
    {
      id: 'area_physical',
      name: 'Physical',
      description: 'Body, fitness, and physical health metrics',
      type: 'physical',
      icon: 'dumbbell',
      color: '#EF4444',
      order: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deleted: false,
    },
    {
      id: 'area_mind',
      name: 'Mind',
      description: 'Focus, mental energy, stress, and cognitive performance',
      type: 'mind',
      icon: 'brain',
      color: '#3B82F6',
      order: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deleted: false,
    },
    {
      id: 'area_spiritual',
      name: 'Spiritual',
      description: 'Practices, reflection, and inner peace',
      type: 'spiritual',
      icon: 'zap',
      color: '#8B5CF6',
      order: 2,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deleted: false,
    },
    {
      id: 'area_personal-dev',
      name: 'Personal Development',
      description: 'Learning, skills, and growth-oriented activities',
      type: 'personal-development',
      icon: 'book-open',
      color: '#10B981',
      order: 3,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deleted: false,
    },
    {
      id: 'area_productivity',
      name: 'Productivity',
      description: 'Task completion, goal progress, and efficiency metrics',
      type: 'productivity',
      icon: 'check-square',
      color: '#F59E0B',
      order: 4,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deleted: false,
    },
  ]);
  const [userMetrics, setUserMetrics] = useState<Map<string, LifestyleMetric>>(new Map());
  const [metricScores, setMetricScores] = useState<Map<string, number>>(new Map());
  const [userXP, setUserXP] = useState<UserXP>({
    userId: 'user_local',
    level: 1,
    currentXP: 0,
    xpPerLevel: 100,
    lastUpdated: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  });
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([]);
  const [bodyMeasurements, setBodyMeasurements] = useState<Array<{
    id: string;
    userId: string;
    date: string;
    value: number;
    unit: string;
    label: string;
    muscleGroupId?: string;
    createdAt: string;
    updatedAt: string;
  }>>([]);
  const [workoutSessions, setWorkoutSessions] = useState<Array<{ 
    id: string;
    userId: string;
    date: string;
    startTime: string | null;
    endTime: string | null;
    durationMinutes?: number;
    note?: string;
    createdAt: string;
  }>>([]);
  const [workoutExercises, setWorkoutExercises] = useState<Array<{
    id: string;
    workoutId: string;
    exerciseId: string;
    note?: string;
    createdAt: string;
  }>>([]);
  const [workoutSets, setWorkoutSets] = useState<Array<{
    id: string;
    exerciseId: string;
    workoutExerciseId: string;
    reps: number;
    weight: number;
    unit: string;
    completed: boolean;
  }>>([]);
  const [mindEntries, setMindEntries] = useState<Array<{
    id: string;
    userId: string;
    date: string;
    timestamp: string;
    mood?: number;
    focus?: number;
    mentalEnergy?: number;
    stress?: number;
    sleepHours?: number;
    screenTimeMinutes?: number;
    notes?: string;
    createdAt: string;
  }>>([]);
  const [spiritualEntries, setSpiritualEntries] = useState<Array<{
    id: string;
    userId: string;
    date: string;
    timestamp: string;
    practiceType: string;
    durationMinutes?: number;
    notes?: string;
    createdAt: string;
  }>>([]);
  const [achievements, setAchievements] = useState<Array<{
    id: string;
    title: string;
    description: string;
    icon: string;
    category: 'consistency' | 'quantity' | 'milestone' | 'streak' | 'quit' | 'workout' | 'mind' | 'spiritual' | 'custom';
    threshold: number;
    unlockType: 'count' | 'streak' | 'threshold';
    createdAt: string;
  }>>([]);

  // Initialize DB, Sync, and Notifications
  useEffect(() => {
    let mounted = true;
    syncManager.init().then(() => {
      if (mounted) {
        setIsReady(true);
        setVersion(v => v + 1);
        notificationManager.requestPermissions().catch(() => {});
      }
    });

    const unsubscribeChange = syncManager.subscribe(() => {
      if (mounted) setVersion(v => v + 1);
    });

    const unsubscribeStatus = syncManager.subscribeStatus((newStatus) => {
      if (mounted) setSyncStatus(newStatus);
    });

    return () => {
      mounted = false;
      unsubscribeChange();
      unsubscribeStatus();
    };
  }, []);

  // Sync theme
  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;
    root.classList.toggle('dark', theme === 'dark');
    root.dataset.theme = theme;
    body.classList.toggle('dark', theme === 'dark');
    body.classList.toggle('light', theme === 'light');
    try {
      localStorage.setItem('aureus_theme', theme);
    } catch {
      // Theme still applies for this session if storage is unavailable.
    }
  }, [theme]);

  const setTheme = useCallback((t: 'dark' | 'light') => {
    setThemeState(t);
  }, []);

  const toggleTheme = useCallback(() => {
    setThemeState(prev => (prev === 'dark' ? 'light' : 'dark'));
  }, []);

  // Keyboard Shortcuts (Fedora Desktop productivity)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.tagName === 'SELECT' ||
        target.isContentEditable
      ) {
        if (e.key === 'Escape') target.blur();
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      } else if (e.key === 'n' || e.key === 'N') {
        e.preventDefault();
        setEditingTask(null);
        setIsTaskModalOpen(true);
      } else if (e.key === 'h' || e.key === 'H') {
        e.preventDefault();
        setEditingHabit(null);
        setIsHabitModalOpen(true);
      } else if (e.key === '1') {
        setActiveView('lifestyle');
      } else if (e.key === '2') {
        setActiveView('today');
      } else if (e.key === '3') {
        setActiveView('tasks');
      } else if (e.key === '4') {
        setActiveView('habits');
      } else if (e.key === '5') {
        setActiveView('calendar');
      } else if (e.key === '6') {
        setActiveView('projects');
      } else if (e.key === '7') {
        setActiveView('money');
      } else if (e.key === '8') {
        setActiveView('stats');
      } else if (e.key === '9') {
        setActiveView('downloads');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Materialized State Queries
  const tasks = useMemo(() => {
    const list = Array.from(syncManager.crdtStore.tasks.values()).filter(t => !t.deleted);
    return TaskService.sortTasks(list);
  }, [version, isReady]);

  const habits = useMemo(() => {
    return Array.from(syncManager.crdtStore.habits.values())
      .filter(h => !h.deleted)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }, [version, isReady]);

  const habitLogs = useMemo(() => {
    return syncManager.crdtStore.habitLogs;
  }, [version, isReady]);

  const habitRelapses = useMemo(() => {
    return syncManager.crdtStore.habitRelapses;
  }, [version, isReady]);

  const projects = useMemo(() => {
    return Array.from(syncManager.crdtStore.projects.values())
      .filter(p => !p.deleted)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }, [version, isReady]);

  const tags = useMemo(() => {
    return Array.from(syncManager.crdtStore.tags.values())
      .filter(t => !t.deleted)
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [version, isReady]);

  const meetings = useMemo(() => {
    return Array.from(syncManager.crdtStore.meetings.values())
      .filter(m => !m.deleted)
      .sort((a, b) => (a.date + (a.startTime || '00:00')).localeCompare(b.date + (b.startTime || '00:00')));
  }, [version, isReady]);

  // Re-schedule OS native reminders whenever tasks, habits, or meetings change
  useEffect(() => {
    if (isReady) {
      notificationManager.syncAllScheduledReminders(tasks, habits, meetings).catch(() => {});
    }
  }, [tasks, habits, meetings, isReady]);

  // --- TASK MUTATIONS ---
  const createTask = useCallback(async (data: Partial<Task>): Promise<Task> => {
    const id = 'task_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const now = new Date().toISOString();
    const task: Task = {
      id,
      title: data.title || 'Untitled Task',
      description: data.description || '',
      priority: data.priority || 'p4',
      projectId: data.projectId || selectedProjectId || 'inbox',
      tags: data.tags || (selectedTagId ? [selectedTagId] : []),
      startDate: data.startDate || null,
      dueDate: data.dueDate !== undefined ? data.dueDate : format(new Date(), 'yyyy-MM-dd'),
      reminderTime: data.reminderTime || null,
      reminders: data.reminders || [],
      alarms: data.alarms || [],
      recurrence: data.recurrence || { type: 'none' },
      subtasks: data.subtasks || [],
      completed: false,
      completedAt: null,
      isArchived: false,
      order: tasks.length + 1,
      createdAt: now,
      updatedAt: now,
      deleted: false,
      version: 1,
    };

    await syncManager.recordMutation('task', id, 'create', task);
    soundFx.playPop();
    return task;
  }, [selectedProjectId, selectedTagId, tasks.length]);

  const updateTask = useCallback(async (taskId: string, data: Partial<Task>): Promise<void> => {
    await syncManager.recordMutation('task', taskId, 'update', data);
  }, []);

  const toggleTaskComplete = useCallback(async (taskId: string): Promise<void> => {
    const task = syncManager.crdtStore.tasks.get(taskId);
    if (!task) return;

    const nextCompleted = !task.completed;
    const nowIso = new Date().toISOString();

    if (nextCompleted) {
      soundFx.playTaskComplete();
      fireConfettiBurst();

      // Recurrence auto-advancement
      if (task.recurrence && task.recurrence.type !== 'none') {
        const nextDueDate = TaskService.calculateNextDueDate(task.recurrence, task.dueDate);
        if (nextDueDate) {
          const resetSubtasks = (task.subtasks || []).map(s => ({ ...s, completed: false, completedAt: null }));
          await syncManager.recordMutation('task', taskId, 'update', {
            completed: false,
            completedAt: null,
            dueDate: nextDueDate,
            subtasks: resetSubtasks,
          });
          return;
        }
      }
    } else {
      soundFx.playUndo();
    }

    await syncManager.recordMutation('task', taskId, 'update', {
      completed: nextCompleted,
      completedAt: nextCompleted ? nowIso : null,
    });
  }, []);

  const deleteTask = useCallback(async (taskId: string): Promise<void> => {
    soundFx.playUndo();
    await syncManager.recordMutation('task', taskId, 'delete', { deleted: true });
  }, []);

  // --- HABIT MUTATIONS ---
  const createHabit = useCallback(async (data: Partial<Habit>): Promise<Habit> => {
    const id = 'habit_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const now = new Date().toISOString();
    const isQuit = data.category === 'quit';

    const habit: Habit = {
      id,
      name: data.name || (isQuit ? 'Quit Habit' : 'New Habit'),
      description: data.description || '',
      category: data.category || 'gain',
      icon: data.icon || (isQuit ? 'shield' : 'flame'),
      color: data.color || (isQuit ? '#EF4444' : '#10B981'),
      frequency: data.frequency || { type: 'daily' },
      targetCount: data.targetCount || 1,
      targetUnit: data.targetUnit || (isQuit ? 'days' : 'times'),
      reminderTime: data.reminderTime || null,
      reminders: data.reminders || [],
      startDate: data.startDate || format(new Date(), 'yyyy-MM-dd'),
      quitDetails: data.quitDetails,
      archived: false,
      order: habits.length + 1,
      createdAt: now,
      updatedAt: now,
      deleted: false,
      version: 1,
    };

    await syncManager.recordMutation('habit', id, 'create', habit);
    soundFx.playPop();
    return habit;
  }, [habits.length]);

  const updateHabit = useCallback(async (habitId: string, data: Partial<Habit>): Promise<void> => {
    await syncManager.recordMutation('habit', habitId, 'update', data);
  }, []);

  const deleteHabit = useCallback(async (habitId: string): Promise<void> => {
    soundFx.playUndo();
    await syncManager.recordMutation('habit', habitId, 'delete', { deleted: true });
  }, []);

  const toggleHabitDay = useCallback(async (habitId: string, dateStr: string): Promise<void> => {
    const habit = syncManager.crdtStore.habits.get(habitId);
    if (!habit) return;

    const logId = `${habitId}_${dateStr}`;
    const existingLog = syncManager.crdtStore.habitLogs.get(logId);
    const target = habit.targetCount || 1;

    let newCount = 0;
    let completed = false;

    if (!existingLog || existingLog.count === 0) {
      newCount = target;
      completed = true;
      soundFx.playPop();
      fireConfettiBurst();
    } else {
      newCount = 0;
      completed = false;
      soundFx.playUndo();
    }

    await syncManager.recordMutation('habit_log', logId, 'update', {
      habitId,
      date: dateStr,
      count: newCount,
      target,
      completed,
    });
  }, []);

  const incrementHabitDay = useCallback(async (habitId: string, dateStr: string): Promise<void> => {
    const habit = syncManager.crdtStore.habits.get(habitId);
    if (!habit) return;

    const logId = `${habitId}_${dateStr}`;
    const existingLog = syncManager.crdtStore.habitLogs.get(logId);
    const currentCount = existingLog ? existingLog.count : 0;
    const target = habit.targetCount || 1;

    const newCount = currentCount + 1;
    const completed = newCount >= target;

    if (completed && (!existingLog || !existingLog.completed)) {
      soundFx.playStreakFanfare();
      fireConfettiBurst();
    } else {
      soundFx.playPop();
    }

    await syncManager.recordMutation('habit_log', logId, 'update', {
      habitId,
      date: dateStr,
      count: newCount,
      target,
      completed,
    });
  }, []);

  const decrementHabitDay = useCallback(async (habitId: string, dateStr: string): Promise<void> => {
    const habit = syncManager.crdtStore.habits.get(habitId);
    if (!habit) return;

    const logId = `${habitId}_${dateStr}`;
    const existingLog = syncManager.crdtStore.habitLogs.get(logId);
    const currentCount = existingLog ? existingLog.count : 0;
    const target = habit.targetCount || 1;

    const newCount = Math.max(0, currentCount - 1);
    const completed = newCount >= target;

    soundFx.playUndo();

    await syncManager.recordMutation('habit_log', logId, 'update', {
      habitId,
      date: dateStr,
      count: newCount,
      target,
      completed,
    });
  }, []);

  const setHabitDayCount = useCallback(async (habitId: string, dateStr: string, count: number, notes?: string): Promise<void> => {
    const habit = syncManager.crdtStore.habits.get(habitId);
    if (!habit) return;

    const logId = `${habitId}_${dateStr}`;
    const target = habit.targetCount || 1;
    const completed = count >= target;

    await syncManager.recordMutation('habit_log', logId, 'update', {
      habitId,
      date: dateStr,
      count,
      target,
      completed,
      notes,
    });
  }, []);

  const recordHabitRelapse = useCallback(async (habitId: string, trigger?: string, notes?: string): Promise<void> => {
    const now = new Date();
    const dateStr = format(now, 'yyyy-MM-dd');
    const relapseId = `${habitId}_relapse_${Date.now()}`;

    await syncManager.recordMutation('habit_relapse_log', relapseId, 'create', {
      id: relapseId,
      habitId,
      date: dateStr,
      timestamp: now.toISOString(),
      trigger: trigger || 'Unspecified trigger',
      notes: notes || '',
    });

    soundFx.playUndo();
  }, []);

  const addBodyMeasurement = useCallback(async (data: Partial<{
    id: string;
    userId: string;
    date: string;
    value: number;
    unit: string;
    label: string;
    muscleGroupId?: string;
    createdAt: string;
    updatedAt: string;
  }>): Promise<{
    id: string;
    userId: string;
    date: string;
    value: number;
    unit: string;
    label: string;
    muscleGroupId?: string;
    createdAt: string;
    updatedAt: string;
  }> => {
    const id = data.id || 'meas_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const now = new Date().toISOString();
    const meas = {
      id,
      userId: data.userId || 'user_local',
      date: data.date || format(new Date(), 'yyyy-MM-dd'),
      value: data.value || 0,
      unit: data.unit || 'kg',
      label: data.label || 'Measurement',
      muscleGroupId: data.muscleGroupId,
      createdAt: now,
      updatedAt: now,
    };

    setBodyMeasurements((prev) => [...prev, meas]);
    return meas;
  }, []);

  const clearHabitRelapse = useCallback(async (habitId: string, date: string): Promise<void> => {
    const relapse = Array.from(syncManager.crdtStore.habitRelapses.values())
      .find(r => r.habitId === habitId && r.date === date && !r.deleted);
    if (!relapse) return;
    await syncManager.recordMutation('habit_relapse_log', relapse.id, 'delete', { deleted: true });
  }, []);

  // --- PROJECT MUTATIONS ---
  const createProject = useCallback(async (data: Partial<Project>): Promise<Project> => {
    const id = 'proj_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const now = new Date().toISOString();
    const proj: Project = {
      id,
      name: data.name || 'New Project',
      color: data.color || '#3B82F6',
      icon: data.icon || 'folder',
      isFavorite: data.isFavorite || false,
      archived: false,
      order: projects.length + 1,
      createdAt: now,
      updatedAt: now,
      deleted: false,
    };

    await syncManager.recordMutation('project', id, 'create', proj);
    soundFx.playPop();
    return proj;
  }, [projects.length]);

  const updateProject = useCallback(async (projectId: string, data: Partial<Project>): Promise<void> => {
    await syncManager.recordMutation('project', projectId, 'update', data);
  }, []);

  const deleteProject = useCallback(async (projectId: string): Promise<void> => {
    soundFx.playUndo();
    await syncManager.recordMutation('project', projectId, 'delete', { deleted: true });
  }, []);

  // --- TAG MUTATIONS ---
  const createTag = useCallback(async (name: string, color: string = '#10B981'): Promise<Tag> => {
    const id = 'tag_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const tag: Tag = {
      id,
      name,
      color,
      createdAt: new Date().toISOString(),
      deleted: false,
    };
    await syncManager.recordMutation('tag', id, 'create', tag);
    return tag;
  }, []);

  const deleteTag = useCallback(async (tagId: string): Promise<void> => {
    await syncManager.recordMutation('tag', tagId, 'delete', { deleted: true });
  }, []);

  // --- MEETING MUTATIONS (Google Calendar Style) ---
  const createMeeting = useCallback(async (data: Partial<Meeting>): Promise<Meeting> => {
    const id = 'meeting_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const now = new Date().toISOString();
    const meeting: Meeting = {
      id,
      title: data.title || 'Untitled Meeting',
      description: data.description || '',
      date: data.date || format(new Date(), 'yyyy-MM-dd'),
      startTime: data.startTime || '09:00',
      endTime: data.endTime || '10:00',
      allDay: data.allDay ?? false,
      location: data.location || '',
      color: data.color || '#3B82F6',
      reminders: data.reminders || [{ id: 'rem_0', minutesBefore: 10, enabled: true }],
      attendees: data.attendees || [],
      createdAt: now,
      updatedAt: now,
      deleted: false,
      version: 1,
    };

    await syncManager.recordMutation('meeting', id, 'create', meeting);
    soundFx.playPop();
    return meeting;
  }, []);

  const updateMeeting = useCallback(async (meetingId: string, data: Partial<Meeting>): Promise<void> => {
    await syncManager.recordMutation('meeting', meetingId, 'update', data);
  }, []);

  const deleteMeeting = useCallback(async (meetingId: string): Promise<void> => {
    soundFx.playUndo();
    await syncManager.recordMutation('meeting', meetingId, 'delete', { deleted: true });
  }, []);

  // --- CLOUD AUTH & SYNC (Direct DB mode: auth via embedded API, no Next.js) ---
  const loginUser = useCallback(async (email: string, password: string) => {
    const res = await syncManager.dbClient.login(email, password);
    if (res.success) {
      unlockSession();
      setVersion(v => v + 1);
      await syncManager.triggerDbSync();
    }
    return res;
  }, [unlockSession]);

  const registerUser = useCallback(async (email: string, password: string) => {
    const res = await syncManager.dbClient.register(email, password);
    if (res.success) {
      unlockSession();
      setVersion(v => v + 1);
      await syncManager.triggerDbSync();
    }
    return res;
  }, [unlockSession]);

  const logoutUser = useCallback(() => {
    syncManager.dbClient.setCredentials('');
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem('aureus_user_id');
      localStorage.removeItem('aureus_auth_token');
    }
    lockSession();
    setVersion(v => v + 1);
  }, [lockSession]);

  const reloadData = useCallback(async () => {
    await syncManager.triggerDbSync(false);
  }, []);

  return (
    <AppContext.Provider
      value={{
        tasks,
        habits,
        meetings,
        habitLogs,
        habitRelapses,
        projects,
        tags,
        syncManager,
        syncStatus,
        reloadData,
        activeView,
        setActiveView,
        habitTimeframeView,
        setHabitTimeframeView,
        selectedProjectId,
        setSelectedProjectId,
        selectedPriority,
        setSelectedPriority,
        selectedTagId,
        setSelectedTagId,
        searchQuery,
        setSearchQuery,
        theme,
        setTheme,
        toggleTheme,
        isAccountModalOpen,
        setIsAccountModalOpen,
        isCommandPaletteOpen,
        setIsCommandPaletteOpen,
        isTaskModalOpen,
        setIsTaskModalOpen,
        isHabitModalOpen,
        setIsHabitModalOpen,
        isProjectModalOpen,
        setIsProjectModalOpen,
        isMeetingModalOpen,
        setIsMeetingModalOpen,
        editingTask,
        setEditingTask,
        editingHabit,
        setEditingHabit,
        viewingHabitDetail,
        setViewingHabitDetail,
        editingProject,
        setEditingProject,
        editingMeeting,
        setEditingMeeting,
        lifestyleAreas,
        userMetrics,
        metricScores,
        userXP,
        timelineEvents,
        createTask,
        updateTask,
        toggleTaskComplete,
        deleteTask,
        createHabit,
        updateHabit,
        deleteHabit,
        toggleHabitDay,
        incrementHabitDay,
        decrementHabitDay,
        setHabitDayCount,
        recordHabitRelapse,
        addBodyMeasurement,
        clearHabitRelapse,
        createProject,
        updateProject,
        deleteProject,
        createTag,
        deleteTag,
        createMeeting,
        updateMeeting,
        deleteMeeting,
        isAuthenticated,
        sessionUnlocked,
        unlockSession,
        lockSession,
        loginUser,
        registerUser,
        logoutUser,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextType {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
