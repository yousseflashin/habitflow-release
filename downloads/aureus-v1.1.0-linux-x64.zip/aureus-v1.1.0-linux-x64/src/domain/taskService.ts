// Domain Service for Task Logic, Recurrence Rules, Subtasks & Filtering

import { Task, RecurrenceRule, Priority } from '../types';
import { format, parseISO, addDays, addWeeks, addMonths, isBefore, isAfter, isSameDay, startOfDay, getDay } from 'date-fns';

export class TaskService {
  /**
   * Checks if a task is overdue relative to reference date.
   */
  public static isOverdue(task: Task, today: Date = new Date()): boolean {
    if (task.completed || task.deleted || !task.dueDate) return false;
    const due = parseISO(task.dueDate.substring(0, 10));
    return isBefore(startOfDay(due), startOfDay(today));
  }

  /**
   * Checks if a task is due today.
   */
  public static isDueToday(task: Task, today: Date = new Date()): boolean {
    if (task.deleted || !task.dueDate) return false;
    const due = parseISO(task.dueDate.substring(0, 10));
    return isSameDay(due, today);
  }

  /**
   * Checks if a task is due in the future (after today).
   */
  public static isUpcoming(task: Task, today: Date = new Date()): boolean {
    if (task.deleted || !task.dueDate) return false;
    const due = parseISO(task.dueDate.substring(0, 10));
    return isAfter(startOfDay(due), startOfDay(today));
  }

  /**
   * Calculates the next due date for a recurring task upon completion.
   */
  public static calculateNextDueDate(rule: RecurrenceRule, currentDueDateStr: string | null): string | null {
    if (!rule || rule.type === 'none') return null;

    const baseDate = currentDueDateStr ? parseISO(currentDueDateStr.substring(0, 10)) : new Date();
    let nextDate: Date;

    switch (rule.type) {
      case 'daily':
        nextDate = addDays(baseDate, rule.interval || 1);
        break;

      case 'weekdays': {
        let candidate = addDays(baseDate, 1);
        const day = getDay(candidate);
        if (day === 6) candidate = addDays(candidate, 2); // Sat -> Mon
        else if (day === 0) candidate = addDays(candidate, 1); // Sun -> Mon
        nextDate = candidate;
        break;
      }

      case 'weekly':
        nextDate = addWeeks(baseDate, rule.interval || 1);
        break;

      case 'monthly':
        nextDate = addMonths(baseDate, rule.interval || 1);
        break;

      case 'custom':
        nextDate = addDays(baseDate, rule.interval || 1);
        break;

      default:
        nextDate = addDays(baseDate, 1);
    }

    if (rule.endDate && isAfter(startOfDay(nextDate), startOfDay(parseISO(rule.endDate)))) {
      return null; // Expired recurrence
    }

    return format(nextDate, 'yyyy-MM-dd');
  }

  /**
   * Returns subtask statistics { completed, total, percentage }.
   */
  public static getSubtaskProgress(task: Task): { completed: number; total: number; percentage: number } {
    if (!task.subtasks || task.subtasks.length === 0) {
      return { completed: 0, total: 0, percentage: 0 };
    }
    const completed = task.subtasks.filter(s => s.completed).length;
    const total = task.subtasks.length;
    return {
      completed,
      total,
      percentage: Math.round((completed / total) * 100),
    };
  }

  /**
   * Numerical priority value for sorting: P1 (1) -> P2 (2) -> P3 (3) -> P4 (4).
   */
  public static getPriorityWeight(priority: Priority): number {
    switch (priority) {
      case 'p1': return 1;
      case 'p2': return 2;
      case 'p3': return 3;
      case 'p4': return 4;
      default: return 4;
    }
  }

  /**
   * Sorts tasks by priority -> due date -> order.
   */
  public static sortTasks(tasks: Task[]): Task[] {
    return [...tasks].sort((a, b) => {
      // 1. Completed state (uncompleted first)
      if (a.completed !== b.completed) {
        return a.completed ? 1 : -1;
      }
      // 2. Priority
      const pDiff = this.getPriorityWeight(a.priority) - this.getPriorityWeight(b.priority);
      if (pDiff !== 0) return pDiff;

      // 3. Due date
      if (a.dueDate && b.dueDate) {
        const dDiff = new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        if (dDiff !== 0) return dDiff;
      } else if (a.dueDate && !b.dueDate) {
        return -1;
      } else if (!a.dueDate && b.dueDate) {
        return 1;
      }

      // 4. Order
      return (a.order || 0) - (b.order || 0);
    });
  }
}
