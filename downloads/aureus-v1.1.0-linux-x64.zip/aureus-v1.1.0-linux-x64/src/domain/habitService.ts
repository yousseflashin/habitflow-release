// Domain Service for Habit Logic, Streaks, Quit/Gain Mechanics, and Multi-Timeframe Grid Generation

import { Habit, HabitLog, HabitRelapseLog, HabitStats, HabitTimeframeView } from '../types';
import {
  format,
  subDays,
  addDays,
  differenceInDays,
  parseISO,
  isSameDay,
  getDay,
  isBefore,
  isAfter,
  startOfDay,
  startOfWeek,
  endOfWeek,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
} from 'date-fns';

export interface HabitDayCell {
  date: string;         // 'YYYY-MM-DD'
  dayOfWeek: number;    // 0=Sun, 1=Mon, ..., 6=Sat
  dayOfMonth: number;
  count: number;
  target: number;
  completed: boolean;
  isRelapse?: boolean;  // For quit habits
  intensity: number;    // 0 = empty/missed, 1..4 = intensity, or special for relapse
  isToday: boolean;
  isFuture: boolean;
  isInSchedule: boolean;
  notes?: string;
}

export class HabitService {
  /**
   * Checks if a habit is scheduled for a given date according to its frequency rule.
   */
  public static isHabitScheduledForDate(habit: Habit, dateStr: string): boolean {
    const d = parseISO(dateStr);
    const dayOfWeek = getDay(d); // 0=Sun, 1=Mon, ..., 6=Sat

    if (habit.startDate && isBefore(startOfDay(d), startOfDay(parseISO(habit.startDate)))) {
      return false;
    }

    if (habit.category === 'quit') {
      // Quit habits are tracked every day from start date
      return true;
    }

    switch (habit.frequency.type) {
      case 'daily':
        return true;
      case 'weekdays':
        return dayOfWeek >= 1 && dayOfWeek <= 5;
      case 'custom_days':
        return habit.frequency.customDays ? habit.frequency.customDays.includes(dayOfWeek) : true;
      case 'times_per_week':
        return true; // Any day can contribute to the weekly target
      default:
        return true;
    }
  }

  /**
   * Calculates current streak, best streak, clean days, relapses, and completion statistics from canonical logs.
   */
  public static calculateStats(
    habit: Habit,
    logsMap: Map<string, HabitLog>,
    relapsesMap: Map<string, HabitRelapseLog> = new Map(),
    today: Date = new Date()
  ): HabitStats {
    const todayStr = format(today, 'yyyy-MM-dd');
    const logs = Array.from(logsMap.values()).filter(l => l.habitId === habit.id && !l.deleted);
    const relapses = Array.from(relapsesMap.values()).filter(r => r.habitId === habit.id && !r.deleted);

    const logByDate = new Map<string, HabitLog>();
    let totalUnits = 0;
    let totalCompletions = 0;

    for (const log of logs) {
      logByDate.set(log.date, log);
      totalUnits += log.count;
      if (log.completed) {
        totalCompletions += 1;
      }
    }

    const relapseDates = new Set(relapses.map(r => r.date));

    // --- QUIT HABIT SPECIALIZED CALCULATION ---
    if (habit.category === 'quit') {
      const startDate = habit.startDate ? parseISO(habit.startDate) : subDays(today, 30);
      const totalDaysSinceStart = Math.max(0, differenceInDays(today, startDate) + 1);

      // Current clean streak (days since last relapse)
      let currentCleanStreak = 0;
      let checkDate = today;

      while (!isBefore(startOfDay(checkDate), startOfDay(startDate))) {
        const dStr = format(checkDate, 'yyyy-MM-dd');
        if (relapseDates.has(dStr)) {
          break; // Streak reset by relapse
        }
        currentCleanStreak += 1;
        checkDate = subDays(checkDate, 1);
      }

      // Best clean streak
      let bestCleanStreak = 0;
      let runningStreak = 0;
      let totalCleanDays = 0;

      for (let i = totalDaysSinceStart - 1; i >= 0; i--) {
        const d = subDays(today, i);
        const dStr = format(d, 'yyyy-MM-dd');

        if (relapseDates.has(dStr)) {
          runningStreak = 0;
        } else {
          runningStreak += 1;
          totalCleanDays += 1;
          if (runningStreak > bestCleanStreak) {
            bestCleanStreak = runningStreak;
          }
        }
      }

      bestCleanStreak = Math.max(bestCleanStreak, currentCleanStreak);
      const cleanRate30 = Math.round(
        (Array.from({ length: 30 }, (_, i) => format(subDays(today, i), 'yyyy-MM-dd'))
          .filter(d => !relapseDates.has(d) && !isBefore(startOfDay(parseISO(d)), startOfDay(startDate)))
          .length / Math.min(30, totalDaysSinceStart || 1)) * 100
      );

      return {
        currentStreak: currentCleanStreak,
        bestStreak: bestCleanStreak,
        totalCompletions: totalCleanDays,
        completionRate30Days: isNaN(cleanRate30) ? 100 : cleanRate30,
        completionRateYear: totalDaysSinceStart > 0 ? Math.round((totalCleanDays / totalDaysSinceStart) * 100) : 100,
        activeDaysCount: totalDaysSinceStart,
        missedDaysCount: relapses.length,
        totalUnitsTracked: relapses.length,
        relapseCount: relapses.length,
        totalRelapsesAllTime: relapses.length,
        daysSinceLastRelapse: currentCleanStreak,
      };
    }

    // --- GAIN HABIT CALCULATION ---
    // 1. Calculate Current Streak
    let currentStreak = 0;
    let checkDate = today;
    const todayLog = logByDate.get(todayStr);

    if (todayLog && todayLog.completed) {
      currentStreak += 1;
      checkDate = subDays(today, 1);
    } else {
      checkDate = subDays(today, 1);
    }

    while (true) {
      const dStr = format(checkDate, 'yyyy-MM-dd');
      if (habit.startDate && isBefore(startOfDay(checkDate), startOfDay(parseISO(habit.startDate)))) {
        break;
      }

      const isScheduled = this.isHabitScheduledForDate(habit, dStr);
      if (!isScheduled) {
        checkDate = subDays(checkDate, 1);
        if (differenceInDays(today, checkDate) > 365) break;
        continue;
      }

      const log = logByDate.get(dStr);
      if (log && log.completed) {
        currentStreak += 1;
        checkDate = subDays(checkDate, 1);
      } else {
        break;
      }

      if (differenceInDays(today, checkDate) > 730) break;
    }

    // 2. Calculate Best Streak across all time
    let bestStreak = 0;
    let runningStreak = 0;
    const startDate = habit.startDate ? parseISO(habit.startDate) : subDays(today, 365);
    const totalDays = Math.max(1, differenceInDays(today, startDate) + 1);

    let missedCount = 0;
    let activeScheduledDays = 0;

    for (let i = totalDays; i >= 0; i--) {
      const d = subDays(today, i);
      const dStr = format(d, 'yyyy-MM-dd');

      if (isAfter(startOfDay(d), startOfDay(today))) continue;

      const isScheduled = this.isHabitScheduledForDate(habit, dStr);
      if (!isScheduled) continue;

      activeScheduledDays += 1;
      const log = logByDate.get(dStr);

      if (log && log.completed) {
        runningStreak += 1;
        if (runningStreak > bestStreak) {
          bestStreak = runningStreak;
        }
      } else {
        if (!isSameDay(d, today)) {
          missedCount += 1;
        }
        runningStreak = 0;
      }
    }

    bestStreak = Math.max(bestStreak, currentStreak);

    // 3. 30-Day and Year Completion Rates
    let completed30d = 0;
    let scheduled30d = 0;
    for (let i = 29; i >= 0; i--) {
      const d = subDays(today, i);
      const dStr = format(d, 'yyyy-MM-dd');
      if (this.isHabitScheduledForDate(habit, dStr)) {
        scheduled30d += 1;
        const log = logByDate.get(dStr);
        if (log && log.completed) {
          completed30d += 1;
        }
      }
    }

    const rate30 = scheduled30d > 0 ? Math.round((completed30d / scheduled30d) * 100) : 0;
    const rateYear = activeScheduledDays > 0 ? Math.round((totalCompletions / activeScheduledDays) * 100) : 0;

    return {
      currentStreak,
      bestStreak,
      totalCompletions,
      completionRate30Days: rate30,
      completionRateYear: rateYear,
      activeDaysCount: activeScheduledDays,
      missedDaysCount: missedCount,
      totalUnitsTracked: totalUnits,
    };
  }

  /**
   * Generates HabitKit-style grid cells for visual rendering (e.g. past 7, 14, 30, 90, or 365 days).
   */
  public static generateGridCells(
    habit: Habit,
    logsMap: Map<string, HabitLog>,
    relapsesMap: Map<string, HabitRelapseLog> = new Map(),
    daysCount: number = 30,
    today: Date = new Date()
  ): HabitDayCell[] {
    const cells: HabitDayCell[] = [];
    const todayStr = format(today, 'yyyy-MM-dd');
    const isQuit = habit.category === 'quit';

    for (let i = daysCount - 1; i >= 0; i--) {
      const d = subDays(today, i);
      const dateStr = format(d, 'yyyy-MM-dd');
      const logKey = `${habit.id}_${dateStr}`;
      const log = logsMap.get(logKey);

      // Check if relapse occurred on this date
      const isRelapse = Array.from(relapsesMap.values()).some(
        r => r.habitId === habit.id && r.date === dateStr && !r.deleted
      );

      const count = (log && !log.deleted) ? log.count : 0;
      const target = habit.targetCount || 1;
      const isScheduled = this.isHabitScheduledForDate(habit, dateStr);
      const isBeforeStart = habit.startDate ? isBefore(startOfDay(d), startOfDay(parseISO(habit.startDate))) : false;

      let completed = (log && !log.deleted) ? log.completed : false;
      let intensity = 0;

      if (isQuit) {
        if (isBeforeStart) {
          intensity = 0;
          completed = false;
        } else if (isRelapse) {
          intensity = 0;
          completed = false;
        } else {
          // Clean day
          intensity = 4;
          completed = true;
        }
      } else {
        if (completed) {
          intensity = 4;
        } else if (count > 0) {
          const ratio = count / target;
          if (ratio >= 0.75) intensity = 3;
          else if (ratio >= 0.5) intensity = 2;
          else intensity = 1;
        }
      }

      cells.push({
        date: dateStr,
        dayOfWeek: getDay(d),
        dayOfMonth: d.getDate(),
        count,
        target,
        completed,
        isRelapse,
        intensity,
        isToday: dateStr === todayStr,
        isFuture: isAfter(startOfDay(d), startOfDay(today)),
        isInSchedule: isScheduled && !isBeforeStart,
        notes: log?.notes,
      });
    }

    return cells;
  }

  /**
   * Generates cells for specific timeframe view (Daily, Weekly, Monthly, Yearly).
   */
  public static generateTimeframeCells(
    habit: Habit,
    logsMap: Map<string, HabitLog>,
    relapsesMap: Map<string, HabitRelapseLog>,
    view: HabitTimeframeView,
    today: Date = new Date()
  ): HabitDayCell[] {
    switch (view) {
      case 'daily':
        return this.generateGridCells(habit, logsMap, relapsesMap, 1, today);
      case 'weekly': {
        const weekStart = startOfWeek(today, { weekStartsOn: 1 });
        const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
        const days = eachDayOfInterval({ start: weekStart, end: weekEnd });
        return days.map(d => {
          const dStr = format(d, 'yyyy-MM-dd');
          const cell = this.generateGridCells(habit, logsMap, relapsesMap, 1, d)[0];
          return cell;
        });
      }
      case 'monthly': {
        const monthStart = startOfMonth(today);
        const monthEnd = endOfMonth(today);
        const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
        return days.map(d => this.generateGridCells(habit, logsMap, relapsesMap, 1, d)[0]);
      }
      case 'yearly':
      default:
        return this.generateGridCells(habit, logsMap, relapsesMap, 365, today);
    }
  }
}
