// Aureus Executive — Project & Money Treasury Bridge
// Links Client & Personal Projects with Sprints, Payment Tracking, and the Money Engine.
// Automatically passes project income and pending sprint receivables into the Money System.

import {
  Project,
  ProjectSprint,
  ProjectPayment,
  MoneyAccount,
  MoneyTransaction,
} from '../types';

export interface ProjectFinancialSummary {
  projectId: string;
  projectName: string;
  clientName?: string;
  isClientProject: boolean;
  currency: string;
  contractValue: number;
  totalPaid: number;
  totalInvoiced: number;
  totalPending: number;
  remainingBalance: number;
  collectionRate: number; // 0 to 100
  activeSprintsCount: number;
  completedSprintsCount: number;
}

export interface UpcomingSprintPayout {
  sprintId: string;
  sprintName: string;
  projectId: string;
  projectName: string;
  clientName?: string;
  expectedIncome: number;
  currency: string;
  dueDate?: string;
  paymentStatus: 'pending' | 'invoiced' | 'paid';
}

export interface ProjectReceivablesSummary {
  totalClientContractValue: number;
  totalCollectedRevenue: number;
  totalPendingReceivables: number;
  totalInvoicedReceivables: number;
  activeClientProjectsCount: number;
  upcomingPayouts: UpcomingSprintPayout[];
}

/**
 * Computes financial metrics for a single project.
 */
export function computeProjectFinancials(project: Project): ProjectFinancialSummary {
  const isClientProject = project.kind === 'client';
  const currency = project.currency || 'USD';
  const sprints = project.sprints || [];
  const payments = project.payments || [];

  // Contract value is either explicit contractValue or sum of sprint expected incomes
  const sprintSum = sprints.reduce((acc, s) => acc + (s.expectedIncome || 0), 0);
  const contractValue = project.contractValue ?? (sprintSum > 0 ? sprintSum : 0);

  // Total paid from payments log with status 'received' OR sprints marked paid
  const paymentsReceived = payments
    .filter((p) => p.status === 'received')
    .reduce((acc, p) => acc + p.amount, 0);

  const sprintPaidSum = sprints
    .filter((s) => s.paymentStatus === 'paid')
    .reduce((acc, s) => acc + (s.paidAmount || s.expectedIncome || 0), 0);

  const totalPaid = Math.max(paymentsReceived, sprintPaidSum);

  // Total invoiced
  const paymentsInvoiced = payments
    .filter((p) => p.status === 'invoiced')
    .reduce((acc, p) => acc + p.amount, 0);

  const sprintInvoicedSum = sprints
    .filter((s) => s.paymentStatus === 'invoiced')
    .reduce((acc, s) => acc + (s.expectedIncome || 0), 0);

  const totalInvoiced = Math.max(paymentsInvoiced, sprintInvoicedSum);

  // Total pending (planned or active sprints awaiting invoice/payment)
  const totalPending = sprints
    .filter((s) => s.paymentStatus === 'pending')
    .reduce((acc, s) => acc + (s.expectedIncome || 0), 0);

  const remainingBalance = Math.max(0, contractValue - totalPaid);
  const collectionRate = contractValue > 0 ? Math.min(100, Math.round((totalPaid / contractValue) * 100)) : 0;

  const activeSprintsCount = sprints.filter((s) => s.status === 'in_progress' || s.status === 'planned').length;
  const completedSprintsCount = sprints.filter((s) => s.status === 'completed' || s.status === 'delivered').length;

  return {
    projectId: project.id,
    projectName: project.name,
    clientName: project.clientName,
    isClientProject,
    currency,
    contractValue,
    totalPaid,
    totalInvoiced,
    totalPending,
    remainingBalance,
    collectionRate,
    activeSprintsCount,
    completedSprintsCount,
  };
}

/**
 * Computes portfolio-wide client receivables and upcoming sprint cashflows.
 */
export function getProjectReceivablesSummary(projects: Project[]): ProjectReceivablesSummary {
  const activeProjects = projects.filter((p) => !p.deleted && !p.archived && p.kind === 'client');

  let totalClientContractValue = 0;
  let totalCollectedRevenue = 0;
  let totalPendingReceivables = 0;
  let totalInvoicedReceivables = 0;
  const upcomingPayouts: UpcomingSprintPayout[] = [];

  for (const proj of activeProjects) {
    const fin = computeProjectFinancials(proj);
    totalClientContractValue += fin.contractValue;
    totalCollectedRevenue += fin.totalPaid;
    totalPendingReceivables += fin.totalPending;
    totalInvoicedReceivables += fin.totalInvoiced;

    for (const s of proj.sprints || []) {
      if (s.paymentStatus !== 'paid') {
        upcomingPayouts.push({
          sprintId: s.id,
          sprintName: s.name,
          projectId: proj.id,
          projectName: proj.name,
          clientName: proj.clientName,
          expectedIncome: s.expectedIncome,
          currency: proj.currency || 'USD',
          dueDate: s.dueDate,
          paymentStatus: s.paymentStatus,
        });
      }
    }
  }

  // Sort upcoming payouts by due date
  upcomingPayouts.sort((a, b) => {
    if (!a.dueDate) return 1;
    if (!b.dueDate) return -1;
    return a.dueDate.localeCompare(b.dueDate);
  });

  return {
    totalClientContractValue,
    totalCollectedRevenue,
    totalPendingReceivables,
    totalInvoicedReceivables,
    activeClientProjectsCount: activeProjects.length,
    upcomingPayouts,
  };
}

/**
 * Records a project payment, updates sprint status, and creates a corresponding MoneyTransaction.
 */
export function recordProjectPayment(
  project: Project,
  paymentInput: {
    title: string;
    amount: number;
    currency?: string;
    date: string;
    status: 'expected' | 'invoiced' | 'received';
    sprintId?: string;
    accountId?: string;
    notes?: string;
  },
  accounts: MoneyAccount[] = [],
  transactions: MoneyTransaction[] = []
): {
  updatedProject: Project;
  updatedAccounts: MoneyAccount[];
  updatedTransactions: MoneyTransaction[];
  newTransaction?: MoneyTransaction;
} {
  const paymentId = 'pay_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
  const currency = paymentInput.currency || project.currency || 'USD';

  let newTx: MoneyTransaction | undefined;
  let updatedAccounts = [...accounts];
  let updatedTransactions = [...transactions];

  // If received, pass directly into Money System as an income transaction
  if (paymentInput.status === 'received' && paymentInput.accountId) {
    newTx = {
      id: 'tx_proj_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      accountId: paymentInput.accountId,
      type: 'income',
      amount: Math.abs(paymentInput.amount),
      currency,
      date: paymentInput.date,
      note: `Project Income: ${project.name}${project.clientName ? ` (${project.clientName})` : ''} - ${paymentInput.title}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deleted: false,
    };

    updatedTransactions = [newTx, ...updatedTransactions];

    // Update account balance
    updatedAccounts = updatedAccounts.map((acc) => {
      if (acc.id === paymentInput.accountId) {
        return {
          ...acc,
          balance: acc.balance + Math.abs(paymentInput.amount),
          updatedAt: new Date().toISOString(),
        };
      }
      return acc;
    });
  }

  const paymentRecord: ProjectPayment = {
    id: paymentId,
    projectId: project.id,
    sprintId: paymentInput.sprintId,
    title: paymentInput.title,
    amount: paymentInput.amount,
    currency,
    date: paymentInput.date,
    status: paymentInput.status,
    accountId: paymentInput.accountId,
    transactionId: newTx?.id,
    notes: paymentInput.notes,
    createdAt: new Date().toISOString(),
  };

  // Update sprints if linked
  let updatedSprints = project.sprints ? [...project.sprints] : [];
  if (paymentInput.sprintId) {
    updatedSprints = updatedSprints.map((s) => {
      if (s.id === paymentInput.sprintId) {
        return {
          ...s,
          paymentStatus: paymentInput.status === 'received' ? 'paid' : (paymentInput.status === 'invoiced' ? 'invoiced' : 'pending'),
          paidAmount: paymentInput.status === 'received' ? paymentInput.amount : s.paidAmount,
          paidDate: paymentInput.status === 'received' ? paymentInput.date : s.paidDate,
          accountId: paymentInput.accountId || s.accountId,
        };
      }
      return s;
    });
  }

  const updatedProject: Project = {
    ...project,
    payments: [...(project.payments || []), paymentRecord],
    sprints: updatedSprints,
    updatedAt: new Date().toISOString(),
  };

  return {
    updatedProject,
    updatedAccounts,
    updatedTransactions,
    newTransaction: newTx,
  };
}

const MONEY_STORAGE_KEY = 'habitflow_money_v1';

export function getStoredMoneyState(): { accounts: MoneyAccount[]; transactions: MoneyTransaction[] } {
  if (typeof localStorage === 'undefined') return { accounts: [], transactions: [] };
  try {
    const raw = localStorage.getItem(MONEY_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        accounts: parsed.accounts || [],
        transactions: parsed.transactions || [],
      };
    }
  } catch (e) {
    console.warn('Error reading money storage:', e);
  }
  return { accounts: [], transactions: [] };
}

export function depositProjectPaymentToMoney(
  project: Project,
  paymentInput: {
    title: string;
    amount: number;
    currency?: string;
    date: string;
    status: 'expected' | 'invoiced' | 'received';
    sprintId?: string;
    accountId?: string;
    notes?: string;
  }
): { updatedProject: Project; newTransactionId?: string } {
  const stored = getStoredMoneyState();
  const res = recordProjectPayment(project, paymentInput, stored.accounts, stored.transactions);

  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem(MONEY_STORAGE_KEY);
      const parsed = raw ? JSON.parse(raw) : {};
      parsed.accounts = res.updatedAccounts;
      parsed.transactions = res.updatedTransactions;
      localStorage.setItem(MONEY_STORAGE_KEY, JSON.stringify(parsed));
      window.dispatchEvent(new CustomEvent('habitflow_money_updated'));
    } catch (e) {
      console.warn('Error persisting money state on project payment:', e);
    }
  }

  return {
    updatedProject: res.updatedProject,
    newTransactionId: res.newTransaction?.id,
  };
}
