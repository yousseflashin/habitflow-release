// Aureus Chronos — Real-Time Schedule Conflict & Time-Slot Reconciliation Engine
// Detects mutual overlaps between meetings, appointments (e.g. client meetings, social gatherings)
// and scheduled tasks, with intelligent slot suggestions and resolution actions.

import { Meeting, Task } from '../types';

export interface ConflictItem {
  id: string;
  type: 'meeting' | 'task';
  title: string;
  date: string;
  startTime: string; // 'HH:mm'
  endTime: string; // 'HH:mm'
  isAllDay?: boolean;
  priority?: string;
  location?: string;
  clientName?: string;
}

export interface ScheduleConflict {
  hasConflict: boolean;
  conflicts: ConflictItem[];
  suggestedSlots: Array<{ startTime: string; endTime: string; label: string }>;
  summaryMessage: string;
}

/**
 * Converts 'HH:mm' string to total minutes since midnight
 */
export function timeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (isNaN(h) ? 0 : h) * 60 + (isNaN(m) ? 0 : m);
}

/**
 * Converts total minutes since midnight to 'HH:mm' string
 */
export function minutesToTime(totalMins: number): string {
  const normalized = Math.max(0, Math.min(24 * 60 - 1, totalMins));
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Returns true if two time intervals [startA, endA) and [startB, endB) overlap.
 */
export function intervalsOverlap(
  startA: string,
  endA: string,
  startB: string,
  endB: string
): boolean {
  const a1 = timeToMinutes(startA);
  const a2 = timeToMinutes(endA);
  const b1 = timeToMinutes(startB);
  const b2 = timeToMinutes(endB);

  // If start is after or equal to end (e.g. crossing midnight or zero length), guard
  const endAMin = a2 <= a1 ? a1 + 30 : a2;
  const endBMin = b2 <= b1 ? b1 + 30 : b2;

  return Math.max(a1, b1) < Math.min(endAMin, endBMin);
}

/**
 * Detects conflicts for a meeting against existing meetings and scheduled tasks.
 */
export function detectMeetingConflicts(
  candidate: {
    id?: string;
    date: string; // 'YYYY-MM-DD'
    startTime: string; // 'HH:mm'
    endTime: string; // 'HH:mm'
    allDay?: boolean;
    title?: string;
  },
  meetings: Meeting[],
  tasks: Task[] = []
): ScheduleConflict {
  if (!candidate.date || (!candidate.startTime && !candidate.allDay)) {
    return { hasConflict: false, conflicts: [], suggestedSlots: [], summaryMessage: '' };
  }

  const conflicts: ConflictItem[] = [];
  const candidateStart = candidate.startTime || '09:00';
  const candidateEnd = candidate.endTime || '10:00';

  // 1. Check against active meetings on the same date
  for (const m of meetings) {
    if (m.deleted || (candidate.id && m.id === candidate.id)) continue;
    if (m.date !== candidate.date) continue;

    // Both all-day or one is all-day
    if (candidate.allDay || m.allDay) {
      conflicts.push({
        id: m.id,
        type: 'meeting',
        title: m.title || 'Untitled Meeting',
        date: m.date,
        startTime: m.startTime || '00:00',
        endTime: m.endTime || '23:59',
        isAllDay: m.allDay,
        location: m.location,
      });
      continue;
    }

    if (intervalsOverlap(candidateStart, candidateEnd, m.startTime, m.endTime)) {
      conflicts.push({
        id: m.id,
        type: 'meeting',
        title: m.title || 'Untitled Meeting',
        date: m.date,
        startTime: m.startTime,
        endTime: m.endTime,
        isAllDay: false,
        location: m.location,
      });
    }
  }

  // 2. Check against scheduled tasks with specific times on the same date
  for (const t of tasks) {
    if (t.deleted || t.completed || t.isArchived) continue;
    
    // Check if task is scheduled on candidate date
    const taskDate = t.dueDate?.includes('T') ? t.dueDate.split('T')[0] : t.dueDate;
    if (taskDate !== candidate.date) continue;

    const taskTime = t.scheduledTime || (t.dueDate?.includes('T') ? t.dueDate.split('T')[1]?.slice(0, 5) : null);
    if (!taskTime) continue; // Task is full-day or due-date only, no strict time clash

    // Assume 45 min default duration for timed tasks if not specified
    const taskEndMinutes = timeToMinutes(taskTime) + 45;
    const taskEndTime = minutesToTime(taskEndMinutes);

    if (intervalsOverlap(candidateStart, candidateEnd, taskTime, taskEndTime)) {
      conflicts.push({
        id: t.id,
        type: 'task',
        title: t.title || 'Untitled Task',
        date: taskDate,
        startTime: taskTime,
        endTime: taskEndTime,
        priority: t.priority,
      });
    }
  }

  const hasConflict = conflicts.length > 0;
  let summaryMessage = '';
  const suggestedSlots: Array<{ startTime: string; endTime: string; label: string }> = [];

  if (hasConflict) {
    const firstConflict = conflicts[0];
    const durationMinutes = Math.max(30, timeToMinutes(candidateEnd) - timeToMinutes(candidateStart));

    summaryMessage = `Schedule conflict: Overlaps with ${firstConflict.type === 'meeting' ? 'meeting' : 'task'} "${firstConflict.title}" (${firstConflict.startTime} – ${firstConflict.endTime})`;
    if (conflicts.length > 1) {
      summaryMessage += ` and ${conflicts.length - 1} other item${conflicts.length > 2 ? 's' : ''}`;
    }

    // Find smart suggestions
    const dayMeetings = meetings.filter((m) => !m.deleted && m.date === candidate.date && (!candidate.id || m.id !== candidate.id));
    
    // Suggest slot right after the latest conflicting item
    const latestConflictEnd = Math.max(...conflicts.map((c) => timeToMinutes(c.endTime)));
    if (latestConflictEnd + durationMinutes <= 22 * 60) {
      const altStart = minutesToTime(latestConflictEnd);
      const altEnd = minutesToTime(latestConflictEnd + durationMinutes);
      suggestedSlots.push({
        startTime: altStart,
        endTime: altEnd,
        label: `Right after conflict (${altStart} – ${altEnd})`,
      });
    }

    // Find first free slot in business hours (09:00 - 18:00)
    const freeSlot = findNextAvailableSlot(candidate.date, durationMinutes, dayMeetings);
    if (freeSlot && !suggestedSlots.some((s) => s.startTime === freeSlot.startTime)) {
      suggestedSlots.push({
        startTime: freeSlot.startTime,
        endTime: freeSlot.endTime,
        label: `Next available window (${freeSlot.startTime} – ${freeSlot.endTime})`,
      });
    }
  }

  return {
    hasConflict,
    conflicts,
    suggestedSlots,
    summaryMessage,
  };
}

/**
 * Detects conflicts for a task against existing meetings and other tasks.
 */
export function detectTaskConflicts(
  candidate: {
    id?: string;
    title?: string;
    dueDate: string | null; // 'YYYY-MM-DD' or 'YYYY-MM-DDTHH:mm'
    scheduledTime?: string | null; // 'HH:mm'
    durationMinutes?: number;
  },
  meetings: Meeting[],
  tasks: Task[] = []
): ScheduleConflict {
  if (!candidate.dueDate) {
    return { hasConflict: false, conflicts: [], suggestedSlots: [], summaryMessage: '' };
  }

  const date = candidate.dueDate.includes('T') ? candidate.dueDate.split('T')[0] : candidate.dueDate;
  const time = candidate.scheduledTime || (candidate.dueDate.includes('T') ? candidate.dueDate.split('T')[1]?.slice(0, 5) : null);
  const duration = candidate.durationMinutes || 45;

  if (!time) {
    // If only a date is set (no specific time), find all meetings on this date
    const dayMeetings = meetings.filter((m) => !m.deleted && m.date === date);
    if (dayMeetings.length >= 4) {
      return {
        hasConflict: true,
        conflicts: dayMeetings.map((m) => ({
          id: m.id,
          type: 'meeting',
          title: m.title,
          date: m.date,
          startTime: m.startTime,
          endTime: m.endTime,
        })),
        suggestedSlots: [],
        summaryMessage: `Heavy calendar day: You have ${dayMeetings.length} meetings scheduled on ${date}.`,
      };
    }
    return { hasConflict: false, conflicts: [], suggestedSlots: [], summaryMessage: '' };
  }

  const taskStart = time;
  const taskEnd = minutesToTime(timeToMinutes(time) + duration);

  const conflicts: ConflictItem[] = [];

  // Check against meetings
  for (const m of meetings) {
    if (m.deleted || m.date !== date) continue;
    if (m.allDay || intervalsOverlap(taskStart, taskEnd, m.startTime, m.endTime)) {
      conflicts.push({
        id: m.id,
        type: 'meeting',
        title: m.title || 'Untitled Meeting',
        date: m.date,
        startTime: m.startTime,
        endTime: m.endTime,
        isAllDay: m.allDay,
        location: m.location,
      });
    }
  }

  // Check against other timed tasks on the same date
  for (const t of tasks) {
    if (t.deleted || t.completed || (candidate.id && t.id === candidate.id)) continue;
    const tDate = t.dueDate?.includes('T') ? t.dueDate.split('T')[0] : t.dueDate;
    if (tDate !== date) continue;

    const tTime = t.scheduledTime || (t.dueDate?.includes('T') ? t.dueDate.split('T')[1]?.slice(0, 5) : null);
    if (!tTime) continue;

    const tEnd = minutesToTime(timeToMinutes(tTime) + 45);
    if (intervalsOverlap(taskStart, taskEnd, tTime, tEnd)) {
      conflicts.push({
        id: t.id,
        type: 'task',
        title: t.title || 'Untitled Task',
        date: tDate,
        startTime: tTime,
        endTime: tEnd,
        priority: t.priority,
      });
    }
  }

  const hasConflict = conflicts.length > 0;
  let summaryMessage = '';
  const suggestedSlots: Array<{ startTime: string; endTime: string; label: string }> = [];

  if (hasConflict) {
    const firstConflict = conflicts[0];
    summaryMessage = `Conflict alert: Task overlaps with ${firstConflict.type === 'meeting' ? 'meeting' : 'task'} "${firstConflict.title}" (${firstConflict.startTime} – ${firstConflict.endTime})`;

    const dayMeetings = meetings.filter((m) => !m.deleted && m.date === date);
    const freeSlot = findNextAvailableSlot(date, duration, dayMeetings);
    if (freeSlot) {
      suggestedSlots.push({
        startTime: freeSlot.startTime,
        endTime: freeSlot.endTime,
        label: `Free slot available (${freeSlot.startTime} – ${freeSlot.endTime})`,
      });
    }
  }

  return {
    hasConflict,
    conflicts,
    suggestedSlots,
    summaryMessage,
  };
}

/**
 * Finds the earliest available non-overlapping time slot of the specified duration.
 * Searches in typical active hours (09:00 - 18:00) with 15-minute increments.
 */
export function findNextAvailableSlot(
  date: string,
  durationMinutes: number,
  dayMeetings: Meeting[],
  startHour = 9,
  endHour = 18
): { startTime: string; endTime: string } | null {
  const step = 15; // 15-minute increments
  const startMinute = startHour * 60;
  const endMinute = endHour * 60;

  for (let current = startMinute; current + durationMinutes <= endMinute; current += step) {
    const candidateStart = minutesToTime(current);
    const candidateEnd = minutesToTime(current + durationMinutes);

    const hasClash = dayMeetings.some((m) => {
      if (m.deleted || m.date !== date) return false;
      if (m.allDay) return true;
      return intervalsOverlap(candidateStart, candidateEnd, m.startTime, m.endTime);
    });

    if (!hasClash) {
      return { startTime: candidateStart, endTime: candidateEnd };
    }
  }

  return null;
}
