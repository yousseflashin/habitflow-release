// Life Profile Aggregator — turns a history of daily activity results into everything
// the visualizations need: per-day heat, attribute levels, muscle development,
// brain development, and the Body/Mind/Spirit headline scores.
//
// Pure functions, no React, no storage. This is the single place where the
// "Actions → … → Life Development" hierarchy is actually computed.

import {
  Activity,
  ActivityPolarity,
  AttributeKey,
  ATTRIBUTES,
  ATTRIBUTE_KEYS,
  BrainRegion,
  computeBrainDevelopment,
  computeDayProgress,
  computeDimensionScores,
  computeInProgressMuscles,
  computeMuscleDevelopment,
  DayProgress,
  Dimension,
  DimensionScores,
  DailyActivityResult,
  emptyAccumulator,
  accumulateDay,
  levelsFromValues,
  MuscleGroup,
  MUSCLE_GROUPS,
  AttributeAccumulator,
} from './lifeProgressService';
import { format, subDays, eachDayOfInterval, parseISO, startOfDay } from 'date-fns';

/** Everything the Life Pulse dashboard renders. */
export interface LifeProfile {
  /** 'YYYY-MM-DD' → day cell, for the contribution calendar. */
  days: Map<string, DayProgress>;
  attributes: Record<AttributeKey, number>; // 0..100 levels
  rawAttributePoints: Record<AttributeKey, number>;
  dimensions: DimensionScores;
  muscles: Record<MuscleGroup, number>; // 0..100
  /** Muscles being trained right now, faint-red until the set finishes. */
  inProgressMuscles: Record<MuscleGroup, number>; // 0..100
  brain: Record<BrainRegion, number>; // 0..100
  /** Overall positive behavioural momentum, drives the body aura. 0..100. */
  aura: number;
  /** Positive vs. harmful behaviour balance, 0..100. */
  momentum: { positive: number; resisted: number; relapsed: number };
  streaks: { current: number; best: number; totalActiveDays: number };
  records: { bestDayScore: number; bestDayDate: string | null; longestMuscleStreak: number };
  /** Per-attribute trend: current level minus level N days ago. */
  trends: Record<AttributeKey, number>;
  /**
   * True once there is real history behind the visualizations.
   *
   * With zero logged results every derived level is 0, which renders the radar
   * as a single dot at its centre and the body map as an unlit outline — a
   * broken-looking shell. Views gate their charts on this flag and show a
   * coaching panel instead.
   */
  visualizationReady: boolean;
}

export interface AggregateOptions {
  /** Reference total the user aims for per day; days are normalized against this. */
  dayReferenceTotal?: number;
  /** How many days of history to scan. */
  lookbackDays?: number;
  /** Half-life for the consistency attribute's recency weighting. */
  consistencyHalfLife?: number;
  /** Global intensity multiplier for muscle/brain development (user preference). */
  displayIntensity?: number;
  today?: Date;
}

const DEFAULTS: Required<Omit<AggregateOptions, 'today'>> = {
  dayReferenceTotal: 3,
  lookbackDays: 371, // ~1 year, enough for a full year calendar
  consistencyHalfLife: 21,
  displayIntensity: 1,
};

/**
 * Reference total for normalizing a day's score.
 *
 * A "full" day = every active activity actually hit its target. Dividing by that
 * total is what makes the heat map meaningful:
 *   a day where everything was done   -> ~1.0 -> level 4 (exceptional)
 *   a day where most was done         -> ~0.8 -> level 3 (meaningful)
 *   a day where little was done       -> ~0.3 -> level 1 (very low)
 *
 * If this value is too low (e.g. damped below the sum) almost every real day
 * saturates at level 4 and the calendar stops carrying information.
 */
function defaultReference(activities: Activity[]): number {
  const live = activities.filter((a) => !a.deleted && !a.archived);
  if (live.length === 0) return 1;
  // Each activity contributes ~1.0 on a day it meets its target; a clean day on a
  // harmful habit counts as 1.0 too, since resisting is the achievement.
  const sum = live.reduce(
    (s, a) => s + (a.polarity === 'negative' ? 1 : Math.max(0.25, a.intensity ?? 1)),
    0
  );
  return Math.max(1, sum);
}

/**
 * Group raw results by date.
 * Input can be sparse; the calendar fills gaps with empty cells.
 *
 * One (activity, date) pair must resolve to a single outcome. A relapse record
 * supersedes a clean record for the same day — a day you smoked is a relapse day,
 * not a day that counts as both. Multi-device sync can legitimately produce both
 * rows, so this dedupe is required for correctness, not just tidiness.
 */
function indexByDate(results: DailyActivityResult[]): Map<string, DailyActivityResult[]> {
  // Last write per (activityId, date) wins, with relapse taking precedence.
  const winner = new Map<string, DailyActivityResult>();
  for (const r of results) {
    const key = `${r.activityId}::${r.date}`;
    const prev = winner.get(key);
    if (!prev) {
      winner.set(key, r);
      continue;
    }
    const prevRelapsed = prev.relapsed || prev.actual > 0;
    const nextRelapsed = r.relapsed || r.actual > 0;
    if (nextRelapsed && !prevRelapsed) winner.set(key, r);
  }

  const map = new Map<string, DailyActivityResult[]>();
  for (const r of winner.values()) {
    const list = map.get(r.date);
    if (list) list.push(r);
    else map.set(r.date, [r]);
  }
  return map;
}

export function buildLifeProfile(
  activities: Activity[],
  results: DailyActivityResult[],
  options: AggregateOptions = {}
): LifeProfile {
  const opts = { ...DEFAULTS, ...options };
  const today = options.today ?? new Date();
  const todayStr = format(today, 'yyyy-MM-dd');

  const activitiesById = new Map(activities.map((a) => [a.id, a]));
  const byDate = indexByDate(results);
  const reference = options.dayReferenceTotal ?? defaultReference(activities);

  // Date window: lookback days through today.
  const start = startOfDay(subDays(today, opts.lookbackDays));
  const windowDates = eachDayOfInterval({ start, end: startOfDay(today) }).map((d) =>
    format(d, 'yyyy-MM-dd')
  );

  // ── Pass 1: per-day cells + accumulation ───────────────────────────────
  const days = new Map<string, DayProgress>();
  const muscleVolume: Partial<Record<MuscleGroup, number>> = {};
  const brainVolume: Partial<Record<string, number>> = {};
  const attributePoints = emptyAccumulator();

  let acc = emptyAccumulator();
  // Snapshot for trend computation: level 30 days ago.
  const snapshot30 = new Map<string, number>();
  let snapshotTaken = false;
  const snapshotAt = new Set(windowDates.slice(-1, -31));

  let bestDayScore = 0;
  let bestDayDate: string | null = null;
  let currentRun = 0;
  let bestRun = 0;
  let totalActiveDays = 0;
  let positive = 0;
  let resisted = 0;
  let relapsed = 0;

  for (const date of windowDates) {
    const dayResults = byDate.get(date) ?? [];
    const day = computeDayProgress(dayResults, activitiesById, reference);

    // The very first day of the window is not necessarily the user's start date, so
    // the current streak must not count leading empty days as a broken streak.
    if (dayResults.length > 0) {
      day.completedCount = day.completedCount;
    }

    days.set(date, day);

    if (day.score > 0) {
      totalActiveDays++;
      currentRun++;
      if (currentRun > bestRun) bestRun = currentRun;
      if (day.score > bestDayScore) {
        bestDayScore = day.score;
        bestDayDate = date;
      }
    } else if (date < todayStr) {
      currentRun = 0;
    }

    acc = accumulateDay(acc, day, dayResults, activitiesById, {
      halfLifeDays: opts.consistencyHalfLife,
    });

    if (snapshotAt.has(date) && !snapshotTaken) {
      ATTRIBUTE_KEYS.forEach((k) => snapshot30.set(k, acc.levels[k] ?? 0));
      snapshotTaken = true;
    }

    // Muscle + brain volume accumulate per day, decayed by recency.
    for (const r of dayResults) {
      const activity = activitiesById.get(r.activityId);
      if (!activity) continue;
      const score = computeDayProgress([r], activitiesById, 1).score;
      if (score <= 0) continue;

      const ageDays = windowDates.length - 1 - windowDates.indexOf(date);
      const recency = Math.pow(0.5, ageDays / 180); // 6-month half-life

      const muscles = activity.weights.muscles ?? {};
      (Object.keys(muscles) as MuscleGroup[]).forEach((g) => {
        const w = muscles[g] ?? 0;
        if (w > 0) muscleVolume[g] = (muscleVolume[g] ?? 0) + score * w * 20 * recency;
      });

      const attrs = activity.weights.attributes ?? {};
      ATTRIBUTES.forEach((def) => {
        if (def.dimension !== 'intelligence') return;
        const w = attrs[def.key] ?? 0;
        if (w <= 0) return;
        // Map attributes onto brain regions for the intelligence visualization.
        const region: BrainRegion =
          def.key === 'creativity' ? 'creativity'
          : def.key === 'focus' ? 'focus'
          : def.key === 'knowledge' ? 'knowledge'
          : def.key === 'intelligence' || def.key === 'learning' ? 'reasoning'
          : 'emotion';
        brainVolume[region] = (brainVolume[region] ?? 0) + score * w * 18 * recency;
      });
    }

    positive += day.completedCount;
    resisted += day.resistedCount;
    relapsed += day.relapsedCount;
  }

  // ── Pass 2: streaks ending today (empty leading days must not fake a streak) ──
  let currentStreak = 0;
  for (let i = windowDates.length - 1; i >= 0; i--) {
    const d = days.get(windowDates[i]);
    if (d && d.score > 0) currentStreak++;
    else if (windowDates[i] === todayStr) continue; // today is not over yet
    else break;
  }

  const attributes = acc.levels;
  const dimensions = computeDimensionScores(attributes);
  const muscles = computeMuscleDevelopment(muscleVolume, opts.displayIntensity);
  const inProgress = computeInProgressMuscles(activities, results);
  const inProgressMuscles = {} as Record<MuscleGroup, number>;
  MUSCLE_GROUPS.forEach((g) => { inProgressMuscles[g] = Math.round(inProgress[g] ?? 0); });
  const brain = computeBrainDevelopment(brainVolume);

  // ── Aura: overall positive behavioural momentum, NOT just exercise. ─────
  // Blends: dimension balance, consistency of showing up, and the
  // resisted-vs-relapsed ratio on harmful habits.
  //
  // A user with NO history must get no aura. The harmful-habit term therefore
  // carries weight only when harmful habits are actually being tracked — a
  // neutral 0.5 default would hand a brand-new account 24 free aura points.
  const consistencyLevel = attributes.consistency ?? 0;
  const harmfulTracked = resisted + relapsed > 0;
  const harmfulRatio = harmfulTracked ? resisted / (resisted + relapsed) : 0;

  // Re-weight so the three terms always sum to 1 regardless of which apply.
  const rawWeights = {
    dimensions: 0.45,
    consistency: 0.30,
    harmful: 0.25,
  };
  const activeWeights = {
    dimensions: rawWeights.dimensions,
    consistency: rawWeights.consistency,
    harmful: harmfulTracked ? rawWeights.harmful : 0,
  };
  const weightTotal = activeWeights.dimensions + activeWeights.consistency + activeWeights.harmful;

  const auraInput =
    ((dimensions.overall / 100) * activeWeights.dimensions +
      (consistencyLevel / 100) * activeWeights.consistency +
      harmfulRatio * activeWeights.harmful) /
    weightTotal;

  const aura = Math.round(100 * (1 - Math.exp(-auraInput * 2.2)));

  // ── Trends: current level minus level ~30 days ago ─────────────────────
  const trends = {} as Record<AttributeKey, number>;
  ATTRIBUTE_KEYS.forEach((k) => {
    const before = snapshot30.get(k);
    trends[k] = before === undefined ? 0 : (attributes[k] ?? 0) - before;
  });

  return {
    days,
    attributes,
    rawAttributePoints: acc.values,
    dimensions,
    muscles,
    inProgressMuscles,
    brain,
    aura,
    momentum: { positive, resisted, relapsed },
    streaks: { current: currentStreak, best: bestRun, totalActiveDays },
    records: {
      bestDayScore: Math.round(bestDayScore * 100) / 100,
      bestDayDate,
      longestMuscleStreak: bestRun,
    },
    trends,
    // "Ready" means there is at least one day in the window with a non-zero
    // score, not merely that activities exist. A single logged rep is enough to
    // make the radar and the body map meaningful.
    visualizationReady: totalActiveDays > 0,
  };
}

/** Build the default activity library a new user starts from. */
export function starterActivities(): Activity[] {
  const today = format(new Date(), 'yyyy-MM-dd');
  const base = { startDate: today, archived: false, deleted: false, intensity: 1 };

  return [
    {
      ...base,
      id: 'act_pushups',
      name: 'Push-ups',
      description: 'Target 10 reps. 1 rep counts as 10% — partial work is still work.',
      icon: 'dumbbell',
      color: '#f97316',
      polarity: 'positive',
      metric: 'reps',
      target: 10,
      unit: 'reps',
      maxDailyContribution: 1,
      weights: {
        body: 0.8, health: 0.05, intelligence: 0.1, spirit: 0.1,
        attributes: { strength: 0.9, discipline: 0.2 },
        muscles: { chest: 0.7, arms: 0.5, shoulders: 0.3, core: 0.2 },
      },
    },
    {
      ...base,
      id: 'act_water',
      name: 'Water',
      description: '8 glasses a day.',
      icon: 'droplet',
      color: '#38bdf8',
      polarity: 'positive',
      metric: 'quantity',
      target: 8,
      unit: 'glasses',
      weights: {
        body: 0.7, health: 0.05, intelligence: 0.05, spirit: 0.25,
        attributes: { recovery: 0.6, consistency: 0.4 },
      },
    },
    {
      ...base,
      id: 'act_reading',
      name: 'Reading',
      description: '30 minutes. 5 minutes is 17% — keep the streak honest, not binary.',
      icon: 'book',
      color: '#a78bfa',
      polarity: 'positive',
      metric: 'duration',
      target: 30,
      unit: 'min',
      weights: {
        body: 0.05, health: 0.05, intelligence: 0.75, spirit: 0.2,
        attributes: { knowledge: 0.9, intelligence: 0.4, focus: 0.3 },
      },
    },
    {
      ...base,
      id: 'act_meditation',
      name: 'Meditation',
      description: '10 minutes.',
      icon: 'sparkles',
      color: '#34d399',
      polarity: 'positive',
      metric: 'duration',
      target: 10,
      unit: 'min',
      weights: {
        body: 0.1, health: 0.05, intelligence: 0.4, spirit: 0.5,
        attributes: { focus: 0.6, reflection: 0.5, discipline: 0.3, selfControl: 0.4 },
      },
    },
    {
      ...base,
      id: 'act_walking',
      name: 'Walking',
      description: '5,000 steps.',
      icon: 'footprints',
      color: '#4ade80',
      polarity: 'positive',
      metric: 'quantity',
      target: 5000,
      unit: 'steps',
      weights: {
        body: 0.75, health: 0.05, intelligence: 0.15, spirit: 0.1,
        attributes: { endurance: 0.8, recovery: 0.3, consistency: 0.2 },
        muscles: { calves: 0.4, legs: 0.3, cardio: 0.8 },
      },
    },
    {
      ...base,
      id: 'act_sleep',
      name: 'Sleep',
      description: '8 hours.',
      icon: 'moon',
      color: '#818cf8',
      polarity: 'positive',
      metric: 'duration',
      target: 8,
      unit: 'h',
      weights: {
        body: 0.6, health: 0.05, intelligence: 0.25, spirit: 0.15,
        attributes: { recovery: 1.0, focus: 0.3 },
      },
    },
    {
      ...base,
      id: 'act_smoking',
      name: 'No smoking',
      description: 'One clean day is one successful day. Relapses are recorded, never erase history.',
      icon: 'shield',
      color: '#f43f5e',
      polarity: 'negative',
      metric: 'completion',
      target: 1,
      unit: 'day',
      maxDailyContribution: 1,
      weights: {
        body: 0.5, health: 0.05, intelligence: 0.1, spirit: 0.4,
        attributes: { selfControl: 1.0, discipline: 0.7, recovery: 0.5, endurance: 0.3 },
      },
    },
  ] as Activity[];
}
