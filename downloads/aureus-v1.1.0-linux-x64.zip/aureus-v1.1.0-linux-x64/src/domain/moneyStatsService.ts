// Money analytics — pure functions over the money state, shared by the
// Life Pulse dashboard (finance tiles), the Money page, and the Executive Wallet.
//
// Keeping the math here (not in either view) means the net-worth number
// the dashboard shows and the one the Money page shows can never drift.

import {
  format,
  startOfMonth,
  endOfMonth,
  startOfQuarter,
  endOfQuarter,
  startOfYear,
  endOfYear,
  getQuarter,
} from 'date-fns';
import type {
  AssetType,
  MoneyAccount,
  MoneyAccountType,
  MoneyAsset,
  MoneyTransaction,
} from '../types';

export type TimeframeRange = 'monthly' | 'quarterly' | 'yearly' | 'all';

export interface RangeDateWindow {
  start: string; // 'YYYY-MM-DD'
  end: string; // 'YYYY-MM-DD'
  label: string; // e.g. "November 2026", "Q4 2026", "2026", "All-Time"
  monthsCount: number;
}

export interface RangeMoneyStats {
  range: TimeframeRange;
  label: string;
  start: string;
  end: string;
  monthsCount: number;
  income: number;
  expense: number;
  netCashflow: number;
  savingsRate: number; // 0 to 100
  monthlyRunrateIncome: number;
  monthlyRunrateExpense: number;
  monthlyRunrateNet: number;
  quarterlyProjectedNet: number;
  yearlyProjectedNet: number;
  incomeByCategory: Record<string, number>;
  expenseByCategory: Record<string, number>;
  transactionCount: number;
}

export interface WalletFlowItem {
  id: string;
  name: string;
  type: 'income' | 'expense';
  amount: number; // Base amount for the specified period
  period: 'monthly' | 'quarterly' | 'yearly';
  category: string;
  accountId?: string;
  enabled: boolean;
  notes?: string;
  createdAt: string;
}

export interface MoneyStats {
  /** Cash + non-debt account balances. */
  cash: number;
  /** Absolute value of credit/debt account balances. */
  debt: number;
  /** Current market value of all held assets. */
  invested: number;
  /** Total cost basis of all held assets. */
  investedCost: number;
  /** invested - investedCost. */
  investedPnl: number;
  /** cash + invested - debt. */
  netWorth: number;
  /** This calendar month's money in. */
  income: number;
  /** This calendar month's money out (positive number). */
  expense: number;
  /** Value grouped by asset type, for the dashboard breakdown. */
  byAssetType: Partial<Record<AssetType, number>>;
  /** Balance grouped by account type. */
  byAccountType: Partial<Record<MoneyAccountType, number>>;
}

export const assetValue = (a: MoneyAsset): number => a.quantity * a.currentPrice;
export const assetCost = (a: MoneyAsset): number => a.quantity * a.avgCost;

/** 'YYYY-MM' prefix for the current month. */
export const monthPrefix = (): string => new Date().toISOString().slice(0, 7);

/** Currency-aware formatting shared by every money surface. */
export function fmtMoney(n: number, currency = 'USD'): string {
  const abs = Math.abs(n);
  const str = abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const sign = n < 0 ? '−' : '';
  const sym = currency === 'EUR' ? '€' : currency === 'GBP' ? '£' : '$';
  return `${sign}${sym}${str}`;
}

export function computeMoneyStats(
  accounts: MoneyAccount[],
  assets: MoneyAsset[],
  transactions: MoneyTransaction[],
  month = monthPrefix()
): MoneyStats {
  const liveAccounts = accounts.filter((a) => !a.deleted);
  const liveAssets = assets.filter((a) => !a.deleted);
  const liveTx = transactions.filter((t) => !t.deleted);

  const cash = liveAccounts
    .filter((a) => a.type !== 'credit' && a.type !== 'debt')
    .reduce((s, a) => s + a.balance, 0);
  const debt = liveAccounts
    .filter((a) => a.type === 'credit' || a.type === 'debt')
    .reduce((s, a) => s + Math.abs(a.balance), 0);
  const invested = liveAssets.reduce((s, a) => s + assetValue(a), 0);
  const investedCost = liveAssets.reduce((s, a) => s + assetCost(a), 0);

  const monthTx = liveTx.filter((t) => t.date >= `${month}-01`);
  const income = monthTx.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  const expense = monthTx
    .filter((t) => t.amount < 0)
    .reduce((s, t) => s + Math.abs(t.amount), 0);

  const byAssetType: Partial<Record<AssetType, number>> = {};
  for (const a of liveAssets) {
    byAssetType[a.type] = (byAssetType[a.type] ?? 0) + assetValue(a);
  }

  const byAccountType: Partial<Record<MoneyAccountType, number>> = {};
  for (const a of liveAccounts) {
    byAccountType[a.type] = (byAccountType[a.type] ?? 0) + a.balance;
  }

  return {
    cash,
    debt,
    invested,
    investedCost,
    investedPnl: invested - investedCost,
    netWorth: cash + invested - debt,
    income,
    expense,
    byAssetType,
    byAccountType,
  };
}

/** Calculates the exact start date, end date, and descriptive label for any timeframe range */
export function getTimeframeRangeDates(range: TimeframeRange, refDate: Date = new Date()): RangeDateWindow {
  if (range === 'monthly') {
    const start = format(startOfMonth(refDate), 'yyyy-MM-dd');
    const end = format(endOfMonth(refDate), 'yyyy-MM-dd');
    const label = format(refDate, 'MMMM yyyy');
    return { start, end, label, monthsCount: 1 };
  }

  if (range === 'quarterly') {
    const start = format(startOfQuarter(refDate), 'yyyy-MM-dd');
    const end = format(endOfQuarter(refDate), 'yyyy-MM-dd');
    const q = getQuarter(refDate);
    const label = `Q${q} ${format(refDate, 'yyyy')}`;
    return { start, end, label, monthsCount: 3 };
  }

  if (range === 'yearly') {
    const start = format(startOfYear(refDate), 'yyyy-MM-dd');
    const end = format(endOfYear(refDate), 'yyyy-MM-dd');
    const label = format(refDate, 'yyyy');
    return { start, end, label, monthsCount: 12 };
  }

  // All-time window
  return {
    start: '1970-01-01',
    end: '2099-12-31',
    label: 'All-Time',
    monthsCount: 12,
  };
}

/** Computes income, expenses, net cash flow, and monthly normalized runrates for any range */
export function computeRangeMoneyStats(
  transactions: MoneyTransaction[],
  range: TimeframeRange,
  refDate: Date = new Date()
): RangeMoneyStats {
  const window = getTimeframeRangeDates(range, refDate);
  const liveTx = transactions.filter((t) => !t.deleted);

  const rangeTx = range === 'all'
    ? liveTx
    : liveTx.filter((t) => t.date >= window.start && t.date <= window.end);

  const income = rangeTx.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  const expense = rangeTx.filter((t) => t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0);
  const netCashflow = income - expense;
  const savingsRate = income > 0 ? Math.max(0, Math.round((netCashflow / income) * 100)) : 0;

  const monthsCount = Math.max(1, window.monthsCount);
  const monthlyRunrateIncome = income / monthsCount;
  const monthlyRunrateExpense = expense / monthsCount;
  const monthlyRunrateNet = netCashflow / monthsCount;

  // Category breakdowns
  const incomeByCategory: Record<string, number> = {};
  const expenseByCategory: Record<string, number> = {};

  for (const t of rangeTx) {
    const cat = (t.note || (t.amount > 0 ? 'General Income' : 'General Expense')).trim();
    if (t.amount > 0) {
      incomeByCategory[cat] = (incomeByCategory[cat] || 0) + t.amount;
    } else {
      expenseByCategory[cat] = (expenseByCategory[cat] || 0) + Math.abs(t.amount);
    }
  }

  return {
    range,
    label: window.label,
    start: window.start,
    end: window.end,
    monthsCount,
    income,
    expense,
    netCashflow,
    savingsRate,
    monthlyRunrateIncome,
    monthlyRunrateExpense,
    monthlyRunrateNet,
    quarterlyProjectedNet: monthlyRunrateNet * 3,
    yearlyProjectedNet: monthlyRunrateNet * 12,
    incomeByCategory,
    expenseByCategory,
    transactionCount: rangeTx.length,
  };
}

/** Normalizes a planned cashflow item amount (monthly, quarterly, yearly) into the selected target range */
export function computeFlowItemAmountForRange(item: WalletFlowItem, targetRange: TimeframeRange): number {
  if (!item.enabled) return 0;

  // First convert item amount to monthly equivalent
  let monthlyEquivalent = item.amount;
  if (item.period === 'quarterly') monthlyEquivalent = item.amount / 3;
  else if (item.period === 'yearly') monthlyEquivalent = item.amount / 12;

  // Then scale monthly to the target range
  if (targetRange === 'monthly') return monthlyEquivalent;
  if (targetRange === 'quarterly') return monthlyEquivalent * 3;
  if (targetRange === 'yearly' || targetRange === 'all') return monthlyEquivalent * 12;
  return monthlyEquivalent;
}

/** Summarizes planned wallet cashflow items for a target range */
export function computeWalletFlowSummary(
  flows: WalletFlowItem[],
  targetRange: TimeframeRange
): {
  totalIncome: number;
  totalExpense: number;
  netFlow: number;
  savingsRate: number;
  monthlyRunrateIncome: number;
  monthlyRunrateExpense: number;
  monthlyRunrateNet: number;
} {
  const activeFlows = flows.filter((f) => f.enabled);

  const totalIncome = activeFlows
    .filter((f) => f.type === 'income')
    .reduce((s, f) => s + computeFlowItemAmountForRange(f, targetRange), 0);

  const totalExpense = activeFlows
    .filter((f) => f.type === 'expense')
    .reduce((s, f) => s + computeFlowItemAmountForRange(f, targetRange), 0);

  const netFlow = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? Math.max(0, Math.round((netFlow / totalIncome) * 100)) : 0;

  // Monthly normalized run-rates
  const monthlyRunrateIncome = activeFlows
    .filter((f) => f.type === 'income')
    .reduce((s, f) => s + computeFlowItemAmountForRange(f, 'monthly'), 0);

  const monthlyRunrateExpense = activeFlows
    .filter((f) => f.type === 'expense')
    .reduce((s, f) => s + computeFlowItemAmountForRange(f, 'monthly'), 0);

  const monthlyRunrateNet = monthlyRunrateIncome - monthlyRunrateExpense;

  return {
    totalIncome,
    totalExpense,
    netFlow,
    savingsRate,
    monthlyRunrateIncome,
    monthlyRunrateExpense,
    monthlyRunrateNet,
  };
}
