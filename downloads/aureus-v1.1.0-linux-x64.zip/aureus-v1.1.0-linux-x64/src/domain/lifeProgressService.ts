// Life Progress Engine — the bridge between raw actions and who the user is becoming.
//
//   Actions → Activities → Daily Progress → Attributes → Body/Mind/Spirit → Life Development
//
// Design rules baked in here:
//  * NOT binary. Progress = actual / target, scaled, then capped.
//  * Diminishing returns: overshooting a target helps, but sub-linearly, so 100 push-ups
//    does not flatten every other day in the contribution calendar.
//  * One action can never max an attribute. Per-day contribution is capped and the
//    attribute curve is asymptotic (half-saturation), so attributes grow over weeks.
//  * Quitting a harmful habit scores POSITIVE progress — resisting is an achievement.
//  * Recovery is rewarded: a relapse costs a day, it never rewrites history.

/**
 * The four primary dimensions of the whole-life model.
 * `mind` was renamed to `intelligence` and `health` split out of `body`
 * so the radar shows Body | Health | Intelligence | Spirit.
 */
export type Dimension = 'body' | 'health' | 'intelligence' | 'spirit';

export const DIMENSIONS: Dimension[] = ['body', 'health', 'intelligence', 'spirit'];

/**
 * High-level life attributes surfaced on the radar. These are NOT raw habits —
 * they are the compressed, normalized reading of many activities.
 */
export type AttributeKey =
  // BODY
  | 'strength'
  | 'endurance'
  | 'mobility'
  // HEALTH
  | 'recovery'
  // INTELLIGENCE
  | 'intelligence'
  | 'knowledge'
  | 'focus'
  | 'creativity'
  | 'learning'
  // SPIRIT
  | 'discipline'
  | 'consistency'
  | 'purpose'
  | 'selfControl'
  | 'reflection';

export interface AttributeDefinition {
  key: AttributeKey;
  label: string;
  dimension: Dimension;
  /** Short line shown in the legend. */
  blurb: string;
  /** How fast this attribute saturates. Higher = builds faster from activity. */
  gain: number;
}

export const ATTRIBUTES: AttributeDefinition[] = [
  { key: 'strength',      label: 'Strength',      dimension: 'body',         blurb: 'Force produced against resistance',        gain: 1.0 },
  { key: 'endurance',     label: 'Endurance',     dimension: 'body',         blurb: 'Sustained capacity over time',              gain: 1.0 },
  { key: 'mobility',      label: 'Mobility',      dimension: 'body',         blurb: 'Range of motion and flexibility',           gain: 1.15 },
  { key: 'recovery',      label: 'Recovery',      dimension: 'health',       blurb: 'Sleep, rest and restoration',               gain: 0.9 },
  { key: 'intelligence',  label: 'Intelligence',  dimension: 'intelligence',   blurb: 'Reasoning and problem solving',             gain: 0.85 },
  { key: 'knowledge',     label: 'Knowledge',     dimension: 'intelligence',   blurb: 'Accumulated understanding',                 gain: 0.9 },
  { key: 'focus',         label: 'Focus',         dimension: 'intelligence',   blurb: 'Sustained attention without drift',         gain: 1.0 },
  { key: 'creativity',    label: 'Creativity',    dimension: 'intelligence',   blurb: 'Original thought and expression',           gain: 1.05 },
  { key: 'learning',     label: 'Learning',     dimension: 'intelligence', blurb: 'Rate of acquiring new skill',       gain: 1.0 },
  { key: 'discipline',   label: 'Discipline',   dimension: 'spirit', blurb: 'Doing what is required, not merely wanted', gain: 0.95 },
  { key: 'consistency',  label: 'Consistency',  dimension: 'spirit', blurb: 'Showing up repeatedly over long spans',     gain: 0.8 },
  { key: 'purpose',       label: 'Purpose',       dimension: 'spirit', blurb: 'Alignment with what you say matters',      gain: 0.75 },
  { key: 'selfControl',   label: 'Self-control', dimension: 'spirit', blurb: 'Resisting the harmful, choosing the good',  gain: 1.1 },
  { key: 'reflection',    label: 'Reflection',    dimension: 'spirit', blurb: 'Looking honestly at yourself',              gain: 0.9 },
];

export const ATTRIBUTE_KEYS: AttributeKey[] = ATTRIBUTES.map((a) => a.key);

/**
 * The one place a dimension's colour is defined. Every chart (radar, calendar,
 * body visual) imports this so a palette change lands everywhere at once.
 */
export const DIMENSION_COLOR: Record<Dimension, string> = {
  body: '#f97316',
  health: '#38bdf8',
  intelligence: '#a78bfa',
  spirit: '#34d399',
};

/** Muscle groups on the body visualization. */
export type MuscleGroup =
  | 'chest' | 'back' | 'shoulders' | 'arms' | 'legs' | 'core' | 'cardio' | 'calves';

export const MUSCLE_GROUPS: MuscleGroup[] = [
  'chest', 'back', 'shoulders', 'arms', 'legs', 'core', 'cardio', 'calves',
];

// ───────────────────────────────────────────────────────────────────────────
// Activity model
// ───────────────────────────────────────────────────────────────────────────

/** How the user measures an activity. Drives input UI and target semantics. */
export type ActivityMetric =
  | 'completion'   // "One successful day counts" — push-up-free habits, quitting smoking
  | 'reps'         // count of repetitions
  | 'quantity'     // glasses, pages, servings
  | 'duration'     // minutes
  | 'distance'     // km / m
  | 'percentage'   // % of a goal
  | 'custom';      // anything else, label comes from `unit`

export interface ActivityWeights {
  /** Contribution to each life dimension, 0..1. They SHOULD sum to ~1. */
  body: number;
  health: number;
  intelligence: number;
  spirit: number;
  /** Per-attribute multipliers, 0..1. Missing keys mean 0. */
  attributes?: Partial<Record<AttributeKey, number>>;
  /** Muscle groups this activity trains, with intensity weight. */
  muscles?: Partial<Record<MuscleGroup, number>>;
  /**
   * Muscle groups this activity trains RIGHT NOW (a session in progress).
   * Same shape as `muscles`, but scored with the partial-set credit
   * below and rendered faint-red on the body map until finished.
   */
  activeMuscles?: Partial<Record<MuscleGroup, number>>;
}

export type ActivityPolarity = 'positive' | 'negative';

export interface Activity {
  id: string;
  name: string;
  description?: string;
  icon: string;
  color: string;
  polarity: ActivityPolarity;
  metric: ActivityMetric;
  /** Daily target in `unit`. For 'completion' metrics this is 1. */
  target: number;
  unit: string;
  weights: ActivityWeights;
  /**
   * Hard ceiling on how much this single activity can add in one day.
   * Prevents one obsessive session from dominating the whole profile.
   */
  maxDailyContribution?: number;
  /** Global multiplier on every contribution (user-tunable strength). 0..2, default 1. */
  intensity?: number;
  /** Planned set count for set-based activities (default 1). Drives partial-set credit. */
  targetSets?: number;
  startDate: string;
  archived?: boolean;
  deleted?: boolean;
}

// ───────────────────────────────────────────────────────────────────────────
// Per-day progress
// ───────────────────────────────────────────────────────────────────────────

/**
 * One activity's result on one day.
 * For negative activities, `actual` is the harmful exposure and
 * `completed` means "stayed clean" (resisted).
 */
export interface DailyActivityResult {
  activityId: string;
  date: string; // 'YYYY-MM-DD'
  actual: number;
  completed: boolean;
  /** Set when a negative activity was relapsed into that day. */
  relapsed?: boolean;
  /**
   * Sets finished so far today for set-based activities, e.g. 2 of 3.
   * Drives the partial-set credit: a finished set scores immediately,
   * quitting early scores a fraction of the remaining set.
   */
  setsDone?: number;
}

export interface DayProgress {
  date: string;
  /** Sum of capped per-activity scores, 0..1 normalized-ish. */
  score: number;
  /** 0 = empty, 1..4 = the four visible heat levels. */
  intensity: 0 | 1 | 2 | 3 | 4;
  completedCount: number;
  resistedCount: number;
  relapsedCount: number;
  dimensionSplit: Record<Dimension, number>;
}

// ───────────────────────────────────────────────────────────────────────────
// Scoring
// ───────────────────────────────────────────────────────────────────────────

/** Extra credit available from overshooting a target, expressed as a fraction of 1.0. */
const OVERSHOOT_CREDIT = 0.35;
/** Hard ceiling on a single activity's daily score — keeps the calendar readable. */
const MAX_DAILY_RATIO = 1 + OVERSHOOT_CREDIT; // 1.35
/** How quickly overshoot saturates. Larger = a 2× day earns closer to full surplus credit. */
const OVERSHOOT_TAU = 2;

/**
 * Dimension split of a single activity, normalized so the three parts sum to 1.
 * This is what makes the model user-defined: Gym → 80/10/10 behaves as configured.
 */
export function normalizeDimensionWeights(w: ActivityWeights): Record<Dimension, number> {
  const body = Math.max(0, w.body || 0);
  const health = Math.max(0, w.health || 0);
  const intelligence = Math.max(0, w.intelligence || 0);
  const spirit = Math.max(0, w.spirit || 0);
  const total = body + health + intelligence + spirit;
  if (total <= 0) {
    // Default split when the user has not configured one.
    return { body: 0.3, health: 0.25, intelligence: 0.25, spirit: 0.2 };
  }
  return {
    body: body / total,
    health: health / total,
    intelligence: intelligence / total,
    spirit: spirit / total,
  };
}

/**
 * Ratio of work done to target, with sub-linear credit past 100%.
 *   target 10 push-ups:  1 -> 0.10,  5 -> 0.50,  10 -> 1.00,  25 -> 1.22, 100 -> 1.35
 */
export function progressRatio(actual: number, target: number): number {
  if (target <= 0) return actual > 0 ? 1 : 0;
  const ratio = actual / target;
  if (ratio <= 1) return Math.max(0, ratio);
  // Past target: log-shaped credit for the surplus, saturating at MAX_DAILY_RATIO.
  //   2x target -> ~1.16,  10x -> ~1.31,  100x -> ~1.35
  const surplus = 1 - 1 / (1 + (ratio - 1) / OVERSHOOT_TAU);
  return 1 + surplus * OVERSHOOT_CREDIT;
}

/**
 * Per-day score of one activity, 0..1 nominal (can slightly exceed 1 with overshoot).
 * Negative activities score HIGH when the user resists — refusing to smoke is a win.
 */
export function activityDayScore(activity: Activity, result: DailyActivityResult): number {
  if (activity.polarity === 'negative') {
    if (result.relapsed || result.actual > 0) {
      // Harm happened. No progress credit for this day; the relapse is recorded as an
      // event, but previously accumulated history stays intact.
      return 0;
    }
    // Clean day on a harmful habit: resisting is the achievement. Full credit.
    return 1;
  }

  const ratio = progressRatio(result.actual, activity.target);
  const scaled = ratio * (activity.intensity ?? 1);

  // maxDailyContribution caps how much this one activity can contribute per day.
  // Expressed as a multiple of "one full target day" (default 1).
  const cap = Math.max(0.1, activity.maxDailyContribution ?? 1) * MAX_DAILY_RATIO;

  return Math.min(Math.max(0, scaled), cap);
}

/**
 * Score a whole day from every activity result.
 * `intensity` maps the raw score to the 5 visible calendar levels, using a
 * fixed reference so colours stay stable over months (not relative to the
 * user's best-ever day, which would make today always look dim).
 */
export function computeDayProgress(
  results: DailyActivityResult[],
  activitiesById: Map<string, Activity>,
  dayReferenceTotal: number
): DayProgress {
  const split: Record<Dimension, number> = { body: 0, health: 0, intelligence: 0, spirit: 0 };
  let score = 0;
  let completed = 0;
  let resisted = 0;
  let relapsed = 0;

  for (const r of results) {
    const activity = activitiesById.get(r.activityId);
    if (!activity) continue;

    const s = activityDayScore(activity, r);
    if (activity.polarity === 'negative') {
      if (r.relapsed || r.actual > 0) relapsed++;
      else resisted++;
    } else if (r.completed || r.actual >= activity.target) {
      completed++;
    }

    const w = normalizeDimensionWeights(activity.weights);
    split.body += s * w.body;
    split.health += s * w.health;
    split.intelligence += s * w.intelligence;
    split.spirit += s * w.spirit;
    score += s;
  }

  // Normalize by the user's own daily reference (how much they typically aim for),
  // with a floor so a light day still registers. This keeps the heat map meaningful
  // whether the user has 3 activities or 30.
  const ref = Math.max(dayReferenceTotal, score, 1);
  const normalized = score / ref;

  return {
    date: results[0]?.date ?? '',
    score,
    intensity: toIntensity(normalized),
    completedCount: completed,
    resistedCount: resisted,
    relapsedCount: relapsed,
    dimensionSplit: split,
  };
}

/**
 * 5-level heat mapping. Fixed thresholds — NOT relative to the user's history, so
 * colours stay stable month to month instead of always looking dim.
 *
 * The top band is intentionally narrow: level 4 ("exceptional") should mean an
 * unusually complete day, not merely a normal one. A day that only just clears 80%
 * lands at level 3 ("meaningful").
 */
export function toIntensity(normalized: number): 0 | 1 | 2 | 3 | 4 {
  if (normalized <= 0) return 0;
  if (normalized < 0.2) return 1;  // very low
  if (normalized < 0.45) return 2; // low
  if (normalized < 0.75) return 3; // meaningful
  return 4;                        // exceptional
}

// ───────────────────────────────────────────────────────────────────────────
// Attribute accumulation
// ───────────────────────────────────────────────────────────────────────────

export interface AttributeAccumulator {
  values: Record<AttributeKey, number>; // raw 0..∞ "effort points"
  levels: Record<AttributeKey, number>; // normalized 0..100 for display
}

export function emptyAccumulator(): AttributeAccumulator {
  const values = {} as Record<AttributeKey, number>;
  const levels = {} as Record<AttributeKey, number>;
  ATTRIBUTE_KEYS.forEach((k) => {
    values[k] = 0;
    levels[k] = 0;
  });
  return { values, levels };
}

/**
 * Fold one day's results into the accumulator.
 *
 * Consistency is a first-class attribute: it is derived from how many recent days
 * carried real activity, not from any single activity's declared weights.
 */
export function accumulateDay(
  acc: AttributeAccumulator,
  day: DayProgress,
  results: DailyActivityResult[],
  activitiesById: Map<string, Activity>,
  opts: { halfLifeDays: number }
): AttributeAccumulator {
  const values = { ...acc.values };

  for (const r of results) {
    const activity = activitiesById.get(r.activityId);
    if (!activity) continue;
    const score = activityDayScore(activity, r);
    if (score <= 0) continue;

    const attrWeights = activity.weights.attributes ?? {};
    (Object.keys(attrWeights) as AttributeKey[]).forEach((key) => {
      const w = attrWeights[key] ?? 0;
      if (w <= 0) return;
      const def = ATTRIBUTES.find((a) => a.key === key);
      const gain = def?.gain ?? 1;
      values[key] = (values[key] ?? 0) + score * w * gain;
    });
  }

  // Consistency accrues from showing up, scaled by the day's overall effort.
  if (day.score > 0) {
    const h = opts.halfLifeDays;
    // Exponential forgetting: recent days matter more, old days still count.
    const recency = Math.pow(0.5, 1 / Math.max(1, h));
    values.consistency += day.score * 0.12 * recency;
  }

  return { values, levels: levelsFromValues(values) };
}

/**
 * Convert raw effort points into a 0..100 display level using an asymptotic curve.
 * 100 effort points ≈ 63 on the scale; 500 ≈ 99. Nothing saturates instantly.
 */
export function levelsFromValues(values: Record<AttributeKey, number>): Record<AttributeKey, number> {
  const levels = {} as Record<AttributeKey, number>;
  ATTRIBUTE_KEYS.forEach((k) => {
    const v = Math.max(0, values[k] ?? 0);
    levels[k] = Math.round(100 * (1 - Math.exp(-v / 160)));
  });
  return levels;
}

/** Body / Health / Intelligence / Spirit headline scores, each 0..100. */
export interface DimensionScores {
  body: number;
  health: number;
  intelligence: number;
  spirit: number;
  overall: number;
}

export function computeDimensionScores(
  levels: Record<AttributeKey, number>
): DimensionScores {
  const byDim = (dim: Dimension): number => {
    const keys = ATTRIBUTES.filter((a) => a.dimension === dim).map((a) => a.key);
    if (keys.length === 0) return 0;
    return keys.reduce((s, k) => s + (levels[k] ?? 0), 0) / keys.length;
  };

  const body = byDim('body');
  const health = byDim('health');
  const intelligence = byDim('intelligence');
  const spirit = byDim('spirit');

  return {
    body: Math.round(body),
    health: Math.round(health),
    intelligence: Math.round(intelligence),
    spirit: Math.round(spirit),
    overall: Math.round((body + health + intelligence + spirit) / 4),
  };
}

/**
 * Muscle-group development, 0..100, for the body visualization.
 * Gradual by construction: each group's level comes from its own asymptotic curve
 * on accumulated training volume, so one workout cannot develop anything.
 */
export function computeMuscleDevelopment(
  muscleVolume: Partial<Record<MuscleGroup, number>>,
  userIntensity: number
): Record<MuscleGroup, number> {
  const out = {} as Record<MuscleGroup, number>;
  const scale = Math.max(0.2, Math.min(3, userIntensity || 1));
  MUSCLE_GROUPS.forEach((g) => {
    const v = (muscleVolume[g] ?? 0) * scale;
    out[g] = Math.round(100 * (1 - Math.exp(-v / 220)));
  });
  return out;
}

/**
 * Partial-set credit for a session in progress, 0..1 per set.
 *
 *   setsDone = 2 of 3 sets, each of 12 reps:
 *     finished sets score fully (2/3); the abandoned remainder scores a
 *     fraction of itself from the reps already banked (0 of 12 -> 0).
 *   Quitting after 6 of 12 reps on the last set: 2/3 + (1/3)*(6/12) = 0.83.
 *
 * `actual` is total reps done today, `target` total reps planned
 * (sets × reps), `totalSets` the planned set count.
 */
export function partialSetCredit(
  actual: number,
  target: number,
  totalSets: number,
  setsDone: number
): number {
  if (target <= 0 || totalSets <= 0) return 0;
  const done = Math.max(0, Math.min(totalSets, Math.floor(setsDone)));
  const finishedCredit = done / totalSets;
  // Reps banked on the unfinished set, if any.
  const remainingTarget = Math.max(0, target - (done * target) / totalSets);
  const remainingActual = Math.max(0, actual - (done * target) / totalSets);
  const partialCredit =
    remainingTarget > 0 ? (remainingActual / remainingTarget) * (1 / totalSets) : 0;
  return Math.min(1, finishedCredit + partialCredit);
}

/**
 * In-progress muscle levels, 0..100, for muscles being trained RIGHT NOW.
 * Each finished set adds +1 point (scaled by the group's weight); a
 * half-finished set adds a proportional fraction. Faint-red on the map.
 */
export function computeInProgressMuscles(
  activities: Activity[],
  results: DailyActivityResult[]
): Partial<Record<MuscleGroup, number>> {
  const out: Partial<Record<MuscleGroup, number>> = {};
  for (const r of results) {
    const activity = activities.find((a) => a.id === r.activityId);
    if (!activity || activity.polarity === 'negative') continue;
    const active = activity.weights.activeMuscles ?? activity.weights.muscles ?? {};
    const credit = partialSetCredit(
      r.actual,
      activity.target,
      Math.max(1, activity.targetSets ?? 1),
      r.setsDone ?? 0
    );
    if (credit <= 0) continue;
    (Object.keys(active) as MuscleGroup[]).forEach((g) => {
      const w = active[g] ?? 0;
      if (w <= 0) return;
      // +1 per finished set, fractionally for a half-done set,
      // weighted by how hard the activity trains that group.
      out[g] = Math.min(100, (out[g] ?? 0) + credit * w * activity.targetSets!);
    });
  }
  return out;
}

/** Brain-region development for the intelligence visualization, 0..100. */
export type BrainRegion = 'reasoning' | 'knowledge' | 'focus' | 'creativity' | 'emotion';

export const BRAIN_REGIONS: BrainRegion[] = ['reasoning', 'knowledge', 'focus', 'creativity', 'emotion'];

export function computeBrainDevelopment(
  regionVolume: Partial<Record<string, number>>
): Record<BrainRegion, number> {
  const map: Record<BrainRegion, number> = {
    reasoning: 0,
    knowledge: 0,
    focus: 0,
    creativity: 0,
    emotion: 0,
  };
  (Object.keys(map) as BrainRegion[]).forEach((r) => {
    const v = regionVolume[r] ?? 0;
    map[r] = Math.round(100 * (1 - Math.exp(-v / 200)));
  });
  return map;
}
