// Reminder Engine — unlimited same-day reminders, with completion and missed tracking.
//
// Explicitly NOT capped: an activity may have 3, 5, or 50 reminders in one day.
// Everything here is O(reminders), with no artificial per-day limit anywhere.

import { format, parseISO, getDay, isBefore, isAfter, startOfDay, addDays } from 'date-fns';

/** One reminder on one activity. */
export interface ActivityReminder {
  id: string;
  activityId: string;
  /** 'HH:mm', 24h. */
  time: string;
  label?: string;
  enabled: boolean;
  /** 0=Sun..6=Sat. Undefined/empty = fires on every scheduled day. */
  daysOfWeek?: number[];
  /** Inclusive bounds on the reminder's own lifetime. */
  startDate?: string;
  endDate?: string;
  /** Minutes to postpone when snoozed. */
  snoozeMinutes?: number;
}

/** How a reminder resolved on a given day. */
export type ReminderState = 'upcoming' | 'fired' | 'completed' | 'missed' | 'snoozed' | 'disabled';

export interface ResolvedReminder {
  reminder: ActivityReminder;
  /** Full ISO timestamp for this occurrence. */
  at: Date;
  state: ReminderState;
  /** Minutes until it fires; negative once overdue. */
  minutesUntil: number;
}

export interface ReminderOccurrenceRecord {
  reminderId: string;
  activityId: string;
  date: string; // 'YYYY-MM-DD' of the occurrence
  time: string;
  completedAt?: string | null;
  missedAt?: string | null;
  snoozedUntil?: string | null;
  snoozeCount?: number;
}

const DEFAULT_SNOOZE = 10;

/** Stable id generator that does not need crypto (works in every runtime we target). */
let seq = 0;
export function newReminderId(activityId: string, time: string): string {
  seq += 1;
  return `${activityId}_${time.replace(':', '')}_${Date.now().toString(36)}_${seq}`;
}

/**
 * Validate a proposed reminder set. There is deliberately no count limit —
 * only real conflicts and malformed values are rejected.
 */
export function validateReminders(
  reminders: Array<Partial<ActivityReminder>>
): { ok: true } | { ok: false; errors: string[] } {
  const errors: string[] = [];
  const seen = new Set<string>();

  for (const r of reminders) {
    if (!r.time || !/^\d{2}:\d{2}$/.test(r.time)) {
      errors.push(`Invalid time "${r.time ?? ''}" — expected HH:mm.`);
      continue;
    }
    const [h, m] = r.time.split(':').map(Number);
    if (h > 23 || m > 59) {
      errors.push(`Time ${r.time} is out of range.`);
      continue;
    }
    if (r.daysOfWeek) {
      for (const d of r.daysOfWeek) {
        if (d < 0 || d > 6) errors.push(`Invalid day of week ${d} (use 0=Sun … 6=Sat).`);
      }
    }
    if (r.startDate && r.endDate && isAfter(parseISO(r.startDate), parseISO(r.endDate))) {
      errors.push(`Start date is after end date (${r.startDate} → ${r.endDate}).`);
    }
    // Duplicate detection is a UX nicety, not a limit: two identical times are legal,
    // but flag them so the user notices a likely mistake.
    const key = `${r.time}|${(r.daysOfWeek ?? []).slice().sort().join(',')}`;
    if (seen.has(key)) {
      errors.push(`Duplicate reminder at ${r.time} on the same days.`);
    }
    seen.add(key);
  }

  return errors.length === 0 ? { ok: true } : { ok: false, errors };
}

/** Does this reminder apply on this date? Respects days-of-week and date bounds. */
export function reminderAppliesOn(r: ActivityReminder, date: Date): boolean {
  if (!r.enabled) return false;
  const day = getDay(date);

  if (r.startDate && isBefore(startOfDay(date), startOfDay(parseISO(r.startDate)))) return false;
  if (r.endDate && isAfter(startOfDay(date), startOfDay(parseISO(r.endDate)))) return false;

  // No daysOfWeek means "every day the activity is scheduled".
  if (r.daysOfWeek && r.daysOfWeek.length > 0 && !r.daysOfWeek.includes(day)) return false;

  return true;
}

/**
 * Expand every reminder into concrete occurrences for a single date.
 * Multiple reminders for the same activity on the same day are all returned —
 * this is the whole point of the feature.
 */
export function resolveRemindersForDate(
  reminders: ActivityReminder[],
  date: Date,
  records: ReminderOccurrenceRecord[] = [],
  now: Date = new Date()
): ResolvedReminder[] {
  const dateStr = format(date, 'yyyy-MM-dd');
  const recordById = new Map(records.filter((r) => r.date === dateStr).map((r) => [r.reminderId, r]));

  const out: ResolvedReminder[] = [];

  for (const r of reminders) {
    if (!reminderAppliesOn(r, date)) continue;

    const [h, m] = r.time.split(':').map(Number);
    const at = new Date(date);
    at.setHours(h, m, 0, 0);

    const record = recordById.get(r.id);
    let state: ReminderState;

    if (record?.completedAt) {
      state = 'completed';
    } else if (record?.snoozedUntil) {
      state = 'snoozed';
    } else if (!r.enabled) {
      state = 'disabled';
    } else if (isAfter(at, now)) {
      state = 'upcoming';
    } else {
      // Past its time and not completed: missed.
      state = 'missed';
    }

    out.push({
      reminder: r,
      at,
      state,
      minutesUntil: Math.round((at.getTime() - now.getTime()) / 60000),
    });
  }

  return out.sort((a, b) => a.at.getTime() - b.at.getTime());
}

/** Occurrences across a date range, for the calendar and the Today view. */
export function resolveRemindersInRange(
  reminders: ActivityReminder[],
  from: Date,
  to: Date,
  records: ReminderOccurrenceRecord[] = []
): ResolvedReminder[] {
  const out: ResolvedReminder[] = [];
  const cursor = startOfDay(from);
  const end = startOfDay(to);

  while (cursor <= end) {
    out.push(
      ...resolveRemindersForDate(
        reminders,
        cursor,
        records,
        // State for future days is "upcoming" regardless of the real clock.
        cursor > new Date() ? addDays(cursor, 1) : new Date()
      )
    );
    cursor.setDate(cursor.getDate() + 1);
  }

  return out;
}

/** Build the canonical 07:00 / 09:00 / 11:00 / … multi-reminder set from the brief. */
export function parseReminderTimeList(spec: string): string[] {
  return spec
    .split(/[,\s]+/)
    .map((t) => t.trim())
    // Format AND range: "25:99" is well-shaped but not a real clock time.
    .filter((t) => {
      const m = /^(\d{2}):(\d{2})$/.exec(t);
      if (!m) return false;
      return Number(m[1]) <= 23 && Number(m[2]) <= 59;
    })
    .sort();
}

/** Group a day's occurrences by activity, preserving order — the Today timeline. */
export function groupByActivity(list: ResolvedReminder[]): Map<string, ResolvedReminder[]> {
  const map = new Map<string, ResolvedReminder[]>();
  for (const item of list) {
    const key = item.reminder.activityId;
    const existing = map.get(key);
    if (existing) existing.push(item);
    else map.set(key, [item]);
  }
  return map;
}

/** Summary counters for the Today view. */
export function summarizeReminders(list: ResolvedReminder[]) {
  return {
    total: list.length,
    upcoming: list.filter((r) => r.state === 'upcoming' || r.state === 'snoozed').length,
    completed: list.filter((r) => r.state === 'completed').length,
    missed: list.filter((r) => r.state === 'missed').length,
  };
}
