// Statistics & Analytics Aggregation Service

import { Task, Habit, HabitLog, HabitRelapseLog } from '../types';
import { HabitService } from './habitService';
import { format, subDays, parseISO, isSameDay } from 'date-fns';

export interface AggregateStats {
  tasks: {
    total: number;
    completed: number;
    pending: number;
    overdue: number;
    completionRate: number;
    completedThisWeek: number;
    byPriority: { p1: number; p2: number; p3: number; p4: number };
    byProject: Record<string, { total: number; completed: number }>;
  };
  habits: {
    total: number;
    activeToday: number;
    completedToday: number;
    todayCompletionRate: number;
    averageConsistencyRate: number;
    longestCurrentStreak: number;
    bestOverallStreak: number;
    habitBreakdown: Array<{
      habitId: string;
      habitName: string;
      color: string;
      icon: string;
      currentStreak: number;
      bestStreak: number;
      completionRate30d: number;
      totalCompletions: number;
    }>;
  };
  weeklyActivity: Array<{
    date: string;
    dayLabel: string;
    tasksCompleted: number;
    habitsCompleted: number;
  }>;
}

export class AnalyticsService {
  public static calculateOverview(
    tasks: Task[],
    habits: Habit[],
    habitLogsMap: Map<string, HabitLog>,
    habitRelapses: Map<string, HabitRelapseLog> = new Map(),
    today: Date = new Date()
  ): AggregateStats {
    const todayStr = format(today, 'yyyy-MM-dd');
    const nonDeletedTasks = tasks.filter(t => !t.deleted && !t.isArchived);
    const nonDeletedHabits = habits.filter(h => !h.deleted && !h.archived);

    // --- TASK METRICS ---
    const totalTasks = nonDeletedTasks.length;
    const completedTasks = nonDeletedTasks.filter(t => t.completed).length;
    const pendingTasks = totalTasks - completedTasks;

    let overdueCount = 0;
    let completedThisWeek = 0;
    const weekAgo = subDays(today, 7);

    const byPriority = { p1: 0, p2: 0, p3: 0, p4: 0 };
    const byProject: Record<string, { total: number; completed: number }> = {};

    for (const t of nonDeletedTasks) {
      // Overdue check
      if (!t.completed && t.dueDate) {
        const due = parseISO(t.dueDate.substring(0, 10));
        if (due < today && !isSameDay(due, today)) {
          overdueCount += 1;
        }
      }

      // Completed this week
      if (t.completed && t.completedAt) {
        const compDate = parseISO(t.completedAt.substring(0, 10));
        if (compDate >= weekAgo) {
          completedThisWeek += 1;
        }
      }

      // Priority counts
      if (t.priority in byPriority) {
        byPriority[t.priority] += 1;
      }

      // Project breakdown
      const projId = t.projectId || 'inbox';
      if (!byProject[projId]) {
        byProject[projId] = { total: 0, completed: 0 };
      }
      byProject[projId].total += 1;
      if (t.completed) {
        byProject[projId].completed += 1;
      }
    }

    const taskCompletionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    // --- HABIT METRICS ---
    let activeToday = 0;
    let completedToday = 0;
    let longestCurrentStreak = 0;
    let bestOverallStreak = 0;
    let sumConsistency = 0;

    const habitBreakdown = [];

    for (const habit of nonDeletedHabits) {
      const stats = HabitService.calculateStats(habit, habitLogsMap, habitRelapses, today);
      const isScheduledToday = HabitService.isHabitScheduledForDate(habit, todayStr);

      if (isScheduledToday) {
        activeToday += 1;
        const log = habitLogsMap.get(`${habit.id}_${todayStr}`);
        if (log && log.completed && !log.deleted) {
          completedToday += 1;
        }
      }

      if (stats.currentStreak > longestCurrentStreak) {
        longestCurrentStreak = stats.currentStreak;
      }
      if (stats.bestStreak > bestOverallStreak) {
        bestOverallStreak = stats.bestStreak;
      }

      sumConsistency += stats.completionRate30Days;

      habitBreakdown.push({
        habitId: habit.id,
        habitName: habit.name,
        color: habit.color,
        icon: habit.icon,
        currentStreak: stats.currentStreak,
        bestStreak: stats.bestStreak,
        completionRate30d: stats.completionRate30Days,
        totalCompletions: stats.totalCompletions,
      });
    }

    const todayCompletionRate = activeToday > 0 ? Math.round((completedToday / activeToday) * 100) : 0;
    const avgConsistency = nonDeletedHabits.length > 0 ? Math.round(sumConsistency / nonDeletedHabits.length) : 0;

    // --- 7-DAY ACTIVITY TREND ---
    const weeklyActivity = [];
    const dayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    for (let i = 6; i >= 0; i--) {
      const d = subDays(today, i);
      const dStr = format(d, 'yyyy-MM-dd');
      const label = dayLabels[d.getDay()];

      let tComp = 0;
      for (const t of tasks) {
        if (t.completed && t.completedAt && t.completedAt.startsWith(dStr)) {
          tComp += 1;
        }
      }

      let hComp = 0;
      for (const h of nonDeletedHabits) {
        const log = habitLogsMap.get(`${h.id}_${dStr}`);
        if (log && log.completed && !log.deleted) {
          hComp += 1;
        }
      }

      weeklyActivity.push({
        date: dStr,
        dayLabel: i === 0 ? 'Today' : label,
        tasksCompleted: tComp,
        habitsCompleted: hComp,
      });
    }

    return {
      tasks: {
        total: totalTasks,
        completed: completedTasks,
        pending: pendingTasks,
        overdue: overdueCount,
        completionRate: taskCompletionRate,
        completedThisWeek,
        byPriority,
        byProject,
      },
      habits: {
        total: nonDeletedHabits.length,
        activeToday,
        completedToday,
        todayCompletionRate,
        averageConsistencyRate: avgConsistency,
        longestCurrentStreak,
        bestOverallStreak,
        habitBreakdown,
      },
      weeklyActivity,
    };
  }
}
