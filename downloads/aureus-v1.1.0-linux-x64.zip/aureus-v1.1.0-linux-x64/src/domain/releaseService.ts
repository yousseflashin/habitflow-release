// Release / download-center domain logic.
//
// Single source of truth: public/releases.json (see ReleasesPage data contract).
// The app NEVER hardcodes release data — it reads the manifest at runtime so shipping
// a new APK or desktop package is a file swap, not a code change.

/** One downloadable artifact for one platform at one version. */
export interface DownloadPackage {
  platform: 'android' | 'windows' | 'linux';
  fileName: string;
  downloadUrl: string;
  fileSize: string;
  sha256?: string;
  /** Optional install note shown when this specific package is selected. */
  installHint?: string;
}

/** One published version: metadata + the packages that were built for it. */
export interface ChangelogEntry {
  version: string;
  date: string; // 'YYYY-MM-DD'
  highlight: string; // one-line summary for the banner
  notes: string[];
  downloads: DownloadPackage[];
}

/** Top-level shape of public/releases.json. */
export interface ReleaseManifest {
  appName: string;
  /** Newest first. The renderer trusts index 0 as "latest". */
  releases: ChangelogEntry[];
}

/**
 * Compare two dotted version strings.
 * Returns  1 if a > b, -1 if a < b, 0 if equal.
 * Pre-release suffixes ("1.2.0-beta.1") sort BEFORE their release ("1.2.0").
 */
export function compareSemver(a: string, b: string): number {
  const parse = (v: string) => {
    const [core = '', pre = ''] = String(v).trim().replace(/^v/i, '').split('-');
    const nums = core.split('.').map((n) => {
      const parsed = parseInt(n, 10);
      return Number.isFinite(parsed) ? parsed : 0;
    });
    // Pad to 4 segments so 1.2 and 1.2.0.0 compare equal
    while (nums.length < 4) nums.push(0);
    return { nums, pre };
  };

  const A = parse(a);
  const B = parse(b);

  for (let i = 0; i < A.nums.length; i++) {
    if (A.nums[i] !== B.nums[i]) return A.nums[i] > B.nums[i] ? 1 : -1;
  }

  // Same core: a version with a pre-release tag is older than the plain release
  if (A.pre === B.pre) return 0;
  if (A.pre === '') return 1;
  if (B.pre === '') return -1;
  return A.pre > B.pre ? 1 : -1;
}

/** Best-effort platform detection so we can label "This device" and default the download CTA. */
export function detectPlatform(): 'android' | 'windows' | 'linux' | 'unknown' {
  if (typeof navigator === 'undefined') return 'unknown';

  const ua = navigator.userAgent || '';
  const haystack = `${ua} ${(navigator as any).userAgentData?.platform ?? ''}`.toLowerCase();

  if (/android|iphone|ipad|ipod|capacitor/.test(haystack)) return 'android';

  const nav = (navigator as any).userAgentData;
  if (nav?.platform) {
    if (/win/.test(nav.platform)) return 'windows';
    if (/mac/.test(nav.platform)) return 'linux'; // no mac build shipped
  }

  if (/win/.test(haystack)) return 'windows';
  if (/linux|x11|ubuntu|fedora|arch/.test(haystack)) return 'linux';

  return 'unknown';
}

/**
 * Installed version of the running build.
 * Order of truth: a native build stamp injected on window.aureusVersion, else the
 * Vite build-time constant, else "0.0.0". Native shells (Capacitor/Electron) should
 * set window.aureusVersion from package.json at boot.
 */
export function currentAppVersion(): string {
  if (typeof window !== 'undefined') {
    const native = (window as any).aureusVersion;
    if (typeof native === 'string' && native.trim().length > 0) return native.trim();
  }
  const build = (import.meta as any).env?.VITE_APP_VERSION;
  if (typeof build === 'string' && build.length > 0) return build;
  return '0.0.0';
}

/** Convenience: the newest version in a manifest, or null. */
export function latestRelease(manifest: ReleaseManifest | null): ChangelogEntry | null {
  if (!manifest || manifest.releases.length === 0) return null;
  // Defensive: don't blindly trust ordering — pick max by semver.
  return [...manifest.releases].sort((a, b) => compareSemver(b.version, a.version))[0];
}

/** Find the artifact for a given version+platform. */
export function packageFor(
  manifest: ReleaseManifest | null,
  version: string,
  platform: string
): DownloadPackage | null {
  const rel = manifest?.releases?.find((r) => r.version === version);
  return rel?.downloads?.find((d) => d.platform === platform) ?? null;
}

/** Human-readable "3 releases ago" style summary for the update banner. */
export function summarizeGap(installed: string, latest: string): string {
  const cmp = compareSemver(latest, installed);
  if (cmp === 0) return 'You are on the latest version.';
  if (cmp < 0) return `You are running a newer build (v${installed}) than the latest published (v${latest}).`;
  return `Update from v${installed} to v${latest}.`;
}