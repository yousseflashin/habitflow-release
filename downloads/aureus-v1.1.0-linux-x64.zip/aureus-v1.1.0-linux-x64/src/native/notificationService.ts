// Local Notification and Alarm Scheduler for Android & Fedora Linux

import { Task, Habit, Reminder, TaskAlarm, Meeting } from '../types';
import { LocalNotifications, ScheduleOptions, ActionPerformed } from '@capacitor/local-notifications';
import { parseISO, format, addMinutes, isAfter, setHours, setMinutes, setSeconds } from 'date-fns';

export interface ScheduledNotificationItem {
  id: number;
  title: string;
  body: string;
  scheduleTime: Date;
  targetType: 'task' | 'habit' | 'meeting';
  targetId: string;
  url?: string;
  actionTypeId?: string;
}

class LocalNotificationManager {
  private isCapacitor: boolean = false;
  private isElectron: boolean = false;
  private permissionGranted: boolean = false;
  private desktopInterval: any = null;
  private scheduledItems: ScheduledNotificationItem[] = [];
  private triggerListeners: Array<(item: ScheduledNotificationItem) => void> = [];

  constructor() {
    this.detectEnvironment();
    this.initDesktopScheduler();
    this.setupCapacitorListeners();
  }

  public onNotificationTriggered(listener: (item: ScheduledNotificationItem) => void): () => void {
    this.triggerListeners.push(listener);
    return () => {
      this.triggerListeners = this.triggerListeners.filter((l) => l !== listener);
    };
  }

  public getScheduledItems(): ScheduledNotificationItem[] {
    return [...this.scheduledItems];
  }

  private detectEnvironment(): void {
    if (typeof window !== 'undefined') {
      this.isCapacitor = !!(window as any).Capacitor?.isNativePlatform?.();
      this.isElectron = !!(window as any).electronAPI || !!(window as any).process?.versions?.electron;
    }
  }

  public async requestPermissions(): Promise<boolean> {
    if (this.isCapacitor) {
      try {
        const result = await LocalNotifications.requestPermissions();
        this.permissionGranted = result.display === 'granted';
        if (this.permissionGranted) {
          await this.registerNotificationActionTypes();
        }
        return this.permissionGranted;
      } catch (e) {
        console.warn('Capacitor notifications permission error:', e);
      }
    }

    if (typeof Notification !== 'undefined') {
      try {
        const perm = await Notification.requestPermission();
        this.permissionGranted = perm === 'granted';
        return this.permissionGranted;
      } catch (e) {
        console.warn('Web notification permission error:', e);
      }
    }

    return false;
  }

  private setupCapacitorListeners(): void {
    if (!this.isCapacitor) return;
    try {
      LocalNotifications.addListener('localNotificationActionPerformed', (notification: ActionPerformed) => {
        if (notification.actionId === 'join') {
          const url = (notification.notification.extra as any)?.url;
          if (url && typeof window !== 'undefined') {
            window.open(url, '_blank');
          }
        }
      });
    } catch (e) {
      console.warn('Capacitor action listener error:', e);
    }
  }

  private async registerNotificationActionTypes(): Promise<void> {
    if (!this.isCapacitor) return;
    try {
      await LocalNotifications.registerActionTypes({
        types: [
          {
            id: 'MEETING_REMINDER_ACTION',
            actions: [
              { id: 'join', title: '🔗 Join Meeting', foreground: true },
              { id: 'dismiss', title: 'Dismiss', foreground: false },
            ],
          },
          {
            id: 'HABIT_REMINDER_ACTION',
            actions: [
              { id: 'complete', title: '✓ Complete', foreground: false },
              { id: 'snooze', title: '⏰ Snooze (15m)', foreground: false },
            ],
          },
          {
            id: 'TASK_REMINDER_ACTION',
            actions: [
              { id: 'complete', title: '✓ Mark Done', foreground: false },
              { id: 'snooze', title: '⏰ Snooze', foreground: false },
            ],
          },
        ],
      });
    } catch (e) {
      console.warn('Failed to register action types:', e);
    }
  }

  /**
   * Schedules all active reminders & alarms for tasks, habits, and meetings locally on the device.
   */
  public async syncAllScheduledReminders(tasks: Task[], habits: Habit[], meetings: Meeting[] = []): Promise<void> {
    this.scheduledItems = [];

    // 1. Collect Habit Reminders
    for (const habit of habits) {
      if (habit.deleted || habit.archived) continue;
      const reminders = habit.reminders || [];

      // Include legacy reminderTime if no reminders array
      if (reminders.length === 0 && habit.reminderTime) {
        reminders.push({
          id: `legacy_${habit.id}`,
          time: habit.reminderTime,
          enabled: true,
          label: habit.name,
        });
      }

      for (const rem of reminders) {
        if (!rem.enabled) continue;
        const [hours, mins] = rem.time.split(':').map(Number);
        if (isNaN(hours) || isNaN(mins)) continue;

        const nextDate = this.getNextOccurrenceTime(hours, mins, rem.daysOfWeek);
        if (nextDate) {
          this.scheduledItems.push({
            id: this.generateNumericId(`habit_${habit.id}_${rem.id}`),
            title: habit.category === 'quit' ? `Stay Strong: ${habit.name}` : `Habit Reminder: ${habit.name}`,
            body: rem.label || (habit.category === 'quit' ? `Keep your clean streak alive!` : `Time for your daily ${habit.targetCount} ${habit.targetUnit}.`),
            scheduleTime: nextDate,
            targetType: 'habit',
            targetId: habit.id,
            actionTypeId: 'HABIT_REMINDER_ACTION',
          });
        }
      }
    }

    // 2. Collect Task Reminders & Alarms
    for (const task of tasks) {
      if (task.deleted || task.completed || task.isArchived) continue;

      // Direct task alarms
      for (const alarm of task.alarms || []) {
        if (!alarm.enabled) continue;
        const [h, m] = alarm.time.split(':').map(Number);
        if (isNaN(h) || isNaN(m)) continue;

        let baseDate = alarm.date ? parseISO(alarm.date) : task.dueDate ? parseISO(task.dueDate.substring(0, 10)) : new Date();
        baseDate = setHours(setMinutes(setSeconds(baseDate, 0), m), h);

        if (alarm.offsetMinutes) {
          baseDate = addMinutes(baseDate, -alarm.offsetMinutes);
        }

        if (isAfter(baseDate, new Date())) {
          this.scheduledItems.push({
            id: this.generateNumericId(`task_alarm_${task.id}_${alarm.id}`),
            title: `Task Alarm: ${task.title}`,
            body: alarm.label || task.description || 'Action required for task.',
            scheduleTime: baseDate,
            targetType: 'task',
            targetId: task.id,
            actionTypeId: 'TASK_REMINDER_ACTION',
          });
        }
      }

      // Task reminders
      for (const rem of task.reminders || []) {
        if (!rem.enabled) continue;
        const [h, m] = rem.time.split(':').map(Number);
        if (isNaN(h) || isNaN(m)) continue;

        const nextDate = this.getNextOccurrenceTime(h, m, rem.daysOfWeek);
        if (nextDate) {
          this.scheduledItems.push({
            id: this.generateNumericId(`task_rem_${task.id}_${rem.id}`),
            title: `Task Reminder: ${task.title}`,
            body: rem.label || `Priority ${task.priority.toUpperCase()} • Due ${task.dueDate || 'Soon'}`,
            scheduleTime: nextDate,
            targetType: 'task',
            targetId: task.id,
            actionTypeId: 'TASK_REMINDER_ACTION',
          });
        }
      }
    }

    // 3. Collect Meeting Reminders (Google Calendar Style)
    for (const meeting of meetings) {
      if (meeting.deleted) continue;
      const [h, m] = (meeting.startTime || '09:00').split(':').map(Number);
      if (isNaN(h) || isNaN(m)) continue;

      let baseDate = parseISO(meeting.date);
      baseDate = setHours(setMinutes(setSeconds(baseDate, 0), m), h);

      for (const rem of meeting.reminders || []) {
        if (!rem.enabled) continue;
        const triggerTime = addMinutes(baseDate, -rem.minutesBefore);

        // Schedule if scheduled moment is in future or within 1 minute in the past
        if (isAfter(triggerTime, addMinutes(new Date(), -1))) {
          const timeText = rem.minutesBefore === 0
            ? 'Starting Now'
            : rem.minutesBefore >= 60
            ? `in ${Math.round(rem.minutesBefore / 60)}h`
            : `in ${rem.minutesBefore}m`;

          const details = [
            `${meeting.startTime} – ${meeting.endTime}`,
            meeting.location ? `📍 ${meeting.location}` : null,
            meeting.description ? meeting.description : null,
          ].filter(Boolean).join(' • ');

          this.scheduledItems.push({
            id: this.generateNumericId(`meeting_${meeting.id}_${rem.id}_${rem.minutesBefore}`),
            title: `🗓️ Meeting ${timeText}: ${meeting.title}`,
            body: details || `Calendar event at ${meeting.startTime}`,
            scheduleTime: triggerTime,
            targetType: 'meeting',
            targetId: meeting.id,
            url: meeting.location,
            actionTypeId: 'MEETING_REMINDER_ACTION',
          });
        }
      }
    }

    // 4. Dispatch to Native Android or Desktop
    if (this.isCapacitor) {
      await this.scheduleCapacitorNotifications(this.scheduledItems);
    } else {
      // Fedora / desktop: persist scheduled items to the daemon inbox so native
      // desktop alerts fire even with no window open (see desktop/scheduler-daemon.js).
      this.persistToDesktopDaemon(this.scheduledItems);
    }
  }

  private persistToDesktopDaemon(items: ScheduledNotificationItem[]): void {
    try {
      const payload = items.map((i) => ({
        id: i.id,
        title: i.title,
        body: i.body,
        scheduleTime: i.scheduleTime.getTime(),
        targetType: i.targetType,
        targetId: i.targetId,
        url: i.url,
      }));

      // Deliver to the Electron main process via IPC; it persists the daemon inbox
      // on the main side (safe under contextIsolation). Best-effort — never throw.
      if (typeof window !== 'undefined' && (window as any).electronAPI?.writeDaemonInbox) {
        (window as any).electronAPI.writeDaemonInbox(payload);
      }
    } catch (e) {
      /* daemon inbox is best-effort; ignore write failures */
    }
  }

  private async scheduleCapacitorNotifications(items: ScheduledNotificationItem[]): Promise<void> {
    try {
      // Cancel previous pending notifications
      const pending = await LocalNotifications.getPending();
      if (pending.notifications.length > 0) {
        await LocalNotifications.cancel({ notifications: pending.notifications });
      }

      if (items.length === 0) return;

      const scheduleOptions: ScheduleOptions = {
        notifications: items.slice(0, 50).map((item) => ({
          id: item.id,
          title: item.title,
          body: item.body,
          schedule: { at: item.scheduleTime },
          actionTypeId: item.actionTypeId,
          extra: { targetType: item.targetType, targetId: item.targetId, url: item.url },
          smallIcon: 'ic_stat_notification',
          iconColor: item.targetType === 'meeting' ? '#3B82F6' : '#10B981',
        })),
      };

      await LocalNotifications.schedule(scheduleOptions);
    } catch (e) {
      console.warn('Capacitor LocalNotifications schedule error:', e);
    }
  }

  /**
   * Linux Desktop & Web Background Notification Checker
   */
  private initDesktopScheduler(): void {
    if (typeof window === 'undefined') return;
    if (this.desktopInterval) clearInterval(this.desktopInterval);

    this.desktopInterval = setInterval(() => {
      const now = new Date();
      const triggered: number[] = [];

      for (const item of this.scheduledItems) {
        if (Math.abs(item.scheduleTime.getTime() - now.getTime()) <= 30000) {
          this.fireDesktopNotification(item.title, item.body, item.url);
          // Notify any registered in-app listeners (for website in-app visual and audio alert)
          this.triggerListeners.forEach((fn) => {
            try { fn(item); } catch (e) {}
          });
          triggered.push(item.id);
        }
      }

      if (triggered.length > 0) {
        this.scheduledItems = this.scheduledItems.filter(i => !triggered.includes(i.id));
      }
    }, 15000); // Check every 15 seconds
  }

  public fireDesktopNotification(title: string, body: string, url?: string): void {
    // 1. If inside Electron with IPC bridge
    if (typeof window !== 'undefined' && (window as any).electronAPI?.sendNotification) {
      (window as any).electronAPI.sendNotification({ title, body, url });
      return;
    }

    // 2. Standard Web Notification API
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try {
        const notif = new Notification(title, {
          body,
          icon: '/manifest.json',
          silent: false,
        });
        if (url) {
          notif.onclick = () => {
            window.open(url, '_blank');
            notif.close();
          };
        }
      } catch (e) {}
    }
  }

  private getNextOccurrenceTime(hours: number, minutes: number, daysOfWeek?: number[]): Date | null {
    const now = new Date();
    for (let dayOffset = 0; dayOffset < 8; dayOffset++) {
      let candidate = new Date(now.getFullYear(), now.getMonth(), now.getDate() + dayOffset, hours, minutes, 0);
      if (daysOfWeek && daysOfWeek.length > 0) {
        if (!daysOfWeek.includes(candidate.getDay())) {
          continue;
        }
      }
      if (isAfter(candidate, now)) {
        return candidate;
      }
    }
    return null;
  }

  private generateNumericId(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash) % 1000000;
  }
}

export const notificationManager = new LocalNotificationManager();
