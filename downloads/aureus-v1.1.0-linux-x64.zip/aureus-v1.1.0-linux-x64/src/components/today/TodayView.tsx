import React, { useMemo, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { HabitService } from '../../domain/habitService';
import { TaskService } from '../../domain/taskService';
import { HabitCard } from '../habits/HabitCard';
import { TaskItem } from '../tasks/TaskItem';
import { TaskQuickAdd } from '../tasks/TaskQuickAdd';
import {
  Sparkles,
  Flame,
  CheckCircle2,
  AlertCircle,
  Plus,
  ArrowRight,
  RotateCcw,
} from 'lucide-react';
import { format } from 'date-fns';

export const TodayView: React.FC = () => {
  const {
    tasks,
    habits,
    habitLogs,
    setActiveView,
    setIsHabitModalOpen,
    setIsTaskModalOpen,
    updateTask,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'habits' | 'tasks'>('all');

  const todayStr = useMemo(() => format(new Date(), 'yyyy-MM-dd'), []);
  const todayDateFormatted = useMemo(() => format(new Date(), 'EEEE, MMMM d'), []);

  // Time-aware greeting
  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 5) return 'Up Late';
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    if (h < 21) return 'Good Evening';
    return 'Winding Down';
  }, []);

  // Filter today's habits
  const todayHabits = useMemo(() => {
    return habits.filter((h) => HabitService.isHabitScheduledForDate(h, todayStr));
  }, [habits, todayStr]);

  const completedHabitsCount = useMemo(() => {
    return todayHabits.filter((h) => {
      const log = habitLogs.get(`${h.id}_${todayStr}`);
      return log && !log.deleted && log.completed;
    }).length;
  }, [todayHabits, habitLogs, todayStr]);

  // Tasks: Overdue, Today, Upcoming
  const overdueTasks = useMemo(() => {
    return tasks.filter((t) => TaskService.isOverdue(t) && !t.completed);
  }, [tasks]);

  const todayTasks = useMemo(() => {
    return tasks.filter((t) => TaskService.isDueToday(t) && !t.completed);
  }, [tasks]);

  const completedTodayTasks = useMemo(() => {
    return tasks.filter(
      (t) => t.completed && t.completedAt && t.completedAt.startsWith(todayStr)
    );
  }, [tasks, todayStr]);

  // Total daily progress score (Habits + Today Tasks)
  const totalItems = todayHabits.length + todayTasks.length + completedTodayTasks.length;
  const completedItems = completedHabitsCount + completedTodayTasks.length;
  const progressPercent = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;

  // Batch move overdue tasks to today
  const handleRescheduleOverdue = async () => {
    for (const task of overdueTasks) {
      await updateTask(task.id, { dueDate: todayStr });
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-16 max-w-5xl mx-auto select-none">
      {/* ── EXECUTIVE TODAY HERO CARD ──────────────────────────────────── */}
      <div className="glass rounded-[2rem] p-6 sm:p-8 border border-white/[0.08] shadow-aureus-lg relative overflow-hidden stagger-1">
        {/* Subtle warm champagne gold background bloom */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#E5A93C]/[0.06] rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 badge-gold mb-1">
              <Sparkles className="w-3 h-3" />
              <span>Today's Command Center</span>
            </div>
            <h1 className="font-display text-2xl sm:text-4xl font-black tracking-tight text-white">
              {greeting}
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 font-medium">{todayDateFormatted}</p>
            <p className="text-xs text-zinc-400 max-w-md pt-1">
              {completedItems === totalItems && totalItems > 0
                ? 'All objectives and habits fulfilled for today. Outstanding execution.'
                : `${completedItems} of ${totalItems} daily targets resolved. Keep your momentum high.`}
            </p>
          </div>

          {/* Precision Ring Progress Metric */}
          <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] shrink-0">
            <div className="relative w-14 h-14 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-white/[0.07]"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-[#F0C465] transition-all duration-700 ease-out"
                  strokeDasharray={`${progressPercent}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute text-xs font-black text-white tabular-nums font-mono">
                {progressPercent}%
              </span>
            </div>

            <div className="text-left">
              <div className="text-xs font-bold text-white uppercase tracking-wider">Completion Index</div>
              <div className="text-[11px] text-zinc-400 mt-0.5">
                <span className="text-[#F0C465] font-semibold">{completedHabitsCount}/{todayHabits.length}</span> Habits •{' '}
                <span className="text-[#38BDF8] font-semibold">{completedTodayTasks.length}/{todayTasks.length + completedTodayTasks.length}</span> Tasks
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Segmented Filter Pills */}
      <div className="flex items-center gap-1.5 p-1 rounded-xl bg-white/[0.02] border border-white/[0.05] w-fit stagger-2">
        {[
          { id: 'all', label: 'All Daily Goals' },
          { id: 'habits', label: `Habits (${completedHabitsCount}/${todayHabits.length})` },
          { id: 'tasks', label: `Tasks (${todayTasks.length} pending)` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-white/[0.1] text-white border border-white/[0.15] shadow-aureus-sm'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* OVERDUE RECOVERY BANNER */}
      {overdueTasks.length > 0 && activeTab !== 'habits' && (
        <div className="p-4 rounded-2xl bg-rose-500/[0.07] border border-rose-500/20 space-y-3">
          <div className="flex items-center justify-between text-rose-400">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              <h2 className="text-xs font-bold uppercase tracking-wider">
                Overdue Tasks ({overdueTasks.length})
              </h2>
            </div>
            <button
              onClick={handleRescheduleOverdue}
              className="px-2.5 py-1 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 flex items-center gap-1 transition-all cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reschedule All to Today</span>
            </button>
          </div>

          <div className="space-y-2">
            {overdueTasks.map((task) => (
              <TaskItem key={task.id} task={task} />
            ))}
          </div>
        </div>
      )}

      {/* TODAY'S HABITS SECTION */}
      {activeTab !== 'tasks' && (
        <section className="space-y-3.5 stagger-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#F0C465]" />
              <h2 className="text-sm font-bold uppercase tracking-wider text-white">
                Today's Habits ({completedHabitsCount}/{todayHabits.length})
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveView('habits')}
                className="text-xs font-semibold text-zinc-400 hover:text-[#F0C465] flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>View Full Registry</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsHabitModalOpen(true)}
                className="btn-secondary px-2.5 py-1 text-xs flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Habit</span>
              </button>
            </div>
          </div>

          {todayHabits.length === 0 ? (
            <div className="text-center py-10 rounded-2xl border border-dashed border-white/10 bg-white/[0.01] p-6 space-y-2">
              <p className="text-xs text-zinc-400">No habit routines scheduled for today.</p>
              <button
                onClick={() => setIsHabitModalOpen(true)}
                className="btn-primary px-4 py-2 text-xs font-bold"
              >
                Launch First Habit
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {todayHabits.map((habit) => (
                <HabitCard key={habit.id} habit={habit} gridDaysCount={14} />
              ))}
            </div>
          )}
        </section>
      )}

      {/* TODAY'S TASKS SECTION */}
      {activeTab !== 'habits' && (
        <section className="space-y-3.5 pt-2 stagger-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#38BDF8]" />
              <h2 className="text-sm font-bold uppercase tracking-wider text-white">
                Today's Tasks ({todayTasks.length} pending)
              </h2>
            </div>

            <button
              onClick={() => setIsTaskModalOpen(true)}
              className="btn-secondary px-2.5 py-1 text-xs flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Full Task</span>
            </button>
          </div>

          {/* Quick Add Bar */}
          <TaskQuickAdd />

          {/* Task List */}
          <div className="space-y-2">
            {todayTasks.length === 0 && completedTodayTasks.length === 0 ? (
              <div className="text-center py-10 rounded-2xl border border-dashed border-white/10 bg-white/[0.01] p-6">
                <p className="text-xs text-zinc-400">
                  No pending deliverables for today. Use the command bar above to log any new item.
                </p>
              </div>
            ) : (
              <>
                {todayTasks.map((task) => (
                  <TaskItem key={task.id} task={task} />
                ))}

                {completedTodayTasks.length > 0 && (
                  <div className="pt-4 space-y-2">
                    <h3 className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Completed Today ({completedTodayTasks.length})</span>
                    </h3>
                    {completedTodayTasks.map((task) => (
                      <TaskItem key={task.id} task={task} />
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </section>
      )}
    </div>
  );
};

export default TodayView;
