// Aureus Chronos — Unified Master Calendar & Google Calendar Style Event Manager
// Integrates Meetings, Commitments, Tasks, and Habits with Multi-View (Month, Week, Day, Schedule)

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { HabitService } from '../../domain/habitService';
import { Meeting } from '../../types';
import { TaskItem } from '../tasks/TaskItem';
import {
  format,
  addMonths,
  subMonths,
  addWeeks,
  subWeeks,
  addDays,
  subDays,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  isToday as checkIsToday,
  parseISO,
} from 'date-fns';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Flame,
  CheckCircle2,
  Clock,
  Plus,
  Sparkles,
  Video,
  MapPin,
  ExternalLink,
  Layers,
  CalendarDays,
  Columns,
  Grid,
  List,
  Edit3,
  Trash2,
  Bell,
  Search,
  Filter,
} from 'lucide-react';

type CalendarViewMode = 'month' | 'week' | 'day' | 'schedule';

const HOURS_IN_DAY = Array.from({ length: 24 }, (_, i) => i);
const HOUR_HEIGHT = 56; // 56px per hour row

export const SharedCalendarView: React.FC = () => {
  const {
    tasks,
    habits,
    meetings,
    habitLogs,
    habitRelapses,
    toggleHabitDay,
    recordHabitRelapse,
    clearHabitRelapse,
    setEditingTask,
    setIsTaskModalOpen,
    setIsMeetingModalOpen,
    setEditingMeeting,
    deleteMeeting,
    toggleTaskComplete,
  } = useApp();

  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<CalendarViewMode>('month');

  // Layer filters
  const [showMeetings, setShowMeetings] = useState(true);
  const [showTasks, setShowTasks] = useState(true);
  const [showHabits, setShowHabits] = useState(true);

  // Search filter for schedule view
  const [scheduleSearch, setScheduleSearch] = useState('');

  // Auto-scroll ref for week/day time grid
  const timeGridScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // When switching to week or day view, auto-scroll to 8:00 AM
    if ((viewMode === 'week' || viewMode === 'day') && timeGridScrollRef.current) {
      timeGridScrollRef.current.scrollTop = 8 * HOUR_HEIGHT;
    }
  }, [viewMode]);

  // Current selected date string
  const selectedDateStr = useMemo(() => format(selectedDate, 'yyyy-MM-dd'), [selectedDate]);

  // Active (non-deleted) meetings
  const activeMeetings = useMemo(() => {
    return meetings.filter((m) => !m.deleted);
  }, [meetings]);

  // Active (non-deleted, non-archived) tasks
  const activeTasks = useMemo(() => {
    return tasks.filter((t) => !t.deleted && !t.isArchived);
  }, [tasks]);

  // Active habits
  const activeHabits = useMemo(() => {
    return habits.filter((h) => !h.deleted && !h.archived);
  }, [habits]);

  // Days in calendar for Month View
  const daysInMonthView = useMemo(() => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart, { weekStartsOn: 1 }); // Monday start
    const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 });

    return eachDayOfInterval({ start: startDate, end: endDate });
  }, [currentDate]);

  // Days in calendar for Week View
  const daysInWeekView = useMemo(() => {
    const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(weekStart, { weekStartsOn: 1 });
    return eachDayOfInterval({ start: weekStart, end: weekEnd });
  }, [currentDate]);

  // Scheduled items for the selected date
  const selectedDayMeetings = useMemo(() => {
    return activeMeetings
      .filter((m) => m.date === selectedDateStr)
      .sort((a, b) => (a.allDay ? -1 : b.allDay ? 1 : a.startTime.localeCompare(b.startTime)));
  }, [activeMeetings, selectedDateStr]);

  const selectedDayHabits = useMemo(() => {
    return activeHabits.filter((h) => HabitService.isHabitScheduledForDate(h, selectedDateStr));
  }, [activeHabits, selectedDateStr]);

  const selectedDayTasks = useMemo(() => {
    return activeTasks.filter((t) => t.dueDate && t.dueDate.startsWith(selectedDateStr));
  }, [activeTasks, selectedDateStr]);

  // Helper to extract a clickable video conference link
  const getVideoLink = (location?: string) => {
    if (!location) return null;
    const match = location.match(/https?:\/\/[^\s]+/i);
    if (match) return match[0];
    if (
      location.includes('meet.google.com') ||
      location.includes('zoom.us') ||
      location.includes('teams.microsoft.com')
    ) {
      return location.startsWith('http') ? location : `https://${location}`;
    }
    return null;
  };

  // Open Meeting Modal for scheduling a new meeting
  const handleOpenNewMeeting = (dateStr?: string, timeStr?: string) => {
    const targetDate = dateStr || selectedDateStr;
    const targetStart = timeStr || '09:00';
    const [h, m] = targetStart.split(':').map(Number);
    const endH = (h + 1) % 24;
    const targetEnd = `${String(endH).padStart(2, '0')}:${String(m || 0).padStart(2, '0')}`;

    setEditingMeeting({
      id: '',
      title: '',
      description: '',
      date: targetDate,
      startTime: targetStart,
      endTime: targetEnd,
      allDay: false,
      location: '',
      color: '#2563EB',
      reminders: [{ id: 'rem_default', minutesBefore: 10, enabled: true }],
      attendees: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deleted: false,
      version: 1,
    });
    setIsMeetingModalOpen(true);
  };

  // Open Meeting Modal to edit an existing meeting
  const handleEditMeeting = (meeting: Meeting, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingMeeting(meeting);
    setIsMeetingModalOpen(true);
  };

  // Delete meeting
  const handleDeleteMeeting = async (meeting: Meeting, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (confirm(`Delete meeting "${meeting.title}"?`)) {
      await deleteMeeting(meeting.id);
    }
  };

  // Open Task Modal for a specific date
  const handleOpenNewTask = (dateStr?: string) => {
    const targetDate = dateStr || selectedDateStr;
    setEditingTask({
      id: '',
      title: '',
      priority: 'p4',
      projectId: 'inbox',
      tags: [],
      dueDate: targetDate,
      reminders: [],
      alarms: [],
      subtasks: [],
      completed: false,
      completedAt: null,
      isArchived: false,
      order: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deleted: false,
      version: 1,
    });
    setIsTaskModalOpen(true);
  };

  // Navigation handlers
  const handlePrev = () => {
    if (viewMode === 'month') setCurrentDate(subMonths(currentDate, 1));
    else if (viewMode === 'week') setCurrentDate(subWeeks(currentDate, 1));
    else if (viewMode === 'day') {
      const prev = subDays(currentDate, 1);
      setCurrentDate(prev);
      setSelectedDate(prev);
    } else setCurrentDate(subMonths(currentDate, 1));
  };

  const handleNext = () => {
    if (viewMode === 'month') setCurrentDate(addMonths(currentDate, 1));
    else if (viewMode === 'week') setCurrentDate(addWeeks(currentDate, 1));
    else if (viewMode === 'day') {
      const next = addDays(currentDate, 1);
      setCurrentDate(next);
      setSelectedDate(next);
    } else setCurrentDate(addMonths(currentDate, 1));
  };

  const handleToday = () => {
    const now = new Date();
    setCurrentDate(now);
    setSelectedDate(now);
  };

  // Formatted date label for header
  const headerDateLabel = useMemo(() => {
    if (viewMode === 'month') {
      return format(currentDate, 'MMMM yyyy');
    }
    if (viewMode === 'week') {
      const start = startOfWeek(currentDate, { weekStartsOn: 1 });
      const end = endOfWeek(currentDate, { weekStartsOn: 1 });
      if (isSameMonth(start, end)) {
        return `${format(start, 'MMM d')} – ${format(end, 'd, yyyy')}`;
      }
      return `${format(start, 'MMM d')} – ${format(end, 'MMM d, yyyy')}`;
    }
    if (viewMode === 'day') {
      return format(currentDate, 'EEEE, MMMM d, yyyy');
    }
    return `${format(currentDate, 'MMMM yyyy')} Schedule`;
  }, [currentDate, viewMode]);

  // Current time position indicator for week/day view
  const currentTimeMins = useMemo(() => {
    const now = new Date();
    return now.getHours() * 60 + now.getMinutes();
  }, []);

  return (
    <div className="space-y-6 pb-20 max-w-7xl mx-auto animate-fadeIn">
      {/* ── Top Executive Calendar Header ─────────────────────────────────────── */}
      <div className="stagger-1 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-400/10 border border-amber-400/25 text-amber-300 flex items-center justify-center shrink-0 shadow-glow-sm">
              <CalendarIcon className="w-6 h-6" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-300 uppercase tracking-widest mb-0.5">
                <Sparkles className="w-3 h-3" />
                <span>Executive Calendar & Meetings</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                {headerDateLabel}
              </h1>
              <p className="text-xs text-slate-400">
                Unified Google Calendar timeline: meetings, habits, and task milestones.
              </p>
            </div>
          </div>

          {/* Action CTAs: + Meeting & + Task */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => handleOpenNewMeeting()}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-blue-500/20 active:scale-95 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Meeting</span>
            </button>
            <button
              type="button"
              onClick={() => handleOpenNewTask()}
              className="px-3.5 py-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-200 font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-amber-400" />
              <span>New Task</span>
            </button>
          </div>
        </div>

        {/* ── Sub-Bar: Navigation, View Mode Tabs, & Layer Filters ───────────── */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pt-3 border-t border-white/[0.06]">
          {/* Date Navigation */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrev}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer active:scale-95"
              title="Previous"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleToday}
              className="px-3.5 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-200 text-xs font-bold transition-all cursor-pointer active:scale-95"
            >
              Today
            </button>
            <button
              type="button"
              onClick={handleNext}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer active:scale-95"
              title="Next"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* View Mode Switcher */}
          <div className="inline-flex p-1 rounded-2xl bg-white/[0.03] border border-white/[0.08] self-start lg:self-auto">
            <button
              type="button"
              onClick={() => setViewMode('month')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === 'month'
                  ? 'bg-amber-400 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              <span>Month</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('week')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === 'week'
                  ? 'bg-amber-400 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <Columns className="w-3.5 h-3.5" />
              <span>Week</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setViewMode('day');
                setCurrentDate(selectedDate);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === 'day'
                  ? 'bg-amber-400 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Day</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('schedule')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === 'schedule'
                  ? 'bg-amber-400 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Schedule</span>
            </button>
          </div>

          {/* Calendar Layer Filters */}
          <div className="flex items-center gap-2 flex-wrap text-xs font-medium">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider flex items-center gap-1 mr-1">
              <Layers className="w-3 h-3" />
              <span>Layers:</span>
            </span>

            {/* Meetings Pill */}
            <button
              type="button"
              onClick={() => setShowMeetings(!showMeetings)}
              className={`px-2.5 py-1 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer ${
                showMeetings
                  ? 'bg-blue-500/15 border-blue-500/40 text-blue-300 font-bold'
                  : 'bg-white/[0.02] border-white/[0.06] text-slate-500 opacity-60'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
              <span>Meetings</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
                {activeMeetings.length}
              </span>
            </button>

            {/* Tasks Pill */}
            <button
              type="button"
              onClick={() => setShowTasks(!showTasks)}
              className={`px-2.5 py-1 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer ${
                showTasks
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 font-bold'
                  : 'bg-white/[0.02] border-white/[0.06] text-slate-500 opacity-60'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
              <span>Tasks</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
                {activeTasks.length}
              </span>
            </button>

            {/* Habits Pill */}
            <button
              type="button"
              onClick={() => setShowHabits(!showHabits)}
              className={`px-2.5 py-1 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer ${
                showHabits
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 font-bold'
                  : 'bg-white/[0.02] border-white/[0.06] text-slate-500 opacity-60'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
              <span>Habits</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
                {activeHabits.length}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* ── Main View Content Area ─────────────────────────────────────── */}
      {viewMode === 'month' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Month Grid (2 cols on lg) */}
          <div className="stagger-2 lg:col-span-2 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-4 sm:p-6 shadow-2xl space-y-3">
            {/* Day of Week Headers */}
            <div className="grid grid-cols-7 gap-1 text-center mb-1">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => (
                <div key={day} className="text-[11px] font-bold text-slate-500 uppercase tracking-wider py-1">
                  {day}
                </div>
              ))}
            </div>

            {/* Days Cells */}
            <div className="grid grid-cols-7 gap-1.5">
              {daysInMonthView.map((day) => {
                const dayStr = format(day, 'yyyy-MM-dd');
                const isCurrentMonth = isSameMonth(day, currentDate);
                const isSelected = isSameDay(day, selectedDate);
                const isToday = checkIsToday(day);

                // Day items
                const dayMeetings = showMeetings
                  ? activeMeetings.filter((m) => m.date === dayStr)
                  : [];
                const dayHabits = showHabits
                  ? activeHabits.filter((h) => HabitService.isHabitScheduledForDate(h, dayStr))
                  : [];
                const dayTasks = showTasks
                  ? activeTasks.filter((t) => t.dueDate && t.dueDate.startsWith(dayStr))
                  : [];
                const pendingTasks = dayTasks.filter((t) => !t.completed).length;

                return (
                  <div
                    key={dayStr}
                    onClick={() => setSelectedDate(day)}
                    className={`min-h-[92px] sm:min-h-[110px] p-2 rounded-2xl border text-left flex flex-col justify-between transition-all duration-150 relative cursor-pointer group ${
                      isSelected
                        ? 'border-amber-400 bg-amber-400/[0.08] shadow-glow-sm ring-1 ring-amber-400/40'
                        : isToday
                        ? 'border-white/30 bg-white/[0.05]'
                        : 'border-white/[0.04] bg-white/[0.015] hover:border-white/20 hover:bg-white/[0.03]'
                    } ${!isCurrentMonth ? 'opacity-30' : ''}`}
                  >
                    {/* Top Row: Date Number & Badges */}
                    <div className="flex items-center justify-between w-full">
                      <span
                        className={`text-xs font-bold ${
                          isToday
                            ? 'w-5 h-5 rounded-full bg-amber-400 text-slate-950 font-black flex items-center justify-center'
                            : isSelected
                            ? 'text-amber-300 font-extrabold'
                            : 'text-slate-300'
                        }`}
                      >
                        {format(day, 'd')}
                      </span>

                      <div className="flex items-center gap-1">
                        {pendingTasks > 0 && (
                          <span
                            className="w-2 h-2 rounded-full bg-amber-400 shadow-xs"
                            title={`${pendingTasks} pending tasks`}
                          />
                        )}
                        {/* Quick Add Button on Hover */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenNewMeeting(dayStr);
                          }}
                          className="opacity-0 group-hover:opacity-100 p-0.5 rounded-md hover:bg-white/10 text-slate-400 hover:text-white transition-opacity"
                          title="Add meeting for this day"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* Middle: Meeting Chips (Google Calendar Style) */}
                    <div className="space-y-1 w-full my-1 overflow-hidden">
                      {dayMeetings.slice(0, 2).map((m) => (
                        <div
                          key={m.id}
                          onClick={(e) => handleEditMeeting(m, e)}
                          style={{
                            borderLeftColor: m.color || '#2563EB',
                            backgroundColor: `${m.color || '#2563EB'}22`,
                          }}
                          className="px-1.5 py-0.5 rounded text-[10px] font-semibold border-l-2 text-white/90 truncate hover:brightness-125 transition-all flex items-center gap-1"
                          title={`${m.title} (${m.allDay ? 'All day' : m.startTime})`}
                        >
                          {!m.allDay && (
                            <span className="text-[9px] text-slate-400 font-mono shrink-0">
                              {m.startTime}
                            </span>
                          )}
                          <span className="truncate">{m.title}</span>
                        </div>
                      ))}
                      {dayMeetings.length > 2 && (
                        <div className="text-[9px] font-bold text-blue-400 px-1 truncate">
                          +{dayMeetings.length - 2} more meeting{dayMeetings.length - 2 > 1 ? 's' : ''}
                        </div>
                      )}
                    </div>

                    {/* Bottom Row: Habits Dots & Task Count */}
                    <div className="space-y-1 w-full">
                      {dayHabits.length > 0 && (
                        <div className="flex items-center gap-1 flex-wrap">
                          {dayHabits.slice(0, 4).map((h) => {
                            const log = habitLogs.get(`${h.id}_${dayStr}`);
                            const isDone = log && log.completed && !log.deleted;
                            return (
                              <span
                                key={h.id}
                                style={{
                                  backgroundColor: isDone ? h.color : 'transparent',
                                  borderColor: h.color,
                                }}
                                className="w-1.5 h-1.5 rounded-full border shrink-0"
                              />
                            );
                          })}
                          {dayHabits.length > 4 && (
                            <span className="text-[8px] text-slate-500 font-mono">
                              +{dayHabits.length - 4}
                            </span>
                          )}
                        </div>
                      )}

                      {dayTasks.length > 0 && (
                        <div className="text-[9px] text-slate-400 font-mono truncate">
                          {dayTasks.length} task{dayTasks.length > 1 ? 's' : ''}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Side Agenda (1 col on lg) */}
          <SideAgendaSection
            selectedDate={selectedDate}
            selectedDateStr={selectedDateStr}
            selectedDayMeetings={selectedDayMeetings}
            selectedDayHabits={selectedDayHabits}
            selectedDayTasks={selectedDayTasks}
            habitLogs={habitLogs}
            habitRelapses={habitRelapses}
            toggleHabitDay={toggleHabitDay}
            recordHabitRelapse={recordHabitRelapse}
            clearHabitRelapse={clearHabitRelapse}
            handleOpenNewMeeting={handleOpenNewMeeting}
            handleEditMeeting={handleEditMeeting}
            handleDeleteMeeting={handleDeleteMeeting}
            handleOpenNewTask={handleOpenNewTask}
            getVideoLink={getVideoLink}
          />
        </div>
      )}

      {/* ── Week View: Google Calendar 7-Column Time Grid ───────────────── */}
      {viewMode === 'week' && (
        <div className="stagger-2 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] shadow-2xl overflow-hidden flex flex-col">
          {/* Week Column Header */}
          <div className="grid grid-cols-[60px_repeat(7,1fr)] border-b border-white/[0.08] bg-white/[0.02] sticky top-0 z-20">
            {/* Corner Cell: Timezone / GMT */}
            <div className="p-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-center border-r border-white/[0.06]">
              GMT
            </div>
            {/* 7 Day Headers */}
            {daysInWeekView.map((day) => {
              const dayStr = format(day, 'yyyy-MM-dd');
              const isToday = checkIsToday(day);
              const isSelected = isSameDay(day, selectedDate);

              return (
                <div
                  key={dayStr}
                  onClick={() => setSelectedDate(day)}
                  className={`p-3 text-center border-r border-white/[0.06] last:border-r-0 cursor-pointer transition-colors ${
                    isSelected ? 'bg-amber-400/[0.06]' : 'hover:bg-white/[0.02]'
                  }`}
                >
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    {format(day, 'EEE')}
                  </div>
                  <div
                    className={`text-lg font-black mt-0.5 inline-flex items-center justify-center w-8 h-8 rounded-full ${
                      isToday
                        ? 'bg-amber-400 text-slate-950 font-black'
                        : isSelected
                        ? 'text-amber-300'
                        : 'text-white'
                    }`}
                  >
                    {format(day, 'd')}
                  </div>
                </div>
              );
            })}
          </div>

          {/* All Day Row (Meetings & Tasks) */}
          <div className="grid grid-cols-[60px_repeat(7,1fr)] border-b border-white/[0.08] bg-white/[0.01]">
            <div className="p-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-center border-r border-white/[0.06]">
              All-Day
            </div>
            {daysInWeekView.map((day) => {
              const dayStr = format(day, 'yyyy-MM-dd');
              const allDayMeetings = showMeetings
                ? activeMeetings.filter((m) => m.date === dayStr && m.allDay)
                : [];
              const dayTasks = showTasks
                ? activeTasks.filter((t) => t.dueDate && t.dueDate.startsWith(dayStr))
                : [];

              return (
                <div
                  key={`allday_${dayStr}`}
                  className="p-1.5 border-r border-white/[0.06] last:border-r-0 min-h-[36px] space-y-1"
                >
                  {allDayMeetings.map((m) => (
                    <div
                      key={m.id}
                      onClick={() => handleEditMeeting(m)}
                      style={{ backgroundColor: m.color || '#2563EB' }}
                      className="px-2 py-0.5 rounded text-[10px] font-bold text-white truncate cursor-pointer hover:brightness-110 shadow-xs"
                      title={m.title}
                    >
                      {m.title}
                    </div>
                  ))}
                  {dayTasks.slice(0, 1).map((t) => (
                    <div
                      key={t.id}
                      className="px-2 py-0.5 rounded text-[9px] font-semibold bg-white/[0.06] text-slate-300 border border-white/10 truncate flex items-center gap-1"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                      <span className="truncate">{t.title}</span>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Hourly Time Grid (Scrollable) */}
          <div
            ref={timeGridScrollRef}
            className="overflow-y-auto max-h-[640px] relative grid grid-cols-[60px_repeat(7,1fr)]"
          >
            {/* Left Column: Time Labels */}
            <div className="border-r border-white/[0.06] select-none">
              {HOURS_IN_DAY.map((hour) => (
                <div
                  key={hour}
                  style={{ height: `${HOUR_HEIGHT}px` }}
                  className="relative text-[10px] font-mono font-bold text-slate-500 pr-2 pt-1 text-right border-b border-white/[0.04]"
                >
                  {hour === 0 ? '' : `${String(hour).padStart(2, '0')}:00`}
                </div>
              ))}
            </div>

            {/* 7 Columns: One for each day */}
            {daysInWeekView.map((day) => {
              const dayStr = format(day, 'yyyy-MM-dd');
              const isToday = checkIsToday(day);
              const dayMeetings = showMeetings
                ? activeMeetings.filter((m) => m.date === dayStr && !m.allDay)
                : [];

              return (
                <div
                  key={`col_${dayStr}`}
                  className="relative border-r border-white/[0.06] last:border-r-0"
                >
                  {/* Hourly Grid Rows */}
                  {HOURS_IN_DAY.map((hour) => {
                    const hourTimeStr = `${String(hour).padStart(2, '0')}:00`;
                    return (
                      <div
                        key={hour}
                        onClick={() => handleOpenNewMeeting(dayStr, hourTimeStr)}
                        style={{ height: `${HOUR_HEIGHT}px` }}
                        className="border-b border-white/[0.04] hover:bg-white/[0.02] transition-colors cursor-pointer group relative"
                        title={`Click to schedule meeting at ${hourTimeStr}`}
                      >
                        <span className="opacity-0 group-hover:opacity-100 absolute top-1 right-1 text-[9px] font-mono text-slate-500">
                          + {hourTimeStr}
                        </span>
                      </div>
                    );
                  })}

                  {/* Red Current Time Indicator Line (If today) */}
                  {isToday && (
                    <div
                      style={{ top: `${(currentTimeMins / 60) * HOUR_HEIGHT}px` }}
                      className="absolute left-0 right-0 z-10 pointer-events-none flex items-center"
                    >
                      <div className="w-2.5 h-2.5 rounded-full bg-rose-500 -ml-1.5 shadow-sm shadow-rose-500/50" />
                      <div className="h-[2px] bg-rose-500 w-full shadow-sm shadow-rose-500/50" />
                    </div>
                  )}

                  {/* Meeting Blocks Positioned Inside the Column */}
                  {dayMeetings.map((m) => {
                    const [startH, startM] = m.startTime.split(':').map(Number);
                    const [endH, endM] = m.endTime.split(':').map(Number);
                    const startMins = startH * 60 + (startM || 0);
                    const endMins = endH * 60 + (endM || 0);
                    const durationMins = Math.max(20, endMins - startMins);

                    const topOffset = (startMins / 60) * HOUR_HEIGHT;
                    const blockHeight = Math.max(24, (durationMins / 60) * HOUR_HEIGHT);
                    const videoLink = getVideoLink(m.location);

                    return (
                      <div
                        key={m.id}
                        onClick={(e) => handleEditMeeting(m, e)}
                        style={{
                          top: `${topOffset}px`,
                          height: `${blockHeight}px`,
                          borderLeftColor: m.color || '#2563EB',
                          backgroundColor: `${m.color || '#2563EB'}33`,
                        }}
                        className="absolute left-1 right-1 rounded-xl p-2 border-l-4 shadow-lg backdrop-blur-xs cursor-pointer hover:brightness-125 transition-all overflow-hidden flex flex-col justify-between group z-5"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[11px] font-bold text-white truncate">
                              {m.title}
                            </span>
                            {videoLink && (
                              <a
                                href={videoLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="p-1 rounded-md bg-blue-500/30 text-blue-300 hover:bg-blue-500/50 transition-colors"
                                title="Join Meeting"
                              >
                                <Video className="w-3 h-3" />
                              </a>
                            )}
                          </div>
                          <div className="text-[10px] font-mono text-slate-300 flex items-center gap-1 mt-0.5">
                            <Clock className="w-2.5 h-2.5 text-slate-400" />
                            <span>
                              {m.startTime} – {m.endTime}
                            </span>
                          </div>
                        </div>

                        {durationMins >= 45 && m.location && (
                          <div className="text-[9px] text-slate-400 truncate flex items-center gap-1">
                            <MapPin className="w-2.5 h-2.5 shrink-0" />
                            <span className="truncate">{m.location}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Day View: Expanded 24-Hour Timeline for Single Day ──────────── */}
      {viewMode === 'day' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Day Timeline (2 cols) */}
          <div className="stagger-2 lg:col-span-2 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] shadow-2xl overflow-hidden flex flex-col">
            {/* Day Header Banner */}
            <div className="p-4 sm:p-5 border-b border-white/[0.08] bg-white/[0.02] flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                  Day Schedule
                </span>
                <h2 className="text-xl font-black text-white">
                  {format(currentDate, 'EEEE, MMMM d, yyyy')}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => handleOpenNewMeeting(format(currentDate, 'yyyy-MM-dd'))}
                className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/20 active:scale-95 transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Schedule Event</span>
              </button>
            </div>

            {/* Hourly Scroll Container */}
            <div
              ref={timeGridScrollRef}
              className="overflow-y-auto max-h-[640px] relative grid grid-cols-[70px_1fr]"
            >
              {/* Left Column: Time Labels */}
              <div className="border-r border-white/[0.06] select-none">
                {HOURS_IN_DAY.map((hour) => (
                  <div
                    key={hour}
                    style={{ height: `${HOUR_HEIGHT}px` }}
                    className="relative text-[11px] font-mono font-bold text-slate-500 pr-3 pt-1 text-right border-b border-white/[0.04]"
                  >
                    {hour === 0 ? '' : `${String(hour).padStart(2, '0')}:00`}
                  </div>
                ))}
              </div>

              {/* Day Time Slot Grid */}
              <div className="relative">
                {HOURS_IN_DAY.map((hour) => {
                  const hourTimeStr = `${String(hour).padStart(2, '0')}:00`;
                  const dayStr = format(currentDate, 'yyyy-MM-dd');
                  return (
                    <div
                      key={hour}
                      onClick={() => handleOpenNewMeeting(dayStr, hourTimeStr)}
                      style={{ height: `${HOUR_HEIGHT}px` }}
                      className="border-b border-white/[0.04] hover:bg-white/[0.02] transition-colors cursor-pointer group relative px-4 flex items-center justify-between"
                    >
                      <span className="opacity-0 group-hover:opacity-100 text-[10px] font-mono text-slate-500">
                        + Schedule at {hourTimeStr}
                      </span>
                    </div>
                  );
                })}

                {/* Red Current Time Line */}
                {checkIsToday(currentDate) && (
                  <div
                    style={{ top: `${(currentTimeMins / 60) * HOUR_HEIGHT}px` }}
                    className="absolute left-0 right-0 z-10 pointer-events-none flex items-center"
                  >
                    <div className="w-3 h-3 rounded-full bg-rose-500 -ml-1.5 shadow-md shadow-rose-500/50" />
                    <div className="h-[2px] bg-rose-500 w-full shadow-md shadow-rose-500/50" />
                  </div>
                )}

                {/* Day Meeting Blocks */}
                {showMeetings &&
                  activeMeetings
                    .filter((m) => m.date === format(currentDate, 'yyyy-MM-dd') && !m.allDay)
                    .map((m) => {
                      const [startH, startM] = m.startTime.split(':').map(Number);
                      const [endH, endM] = m.endTime.split(':').map(Number);
                      const startMins = startH * 60 + (startM || 0);
                      const endMins = endH * 60 + (endM || 0);
                      const durationMins = Math.max(20, endMins - startMins);

                      const topOffset = (startMins / 60) * HOUR_HEIGHT;
                      const blockHeight = Math.max(32, (durationMins / 60) * HOUR_HEIGHT);
                      const videoLink = getVideoLink(m.location);

                      return (
                        <div
                          key={m.id}
                          onClick={() => handleEditMeeting(m)}
                          style={{
                            top: `${topOffset}px`,
                            height: `${blockHeight}px`,
                            borderLeftColor: m.color || '#2563EB',
                            backgroundColor: `${m.color || '#2563EB'}28`,
                          }}
                          className="absolute left-3 right-4 rounded-2xl p-3 border-l-4 shadow-xl backdrop-blur-sm cursor-pointer hover:brightness-125 transition-all overflow-hidden flex flex-col justify-between group z-5"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <h4 className="text-sm font-black text-white">{m.title}</h4>
                              <div className="text-xs font-mono text-slate-300 flex items-center gap-1.5 mt-0.5">
                                <Clock className="w-3 h-3 text-slate-400" />
                                <span>
                                  {m.startTime} – {m.endTime} ({durationMins}m)
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-1">
                              {videoLink && (
                                <a
                                  href={videoLink}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  onClick={(e) => e.stopPropagation()}
                                  className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1 shadow-md transition-colors"
                                >
                                  <Video className="w-3 h-3" />
                                  <span>Join</span>
                                </a>
                              )}
                              <button
                                type="button"
                                onClick={(e) => handleDeleteMeeting(m, e)}
                                className="p-1 rounded-lg hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {m.location && (
                            <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-1 truncate">
                              <MapPin className="w-3 h-3 shrink-0" />
                              <span className="truncate">{m.location}</span>
                            </div>
                          )}
                        </div>
                      );
                    })}
              </div>
            </div>
          </div>

          {/* Side Agenda */}
          <SideAgendaSection
            selectedDate={currentDate}
            selectedDateStr={format(currentDate, 'yyyy-MM-dd')}
            selectedDayMeetings={selectedDayMeetings}
            selectedDayHabits={selectedDayHabits}
            selectedDayTasks={selectedDayTasks}
            habitLogs={habitLogs}
            habitRelapses={habitRelapses}
            toggleHabitDay={toggleHabitDay}
            recordHabitRelapse={recordHabitRelapse}
            clearHabitRelapse={clearHabitRelapse}
            handleOpenNewMeeting={handleOpenNewMeeting}
            handleEditMeeting={handleEditMeeting}
            handleDeleteMeeting={handleDeleteMeeting}
            handleOpenNewTask={handleOpenNewTask}
            getVideoLink={getVideoLink}
          />
        </div>
      )}

      {/* ── Schedule / Agenda View: Chronological List of Events ─────────── */}
      {viewMode === 'schedule' && (
        <div className="stagger-2 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                Agenda Feed
              </span>
              <h2 className="text-xl font-black text-white">Chronological Schedule</h2>
            </div>

            {/* Quick Search Bar */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={scheduleSearch}
                onChange={(e) => setScheduleSearch(e.target.value)}
                placeholder="Search meetings, tasks..."
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400/50"
              />
            </div>
          </div>

          {/* Grouped Chronological Days */}
          <ScheduleAgendaFeed
            currentDate={currentDate}
            showMeetings={showMeetings}
            showTasks={showTasks}
            showHabits={showHabits}
            searchQuery={scheduleSearch}
            activeMeetings={activeMeetings}
            activeTasks={activeTasks}
            activeHabits={activeHabits}
            habitLogs={habitLogs}
            toggleHabitDay={toggleHabitDay}
            toggleTaskComplete={toggleTaskComplete}
            handleEditMeeting={handleEditMeeting}
            handleDeleteMeeting={handleDeleteMeeting}
            getVideoLink={getVideoLink}
          />
        </div>
      )}
    </div>
  );
};

// ── SUB-COMPONENT: Side Agenda Section (Meetings, Habits, Tasks) ────────────
interface SideAgendaSectionProps {
  selectedDate: Date;
  selectedDateStr: string;
  selectedDayMeetings: Meeting[];
  selectedDayHabits: any[];
  selectedDayTasks: any[];
  habitLogs: Map<string, any>;
  habitRelapses: Map<string, any>;
  toggleHabitDay: (habitId: string, dateStr: string) => Promise<void>;
  recordHabitRelapse: (habitId: string, trigger?: string, notes?: string) => Promise<void>;
  clearHabitRelapse: (habitId: string, date: string) => Promise<void>;
  handleOpenNewMeeting: (dateStr?: string) => void;
  handleEditMeeting: (meeting: Meeting) => void;
  handleDeleteMeeting: (meeting: Meeting, e?: React.MouseEvent) => void;
  handleOpenNewTask: (dateStr?: string) => void;
  getVideoLink: (location?: string) => string | null;
}

const SideAgendaSection: React.FC<SideAgendaSectionProps> = ({
  selectedDate,
  selectedDateStr,
  selectedDayMeetings,
  selectedDayHabits,
  selectedDayTasks,
  habitLogs,
  habitRelapses,
  toggleHabitDay,
  recordHabitRelapse,
  clearHabitRelapse,
  handleOpenNewMeeting,
  handleEditMeeting,
  handleDeleteMeeting,
  handleOpenNewTask,
  getVideoLink,
}) => {
  return (
    <div className="stagger-3 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-6">
      <div className="border-b border-white/[0.07] pb-4">
        <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Day Agenda</span>
        </span>
        <h2 className="text-xl font-black text-white mt-0.5 tracking-tight">
          {format(selectedDate, 'EEEE, MMM d, yyyy')}
        </h2>
      </div>

      {/* ── Section 1: Meetings & Calendar Events ───────────────────── */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
            <CalendarIcon className="w-3.5 h-3.5 text-blue-400" />
            <span>Meetings ({selectedDayMeetings.length})</span>
          </h3>
          <button
            type="button"
            onClick={() => handleOpenNewMeeting(selectedDateStr)}
            className="text-[11px] font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <Plus className="w-3 h-3" />
            <span>Add Meeting</span>
          </button>
        </div>

        {selectedDayMeetings.length === 0 ? (
          <p className="text-xs text-slate-500 py-2">No meetings scheduled for this date.</p>
        ) : (
          <div className="space-y-2.5">
            {selectedDayMeetings.map((m) => {
              const videoLink = getVideoLink(m.location);
              return (
                <div
                  key={m.id}
                  onClick={() => handleEditMeeting(m)}
                  style={{ borderLeftColor: m.color || '#2563EB' }}
                  className="p-3 rounded-2xl border border-white/[0.06] border-l-4 bg-white/[0.02] hover:bg-white/[0.05] transition-all cursor-pointer group space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-white truncate group-hover:text-blue-300 transition-colors">
                        {m.title}
                      </h4>
                      <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3 text-slate-500" />
                        <span>
                          {m.allDay ? 'All Day' : `${m.startTime} – ${m.endTime}`}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      {videoLink && (
                        <a
                          href={videoLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="px-2 py-0.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] flex items-center gap-1 transition-colors"
                          title="Join Meeting"
                        >
                          <Video className="w-2.5 h-2.5" />
                          <span>Join</span>
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={(e) => handleDeleteMeeting(m, e)}
                        className="p-1 rounded-md text-slate-500 hover:text-rose-400 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {m.location && (
                    <div className="text-[11px] text-slate-400 flex items-center gap-1 truncate">
                      <MapPin className="w-3 h-3 shrink-0 text-slate-500" />
                      <span className="truncate">{m.location}</span>
                    </div>
                  )}

                  {m.reminders && m.reminders.length > 0 && (
                    <div className="flex items-center gap-1 flex-wrap pt-1 border-t border-white/[0.04]">
                      <Bell className="w-2.5 h-2.5 text-amber-400/80 shrink-0" />
                      <span className="text-[9px] text-slate-400 font-mono">
                        {m.reminders.map((r) => `${r.minutesBefore}m`).join(', ')} before
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ── Section 2: Scheduled Habits ──────────────────────────────── */}
      <div className="space-y-3 pt-4 border-t border-white/[0.07]">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>Habits ({selectedDayHabits.length})</span>
          </h3>
        </div>

        {selectedDayHabits.length === 0 ? (
          <p className="text-xs text-slate-500 py-2">No habits scheduled for this date.</p>
        ) : (
          <div className="space-y-2">
            {selectedDayHabits.map((habit) => {
              const isQuit = habit.category === 'quit';
              const log = habitLogs.get(`${habit.id}_${selectedDateStr}`);
              const isDone = log && log.completed && !log.deleted;
              const isRelapsed =
                isQuit &&
                Array.from(habitRelapses.values()).some(
                  (r) => r.habitId === habit.id && r.date === selectedDateStr && !r.deleted
                );

              return (
                <div
                  key={habit.id}
                  onClick={() => {
                    if (isQuit) {
                      if (isRelapsed) {
                        clearHabitRelapse(habit.id, selectedDateStr);
                      } else {
                        recordHabitRelapse(habit.id, undefined, `Slipped on ${selectedDateStr}`);
                      }
                    } else {
                      toggleHabitDay(habit.id, selectedDateStr);
                    }
                  }}
                  className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all active:scale-[0.98] ${
                    isQuit
                      ? isRelapsed
                        ? 'border-rose-500/30 bg-rose-500/10'
                        : 'border-emerald-500/30 bg-emerald-500/10'
                      : isDone
                      ? 'border-emerald-500/30 bg-emerald-500/10'
                      : 'border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.05]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      style={{ backgroundColor: isRelapsed ? '#F43F5E' : habit.color }}
                      className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs"
                    />
                    <span
                      className={`text-xs font-bold truncate ${
                        isRelapsed
                          ? 'text-rose-400'
                          : isDone
                          ? 'text-emerald-400'
                          : 'text-slate-200'
                      }`}
                    >
                      {habit.name}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-slate-400">
                    {isQuit
                      ? isRelapsed
                        ? '⚠ Slipped'
                        : '✓ Clean'
                      : isDone
                      ? '✓ Done'
                      : 'Pending'}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ── Section 3: Tasks Due ─────────────────────────────────────── */}
      <div className="space-y-3 pt-4 border-t border-white/[0.07]">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Tasks Due ({selectedDayTasks.length})</span>
          </h3>
          <button
            type="button"
            onClick={() => handleOpenNewTask(selectedDateStr)}
            className="text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <Plus className="w-3 h-3" />
            <span>Add Task</span>
          </button>
        </div>

        {selectedDayTasks.length === 0 ? (
          <p className="text-xs text-slate-500 py-2">No tasks due on this date.</p>
        ) : (
          <div className="space-y-2">
            {selectedDayTasks.map((t) => (
              <TaskItem key={t.id} task={t} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ── SUB-COMPONENT: Schedule / Agenda Feed ──────────────────────────────────
interface ScheduleAgendaFeedProps {
  currentDate: Date;
  showMeetings: boolean;
  showTasks: boolean;
  showHabits: boolean;
  searchQuery: string;
  activeMeetings: Meeting[];
  activeTasks: any[];
  activeHabits: any[];
  habitLogs: Map<string, any>;
  toggleHabitDay: (habitId: string, dateStr: string) => Promise<void>;
  toggleTaskComplete: (taskId: string) => Promise<void>;
  handleEditMeeting: (meeting: Meeting) => void;
  handleDeleteMeeting: (meeting: Meeting, e?: React.MouseEvent) => void;
  getVideoLink: (location?: string) => string | null;
}

const ScheduleAgendaFeed: React.FC<ScheduleAgendaFeedProps> = ({
  currentDate,
  showMeetings,
  showTasks,
  showHabits,
  searchQuery,
  activeMeetings,
  activeTasks,
  activeHabits,
  habitLogs,
  toggleHabitDay,
  toggleTaskComplete,
  handleEditMeeting,
  handleDeleteMeeting,
  getVideoLink,
}) => {
  // Generate 45 days forward from start of current month
  const daysList = useMemo(() => {
    const start = startOfMonth(currentDate);
    return Array.from({ length: 45 }, (_, i) => addDays(start, i));
  }, [currentDate]);

  const query = searchQuery.trim().toLowerCase();

  return (
    <div className="space-y-6">
      {daysList.map((day) => {
        const dayStr = format(day, 'yyyy-MM-dd');
        const isToday = checkIsToday(day);

        // Filter items
        let dayMeetings = showMeetings
          ? activeMeetings.filter((m) => m.date === dayStr)
          : [];
        let dayTasks = showTasks
          ? activeTasks.filter((t) => t.dueDate && t.dueDate.startsWith(dayStr))
          : [];
        let dayHabits = showHabits
          ? activeHabits.filter((h) => HabitService.isHabitScheduledForDate(h, dayStr))
          : [];

        if (query) {
          dayMeetings = dayMeetings.filter(
            (m) =>
              m.title.toLowerCase().includes(query) ||
              (m.location && m.location.toLowerCase().includes(query)) ||
              (m.description && m.description.toLowerCase().includes(query))
          );
          dayTasks = dayTasks.filter((t) => t.title.toLowerCase().includes(query));
          dayHabits = dayHabits.filter((h) => h.name.toLowerCase().includes(query));
        }

        const totalItems = dayMeetings.length + dayTasks.length + dayHabits.length;
        if (totalItems === 0) return null;

        return (
          <div
            key={dayStr}
            className={`rounded-2xl border p-4 sm:p-5 transition-all ${
              isToday
                ? 'border-amber-400/40 bg-amber-400/[0.04]'
                : 'border-white/[0.06] bg-white/[0.02]'
            }`}
          >
            {/* Day Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.06] mb-3">
              <div className="flex items-center gap-3">
                <span
                  className={`text-sm font-black ${
                    isToday ? 'text-amber-300' : 'text-white'
                  }`}
                >
                  {format(day, 'EEEE, MMMM d, yyyy')}
                </span>
                {isToday && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-[10px] uppercase">
                    Today
                  </span>
                )}
              </div>
              <span className="text-xs font-mono text-slate-400">
                {totalItems} item{totalItems > 1 ? 's' : ''}
              </span>
            </div>

            {/* Items List */}
            <div className="space-y-2">
              {/* Meetings */}
              {dayMeetings.map((m) => {
                const videoLink = getVideoLink(m.location);
                return (
                  <div
                    key={m.id}
                    onClick={() => handleEditMeeting(m)}
                    style={{ borderLeftColor: m.color || '#2563EB' }}
                    className="p-3 rounded-xl border border-white/[0.06] border-l-4 bg-white/[0.02] hover:bg-white/[0.05] transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-blue-500/15 text-blue-400 flex items-center justify-center shrink-0">
                        <CalendarIcon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-white truncate group-hover:text-blue-300">
                          {m.title}
                        </h4>
                        <div className="text-[11px] font-mono text-slate-400 flex items-center gap-2 mt-0.5">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {m.allDay ? 'All Day' : `${m.startTime} – ${m.endTime}`}
                          </span>
                          {m.location && (
                            <span className="truncate flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {m.location}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                      {videoLink && (
                        <a
                          href={videoLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition-colors"
                        >
                          <Video className="w-3 h-3" />
                          <span>Join Meeting</span>
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={(e) => handleDeleteMeeting(m, e)}
                        className="p-1 rounded-md text-slate-500 hover:text-rose-400 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {/* Tasks */}
              {dayTasks.map((t) => (
                <div
                  key={t.id}
                  className="p-2.5 rounded-xl border border-white/[0.04] bg-white/[0.01] flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      type="button"
                      onClick={() => toggleTaskComplete(t.id)}
                      className={`w-4 h-4 rounded border flex items-center justify-center transition-colors cursor-pointer ${
                        t.completed
                          ? 'bg-amber-400 border-amber-400 text-slate-950'
                          : 'border-white/20 hover:border-amber-400'
                      }`}
                    >
                      {t.completed && <CheckCircle2 className="w-3 h-3" />}
                    </button>
                    <span
                      className={`text-xs font-medium truncate ${
                        t.completed ? 'line-through text-slate-500' : 'text-slate-200'
                      }`}
                    >
                      {t.title}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase px-2 py-0.5 rounded bg-white/[0.04]">
                    Task ({t.priority})
                  </span>
                </div>
              ))}

              {/* Habits */}
              {dayHabits.map((h) => {
                const log = habitLogs.get(`${h.id}_${dayStr}`);
                const isDone = log && log.completed && !log.deleted;
                return (
                  <div
                    key={h.id}
                    onClick={() => toggleHabitDay(h.id, dayStr)}
                    className="p-2.5 rounded-xl border border-white/[0.04] bg-white/[0.01] hover:bg-white/[0.03] flex items-center justify-between gap-3 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        style={{ backgroundColor: h.color }}
                        className="w-2 h-2 rounded-full shrink-0"
                      />
                      <span className="text-xs font-medium text-slate-300 truncate">
                        {h.name}
                      </span>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        isDone
                          ? 'bg-emerald-500/15 text-emerald-400'
                          : 'bg-white/[0.04] text-slate-500'
                      }`}
                    >
                      {isDone ? '✓ Completed' : 'Pending'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default SharedCalendarView;
