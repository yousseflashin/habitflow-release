// Aureus Chronos — Meeting & Calendar Event Modal (Google Calendar Style)

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Meeting, MeetingReminder } from '../../types';
import {
  Calendar,
  Clock,
  MapPin,
  Video,
  FileText,
  Trash2,
  X,
  Bell,
  Check,
  ExternalLink,
  Sparkles,
} from 'lucide-react';

interface MeetingModalProps {
  isOpen: boolean;
  onClose: () => void;
  meeting?: Meeting | null;
  defaultDate?: string;
  defaultStartTime?: string;
}

const COLOR_PALETTE = [
  { name: 'Cobalt', hex: '#2563EB' },
  { name: 'Emerald', hex: '#059669' },
  { name: 'Amethyst', hex: '#7C3AED' },
  { name: 'Amber', hex: '#D97706' },
  { name: 'Crimson', hex: '#E11D48' },
  { name: 'Cyan', hex: '#0891B2' },
  { name: 'Indigo', hex: '#4F46E5' },
  { name: 'Pink', hex: '#DB2777' },
];

const REMINDER_PRESETS = [
  { label: 'At start time', minutes: 0 },
  { label: '5 min before', minutes: 5 },
  { label: '10 min before', minutes: 10 },
  { label: '15 min before', minutes: 15 },
  { label: '30 min before', minutes: 30 },
  { label: '1 hour before', minutes: 60 },
  { label: '1 day before', minutes: 1440 },
];

export const MeetingModal: React.FC<MeetingModalProps> = ({
  isOpen,
  onClose,
  meeting,
  defaultDate,
  defaultStartTime,
}) => {
  const { createMeeting, updateMeeting, deleteMeeting } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [allDay, setAllDay] = useState(false);
  const [location, setLocation] = useState('');
  const [color, setColor] = useState('#2563EB');
  const [reminders, setReminders] = useState<MeetingReminder[]>([
    { id: 'rem_default', minutesBefore: 10, enabled: true },
  ]);

  useEffect(() => {
    if (meeting) {
      setTitle(meeting.title || '');
      setDescription(meeting.description || '');
      setDate(meeting.date || new Date().toISOString().substring(0, 10));
      setStartTime(meeting.startTime || '09:00');
      setEndTime(meeting.endTime || '10:00');
      setAllDay(meeting.allDay || false);
      setLocation(meeting.location || '');
      setColor(meeting.color || '#2563EB');
      setReminders(meeting.reminders?.length ? meeting.reminders : [{ id: 'rem_default', minutesBefore: 10, enabled: true }]);
    } else {
      const todayStr = defaultDate || new Date().toISOString().substring(0, 10);
      setTitle('');
      setDescription('');
      setDate(todayStr);
      const start = defaultStartTime || '09:00';
      setStartTime(start);
      // Auto-set end time 1 hour after start
      const [h, m] = start.split(':').map(Number);
      const endH = (h + 1) % 24;
      setEndTime(`${String(endH).padStart(2, '0')}:${String(m || 0).padStart(2, '0')}`);
      setAllDay(false);
      setLocation('');
      setColor('#2563EB');
      setReminders([{ id: 'rem_default', minutesBefore: 10, enabled: true }]);
    }
  }, [meeting, isOpen, defaultDate, defaultStartTime]);

  if (!isOpen) return null;

  const handleAddDuration = (minsToAdd: number) => {
    const [h, m] = startTime.split(':').map(Number);
    if (isNaN(h) || isNaN(m)) return;
    const totalMins = h * 60 + m + minsToAdd;
    const newH = Math.floor(totalMins / 60) % 24;
    const newM = totalMins % 60;
    setEndTime(`${String(newH).padStart(2, '0')}:${String(newM).padStart(2, '0')}`);
  };

  const toggleReminderPreset = (minutes: number) => {
    const exists = reminders.find((r) => r.minutesBefore === minutes);
    if (exists) {
      setReminders((prev) => prev.filter((r) => r.minutesBefore !== minutes));
    } else {
      setReminders((prev) => [
        ...prev,
        { id: `rem_${Date.now()}_${minutes}`, minutesBefore: minutes, enabled: true },
      ]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (meeting?.id) {
      await updateMeeting(meeting.id, {
        title: title.trim(),
        description: description.trim(),
        date,
        startTime,
        endTime,
        allDay,
        location: location.trim(),
        color,
        reminders,
        updatedAt: new Date().toISOString(),
      });
    } else {
      await createMeeting({
        title: title.trim(),
        description: description.trim(),
        date,
        startTime,
        endTime,
        allDay,
        location: location.trim(),
        color,
        reminders,
      });
    }

    onClose();
  };

  const handleDelete = async () => {
    if (!meeting?.id) return;
    if (confirm(`Delete meeting "${meeting.title}"?`)) {
      await deleteMeeting(meeting.id);
      onClose();
    }
  };

  const isVideoLink = location.includes('meet.google.com') || location.includes('zoom.us') || location.includes('teams.microsoft.com');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="rounded-3xl bg-[#0c0e14] border border-white/[0.1] w-full max-w-lg shadow-2xl overflow-hidden my-auto relative text-white">
        {/* Header with color indicator banner */}
        <div className="p-6 border-b border-white/[0.08] flex items-center justify-between relative bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center border shadow-xs"
              style={{
                backgroundColor: `${color}25`,
                borderColor: `${color}50`,
                color: color,
              }}
            >
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-amber-400">
                <Sparkles className="w-3 h-3" />
                <span>Google Calendar Style Event</span>
              </div>
              <h2 className="text-lg font-black text-white tracking-tight">
                {meeting ? 'Edit Meeting / Event' : 'Schedule New Meeting'}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Title */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Meeting Title *
            </label>
            <input
              type="text"
              required
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Q4 Strategy Review, Client Demo, Team 1:1"
              className="w-full px-4 py-3 rounded-2xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-400/50 transition-all"
            />
          </div>

          {/* Date & Time Row */}
          <div className="space-y-3 p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Date &amp; Time</span>
              </span>

              <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-400">
                <input
                  type="checkbox"
                  checked={allDay}
                  onChange={(e) => setAllDay(e.target.checked)}
                  className="rounded border-white/20 bg-white/5 text-amber-400 focus:ring-0"
                />
                <span>All Day</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="sm:col-span-1">
                <label className="block text-[10px] text-slate-400 font-mono mb-1">Date</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white/[0.05] border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              {!allDay && (
                <>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">Start Time</label>
                    <input
                      type="time"
                      required
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white/[0.05] border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">End Time</label>
                    <input
                      type="time"
                      required
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white/[0.05] border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </>
              )}
            </div>

            {/* Quick duration presets */}
            {!allDay && (
              <div className="flex items-center gap-1.5 pt-1 text-[11px] text-slate-400">
                <span className="text-[10px] uppercase font-mono mr-1">Duration:</span>
                {[
                  { label: '+15m', mins: 15 },
                  { label: '+30m', mins: 30 },
                  { label: '+45m', mins: 45 },
                  { label: '+1h', mins: 60 },
                  { label: '+2h', mins: 120 },
                ].map((chip) => (
                  <button
                    key={chip.label}
                    type="button"
                    onClick={() => handleAddDuration(chip.mins)}
                    className="px-2 py-0.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 text-[10px] font-mono cursor-pointer transition-colors"
                  >
                    {chip.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Meeting Link / Location */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                {isVideoLink ? <Video className="w-3.5 h-3.5 text-sky-400" /> : <MapPin className="w-3.5 h-3.5 text-amber-400" />}
                <span>Meeting Link or Location</span>
              </span>
              {isVideoLink && (
                <span className="text-[10px] text-sky-400 font-mono">Video Link Detected</span>
              )}
            </label>
            <div className="relative">
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="https://meet.google.com/xyz or Zoom link / Room B"
                className="w-full pl-4 pr-10 py-2.5 rounded-2xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400/50 transition-all font-mono"
              />
              {location.startsWith('http') && (
                <a
                  href={location}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  title="Test link"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>

          {/* Reminders & Notifications */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-amber-400" />
              <span>Multi-Platform Notifications (Mobile, Desktop, Web)</span>
            </label>
            <div className="flex flex-wrap gap-1.5">
              {REMINDER_PRESETS.map((preset) => {
                const isSelected = reminders.some((r) => r.minutesBefore === preset.minutes);
                return (
                  <button
                    key={preset.minutes}
                    type="button"
                    onClick={() => toggleReminderPreset(preset.minutes)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-amber-400/15 border-amber-400/40 text-amber-300 shadow-xs'
                        : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-white hover:bg-white/[0.06]'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3 text-amber-400" />}
                    <span>{preset.label}</span>
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-slate-500 font-mono">
              Notifications fire on your Android status bar, Linux desktop (notify-send), and browser window.
            </p>
          </div>

          {/* Color Tag */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Calendar Color Tag
            </label>
            <div className="flex items-center gap-2">
              {COLOR_PALETTE.map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  onClick={() => setColor(c.hex)}
                  style={{ backgroundColor: c.hex }}
                  className={`w-7 h-7 rounded-xl transition-all cursor-pointer flex items-center justify-center ${
                    color === c.hex ? 'ring-2 ring-white scale-110 shadow-lg' : 'opacity-80 hover:opacity-100 hover:scale-105'
                  }`}
                  title={c.name}
                >
                  {color === c.hex && <Check className="w-3.5 h-3.5 text-white drop-shadow-sm" />}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>Agenda &amp; Notes</span>
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Key talking points, zoom passcodes, agenda..."
              className="w-full px-4 py-2.5 rounded-2xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400/50 transition-all resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-white/[0.08]">
            {meeting?.id ? (
              <button
                type="button"
                onClick={handleDelete}
                className="py-2.5 px-3.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 border border-rose-500/25 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete</span>
              </button>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 font-bold text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary !py-2.5 !px-5 !text-xs !rounded-xl !shadow-glow-sm cursor-pointer"
              >
                {meeting ? 'Save Changes' : 'Schedule Meeting'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
