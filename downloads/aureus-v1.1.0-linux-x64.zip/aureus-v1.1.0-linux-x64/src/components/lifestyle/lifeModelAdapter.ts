// Bridge between the existing habit/log data model and the whole-life progress engine.
//
// The app already stores habits and (habitId, date) logs. Rather than migrate that
// storage, we ADAPT it: every existing habit becomes an Activity, its targetCount
// becomes the daily target, and its logs become DailyActivityResults. This keeps
// sync, the CRDT store, and the MonsterASP schema untouched.
//
// The adapter runs on every render over the current dataset — it is a pure mapping,
// cheap enough for the sizes involved (hundreds of habits × a year of logs).

import { useMemo } from 'react';
import { Habit, HabitLog, HabitRelapseLog } from '../../types';
import {
  Activity,
  ActivityMetric,
  DailyActivityResult,
  AttributeKey,
  MuscleGroup,
  normalizeDimensionWeights,
} from '../../domain/lifeProgressService';
import { buildLifeProfile, LifeProfile } from '../../domain/lifeProfileService';
import { format, parseISO } from 'date-fns';

/** Icon-name → sensible default life-model weights. */
const PRESET_WEIGHTS: Record<
  string,
  {
    body: number;
    health: number;
    intelligence: number;
    spirit: number;
    attributes?: Partial<Record<AttributeKey, number>>;
    muscles?: Partial<Record<MuscleGroup, number>>;
  }
> = {
  dumbbell: {
    body: 0.65, health: 0.2, intelligence: 0.05, spirit: 0.1,
    attributes: { strength: 0.9, discipline: 0.2 },
    muscles: { chest: 0.6, arms: 0.5, shoulders: 0.4, back: 0.4, legs: 0.3, core: 0.2 },
  },
  footprints: {
    body: 0.55, health: 0.35, intelligence: 0.05, spirit: 0.05,
    attributes: { endurance: 0.8, consistency: 0.3 },
    muscles: { legs: 0.4, calves: 0.4, cardio: 0.7 },
  },
  run: {
    body: 0.65, health: 0.25, intelligence: 0.05, spirit: 0.05,
    attributes: { endurance: 0.9, recovery: 0.2 },
    muscles: { legs: 0.5, calves: 0.5, cardio: 1 },
  },
  bike: {
    body: 0.6, health: 0.3, intelligence: 0.05, spirit: 0.05,
    attributes: { endurance: 0.9, recovery: 0.2 },
    muscles: { legs: 0.4, cardio: 0.9 },
  },
  droplet: {
    body: 0.7, health: 0.05, intelligence: 0.05, spirit: 0.25,
    attributes: { recovery: 0.6, consistency: 0.4 },
  },
  'glass-water': {
    body: 0.7, health: 0.05, intelligence: 0.05, spirit: 0.25,
    attributes: { recovery: 0.6, consistency: 0.4 },
  },
  book: {
    body: 0.05, health: 0.05, intelligence: 0.75, spirit: 0.2,
    attributes: { knowledge: 0.9, intelligence: 0.4, focus: 0.3 },
  },
  'book-open': {
    body: 0.05, health: 0.05, intelligence: 0.75, spirit: 0.2,
    attributes: { knowledge: 0.9, intelligence: 0.4, focus: 0.3 },
  },
  code: {
    body: 0.05, health: 0.05, intelligence: 0.8, spirit: 0.15,
    attributes: { intelligence: 0.7, creativity: 0.5, focus: 0.5, learning: 0.6 },
  },
  brain: {
    body: 0.1, health: 0.05, intelligence: 0.7, spirit: 0.2,
    attributes: { intelligence: 0.6, focus: 0.6, learning: 0.5 },
  },
  sparkles: {
    body: 0.1, health: 0.05, intelligence: 0.4, spirit: 0.5,
    attributes: { focus: 0.6, reflection: 0.5, discipline: 0.3, selfControl: 0.4 },
  },
  moon: {
    body: 0.6, health: 0.25, intelligence: 0.05, spirit: 0.15,
    attributes: { recovery: 1, focus: 0.3 },
  },
  heart: {
    body: 0.4, health: 0.2, intelligence: 0.05, spirit: 0.4,
    attributes: { recovery: 0.4, reflection: 0.3, selfControl: 0.3 },
  },
  flame: {
    body: 0.3, health: 0.05, intelligence: 0.2, spirit: 0.5,
    attributes: { discipline: 0.7, consistency: 0.5, selfControl: 0.5 },
  },
  shield: {
    body: 0.4, health: 0.05, intelligence: 0.2, spirit: 0.4,
    attributes: { selfControl: 0.9, discipline: 0.6 },
  },
  target: {
    body: 0.2, health: 0.05, intelligence: 0.3, spirit: 0.5,
    attributes: { purpose: 0.8, discipline: 0.5, reflection: 0.3 },
  },
  users: {
    body: 0.1, health: 0.05, intelligence: 0.3, spirit: 0.6,
    attributes: { reflection: 0.4, purpose: 0.3, selfControl: 0.3 },
  },
  music: {
    body: 0.2, health: 0.05, intelligence: 0.4, spirit: 0.4,
    attributes: { creativity: 0.8, focus: 0.3, reflection: 0.3 },
  },
  palette: {
    body: 0.1, health: 0.05, intelligence: 0.4, spirit: 0.5,
    attributes: { creativity: 1, focus: 0.3 },
  },
  coffee: {
    body: 0.3, health: 0.05, intelligence: 0.5, spirit: 0.2,
    attributes: { focus: 0.5, consistency: 0.2 },
  },
  salad: {
    body: 0.15, health: 0.75, intelligence: 0.05, spirit: 0.05,
    attributes: { recovery: 0.7, consistency: 0.3 },
  },
  apple: {
    body: 0.15, health: 0.75, intelligence: 0.05, spirit: 0.05,
    attributes: { recovery: 0.7, consistency: 0.3 },
  },
  ban: {
    body: 0.3, health: 0.05, intelligence: 0.2, spirit: 0.5,
    attributes: { selfControl: 0.9, discipline: 0.7 },
  },
};

const FALLBACK = {
  body: 0.3, health: 0.25, intelligence: 0.25, spirit: 0.2,
  attributes: { consistency: 0.4, discipline: 0.3 } as Partial<Record<AttributeKey, number>>,
};

/** Unit names → metric kind, so the input UI matches what the user is logging. */
function inferMetric(unit: string): ActivityMetric {
  const u = (unit || '').toLowerCase();
  if (u.includes('min') || u.includes('hour') || u === 'h' || u === 'hr') return 'duration';
  if (u.includes('km') || u.includes('mile') || u.includes('m ')) return 'distance';
  if (u.includes('%')) return 'percentage';
  if (u.includes('rep') || u.includes('set')) return 'reps';
  if (u.includes('step')) return 'quantity';
  if (u.includes('time') || u.includes('session') || u.includes('day')) return 'completion';
  return 'quantity';
}

/** Set count inferred from the habit's target unit ("12 x 3" style), if any. */
function inferSets(habit: Habit): number | undefined {
  const m = /(\d+)\s*[x×]\s*(\d+)/.exec(habit.targetUnit || '');
  return m ? parseInt(m[2], 10) : undefined;
}

/** Adapt one habit into an Activity for the life-progress engine. */
export function habitToActivity(habit: Habit): Activity {
  const preset = PRESET_WEIGHTS[habit.icon] ?? FALLBACK;

  return {
    id: habit.id,
    name: habit.name,
    description: habit.description,
    icon: habit.icon,
    color: habit.color,
    polarity: habit.category === 'quit' ? 'negative' : 'positive',
    metric: habit.category === 'quit' ? 'completion' : inferMetric(habit.targetUnit),
    target: habit.category === 'quit' ? 1 : Math.max(1, habit.targetCount || 1),
    unit: habit.targetUnit || 'times',
    // A quit habit's whole point is that resisting counts; give it a strong
    // but bounded voice so it is not drowned out by high-frequency positives.
    maxDailyContribution: habit.category === 'quit' ? 1 : undefined,
    intensity: 1,
    targetSets: inferSets(habit),
    startDate: habit.startDate,
    archived: habit.archived,
    deleted: habit.deleted,
    weights: {
      body: preset.body,
      health: preset.health,
      intelligence: preset.intelligence,
      spirit: preset.spirit,
      attributes: preset.attributes,
      muscles: preset.muscles,
    },
  };
}

/**
 * Adapt habit logs (+ relapse logs for quit habits) into daily activity results.
 *
 * For quit habits a clean day has NO log row at all in the existing model — it is
 * simply the absence of a relapse. We therefore synthesize a clean result for
 * every day between the habit's start date and today, then overwrite the days
 * that actually have a relapse. Without this, a smoke-free month would score zero.
 */
export function adaptLogsToResults(
  habits: Habit[],
  logs: Map<string, HabitLog>,
  relapses: Map<string, HabitRelapseLog>,
  today: Date
): DailyActivityResult[] {
  const out: DailyActivityResult[] = [];
  const todayStr = format(today, 'yyyy-MM-dd');
  const habitById = new Map(habits.map((h) => [h.id, h]));

  // 1. Positive habits: one result per existing log row.
  for (const log of logs.values()) {
    if (log.deleted) continue;
    const habit = habitById.get(log.habitId);
    if (!habit || habit.deleted || habit.category === 'quit') continue;
    if (log.date > todayStr) continue;
    // If the habit's unit encodes "12 x 3", each finished set of 12 reps
    // counts as one set; leftover reps are partial credit on the next set.
    const setMatch = /(\d+)\s*[x×]\s*(\d+)/.exec(habit.targetUnit || '');
    const repsPerSet = setMatch ? parseInt(setMatch[1], 10) : 0;
    out.push({
      activityId: log.habitId,
      date: log.date,
      actual: log.count ?? 0,
      completed: log.completed,
      setsDone: repsPerSet > 0 ? Math.floor((log.count ?? 0) / repsPerSet) : undefined,
    });
  }

  // 2. Quit habits: synthesize clean days, then stamp relapses over them.
  for (const habit of habits) {
    if (habit.deleted || habit.category !== 'quit') continue;

    const relapsedDates = new Set<string>();
    for (const r of relapses.values()) {
      if (r.deleted) continue;
      if (r.habitId === habit.id) relapsedDates.add(r.date);
    }

    const start = habit.startDate || todayStr;
    if (start > todayStr) continue;

    // Cap the synthesized range at ~2 years to stay bounded on long-lived habits.
    const maxDays = 730;
    const startDate = new Date(parseISO(start).getTime());
    const spanDays = Math.floor((today.getTime() - startDate.getTime()) / 86400000);
    const from = spanDays > maxDays ? new Date(today.getTime() - maxDays * 86400000) : startDate;

    const cursor = new Date(from);
    while (cursor <= today) {
      const date = format(cursor, 'yyyy-MM-dd');
      const relapsed = relapsedDates.has(date);
      out.push({
        activityId: habit.id,
        date,
        actual: relapsed ? 1 : 0,
        completed: !relapsed,
        relapsed,
      });
      cursor.setDate(cursor.getDate() + 1);
    }
  }

  return out;
}

export interface AdaptedLifeData {
  activities: Activity[];
  results: DailyActivityResult[];
  profile: LifeProfile;
  /** activityId → actual logged today, for the Today list. */
  todaysResults: Map<string, number>;
}

/** Full pipeline: habits + logs → activities → results → life profile. */
export function useLifeProfile(
  habits: Habit[],
  logs: Map<string, HabitLog>,
  relapses: Map<string, HabitRelapseLog>
): AdaptedLifeData {
  return useMemo(() => {
    const today = new Date();
    const activities = habits.filter((h) => !h.deleted).map(habitToActivity);
    const results = adaptLogsToResults(habits, logs, relapses, today);
    const profile = buildLifeProfile(activities, results, { today });

    const todayStr = format(today, 'yyyy-MM-dd');
    const todaysResults = new Map<string, number>();
    for (const r of results) {
      if (r.date !== todayStr) continue;
      // For a quit habit, 0 means "held" — keep 0 so the UI shows the resist state.
      todaysResults.set(r.activityId, r.actual);
    }

    return { activities, results, profile, todaysResults };
  }, [habits, logs, relapses]);
}

export { normalizeDimensionWeights };
