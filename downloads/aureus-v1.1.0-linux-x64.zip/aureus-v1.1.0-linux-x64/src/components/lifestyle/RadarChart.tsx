import React, { useMemo } from 'react';
import { LifestyleArea, LifestyleMetric } from '../../types';

interface RadarChartProps {
  areas: LifestyleArea[];
  metrics: Map<string, LifestyleMetric>;
  metricScores: Map<string, number>;
  size?: number;
}

export const RadarChart: React.FC<RadarChartProps> = ({
  areas,
  metrics,
  metricScores,
  size = 320,
}) => {
  const center = size / 2;
  const radius = (size / 2) - 45;

  // Calculate normalized 0-100 score for each area
  const areaData = useMemo(() => {
    const active = areas.filter(a => !a.deleted).sort((a, b) => a.order - b.order);
    if (active.length < 3) return [];

    return active.map(area => {
      let areaScoreSum = 0;
      let areaScoreCount = 0;

      Array.from(metrics.values()).forEach(m => {
        if (!m.deleted && m.areaId === area.id) {
          const s = metricScores.get(m.id) || 0;
          areaScoreSum += s;
          areaScoreCount += 1;
        }
      });

      // Default baseline score between 20-80 for nice radar representation if no metrics
      const avgScore = areaScoreCount > 0 ? Math.min(100, Math.max(5, areaScoreSum / areaScoreCount)) : 25;

      return {
        id: area.id,
        name: area.name,
        color: area.color,
        score: avgScore,
      };
    });
  }, [areas, metrics, metricScores]);

  if (areaData.length < 3) {
    return null;
  }

  const numPoints = areaData.length;
  const angleStep = (Math.PI * 2) / numPoints;

  // Concentric polygon grid levels: 25%, 50%, 75%, 100%
  const gridLevels = [0.25, 0.5, 0.75, 1.0];

  const getCoordinates = (index: number, valueRatio: number) => {
    const angle = index * angleStep - Math.PI / 2;
    const r = radius * valueRatio;
    return {
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle),
    };
  };

  // Build the data polygon path
  const dataPoints = areaData.map((d, i) => getCoordinates(i, d.score / 100));
  const dataPolygonString = dataPoints.map(p => `${p.x},${p.y}`).join(' ');

  return (
    <div className="flex flex-col items-center justify-center p-2">
      <svg width={size} height={size} className="overflow-visible select-none">
        <defs>
          <linearGradient id="radarGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#10B981" stopOpacity="0.45" />
            <stop offset="50%" stopColor="#06B6D4" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0.45" />
          </linearGradient>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Background Grid Rings */}
        {gridLevels.map((lvl, idx) => {
          const ringPoints = areaData
            .map((_, i) => getCoordinates(i, lvl))
            .map(p => `${p.x},${p.y}`)
            .join(' ');

          return (
            <g key={idx}>
              <polygon
                points={ringPoints}
                className="stroke-slate-200 dark:stroke-slate-800 fill-transparent"
                strokeWidth="1"
                strokeDasharray={lvl === 1.0 ? 'none' : '3,3'}
              />
              {/* Ring percentage label */}
              <text
                x={center + 4}
                y={center - radius * lvl + 10}
                className="text-[9px] fill-slate-400 dark:fill-slate-600 font-mono"
              >
                {Math.round(lvl * 100)}%
              </text>
            </g>
          );
        })}

        {/* Spokes from center */}
        {areaData.map((_, i) => {
          const end = getCoordinates(i, 1.0);
          return (
            <line
              key={i}
              x1={center}
              y1={center}
              x2={end.x}
              y2={end.y}
              className="stroke-slate-200 dark:stroke-slate-800"
              strokeWidth="1"
            />
          );
        })}

        {/* Filled Data Polygon */}
        <polygon
          points={dataPolygonString}
          fill="url(#radarGradient)"
          className="stroke-emerald-500 dark:stroke-emerald-400"
          strokeWidth="2.5"
          filter="url(#glow)"
        />

        {/* Data Vertices */}
        {dataPoints.map((p, i) => (
          <g key={i}>
            <circle
              cx={p.x}
              cy={p.y}
              r="5"
              className="fill-emerald-500 stroke-white dark:stroke-slate-900"
              strokeWidth="2"
            />
            <circle
              cx={p.x}
              cy={p.y}
              r="2"
              className="fill-white"
            />
          </g>
        ))}

        {/* Category Labels & Scores around periphery */}
        {areaData.map((d, i) => {
          const labelCoord = getCoordinates(i, 1.22);
          const isLeft = labelCoord.x < center - 10;
          const isRight = labelCoord.x > center + 10;
          const textAnchor = isLeft ? 'end' : isRight ? 'start' : 'middle';

          return (
            <g key={i}>
              <text
                x={labelCoord.x}
                y={labelCoord.y - 4}
                textAnchor={textAnchor}
                className="text-[11px] font-bold fill-slate-800 dark:fill-slate-200"
              >
                {d.name}
              </text>
              <text
                x={labelCoord.x}
                y={labelCoord.y + 10}
                textAnchor={textAnchor}
                className="text-[10px] font-mono font-semibold fill-emerald-500 dark:fill-emerald-400"
              >
                {Math.round(d.score)}%
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};
