// Aureus Lifestyle Dashboard — Multi-Dimensional Holistic Equilibrium

import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { RadarChart } from './RadarChart';
import { HumanBodyMuscleMap } from './HumanBodyMuscleMap';
import { BodyMeasurementForm } from './BodyMeasurementForm';
import {
  Activity,
  Clock,
  Compass,
  Sparkles,
  Dumbbell,
  Shield,
  Zap,
} from 'lucide-react';

export const LifestyleDashboard: React.FC = () => {
  const {
    lifestyleAreas,
    userMetrics,
    metricScores,
    userXP,
    timelineEvents,
  } = useApp();

  const activeAreas = useMemo(() => {
    return (lifestyleAreas || [])
      .filter((a) => !a.deleted)
      .sort((a, b) => a.order - b.order);
  }, [lifestyleAreas]);

  return (
    <div className="space-y-8 pb-24 max-w-7xl mx-auto px-4 sm:px-6 animate-fadeIn">
      {/* 1. HERO & EXECUTIVE LEVEL BANNER */}
      <div className="rounded-3xl bg-gradient-to-b from-[#161a24] to-[#0c0e14] border border-white/[0.08] p-8 sm:p-10 text-white flex flex-col md:flex-row md:items-center justify-between gap-8 shadow-2xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/25 text-amber-300 text-[11px] font-bold uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Whole-Life Mastery</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            Equilibrium &amp; Vitality
          </h1>
          <p className="text-sm text-slate-400 max-w-lg leading-relaxed">
            Continuous synthesis of physical conditioning, mental discipline, and spiritual focus into unified life metrics.
          </p>
        </div>

        <div className="rounded-2xl bg-white/[0.03] border border-white/10 px-8 py-5 text-center shrink-0">
          <div className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
            Vitality Level
          </div>
          <div className="text-5xl font-black text-amber-300 font-mono tracking-tight my-1">
            {userXP?.level || 1}
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            {userXP?.currentXP || 0} / {(userXP?.level || 1) * (userXP?.xpPerLevel || 100)} XP
          </div>
        </div>
      </div>

      {/* 2. BENTO GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Radar Map (lg col span 2) */}
        <div className="lg:col-span-2 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center gap-2 mb-6">
            <Compass className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-black text-white">Equilibrium Radar</h2>
          </div>
          <div className="flex items-center justify-center py-2">
            <RadarChart
              areas={activeAreas}
              metrics={userMetrics || new Map()}
              metricScores={metricScores || new Map()}
              size={360}
            />
          </div>
        </div>

        {/* Measurement Form */}
        <div className="lg:col-span-1">
          <BodyMeasurementForm />
        </div>
      </div>

      {/* 3. ANATOMY MAP */}
      <HumanBodyMuscleMap />

      {/* 4. TIMELINE */}
      <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-8 shadow-2xl space-y-5">
        <h2 className="text-xl font-black text-white flex items-center gap-2.5">
          <Clock className="w-5 h-5 text-amber-400" />
          <span>Timeline Journal</span>
        </h2>
        {timelineEvents && timelineEvents.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {timelineEvents.slice(0, 6).map((event) => (
              <div
                key={event.id}
                className="rounded-2xl bg-white/[0.02] border border-white/[0.06] p-4 flex items-center gap-3.5"
              >
                <div className="text-amber-400 bg-amber-400/10 border border-amber-400/25 p-2 rounded-xl">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white">{event.label}</div>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    {event.kind} • {new Date(event.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center text-slate-500 py-10 text-xs">
            No activity recorded today. Complete habits or log workouts to stream entries.
          </div>
        )}
      </div>
    </div>
  );
};

export default LifestyleDashboard;