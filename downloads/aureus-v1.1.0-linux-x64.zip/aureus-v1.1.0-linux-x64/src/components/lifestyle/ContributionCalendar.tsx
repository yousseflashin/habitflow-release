// GitHub-style contribution calendar.
//
// Deliberately NOT binary: five heat levels driven by the day's normalized
// effort, with a fixed (not relative-to-your-best) scale so colours stay stable
// month to month instead of always looking dim.

import React, { useEffect, useMemo, useState } from 'react';
import { format, addDays, startOfWeek, parseISO } from 'date-fns';
import { DayProgress, Dimension, DIMENSIONS, DIMENSION_COLOR } from '../../domain/lifeProgressService';

interface CalendarProps {
  days: Map<string, DayProgress>;
  endDate?: Date;
  weeks?: number;
  /** Show the Body/Health/Intelligence/Spirit split as a stacked tint on hover. */
  showDimensions?: boolean;
  onSelectDate?: (date: string, day: DayProgress | undefined) => void;
}

const WEEKDAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

/** Fixed heat scale, with a separate pair of colours per theme. */
const LEVEL_STYLES: Record<number, string> = {
  0: 'bg-slate-100 dark:bg-slate-800/60',
  1: 'bg-emerald-200 dark:bg-emerald-950',
  2: 'bg-emerald-400 dark:bg-emerald-800',
  3: 'bg-emerald-600 dark:bg-emerald-600',
  4: 'bg-emerald-800 dark:bg-emerald-300',
};

const LEVEL_LABELS = ['No activity', 'Very low', 'Low', 'Meaningful', 'Exceptional'];

export const ContributionCalendar: React.FC<CalendarProps> = ({
  days,
  endDate = new Date(),
  weeks = 26,
  showDimensions = true,
  onSelectDate,
}) => {
  const [hovered, setHovered] = useState<{ date: string; day?: DayProgress; x: number; y: number } | null>(null);
  // Today's key is state, not a module constant, so the calendar
  // re-renders at midnight and the ring (and any date logic)
  // follows the year change automatically.
  const [todayKey, setTodayKey] = useState(() => format(new Date(), 'yyyy-MM-dd'));

  useEffect(() => {
    const tick = () => setTodayKey(format(new Date(), 'yyyy-MM-dd'));
    const id = setInterval(tick, 60_000);
    return () => clearInterval(id);
  }, []);

  // Build columns (weeks) of 7 days, starting on a Monday.
  const grid = useMemo(() => {
    const known = Array.from(days.keys()).sort();
    const end = endDate;
    const fallbackEnd = addDays(startOfWeek(end, { weekStartsOn: 1 }), 6);
    const firstDate = known.length
      ? startOfWeek(parseISO(known[0]), { weekStartsOn: 1 })
      : addDays(fallbackEnd, -(weeks * 7 - 1));
    const lastDate = known.length ? parseISO(known[known.length - 1]) : fallbackEnd;

    const columns: Array<Array<{ date: string; day?: DayProgress }>> = [];
    let cursor = firstDate;
    while (cursor <= lastDate) {
      const column: Array<{ date: string; day?: DayProgress }> = [];
      for (let i = 0; i < 7; i++) {
        const key = format(cursor, 'yyyy-MM-dd');
        column.push({ date: key, day: days.get(key) });
        cursor = addDays(cursor, 1);
      }
      columns.push(column);
    }
    return columns;
  }, [days, endDate, weeks]);

  // One label per month, attached to the column that starts it.
  // The year rides along, because a 52-week span crosses years and
  // the same month name (e.g. Sep) would otherwise appear at both
  // ends of the strip and read as one month split in two.
  const monthLabels = useMemo(() => {
    const labels: Array<{ index: number; label: string }> = [];
    let lastMonth = '';
    grid.forEach((col, i) => {
      const first = parseISO(col[0].date);
      const month = format(first, 'yyyy-MM');
      if (month !== lastMonth) {
        labels.push({ index: i, label: format(first, 'MMM yy') });
        lastMonth = month;
      }
    });
    return labels;
  }, [grid]);

  const labelFor = (index: number) => monthLabels.find((m) => m.index === index)?.label ?? '';

  const tooltipStyle = useMemo(() => {
    if (!hovered) return undefined;
    const flipX = hovered.x + 254 > window.innerWidth;
    const flipY = hovered.y < 130;
    return {
      left: flipX ? undefined : hovered.x + 14,
      right: flipX ? window.innerWidth - hovered.x + 14 : undefined,
      top: flipY ? undefined : hovered.y - 12,
      bottom: flipY ? window.innerHeight - hovered.y + 12 : undefined,
      transform: flipY ? 'translateY(-100%)' : 'translateY(-50%)',
    };
  }, [hovered]);

  return (
    <div className="w-full select-none">
      <div className="overflow-x-auto pb-1">
        <div className="inline-flex flex-col">
          {/* Month labels */}
          <div className="flex" style={{ gap: 4, marginBottom: 6 }}>
            <div style={{ width: 26, flexShrink: 0 }} />
            {grid.map((_, i) => (
              <div
                key={i}
                style={{ width: 15, flexShrink: 0 }}
                className="text-[10px] font-semibold text-slate-500 whitespace-nowrap"
              >
                {labelFor(i)}
              </div>
            ))}
          </div>

          <div className="flex" style={{ gap: 4 }}>
            {/* Weekday labels */}
            <div className="flex flex-col" style={{ gap: 4, width: 26, flexShrink: 0 }}>
              {WEEKDAY_LABELS.map((label, i) => (
                <div
                  key={i}
                  style={{ height: 15 }}
                  className="flex items-center text-[9px] text-slate-500 leading-none"
                >
                  {label}
                </div>
              ))}
            </div>

            {/* Grid */}
            {grid.map((col, ci) => (
              <div key={ci} className="flex flex-col" style={{ gap: 4 }}>
                {col.map(({ date, day }) => {
                  const level = day?.intensity ?? 0;
                  const isFuture = day === undefined;
                  return (
                    <button
                      key={date}
                      type="button"
                      aria-label={`${date}: ${LEVEL_LABELS[level]}`}
                      onMouseEnter={(e) => {
                        const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
                        setHovered({ date, day, x: r.left + r.width / 2, y: r.top + r.height / 2 });
                      }}
                      onMouseLeave={() => setHovered(null)}
                      onFocus={(e) => {
                        const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
                        setHovered({ date, day, x: r.left + r.width / 2, y: r.top + r.height / 2 });
                      }}
                      onBlur={() => setHovered(null)}
                      onClick={() => onSelectDate?.(date, day)}
                      style={{ width: 15, height: 15 }}
                      className={`rounded-[4px] transition-all duration-200 ${LEVEL_STYLES[level]} ${
                        isFuture ? 'opacity-30' : 'opacity-100'
                      } hover:ring-2 hover:ring-emerald-400 hover:scale-125 focus:outline-none focus:ring-2 focus:ring-emerald-400 ${
                        // Today: a solid outline so you can see where
                        // the calendar currently is.
                        date === todayKey
                          ? 'ring-2 ring-sky-400 ring-offset-1 ring-offset-white dark:ring-offset-slate-900'
                          : ''
                      }`}
                    />
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-end gap-1.5 mt-3 text-[10px] text-slate-500">
        <span>Less</span>
        {[0, 1, 2, 3, 4].map((lv) => (
          <span
            key={lv}
            title={LEVEL_LABELS[lv]}
            style={{ width: 15, height: 15 }}
            className={`rounded-[4px] ${LEVEL_STYLES[lv]}`}
          />
        ))}
        <span>More</span>
      </div>

      {/* Tooltip */}
      {hovered && (
        <div
          className="fixed z-50 pointer-events-none glass rounded-xl px-3.5 py-2.5 text-xs shadow-2xl w-[230px]"
          style={tooltipStyle}
        >
          <div className="font-bold text-slate-100 mb-1.5">
            {format(parseISO(hovered.date), 'EEE, MMM d yyyy')}
          </div>

          {hovered.day && hovered.day.score > 0 ? (
            <div className="space-y-1.5 text-slate-300">
              <div className="flex items-center justify-between gap-4">
                <span>{LEVEL_LABELS[hovered.day.intensity]}</span>
                <span className="text-emerald-400 font-semibold tabular-nums">
                  {Math.round(hovered.day.score * 100) / 100}
                </span>
              </div>

              {hovered.day.completedCount > 0 && (
                <div className="flex items-center gap-1.5 text-slate-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                  {hovered.day.completedCount} completed
                </div>
              )}
              {hovered.day.resistedCount > 0 && (
                <div className="flex items-center gap-1.5 text-slate-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400 shrink-0" />
                  {hovered.day.resistedCount} resisted
                </div>
              )}
              {hovered.day.relapsedCount > 0 && (
                <div className="flex items-center gap-1.5 text-slate-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
                  {hovered.day.relapsedCount} relapse
                </div>
              )}

              {showDimensions && (() => {
                const split = hovered.day!.dimensionSplit;
                const total = split.body + split.health + split.intelligence + split.spirit;
                if (total <= 0) return null;
                return (
                  <div
                    className="pt-1.5 mt-1.5 border-t border-white/10 flex gap-1 h-1.5 rounded-full overflow-hidden"
                    title="Body / Health / Intelligence / Spirit split"
                  >
                    {DIMENSIONS.map((dim) => (
                      <div
                        key={dim}
                        style={{ width: `${(split[dim] / total) * 100}%`, background: DIMENSION_COLOR[dim] }}
                      />
                    ))}
                  </div>
                );
              })()}
            </div>
          ) : (
            <div className="text-slate-500">No activity</div>
          )}
        </div>
      )}
    </div>
  );
};

export default ContributionCalendar;
