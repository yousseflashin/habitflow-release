// Aureus Anatomical & Cognitive Mapping — Physical, Mental & Spiritual Synergy

import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Dumbbell,
  Brain,
  Sparkles,
  Zap,
  Heart,
  Activity,
  Flame,
  Shield,
} from 'lucide-react';

export const HumanBodyMuscleMap: React.FC = () => {
  const { userMetrics, metricScores } = useApp();

  const getDevelopmentColor = (score: number) => {
    if (score >= 85) return '#F0C465'; // Imperial Gold (Peak)
    if (score >= 60) return '#10B981'; // Emerald (High)
    if (score >= 30) return '#38BDF8'; // Sky (Medium)
    return '#64748B'; // Slate (Baseline)
  };

  const getBrainColor = (score: number) => {
    if (score >= 80) return '#F0C465'; // Gold
    if (score >= 50) return '#10B981'; // Emerald
    return '#818CF8'; // Indigo
  };

  const getAuraIntensity = useMemo(() => {
    const spiritualScore = metricScores.get('metric_spiritualPractice') || 20;
    return Math.min(100, Math.max(10, spiritualScore));
  }, [metricScores]);

  return (
    <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-8 relative overflow-hidden flex flex-col md:flex-row gap-10 items-center shadow-2xl">
      {/* 1. SPIRITUAL AURA CONTAINER */}
      <div className="relative w-72 h-[420px] flex items-center justify-center shrink-0">
        <div
          className="absolute inset-0 rounded-full blur-3xl opacity-25 transition-all duration-1000"
          style={{
            background: 'radial-gradient(circle at center, #F0C465, transparent)',
            transform: `scale(${1 + getAuraIntensity / 250})`,
          }}
        />

        {/* Anatomy SVG Layer */}
        <svg viewBox="0 0 240 400" className="w-full h-full relative z-10 drop-shadow-2xl filter">
          <defs>
            <filter id="neon-glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Brain activity */}
          <path
            d="M100 25 C 100 10, 140 10, 140 25 C 140 40, 100 40, 100 25"
            fill={getBrainColor(metricScores.get('metric_focus') || 20)}
            filter="url(#neon-glow)"
            className="transition-all duration-700"
          />

          {/* Muscle highlight (Chest Left) */}
          <path
            d="M104 74 Q120 78 120 88 Q120 108 98 108 Q94 88 104 74 Z"
            fill={getDevelopmentColor(metricScores.get('metric_strength') || 20)}
            filter="url(#neon-glow)"
            className="transition-all duration-700 cursor-pointer hover:stroke-white hover:stroke-2"
          />
          {/* Mirror Chest (Right) */}
          <path
            d="M136 74 Q120 78 120 88 Q120 108 142 108 Q146 88 136 74 Z"
            fill={getDevelopmentColor(metricScores.get('metric_strength') || 20)}
            filter="url(#neon-glow)"
            className="transition-all duration-700 cursor-pointer"
          />
        </svg>
      </div>

      {/* 2. STATS PANEL */}
      <div className="flex-1 space-y-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 rounded-xl bg-amber-400/10 text-amber-300 border border-amber-400/25">
              <Sparkles className="w-5 h-5" />
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">Anatomical Intelligence</h2>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Physical muscle conditioning and cognitive clarity calculated from daily activity and habit volume.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3.5">
          <div className="rounded-2xl bg-white/[0.02] border border-white/[0.06] p-4 text-center">
            <Dumbbell className="w-5 h-5 text-amber-400 mx-auto mb-2" />
            <div className="text-2xl font-black text-white tabular-nums">
              {Math.round(metricScores.get('metric_strength') || 0)}
            </div>
            <div className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">
              Physical
            </div>
          </div>
          <div className="rounded-2xl bg-white/[0.02] border border-white/[0.06] p-4 text-center">
            <Brain className="w-5 h-5 text-sky-400 mx-auto mb-2" />
            <div className="text-2xl font-black text-white tabular-nums">
              {Math.round(metricScores.get('metric_focus') || 0)}
            </div>
            <div className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">
              Cognitive
            </div>
          </div>
          <div className="rounded-2xl bg-white/[0.02] border border-white/[0.06] p-4 text-center">
            <Zap className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
            <div className="text-2xl font-black text-white tabular-nums">
              {Math.round(getAuraIntensity)}
            </div>
            <div className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">
              Spiritual
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HumanBodyMuscleMap;