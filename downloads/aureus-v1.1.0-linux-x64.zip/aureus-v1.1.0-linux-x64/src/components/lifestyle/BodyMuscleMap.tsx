// React adapter for `body-muscles`, plus the mapping from the app's coarse
// MuscleGroup model onto the library's 89 granular ids.
//
// The library ships a vanilla-JS `BodyChart` class that mounts into a DOM
// element, so it is used via a ref + effect rather than as a component.
//
// Scale note: the library wants intensity 0–10, the app stores 0–100 levels.

import React, { useEffect, useRef, useState } from 'react';
import { BodyChart, ViewSide, MUSCLE_GROUPS } from 'body-muscles';
import { MuscleGroup } from '../../domain/lifeProgressService';

/**
 * In-progress muscles (a set underway) render faint-red instead of
 * their heat colour. The library paints fills via the `fill` attribute,
 * so a CSS class on the path overrides it (presentation attributes
 * lose to any CSS rule).
 */
const IN_PROGRESS_SELECTOR = '.body-muscle-in-progress';

/** The app's coarse groups, in the order the library names them. */
type LibraryGroup =
  | 'Head & Neck' | 'Shoulders' | 'Arms' | 'Chest'
  | 'Back' | 'Abdominals' | 'Legs' | 'Hands & Feet';

/** Stable public data export: group name → every muscle id it owns. */
const MUSCLE_IDS = MUSCLE_GROUPS as Record<LibraryGroup, string[]>;

/** Reverse lookup: library group → the app group that drives it. */
function appGroupFor(group: LibraryGroup): string {
  const entry = (Object.entries(GROUP_MAP) as Array<[MuscleGroup, LibraryGroup]>)
    .find(([, lib]) => lib === group);
  return entry ? entry[0] : 'core';
}

function groupForMuscle(id: string): string {
  for (const [group, ids] of Object.entries(MUSCLE_IDS)) {
    if (ids.includes(id)) return appGroupFor(group as LibraryGroup);
  }
  return 'core';
}

/**
 * app MuscleGroup → library group. `core` maps to Abdominals, `cardio` has no
 * anatomical counterpart (it is rendered as the pulse ring elsewhere), and
 * `calves` folds into Legs.
 */
const GROUP_MAP: Record<MuscleGroup, LibraryGroup> = {
  shoulders: 'Shoulders',
  arms: 'Arms',
  chest: 'Chest',
  back: 'Back',
  core: 'Abdominals',
  legs: 'Legs',
  calves: 'Legs',
  cardio: 'Legs',
};

/**
 * Crown sitting on the head: a band with three rising points, the middle one
 * tallest. Drawn as a single closed path so it strokes and blurs like the other
 * aura fields.
 */
function crownPath(cx: number, cy: number, width: number, height: number): string {
  const half = width / 2;
  const step = half / 3;
  const f = (n: number) => n.toFixed(2);
  return [
    `M${f(cx - half)},${f(cy)}`,
    `L${f(cx - half + step * 0.5)},${f(cy - height)}`,
    `L${f(cx - step * 0.5)},${f(cy - height * 0.45)}`,
    `L${f(cx)},${f(cy - height * 1.3)}`,
    `L${f(cx + step * 0.5)},${f(cy - height * 0.45)}`,
    `L${f(cx + half - step * 0.5)},${f(cy - height)}`,
    `L${f(cx + half)},${f(cy)}`,
    `Q${f(cx)},${f(cy + height * 0.55)} ${f(cx - half)},${f(cy)}`,
    'Z',
  ].join(' ');
}

/**
 * Two aura fields, each a normal 4-point star, mirrored about the body axis and
 * tilted toward the head: Spirit at -22.5° and Health at +22.5°. The pair is
 * 45° apart, so together they read as an 8-point star whose two upper tips
 * straddle the head, leaving it sitting in the V between them.
 */
const AURA_CY = 46;
const AURA_RX = 46;
const AURA_RY = 46;
const AURA_TILT_A = -25;
const AURA_TILT_B = 25;

/**
 * Curved 4-point star: sharp cardinal tips, concave sides between them.
 * `rotateDeg` spins the star about its own center.
 */
function starPath(
  cx: number,
  cy: number,
  radiusX: number,
  radiusY: number,
  rotateDeg = 0,
  shoulder = 0.44
): string {
  const rad = (rotateDeg * Math.PI) / 180;
  const base = [
    [cx, cy - radiusY],
    [cx + radiusX, cy],
    [cx, cy + radiusY],
    [cx - radiusX, cy],
  ] as const;
  const spin = ([x, y]: readonly [number, number]): [number, number] => {
    const dx = x - cx;
    const dy = y - cy;
    return [cx + dx * Math.cos(rad) - dy * Math.sin(rad), cy + dx * Math.sin(rad) + dy * Math.cos(rad)];
  };
  const tips = base.map(spin);

  return tips
    .map(([x, y], i) => {
      const [nextX, nextY] = tips[(i + 1) % tips.length];
      const midX = (x + nextX) / 2;
      const midY = (y + nextY) / 2;
      const c1x = cx + (midX - cx) * shoulder;
      const c1y = cy + (midY - cy) * shoulder;
      const c2x = cx + (midX - cx) * shoulder;
      const c2y = cy + (midY - cy) * shoulder;
      return `${i === 0 ? `M${x.toFixed(2)},${y.toFixed(2)}` : ''} C${c1x.toFixed(2)},${c1y.toFixed(2)} ${c2x.toFixed(2)},${c2y.toFixed(2)} ${nextX.toFixed(2)},${nextY.toFixed(2)}`;
    })
    .join(' ') + ' Z';
}

/** 0..100 → the library's 0..10 intensity scale. */
function toIntensity(level: number): number {
  const t = Math.max(0, Math.min(100, level)) / 100;
  return Math.max(0, Math.min(10, Math.round(t * 10)));
}

interface Props {
  /** group → 0..100 activation level. */
  levels: Record<string, number>;
  /**
   * Groups with a set in progress RIGHT NOW. Rendered faint-red
   * until the set finishes (see computeInProgressMuscles).
   */
  inProgress?: Partial<Record<string, number>>;
  /** Health field around the whole body, 0..100. */
  health: number;
  /** Whole-life spirit field, 0..100. */
  spirit: number;
  /** Intelligence field around the head, 0..100. */
  intelligence: number;
  /** Target height of the body figure in px. */
  height?: number;
}

export const BodyMuscleMap: React.FC<Props> = ({
  levels,
  inProgress = {},
  health,
  spirit,
  intelligence,
  height = 210,
}) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const auraRef = useRef<SVGSVGElement>(null);
  const chartRef = useRef<BodyChart | null>(null);
  const [hovered, setHovered] = useState<{ id: string; name: string } | null>(null);
  const [hoverField, setHoverField] = useState<'intelligence' | 'health' | 'spirit' | null>(null);
  const [view, setView] = useState<ViewSide>(ViewSide.FRONT);
  const isFront = view === ViewSide.FRONT;
  // body-muscles uses viewBox "0 0 35 93" for the front and "37 0 35 93"
  // for the back. Match it exactly so aura rings sit around the actual anatomy.
  const viewBox = isFront ? '0 0 35 93' : '37 0 35 93';
  const centerX = isFront ? 17.5 : 54.5;

  // Rebuild the id → intensity map whenever levels change.
  const stateKey = JSON.stringify(levels);
  const progressKey = JSON.stringify(inProgress);
  useEffect(() => {
    const parsed = JSON.parse(stateKey) as Record<string, number>;
    let opacityObserver: MutationObserver | null = null;
    const host = hostRef.current;
    if (!host) return;

    const bodyState: Record<string, { intensity: number; selected: boolean }> = {};
    const groupIntensity = new Map<LibraryGroup, number>();
    (Object.keys(GROUP_MAP) as MuscleGroup[]).forEach((group) => {
      const libGroup = GROUP_MAP[group];
      const intensity = toIntensity(parsed[group] ?? 0);
      groupIntensity.set(libGroup, Math.max(groupIntensity.get(libGroup) ?? 0, intensity));
    });
    groupIntensity.forEach((intensity, libGroup) => {
      const ids = MUSCLE_IDS[libGroup];
      ids.forEach((id) => {
        bodyState[id] = { intensity, selected: false };
      });
    });

    const chart = new BodyChart(host, {
      view,
      bodyState,
      showViewLabel: false,
      enableTransitions: true,
      onMuscleHover: (id) => {
        if (!id) {
          setHovered(null);
          return;
        }
        setHovered({ id, name: id });
      },
    });
    const wrapper = host.querySelector<HTMLElement>('.body-chart-container');
    const svg = host.querySelector<SVGSVGElement>('.body-chart-svg');
    if (wrapper) {
      // body-muscles adds 1rem internal padding by default; it shifted the
      // anatomy away from the field overlay. Remove it so both share the exact
      // same centered coordinate frame.
      wrapper.style.setProperty('padding', '0', 'important');
      wrapper.style.setProperty('overflow', 'visible', 'important');
    }
    if (svg) {
      // Pin chart size and center actual drawn anatomy, not viewBox whitespace.
      svg.style.setProperty('height', `${height}px`, 'important');
      svg.style.setProperty('width', 'auto', 'important');
      svg.style.setProperty('max-height', 'none', 'important');
      svg.style.setProperty('max-width', 'none', 'important');
      svg.style.setProperty('flex', '0 0 auto', 'important');

      // Mark muscles with a set in progress: they paint faint-red
      // until the set finishes (CSS class overrides the fill attr).
      const markInProgress = () => {
        const active = JSON.parse(progressKey) as Record<string, number>;
        svg.querySelectorAll<SVGPathElement>('path.body-chart-muscle').forEach((p) => {
          const id = p.getAttribute('aria-label')?.split(' ')[0] ?? '';
          const group = groupForMuscle(id);
          const inProgress = (active[group] ?? 0) > 0;
          p.classList.toggle('body-muscle-in-progress', inProgress);
          p.style.fill = inProgress ? 'rgba(239,68,68,0.28)' : '';
        });
      };
      markInProgress();

      // body-muscles leaves muscle fill-opacity at 0.6 when intensity is 0 and
      // paints its own silhouette at opacity 0.1, so the aura shows straight
      // through the anatomy. Force the body fully opaque so it always hides the
      // field behind it. Set after refreshPath, which the library calls on every
      // state update and would otherwise reset the opacity.
      const makeBodyOpaque = () => {
        svg.querySelectorAll<SVGPathElement>('path.body-chart-muscle').forEach((p) => {
          p.style.fillOpacity = '1';
        });
        const bg = svg.querySelector<SVGGElement>('.body-chart-background');
        if (bg) bg.style.opacity = '1';
      };
      makeBodyOpaque();
      const observer = new MutationObserver(() => {
        makeBodyOpaque();
        markInProgress();
      });
      observer.observe(svg, { attributes: true, subtree: true, attributeFilter: ['style', 'fill'] });
      opacityObserver = observer;

      // body-muscles paths are asymmetrically padded in its viewBox (front
      // bounds -6.8..28.3, back -5.1..67). Measure painted muscle geometry and
      // translate the aura to the actual anatomy centroid for the selected view.
      const musclePaths = Array.from(svg.querySelectorAll<SVGPathElement>('path'))
        .filter((path) => !path.closest('.body-chart-background'));
      if (musclePaths.length) {
        const boxes = musclePaths.map((path) => path.getBBox());
        const minX = Math.min(...boxes.map((box) => box.x));
        const maxX = Math.max(...boxes.map((box) => box.x + box.width));
        const actualCenterX = (minX + maxX) / 2;
        const vbCenterX = isFront ? 17.5 : 54.5;
        // Previous pass translated based on bounds, but SVG coordinate scaling
        // and RTL/front-back semantics made the visual displacement larger and
        // in the wrong direction. Keep the measured centering correction, but
        // deliberately apply the opposite sign as requested.
        auraRef.current?.style.setProperty('transform', `translateX(${((actualCenterX - vbCenterX) * height / 93).toFixed(2)}px)`);
      }
    }
    chartRef.current = chart;

    return () => {
      opacityObserver?.disconnect();
      chart.destroy();
      chartRef.current = null;
    };
  }, [stateKey, view, progressKey]);

  const level = hovered ? levels[groupForMuscle(hovered.id)] ?? 0 : null;

  // Field hover: each field names itself, its value, and what it measures.
  const FIELDS = [
    {
      id: 'intelligence' as const,
      label: 'Intelligence',
      value: intelligence,
      blurb: 'Reasoning, focus and learning built from intelligence-weighted activities.',
      text: 'text-blue-300',
    },
    {
      id: 'health' as const,
      label: 'Health',
      value: health,
      blurb: 'Body condition: strength, endurance, recovery and mobility.',
      text: 'text-emerald-300',
    },
    {
      id: 'spirit' as const,
      label: 'Spirit',
      value: spirit,
      blurb: 'Discipline, consistency, purpose and self-control over time.',
      text: 'text-amber-300',
    },
  ];
  const activeField = FIELDS.find((field) => field.id === hoverField);

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex items-center gap-1 rounded-xl bg-slate-900/70 border border-slate-800 p-1">
        {([ViewSide.FRONT, ViewSide.BACK] as ViewSide[]).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`px-3 py-1.5 rounded-lg text-[11px] font-bold uppercase tracking-wider transition-colors ${
              view === v ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            {v === ViewSide.FRONT ? 'Front' : 'Back'}
          </button>
        ))}
      </div>

      {/* Shared narrow stage is sized to body's 35:93 viewBox. Both the library
          chart and aura SVG now occupy identical centered boxes, instead of the
          aura stretching across the full dashboard panel. */}
      <div className="relative mx-auto mt-4"
        style={{ width: `min(${Math.round(height * 35 / 93)}px, 100%)`, height }}
      >
        {/* Draw the filled fields behind the library SVG. Pointer events stay
            disabled so every muscle remains clickable. */}
        {/* Three nested auras: intelligence around the head, health around the complete
            body (beginning at the head), and spirit wrapping both. */}
        <svg
          ref={auraRef}
          className="absolute inset-0 z-0 h-full w-full pointer-events-none overflow-visible"
          viewBox={viewBox}
          preserveAspectRatio="xMidYMid meet"
          aria-hidden="true"
        >
          <defs>
            {/* Fill gradients run bright at the rim and fade toward the core, so
                the field tints its own interior without washing over the body. */}
            <radialGradient id="intelligenceAuraFill">
              <stop offset="0%" stopColor="#60a5fa" stopOpacity="0.02" />
              <stop offset="70%" stopColor="#a78bfa" stopOpacity="0.16" />
              <stop offset="100%" stopColor="#c4b5fd" stopOpacity="0.55" />
            </radialGradient>
            <radialGradient id="healthAuraFill">
              <stop offset="0%" stopColor="#34d399" stopOpacity="0.02" />
              <stop offset="70%" stopColor="#34d399" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.5" />
            </radialGradient>
            <radialGradient id="spiritAuraFill">
              <stop offset="0%" stopColor="#fbbf24" stopOpacity="0.02" />
              <stop offset="70%" stopColor="#f59e0b" stopOpacity="0.13" />
              <stop offset="100%" stopColor="#fcd34d" stopOpacity="0.48" />
            </radialGradient>
            <filter id="auraBlur" x="-35%" y="-20%" width="170%" height="140%">
              <feGaussianBlur stdDeviation="0.65" />
            </filter>
          </defs>

          {/* Spirit field: 4-point star tilted to the head. */}
          <g className="aura-pulse aura-pulse-spirit" style={{ opacity: 0.46 + spirit / 300 }}>
            <path d={starPath(centerX, AURA_CY, AURA_RX, AURA_RY, AURA_TILT_A)}
              fill="url(#spiritAuraFill)" stroke="none" />
            <path d={starPath(centerX, AURA_CY, AURA_RX, AURA_RY, AURA_TILT_A)} fill="none"
              stroke="#f59e0b" strokeOpacity="0.28" strokeWidth="2.8" filter="url(#auraBlur)" />
            <path d={starPath(centerX, AURA_CY, AURA_RX, AURA_RY, AURA_TILT_A)} fill="none"
              stroke="#fbbf24" strokeOpacity="0.52" strokeWidth="0.42" />
            <path d={starPath(centerX, AURA_CY, AURA_RX + 0.5, AURA_RY + 0.4, AURA_TILT_A)} fill="none"
              stroke="#fde68a" strokeOpacity="0.22" strokeWidth="0.2" />
          </g>

          {/* Health field: same star, tilted 45° further, interleaving with it. */}
          <g className="aura-pulse aura-pulse-health" style={{ opacity: 0.52 + health / 320 }}>
            <path d={starPath(centerX, AURA_CY, AURA_RX, AURA_RY, AURA_TILT_B)}
              fill="url(#healthAuraFill)" stroke="none" />
            <path d={starPath(centerX, AURA_CY, AURA_RX, AURA_RY, AURA_TILT_B)} fill="none"
              stroke="#10b981" strokeOpacity="0.24" strokeWidth="2.4" filter="url(#auraBlur)" />
            <path d={starPath(centerX, AURA_CY, AURA_RX, AURA_RY, AURA_TILT_B)} fill="none"
              stroke="#34d399" strokeOpacity="0.48" strokeWidth="0.38" />
          </g>

          {/* Intelligence field: a crown resting on the head. */}
          <g className="aura-pulse aura-pulse-mind" style={{ opacity: 0.54 + intelligence / 320 }}>
            <path d={crownPath(centerX, 1, 9, 4)} fill="url(#intelligenceAuraFill)" stroke="none" />
            <path d={crownPath(centerX, 1, 9, 4)} fill="none"
              stroke="#60a5fa" strokeOpacity="0.24" strokeWidth="2.1" filter="url(#auraBlur)" />
            <path d={crownPath(centerX, 1, 9, 4)} fill="none"
              stroke="#93c5fd" strokeOpacity="0.55" strokeWidth="0.38" />
          </g>
        </svg>
        {/* z-10 keeps the anatomy above the z-0 aura layer, so the body always
            paints on top of the field fills. */}
        <div
          ref={hostRef}
          className="relative z-10 h-full w-full [&_.body-chart-container]:!p-0 [&_.body-chart-container]:!bg-transparent"
        />
        {/* Field hit areas. Drawn as fat transparent strokes ON the star outlines
            in a layer above the body, so hovering a star's line reports the
            field while hovering the anatomy still reports a muscle. Overlapping
            divs could not do this: they sat over the body and swallowed hover. */}
        <svg
          className="absolute inset-0 z-20 h-full w-full overflow-visible pointer-events-none"
          viewBox={viewBox}
          preserveAspectRatio="xMidYMid meet"
          aria-hidden="true"
        >
          <path
            d={starPath(centerX, AURA_CY, AURA_RX, AURA_RY, AURA_TILT_B)}
            fill="none" stroke="transparent" strokeWidth="9"
            className="pointer-events-stroke cursor-help"
            onMouseEnter={() => setHoverField('health')}
            onMouseLeave={() => setHoverField(null)}
          />
          <path
            d={starPath(centerX, AURA_CY, AURA_RX, AURA_RY, AURA_TILT_A)}
            fill="none" stroke="transparent" strokeWidth="9"
            className="pointer-events-stroke cursor-help"
            onMouseEnter={() => setHoverField('spirit')}
            onMouseLeave={() => setHoverField(null)}
          />
          <path
            d={crownPath(centerX, 12, 15, 7)}
            fill="none" stroke="transparent" strokeWidth="6"
            className="pointer-events-stroke cursor-help"
            onMouseEnter={() => setHoverField('intelligence')}
            onMouseLeave={() => setHoverField(null)}
          />
        </svg>
      </div>

      <div className="h-8 flex items-center justify-center">
        {activeField ? (
          // Field hover takes precedence: it explains what the aura measures.
          <div className="glass rounded-xl px-3 py-1.5 text-xs text-center max-w-sm">
            <span className={`font-bold ${activeField.text}`}>{activeField.label}</span>
            <span className="text-slate-500"> · </span>
            <span className="font-bold text-slate-100 tabular-nums">{Math.round(activeField.value)}</span>
            <span className="text-slate-500"> — {activeField.blurb}</span>
          </div>
        ) : hovered && level !== null ? (
          <div className="glass rounded-xl px-3 py-1.5 text-xs whitespace-nowrap">
            <span className="font-bold text-slate-100 capitalize">{hovered.id.replace(/-/g, ' ')}</span>
            <span className="text-slate-500"> · </span>
            <span className="font-bold text-orange-400 tabular-nums">{Math.round(level)}%</span>
          </div>
        ) : (
          <p className="text-[11px] text-slate-600">Hover a muscle or a field for detail</p>
        )}
      </div>
    </div>
  );
};

export default BodyMuscleMap;