// Container for the Life Pulse dashboard: reads the existing habit/log state from
// AppContext, adapts it to the whole-life model, and renders the dashboard.

import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { LifeCommandCenter } from './LifeCommandCenter';
import { useLifeProfile } from './lifeModelAdapter';
import { resolveRemindersForDate } from '../../domain/reminderService';
import { computeMoneyStats, MoneyStats } from '../../domain/moneyStatsService';
import { MoneyAccount, MoneyAsset, MoneyTransaction } from '../../types';
import { Reminder } from '../../types';

// Same storage key as MoneyPage
const STORAGE_KEY = 'habitflow_money_v1';

interface MoneyState {
  accounts: MoneyAccount[];
  assets: MoneyAsset[];
  transactions: MoneyTransaction[];
}

function loadMoneyState(): MoneyState {
  if (typeof localStorage === 'undefined') {
    return { accounts: [], assets: [], transactions: [] };
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<MoneyState>;
      return {
        accounts: parsed.accounts ?? [],
        assets: parsed.assets ?? [],
        transactions: parsed.transactions ?? [],
      };
    }
  } catch {
    // Corrupted: ignore
  }
  return { accounts: [], assets: [], transactions: [] };
}

export const LifeCommandCenterView: React.FC = () => {
  const { habits, habitLogs, habitRelapses, setActiveView, setViewingHabitDetail } = useApp();

  const { activities, profile, todaysResults } = useLifeProfile(habits, habitLogs, habitRelapses);

  // Load money state from localStorage (same source as MoneyPage)
  const moneyState = useMemo(() => loadMoneyState(), []);
  const money: MoneyStats | null = useMemo(
    () => computeMoneyStats(moneyState.accounts, moneyState.assets, moneyState.transactions),
    [moneyState]
  );

  // Adapt the existing per-habit reminders into the new unlimited-reminder shape.
  const reminders = useMemo(() => {
    const today = new Date();
    const adapted = habits
      .filter((h) => !h.deleted && !h.archived)
      .flatMap((h) => (h.reminders ?? []).map((r: Reminder) => ({
        id: r.id,
        activityId: h.id,
        time: r.time,
        label: r.label,
        enabled: r.enabled,
        daysOfWeek: r.daysOfWeek,
      })));

    return resolveRemindersForDate(adapted, today);
  }, [habits]);

  return (
    <LifeCommandCenter
      profile={profile}
      activities={activities}
      todaysResults={todaysResults}
      reminders={reminders}
      money={money}
      onOpenActivity={(id) => {
        if (id === 'new') {
          setActiveView('habits');
          return;
        }
        const habit = habits.find((h) => h.id === id);
        if (habit) setViewingHabitDetail(habit);
      }}
      onSelectDate={() => setActiveView('calendar')}
      onOpenMoney={() => setActiveView('money')}
    />
  );
};

export default LifeCommandCenterView;
