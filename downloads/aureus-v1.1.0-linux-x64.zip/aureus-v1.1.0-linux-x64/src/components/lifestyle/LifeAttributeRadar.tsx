// Life Attribute Radar — high-level attributes, not raw habits.
//
// Values come from the asymptotic attribute levels, so a single action nudges a
// vertex by a fraction of a point and only sustained work visibly changes shape.

import React, { useMemo, useState } from 'react';
import { ATTRIBUTES, AttributeKey, Dimension, DIMENSIONS, DIMENSION_COLOR } from '../../domain/lifeProgressService';

interface RadarProps {
  attributes: Record<AttributeKey, number>;
  trends?: Record<AttributeKey, number>;
  size?: number;
  /** Restrict to a single dimension. */
  dimension?: Dimension | 'all';
}

const GRID_LEVELS = [0.25, 0.5, 0.75, 1];

export const LifeAttributeRadar: React.FC<RadarProps> = ({
  attributes,
  trends,
  size = 380,
  dimension = 'all',
}) => {
  const [hovered, setHovered] = useState<number | null>(null);

  const axes = useMemo(
    () => (dimension === 'all' ? ATTRIBUTES : ATTRIBUTES.filter((a) => a.dimension === dimension)),
    [dimension]
  );

  // Geometry notes:
  //  - Labels ARE drawn on the ring (name + value stacked) because the polygon
  //    alone is unreadable. 14 axes is tight but solvable.
  //  - Each label gets its own band OUTSIDE the outer ring, with the value on a
  //    second line inside that same band. The old code nudged the value by a
  //    hardcoded +10 user units, which on a scaled SVG rendered ~8px and
  //    overlapped the 18px-tall label: 17 measured collisions.
  //  - The band's height scales with `size`, and the radius is derived from the
  //    longest label so nothing is clipped by the panel edge.
  // The <svg> has width/height set in px and NO viewBox, so 1 SVG user unit
  // == 1 CSS px. Font size is set as an explicit SVG attribute rather than a
  // Tailwind class: `className="text-[9px]"` silently fell back to 16px (the
  // SVG default) whenever the class was not applied, which is what made the
  // 18px label overlap the value underneath it.
  const center = size / 2;
  const longestLabel = axes.reduce((max, a) => Math.max(max, a.label.length), 0);
  const LABEL_FONT = 9;
  const VALUE_FONT = 10;
  // Reserve half the widest label on each side so nothing is clipped.
  const halfLabel = Math.min((longestLabel * 5.4) / 2, center * 0.44);
  const bandHeight = Math.max(28, size * 0.09);
  const radius = Math.max(26, center - halfLabel - bandHeight);
  const labelGap = 7;
  // Both lines use dominant-baseline=middle, so the offset must exceed half of
  // each line box plus clearance.
  const labelRadius = radius + labelGap;
  const valueOffset = 14;

  const point = (index: number, ratio: number) => {
    const angle = (index / axes.length) * Math.PI * 2 - Math.PI / 2;
    return {
      x: center + Math.cos(angle) * radius * ratio,
      y: center + Math.sin(angle) * radius * ratio,
    };
  };

  const pointAt = (index: number, r: number) => {
    const angle = (index / axes.length) * Math.PI * 2 - Math.PI / 2;
    return {
      x: center + Math.cos(angle) * r,
      y: center + Math.sin(angle) * r,
    };
  };

  const polygon = (ratio: number) =>
    axes.map((_, i) => {
      const p = point(i, ratio);
      return `${p.x},${p.y}`;
    }).join(' ');

  const hasProgress = axes.some((a) => (attributes[a.key] ?? 0) > 0);

  const valuePolygon = axes
    .map((a, i) => {
      const raw = Math.max(0, Math.min(100, attributes[a.key] ?? 0));
      // Keep a dim radar shape visible before first logged activity; once there
      // is data, show actual attribute scores (including zero-valued axes).
      const ratio = hasProgress ? raw / 100 : 0.18;
      const p = point(i, ratio);
      return `${p.x},${p.y}`;
    })
    .join(' ');

  if (axes.length < 3) {
    return (
      <div className="flex items-center justify-center text-sm text-slate-500 h-64">
        Not enough attributes in this view yet.
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} className="overflow-visible shrink-0">
        {/* Grid rings */}
        {GRID_LEVELS.map((lv) => (
          <polygon
            key={lv}
            points={polygon(lv)}
            fill="none"
            stroke="#1e293b"
            strokeWidth="1"
          />
        ))}

        {/* Spokes + labels */}
        {axes.map((a, i) => {
          const p = point(i, 1.0);
          const lx = pointAt(i, labelRadius);
          const vx = pointAt(i, labelRadius);
          const value = Math.round(attributes[a.key] ?? 0);
          const trend = trends?.[a.key] ?? 0;
          const isHovered = hovered === i;
          // Anchor toward the outside edge so a long label grows away from the
          // chart. `end` on the left means the text ENDS at the anchor.
          const cos = Math.cos((i / axes.length) * Math.PI * 2 - Math.PI / 2);
          const onRight = cos > 0.2;
          const onLeft = cos < -0.2;
          const anchor = onRight ? 'start' : onLeft ? 'end' : 'middle';
          const anchorDx = onRight ? 4 : onLeft ? -4 : 0;

          return (
            <g key={a.key}>
              <line
                x1={center}
                y1={center}
                x2={p.x}
                y2={p.y}
                stroke={isHovered ? DIMENSION_COLOR[a.dimension] : '#1e293b'}
                strokeWidth="1"
              />

              {/* Vertex — grows with the attribute */}
              <circle
                cx={point(i, Math.max(0.01, value / 100)).x}
                cy={point(i, Math.max(0.01, value / 100)).y}
                r={isHovered ? 5 : 3.5}
                fill={DIMENSION_COLOR[a.dimension]}
                className="transition-all duration-700"
              />

              {/* Hit area for hover */}
              <circle
                cx={center}
                cy={center}
                r={radius + 18}
                fill="transparent"
                style={{ pointerEvents: 'none' }}
              />
              <circle
                cx={(center + p.x) / 2}
                cy={(center + p.y) / 2}
                r={radius * 0.55}
                fill="transparent"
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                style={{ pointerEvents: 'all', cursor: 'help' }}
              />

              {/* Label + value, stacked in the band outside the ring */}
              <text
                x={lx.x + anchorDx}
                y={lx.y}
                textAnchor={anchor}
                dominantBaseline="middle"
                fontSize={LABEL_FONT}
                fontWeight="700"
                letterSpacing="0.4"
                fill={isHovered ? DIMENSION_COLOR[a.dimension] : '#64748b'}
              >
                {a.label.toUpperCase()}
              </text>
              <text
                x={vx.x + anchorDx}
                y={lx.y + valueOffset}
                textAnchor={anchor}
                dominantBaseline="middle"
                fontSize={VALUE_FONT}
                fontWeight="800"
                fill={isHovered ? '#e2e8f0' : '#475569'}
              >
                {value}
                {trend !== 0 && (
                  <tspan
                    fill={trend > 0 ? '#34d399' : '#f43f5e'}
                    fontSize="8"
                    dx="3"
                  >
                    {trend > 0 ? '▲' : '▼'}
                  </tspan>
                )}
              </text>
            </g>
          );
        })}

        {/* Value shape */}
        <polygon
          points={valuePolygon}
          fill="url(#radarFill)"
          stroke="#10b981"
          strokeWidth="1.5"
          strokeLinejoin="round"
          className="transition-all duration-1000 ease-out"
        />

        <defs>
          <linearGradient id="radarFill" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
            <stop offset="50%" stopColor="#a78bfa" stopOpacity="0.25" />
            <stop offset="100%" stopColor="#f97316" stopOpacity="0.3" />
          </linearGradient>
        </defs>
      </svg>

      {/* Hover detail */}
      {hovered !== null && axes[hovered] && (
        <div className="glass rounded-xl px-4 py-2.5 text-xs text-slate-300 max-w-xs text-center -mt-2">
          <span className="font-bold text-slate-100">{axes[hovered].label}</span>
          <span className="text-slate-500"> · {axes[hovered].blurb}</span>
        </div>
      )}

      {/* Legend */}
      {dimension === 'all' && (
        <div className="flex gap-4 mt-2 text-[10px] font-bold uppercase tracking-wider">
          {DIMENSIONS.map((d) => (
            <span key={d} className="flex items-center gap-1.5" style={{ color: DIMENSION_COLOR[d] }}>
              <span className="w-2 h-2 rounded-full" style={{ background: DIMENSION_COLOR[d] }} />
              {d}
            </span>
          ))}
        </div>
      )}
    </div>
  );
};

export default LifeAttributeRadar;
