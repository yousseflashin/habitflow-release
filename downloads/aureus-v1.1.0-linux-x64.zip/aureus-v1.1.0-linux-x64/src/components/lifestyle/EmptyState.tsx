// High-quality empty state. Every view needs one — an empty dashboard should
// teach the model, not just report "no data".

import React from 'react';
import { LucideIcon } from 'lucide-react';

interface Props {
  icon: LucideIcon;
  title: string;
  body: string;
  actionLabel?: string;
  onAction?: () => void;
  secondary?: { label: string; onClick: () => void };
}

export const EmptyState: React.FC<Props> = ({
  icon: Icon,
  title,
  body,
  actionLabel,
  onAction,
  secondary,
}) => (
  <div className="flex flex-col items-center justify-center py-20 px-6 text-center">
    {/* Layered glow so the empty state still feels designed */}
    <div className="relative mb-6">
      <div className="absolute inset-0 rounded-full bg-emerald-500/20 blur-2xl" />
      <div className="relative w-20 h-20 rounded-3xl glass flex items-center justify-center">
        <Icon className="w-9 h-9 text-emerald-400" />
      </div>
    </div>

    <h3 className="text-xl font-bold text-slate-100 mb-2">{title}</h3>
    <p className="text-sm text-slate-400 max-w-md leading-relaxed mb-6">{body}</p>

    <div className="flex flex-wrap gap-3 justify-center">
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-colors"
        >
          {actionLabel}
        </button>
      )}
      {secondary && (
        <button
          onClick={secondary.onClick}
          className="px-6 py-3 rounded-xl glass hover:bg-white/10 text-slate-300 font-semibold transition-colors"
        >
          {secondary.label}
        </button>
      )}
    </div>
  </div>
);

export default EmptyState;
