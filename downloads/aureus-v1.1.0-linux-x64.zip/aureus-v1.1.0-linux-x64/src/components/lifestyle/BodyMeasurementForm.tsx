import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Weight, Plus, Activity, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';

const METRIC_PRESETS = [
  { label: 'Weight', defaultUnit: 'kg' },
  { label: 'Body Fat', defaultUnit: '%' },
  { label: 'Waist', defaultUnit: 'cm' },
  { label: 'Chest', defaultUnit: 'cm' },
  { label: 'Resting HR', defaultUnit: 'bpm' },
];

export const BodyMeasurementForm: React.FC = () => {
  const { addBodyMeasurement } = useApp();
  const [value, setValue] = useState('');
  const [label, setLabel] = useState('Weight');
  const [unit, setUnit] = useState('kg');
  const [justSaved, setJustSaved] = useState(false);

  const handleSelectPreset = (pLabel: string, pUnit: string) => {
    setLabel(pLabel);
    setUnit(pUnit);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!value || isNaN(parseFloat(value))) return;

    await addBodyMeasurement({
      value: parseFloat(value),
      unit,
      label,
      date: format(new Date(), 'yyyy-MM-dd'),
    });

    setValue('');
    setJustSaved(true);
    setTimeout(() => setJustSaved(false), 2000);
  };

  return (
    <form onSubmit={handleSubmit} className="glass rounded-[2rem] p-6 border border-white/10 flex flex-col gap-4 shadow-xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <Weight className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-black text-white">Log Biomarkers</h3>
            <p className="text-[11px] text-slate-400">Record physical metrics</p>
          </div>
        </div>

        {justSaved && (
          <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 animate-fadeIn">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Recorded</span>
          </div>
        )}
      </div>

      {/* Quick Metric Presets */}
      <div className="flex items-center gap-1.5 overflow-x-auto py-1">
        {METRIC_PRESETS.map((p) => (
          <button
            key={p.label}
            type="button"
            onClick={() => handleSelectPreset(p.label, p.defaultUnit)}
            className={`px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              label === p.label
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-glow-sm'
                : 'bg-white/[0.03] text-slate-400 hover:text-white border border-white/5'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Input Row */}
      <div className="grid grid-cols-2 gap-2">
        <input
          type="number"
          step="0.1"
          required
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder={`Value (${unit})`}
          className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
        />

        <input
          type="text"
          value={unit}
          onChange={(e) => setUnit(e.target.value)}
          placeholder="Unit (e.g. kg, %, cm)"
          className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
        />
      </div>

      <button
        type="submit"
        className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-glow-sm transition-all active:scale-95 cursor-pointer"
      >
        <Plus className="w-4 h-4" />
        <span>Save Biomarker Entry</span>
      </button>
    </form>
  );
};
