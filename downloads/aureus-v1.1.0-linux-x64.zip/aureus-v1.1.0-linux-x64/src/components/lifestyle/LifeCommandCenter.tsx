// Life Pulse — the top-level whole-life dashboard.
//
//   Top      : overall life progress, Body | Health | Intelligence | Spirit
//   Center   : body + brain + aura visualization
//   Side     : life attribute radar
//   Below    : GitHub-style contribution calendar
//   Daily    : today's activities, reminders, streaks
//   Progress : records, positive habits built, harmful habits reduced
//   Finance  : net worth, invested value, monthly cash-flow
//
import React, { useMemo, useState } from 'react';
import {
  Activity as ActivityIcon,
  Flame,
  TrendingUp,
  Shield,
  Heart,
  Brain,
  Sparkles,
  Clock,
  CheckCircle2,
  CircleDashed,
  CalendarDays,
  ChevronRight,
  Trophy,
  Wallet,
  PiggyBank,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { BodyMuscleMap } from './BodyMuscleMap';
import { LifeAttributeRadar } from './LifeAttributeRadar';
import { ContributionCalendar } from './ContributionCalendar';
import { LifeProfile } from '../../domain/lifeProfileService';
import {
  Activity,
  DayProgress,
  Dimension,
  DIMENSIONS,
} from '../../domain/lifeProgressService';
import { ResolvedReminder, summarizeReminders } from '../../domain/reminderService';
import {
  computeMoneyStats,
  fmtMoney,
  MoneyStats,
} from '../../domain/moneyStatsService';
import { format, parseISO } from 'date-fns';

interface Props {
  profile: LifeProfile;
  activities: Activity[];
  todaysResults: Map<string, number>;   // activityId → actual today
  reminders: ResolvedReminder[];
  /** Money state for the finance analytics tiles. Optional — dashboard renders without it. */
  money?: MoneyStats | null;
  onOpenActivity?: (id: string) => void;
  onSelectDate?: (date: string) => void;
  onOpenMoney?: () => void;
}

const DIMENSION_META: Array<{ key: Dimension; label: string; color: string; Icon: typeof ActivityIcon }> = [
  { key: 'body', label: 'Body', color: '#ef4444', Icon: ActivityIcon },       // Red
  { key: 'health', label: 'Health', color: '#10b981', Icon: Heart },       // Green
  { key: 'intelligence', label: 'Intelligence', color: '#3b82f6', Icon: Brain }, // Blue
  { key: 'spirit', label: 'Spirit', color: '#f59e0b', Icon: Shield },     // Gold
];

const STATE_STYLES = {
  completed: { text: 'text-emerald-400', Icon: CheckCircle2, label: 'Completed' },
  missed: { text: 'text-rose-400', Icon: CircleDashed, label: 'Missed' },
  upcoming: { text: 'text-sky-400', Icon: Clock, label: 'Upcoming' },
  snoozed: { text: 'text-amber-400', Icon: Clock, label: 'Snoozed' },
  fired: { text: 'text-slate-400', Icon: Clock, label: 'Due' },
  disabled: { text: 'text-slate-600', Icon: CircleDashed, label: 'Off' },
} as const;

export const LifeCommandCenter: React.FC<Props> = ({
  profile,
  activities,
  todaysResults,
  reminders,
  money,
  onOpenActivity,
  onSelectDate,
  onOpenMoney,
}) => {
  const [focus, setFocus] = useState<'all' | Dimension>('all');
  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const today = profile.days.get(todayStr);

  const live = useMemo(() => activities.filter((a) => !a.deleted && !a.archived), [activities]);

  const todaysActivities = useMemo(() => {
    return live
      .map((a) => {
        const actual = todaysResults.get(a.id) ?? 0;
        const ratio = a.target > 0 ? actual / a.target : 0;
        const isHarmful = a.polarity === 'negative';
        const relapsed = isHarmful && actual > 0;

        let status: 'completed' | 'progress' | 'remaining' | 'relapsed' = 'remaining';
        if (isHarmful) {
          status = relapsed ? 'relapsed' : 'completed';
        } else if (actual >= a.target && a.target > 0) status = 'completed';
        else if (actual > 0) status = 'progress';

        return { activity: a, actual, ratio, status, isHarmful, relapsed };
      })
      .sort((x, y) => {
        // Relapsed first (needs attention), then in-progress, then remaining.
        const rank = (s: string) =>
          s === 'relapsed' ? 0 : s === 'progress' ? 1 : s === 'remaining' ? 2 : 3;
        return rank(x.status) - rank(y.status);
      });
  }, [live, todaysResults]);

  const reminderSummary = useMemo(() => summarizeReminders(reminders), [reminders]);

  const hasAnyData = profile.streaks.totalActiveDays > 0;

  // Keep the dashboard and its graphs mounted even before the user adds an
  // activity. The charts have explicit zero-data visuals; returning a standalone
  // empty state here hid them entirely for brand-new users.
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8 pb-24 animate-fadeIn">
      {/* ── TOP: overall life progress ──────────────────────────────────── */}
      <header className="stagger-1 glass rounded-[2rem] p-6 sm:p-8 relative overflow-hidden border border-white/[0.08] shadow-aureus-lg">
        <div className="relative flex flex-col lg:flex-row lg:items-center gap-8">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-[#F0C465] text-xs font-bold uppercase tracking-widest mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Life Pulse Command Center</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black heading-gradient tracking-tight">
              Holistic Equilibrium & Vitality
            </h1>

            <div className="mt-5 flex items-center gap-6">
              <div>
                <div className="text-4xl sm:text-5xl font-black text-white tabular-nums leading-none">
                  {profile.dimensions.overall}
                </div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mt-1">
                  Life Index
                </div>
              </div>
              <div className="h-10 w-px bg-white/10 hidden md:block" />
              <div className="flex gap-1.5 flex-wrap">
                {DIMENSIONS.map((d) => {
                  const meta = DIMENSION_META.find((m) => m.key === d)!;
                  const Icon = meta.Icon;
                  const value = profile.dimensions[d];
                  const isSelected = focus === d;
                  return (
                    <button
                      key={d}
                      onClick={() => setFocus(focus === d ? 'all' : d)}
                      className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-white/[0.1] border border-white/20 shadow-aureus-sm'
                          : 'bg-white/[0.02] border border-white/[0.05] hover:bg-white/[0.06]'
                      }`}
                    >
                      <Icon className="w-4 h-4" style={{ color: meta.color }} />
                      <span className="text-base font-black text-white tabular-nums">{value}</span>
                      <span className="text-[9px] font-semibold uppercase tracking-wider text-zinc-400 whitespace-nowrap">
                        {meta.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Aura meter */}
          <div className="lg:w-56 shrink-0 p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
            <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2 flex items-center justify-between">
              <span>Momentum Aura</span>
              <span className="font-bold text-[#F0C465]">{profile.aura}%</span>
            </div>
            <div className="h-2 rounded-full bg-black/40 border border-white/[0.08] overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#E5A93C] via-[#F3C766] to-[#10B981] transition-all duration-1000"
                style={{ width: `${profile.aura}%` }}
              />
            </div>
            <p className="text-[10px] text-zinc-500 mt-2 leading-relaxed">
              Synthesized from active consistency, balanced daily actions, and resisted habits.
            </p>
          </div>
        </div>
      </header>

      {/* ── VISUAL COCKPIT: Anatomical Map & Equilibrium Radar ────────── */}
      <div className="stagger-2 grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Anatomical Muscle Map */}
        <section className="glass rounded-3xl p-6 sm:p-7 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-400 mb-0.5">
                Physical Anatomy
              </div>
              <h2 className="text-base font-bold text-slate-100">
                Muscle Development & Aura
              </h2>
            </div>
            <div className="text-xs text-slate-400">
              Interactive View
            </div>
          </div>
          <div className="flex-1 flex items-center justify-center py-2">
            <BodyMuscleMap
              levels={profile.muscles}
              inProgress={profile.inProgressMuscles}
              health={profile.dimensions.health}
              spirit={profile.dimensions.spirit}
              intelligence={profile.attributes.intelligence}
              height={380}
            />
          </div>
        </section>

        {/* Life Attribute Radar */}
        <section className="glass rounded-3xl p-6 sm:p-7 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-blue-400 mb-0.5">
                Attribute Equilibrium
              </div>
              <h2 className="text-base font-bold text-slate-100">
                14-Factor Life Radar
              </h2>
            </div>
            {focus !== 'all' && (
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-white/10 text-slate-300">
                {focus}
              </span>
            )}
          </div>
          <div className="flex-1 flex items-center justify-center py-2">
            <LifeAttributeRadar
              attributes={profile.attributes}
              size={360}
              dimension={focus}
            />
          </div>
        </section>
      </div>

      {/* ── 52-WEEK ACTIVITY CONTRIBUTION HEATMAP ─────────────────────── */}
      <section className="stagger-3 glass rounded-3xl p-6 sm:p-7 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-emerald-400" />
            <h2 className="text-sm font-bold uppercase tracking-widest text-slate-300">
              Activity Consistency Heatmap (52 Weeks)
            </h2>
          </div>
          <button
            onClick={() => onSelectDate?.(todayStr)}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>Jump to Calendar</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <ContributionCalendar
          days={profile.days}
          weeks={52}
          onSelectDate={(date) => onSelectDate?.(date)}
        />
      </section>

      {/* ── DAILY + PROGRESS ───────────────────────────────────────────── */}
      <div className="stagger-4 grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today */}
        <section className="glass rounded-3xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400">
              Today
            </h2>
            <div className="flex gap-3 text-[10px] text-slate-500">
              <span><span className="text-emerald-400 font-bold">{today?.completedCount ?? 0}</span> done</span>
              <span><span className="text-rose-400 font-bold">{reminderSummary.missed}</span> missed</span>
              <span><span className="text-sky-400 font-bold">{reminderSummary.upcoming}</span> upcoming</span>
            </div>
          </div>

          {todaysActivities.length === 0 ? (
            <p className="text-sm text-slate-500 py-6 text-center">No activities scheduled today.</p>
          ) : (
            <ul className="space-y-2">
              {todaysActivities.map(({ activity, actual, ratio, status, relapsed }) => {
                const pct = Math.min(100, Math.round(ratio * 100));
                return (
                  <li key={activity.id}>
                    <button
                      onClick={() => onOpenActivity?.(activity.id)}
                      className="w-full text-left p-3 rounded-xl hover:bg-white/5 transition-colors"
                    >
                      <div className="flex items-center justify-between gap-3 mb-1.5">
                        <span className="flex items-center gap-2 min-w-0">
                          <span
                            className="w-2 h-2 rounded-full shrink-0"
                            style={{ background: activity.color }}
                          />
                          <span className="text-sm font-semibold text-slate-200 truncate">
                            {activity.name}
                          </span>
                          {activity.polarity === 'negative' && (
                            <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-rose-500/15 text-rose-400 shrink-0">
                              resist
                            </span>
                          )}
                        </span>
                        <span
                          className={`text-xs font-bold shrink-0 ${
                            status === 'completed'
                              ? 'text-emerald-400'
                              : status === 'relapsed'
                              ? 'text-rose-400'
                              : 'text-slate-500'
                          }`}
                        >
                          {activity.polarity === 'negative'
                            ? relapsed
                              ? 'relapsed'
                              : 'held'
                            : `${actual}/${activity.target} ${activity.unit}`}
                        </span>
                      </div>
                      {!relapsed && (
                        <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-700 ${
                              status === 'completed' ? 'bg-emerald-500' : 'bg-emerald-500/50'
                            }`}
                            style={{ width: `${activity.polarity === 'negative' ? (relapsed ? 0 : 100) : pct}%` }}
                          />
                        </div>
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}

          {/* Upcoming reminders timeline */}
          {reminders.filter((r) => r.state === 'upcoming' || r.state === 'snoozed').length > 0 && (
            <div className="mt-5 pt-4 border-t border-white/5">
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-2">
                Upcoming reminders
              </h3>
              <ul className="space-y-1">
                {reminders
                  .filter((r) => r.state === 'upcoming' || r.state === 'snoozed')
                  .slice(0, 6)
                  .map((r) => {
                    const act = live.find((a) => a.id === r.reminder.activityId);
                    const style = STATE_STYLES[r.state];
                    return (
                      <li key={r.reminder.id} className="flex items-center gap-2 text-xs">
                        <span className="text-slate-500 font-mono shrink-0">
                          {format(r.at, 'HH:mm')}
                        </span>
                        <span className="text-slate-300 truncate">{act?.name ?? 'Activity'}</span>
                        {r.reminder.label && (
                          <span className="text-slate-600 truncate">· {r.reminder.label}</span>
                        )}
                        <span className={`ml-auto shrink-0 ${style.text}`}>{style.label}</span>
                      </li>
                    );
                  })}
              </ul>
            </div>
          )}
        </section>

        {/* Progress */}
        <section className="glass rounded-3xl p-6 space-y-5">
          <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400">
            Long-term progress
          </h2>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-white/[0.03] p-4">
              <Flame className="w-4 h-4 text-orange-400 mb-2" />
              <div className="text-2xl font-black text-slate-100">{profile.streaks.current}</div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">Current streak</div>
            </div>
            <div className="rounded-2xl bg-white/[0.03] p-4">
              <TrendingUp className="w-4 h-4 text-emerald-400 mb-2" />
              <div className="text-2xl font-black text-slate-100">{profile.streaks.best}</div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">Best streak</div>
            </div>
            <div className="rounded-2xl bg-white/[0.03] p-4">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 mb-2" />
              <div className="text-2xl font-black text-slate-100">{profile.momentum.positive}</div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">Habits built</div>
            </div>
            <div className="rounded-2xl bg-white/[0.03] p-4">
              <Shield className="w-4 h-4 text-sky-400 mb-2" />
              <div className="text-2xl font-black text-slate-100">{profile.momentum.resisted}</div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">
                Days resisted
              </div>
            </div>
          </div>

          {profile.momentum.relapsed > 0 && (
            <div className="rounded-2xl bg-rose-500/5 border border-rose-500/20 p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-rose-400 font-semibold">Relapses recorded</span>
                <span className="text-rose-300 font-black">{profile.momentum.relapsed}</span>
              </div>
              <p className="text-xs text-slate-500 mt-1.5">
                A relapse costs you a day. It never erases the progress you already made —{' '}
                {profile.attributes.selfControl} self-control remains, and the next clean day adds
                to it.
              </p>
            </div>
          )}

          <div className="rounded-2xl bg-white/[0.03] p-4">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span className="text-sm font-semibold text-slate-200">Personal records</span>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li className="flex justify-between">
                <span>Strongest day</span>
                <span className="text-slate-200 font-bold">
                  {profile.records.bestDayDate
                    ? `${format(parseISO(profile.records.bestDayDate), 'MMM d')} · ${profile.records.bestDayScore}`
                    : '—'}
                </span>
              </li>
              <li className="flex justify-between">
                <span>Longest run</span>
                <span className="text-slate-200 font-bold">{profile.records.longestMuscleStreak} days</span>
              </li>
              <li className="flex justify-between">
                <span>Days with activity</span>
                <span className="text-slate-200 font-bold">{profile.streaks.totalActiveDays}</span>
              </li>
            </ul>
          </div>

          {!hasAnyData && (
            <p className="text-xs text-slate-500 text-center pt-2">
              Log your first activity and this page starts filling in.
            </p>
          )}
        </section>
      </div>

      {/* ── FINANCE: money analytics ───────────────────────────── */}
      {money && (
        <section className="stagger-5 glass rounded-3xl p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400">
              Finances
            </h2>
            {onOpenMoney && (
              <button
                onClick={onOpenMoney}
                className="text-xs font-semibold text-emerald-400 hover:text-emerald-300"
              >
                Open money manager
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-2xl bg-white/[0.03] p-4">
              <Wallet className="w-4 h-4 text-emerald-400 mb-2" />
              <div className="text-xl font-black text-slate-100 tabular-nums">
                {fmtMoney(money.netWorth)}
              </div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">
                Net worth
              </div>
            </div>
            <div className="rounded-2xl bg-white/[0.03] p-4">
              <PiggyBank className="w-4 h-4 text-sky-400 mb-2" />
              <div className="text-xl font-black text-slate-100 tabular-nums">
                {fmtMoney(money.invested)}
              </div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">
                Invested
              </div>
            </div>
            <div className="rounded-2xl bg-white/[0.03] p-4">
              <ArrowUpRight className="w-4 h-4 text-emerald-400 mb-2" />
              <div className="text-xl font-black text-emerald-400 tabular-nums">
                {fmtMoney(money.income)}
              </div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">
                Income · month
              </div>
            </div>
            <div className="rounded-2xl bg-white/[0.03] p-4">
              <ArrowDownRight className="w-4 h-4 text-rose-400 mb-2" />
              <div className="text-xl font-black text-rose-400 tabular-nums">
                {fmtMoney(money.expense)}
              </div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">
                Expenses · month
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="rounded-2xl bg-white/[0.03] p-4 flex justify-between items-center">
              <span className="text-slate-400">Cash</span>
              <span className="text-slate-200 font-bold tabular-nums">
                {fmtMoney(money.cash)}
              </span>
            </div>
            <div className="rounded-2xl bg-white/[0.03] p-4 flex justify-between items-center">
              <span className="text-slate-400">Debt</span>
              <span className={`font-bold tabular-nums ${money.debt > 0 ? 'text-rose-300' : 'text-slate-200'}`}>
                {fmtMoney(money.debt)}
              </span>
            </div>
            <div className="rounded-2xl bg-white/[0.03] p-4 flex justify-between items-center">
              <span className="text-slate-400">Invest. P/L</span>
              <span className={`font-bold tabular-nums ${money.investedPnl >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                {money.investedPnl >= 0 ? '+' : '−'}{fmtMoney(Math.abs(money.investedPnl))}
              </span>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default LifeCommandCenter;
