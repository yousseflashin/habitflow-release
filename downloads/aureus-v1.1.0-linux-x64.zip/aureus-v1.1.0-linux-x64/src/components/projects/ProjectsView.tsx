// Aureus Projects & Classification — Domain & Tag Management

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { IconHelper } from '../common/IconHelper';
import { Folder, Plus, Edit2, Trash2, Tag as TagIcon, Sparkles, Inbox, ChevronRight } from 'lucide-react';

export const ProjectsView: React.FC = () => {
  const {
    projects,
    tasks,
    tags,
    setSelectedProjectId,
    setSelectedTagId,
    setActiveView,
    setEditingProject,
    setIsProjectModalOpen,
    setEditingTask,
    setIsTaskModalOpen,
    deleteProject,
    createTag,
    deleteTag,
  } = useApp();

  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#F0C465');

  const handleAddTag = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName.trim()) return;
    await createTag(newTagName.trim(), newTagColor);
    setNewTagName('');
  };

  const inboxTasks = tasks.filter((t) => !t.deleted && (!t.projectId || t.projectId === 'inbox') && !t.completed);

  return (
    <div className="space-y-8 pb-20 max-w-6xl mx-auto animate-fadeIn">
      {/* ── Header ──────────────────────────────────────────────── */}
      <div className="stagger-1 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-300 uppercase tracking-widest mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Vault Architecture</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Projects &amp; Labels
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Structured domains of life, long-term initiatives, and categorical tag hierarchies.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingProject(null);
            setIsProjectModalOpen(true);
          }}
          className="btn-primary !px-5 !py-2.5 !text-xs !rounded-2xl flex items-center gap-2 cursor-pointer self-start sm:self-auto active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Project</span>
        </button>
      </div>

      {/* ── Projects Grid ────────────────────────────────────────── */}
      <div className="stagger-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Inbox Default Card */}
        <div
          onClick={() => {
            setSelectedProjectId('inbox');
            setActiveView('tasks');
          }}
          className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 hover:border-amber-400/40 transition-all cursor-pointer group shadow-2xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center gap-3.5 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-white/[0.04] border border-white/10 text-amber-300 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Inbox className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white group-hover:text-amber-300 transition-colors">
                  Inbox
                </h3>
                <p className="text-xs text-slate-400">Default triage & capture</p>
              </div>
            </div>

            <p className="text-xs text-slate-400">
              Unassigned items waiting to be organized into dedicated projects.
            </p>
          </div>

          <div className="pt-4 mt-6 border-t border-white/[0.06] flex items-center justify-between text-xs">
            <span className="font-bold text-slate-300 font-mono">
              {inboxTasks.length} pending task{inboxTasks.length === 1 ? '' : 's'}
            </span>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-amber-300 group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>

        {/* Custom Projects */}
        {projects.filter((p) => !p.deleted).map((proj) => {
          const projTasks = tasks.filter((t) => !t.deleted && t.projectId === proj.id);
          const completedCount = projTasks.filter((t) => t.completed).length;
          const totalCount = projTasks.length;
          const pendingCount = totalCount - completedCount;
          const pct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

          return (
            <div
              key={proj.id}
              onClick={() => {
                setSelectedProjectId(proj.id);
                setActiveView('tasks');
              }}
              className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 hover:border-white/20 transition-all cursor-pointer group shadow-2xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-4">
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div
                      style={{
                        backgroundColor: `${proj.color}20`,
                        color: proj.color,
                        borderColor: `${proj.color}40`,
                      }}
                      className="w-12 h-12 rounded-2xl flex items-center justify-center border group-hover:scale-105 transition-transform shrink-0"
                    >
                      <IconHelper name={proj.icon} className="w-6 h-6" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-lg font-black text-white group-hover:text-amber-300 transition-colors truncate">
                        {proj.name}
                      </h3>
                      <p className="text-xs text-slate-400 font-mono">
                        {pendingCount} pending · {completedCount} done
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingProject(proj);
                        setIsProjectModalOpen(true);
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                      title="Edit project"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Delete project "${proj.name}"?`)) {
                          deleteProject(proj.id);
                        }
                      }}
                      className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title="Delete project"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-white/[0.06] h-1.5 rounded-full overflow-hidden my-3">
                  <div
                    style={{ width: `${pct}%`, backgroundColor: proj.color }}
                    className="h-full rounded-full transition-all duration-300"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-white/[0.06] flex items-center justify-between">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedProjectId(proj.id);
                    setEditingTask(null);
                    setIsTaskModalOpen(true);
                  }}
                  className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Task</span>
                </button>
                <div className="text-xs text-slate-400 font-mono font-bold">
                  {pct}% complete
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Tags Section ─────────────────────────────────────────── */}
      <div className="stagger-3 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-7 shadow-2xl space-y-5">
        <div className="flex items-center gap-2.5">
          <TagIcon className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300">
            Categorical Tags ({tags.filter((t) => !t.deleted).length})
          </h2>
        </div>

        {/* Tag Creator Form */}
        <form onSubmit={handleAddTag} className="flex items-center gap-2.5 flex-wrap">
          <input
            type="text"
            value={newTagName}
            onChange={(e) => setNewTagName(e.target.value)}
            placeholder="New tag label..."
            className="px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400/50"
          />
          <input
            type="color"
            value={newTagColor}
            onChange={(e) => setNewTagColor(e.target.value)}
            className="w-10 h-10 p-1 rounded-xl border border-white/10 bg-white/[0.04] cursor-pointer"
            title="Pick tag accent color"
          />
          <button
            type="submit"
            className="btn-primary !px-4 !py-2.5 !text-xs !rounded-xl cursor-pointer"
          >
            Create Tag
          </button>
        </form>

        {/* Existing Tags Chips */}
        <div className="flex items-center gap-2 flex-wrap pt-2">
          {tags.filter((tg) => !tg.deleted).map((tg) => {
            const tagTaskCount = tasks.filter((t) => !t.deleted && t.tags?.includes(tg.id) && !t.completed).length;
            return (
              <div
                key={tg.id}
                style={{
                  backgroundColor: `${tg.color}15`,
                  borderColor: `${tg.color}35`,
                  color: tg.color,
                }}
                onClick={() => {
                  setSelectedTagId(tg.id);
                  setActiveView('tasks');
                }}
                className="px-3.5 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-2 cursor-pointer hover:scale-105 transition-all shadow-xs"
                title={`Filter tasks by #${tg.name}`}
              >
                <span>#{tg.name}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
                  {tagTaskCount}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm(`Delete tag #${tg.name}?`)) {
                      deleteTag(tg.id);
                    }
                  }}
                  className="hover:text-rose-400 cursor-pointer ml-1 text-slate-400 transition-colors"
                >
                  ×
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProjectsView;