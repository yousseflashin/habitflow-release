// HabitFlow — Projects & Commercial Client Pipeline
// Interconnected Work Management: Personal Initiatives, Client Sprints, and Money Treasury Integration.

import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { IconHelper } from '../common/IconHelper';
import { Project } from '../../types';
import { ProjectFinanceModal } from './ProjectFinanceModal';
import {
  computeProjectFinancials,
  getProjectReceivablesSummary,
} from '../../domain/projectMoneyBridge';
import { fmtMoney } from '../../domain/moneyStatsService';
import {
  Folder,
  Plus,
  Edit2,
  Trash2,
  Tag as TagIcon,
  Sparkles,
  Inbox,
  ChevronRight,
  Briefcase,
  DollarSign,
  Layers,
  TrendingUp,
  CheckCircle2,
} from 'lucide-react';

export const ProjectsView: React.FC = () => {
  const {
    projects,
    tasks,
    tags,
    setSelectedProjectId,
    setSelectedTagId,
    setActiveView,
    setEditingProject,
    setIsProjectModalOpen,
    setEditingTask,
    setIsTaskModalOpen,
    updateProject,
    deleteProject,
    createTag,
    deleteTag,
  } = useApp();

  const [projectFilter, setProjectFilter] = useState<'all' | 'client' | 'personal'>('all');
  const [managingFinanceProject, setManagingFinanceProject] = useState<Project | null>(null);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#38BDF8');

  // Compute portfolio-level client receivables summary
  const receivablesSummary = useMemo(() => {
    return getProjectReceivablesSummary(projects);
  }, [projects]);

  const handleAddTag = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName.trim()) return;
    await createTag(newTagName.trim(), newTagColor);
    setNewTagName('');
  };

  const inboxTasks = tasks.filter((t) => !t.deleted && (!t.projectId || t.projectId === 'inbox') && !t.completed);

  // Filtered project list
  const filteredProjects = useMemo(() => {
    return projects
      .filter((p) => !p.deleted)
      .filter((p) => {
        if (projectFilter === 'client') return p.kind === 'client';
        if (projectFilter === 'personal') return p.kind !== 'client';
        return true;
      });
  }, [projects, projectFilter]);

  return (
    <div className="space-y-8 pb-20 max-w-6xl mx-auto animate-fadeIn text-white">
      {/* ── Top Header ────────────────────────────────────────────── */}
      <div className="stagger-1 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-cyan-400 uppercase tracking-widest mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Executive Workspace Architecture</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Projects &amp; Client Pipeline
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Personal initiatives, commercial client contracts, billable sprint milestones, and categorical tags.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingProject(null);
            setIsProjectModalOpen(true);
          }}
          className="btn-primary !px-5 !py-2.5 !text-xs !rounded-2xl flex items-center gap-2 cursor-pointer self-start sm:self-auto active:scale-95 shadow-brand-glow"
        >
          <Plus className="w-4 h-4" />
          <span>New Project</span>
        </button>
      </div>

      {/* ── Commercial & Pipeline Metric Cards ─────────────────────── */}
      <div className="stagger-2 grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] shadow-xl">
          <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block mb-1">
            Active Projects
          </span>
          <div className="text-xl sm:text-2xl font-black text-white font-mono">
            {projects.filter((p) => !p.deleted).length}
          </div>
          <span className="text-[10px] text-slate-500 font-mono mt-0.5 block">
            {receivablesSummary.activeClientProjectsCount} Commercial Clients
          </span>
        </div>

        <div className="p-4 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] shadow-xl">
          <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block mb-1">
            Client Contract Pipeline
          </span>
          <div className="text-xl sm:text-2xl font-black text-white font-mono">
            {fmtMoney(receivablesSummary.totalClientContractValue)}
          </div>
          <span className="text-[10px] text-cyan-400 font-mono mt-0.5 block flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>Total Value</span>
          </span>
        </div>

        <div className="p-4 rounded-3xl bg-[#0c0e14]/90 border border-emerald-500/20 bg-emerald-500/[0.03] shadow-xl">
          <span className="text-[10px] text-emerald-400 font-mono uppercase tracking-wider block mb-1">
            Collected Revenue
          </span>
          <div className="text-xl sm:text-2xl font-black text-emerald-300 font-mono">
            {fmtMoney(receivablesSummary.totalCollectedRevenue)}
          </div>
          <span className="text-[10px] text-emerald-400/80 font-mono mt-0.5 block">
            Passed to Money Treasury
          </span>
        </div>

        <div className="p-4 rounded-3xl bg-[#0c0e14]/90 border border-cyan-500/20 bg-cyan-500/[0.03] shadow-xl">
          <span className="text-[10px] text-cyan-400 font-mono uppercase tracking-wider block mb-1">
            Pending Sprints
          </span>
          <div className="text-xl sm:text-2xl font-black text-cyan-300 font-mono">
            {fmtMoney(receivablesSummary.totalPendingReceivables)}
          </div>
          <span className="text-[10px] text-cyan-400/80 font-mono mt-0.5 block">
            Expected Inflow
          </span>
        </div>
      </div>

      {/* ── Filter Tabs ───────────────────────────────────────────── */}
      <div className="flex items-center gap-2 border-b border-white/[0.06] pb-3 text-xs">
        <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider mr-2">Filter:</span>
        {[
          { id: 'all', label: 'All Projects', count: projects.filter((p) => !p.deleted).length },
          { id: 'client', label: 'Commercial Clients', count: projects.filter((p) => !p.deleted && p.kind === 'client').length },
          { id: 'personal', label: 'Personal Initiatives', count: projects.filter((p) => !p.deleted && p.kind !== 'client').length },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setProjectFilter(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              projectFilter === tab.id
                ? 'bg-indigo-600 text-white shadow-brand-sm'
                : 'bg-white/[0.03] hover:bg-white/[0.06] text-slate-400 hover:text-white border border-white/5'
            }`}
          >
            <span>{tab.label}</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* ── Projects Grid ────────────────────────────────────────── */}
      <div className="stagger-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Inbox Default Card (Only in 'all' or 'personal') */}
        {projectFilter !== 'client' && (
          <div
            onClick={() => {
              setSelectedProjectId('inbox');
              setActiveView('tasks');
            }}
            className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 hover:border-cyan-400/40 transition-all cursor-pointer group shadow-2xl flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-3.5 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-white/[0.04] border border-white/10 text-cyan-300 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Inbox className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white group-hover:text-cyan-300 transition-colors">
                    Inbox
                  </h3>
                  <p className="text-xs text-slate-400">Default triage &amp; capture</p>
                </div>
              </div>

              <p className="text-xs text-slate-400">
                Unassigned items waiting to be organized into dedicated projects or client sprints.
              </p>
            </div>

            <div className="pt-4 mt-6 border-t border-white/[0.06] flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 font-mono">
                {inboxTasks.length} pending task{inboxTasks.length === 1 ? '' : 's'}
              </span>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-300 group-hover:translate-x-0.5 transition-all" />
            </div>
          </div>
        )}

        {/* Custom Projects */}
        {filteredProjects.map((proj) => {
          const projTasks = tasks.filter((t) => !t.deleted && t.projectId === proj.id);
          const completedCount = projTasks.filter((t) => t.completed).length;
          const totalCount = projTasks.length;
          const pendingCount = totalCount - completedCount;
          const pct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
          const financials = computeProjectFinancials(proj);
          const isClient = proj.kind === 'client';

          return (
            <div
              key={proj.id}
              onClick={() => {
                setSelectedProjectId(proj.id);
                setActiveView('tasks');
              }}
              className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 hover:border-white/20 transition-all cursor-pointer group shadow-2xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div
                      style={{
                        backgroundColor: `${proj.color}20`,
                        color: proj.color,
                        borderColor: `${proj.color}40`,
                      }}
                      className="w-12 h-12 rounded-2xl flex items-center justify-center border group-hover:scale-105 transition-transform shrink-0"
                    >
                      <IconHelper name={proj.icon} className="w-6 h-6" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-black text-white group-hover:text-cyan-300 transition-colors truncate">
                          {proj.name}
                        </h3>
                      </div>
                      <p className="text-xs text-slate-400 font-mono">
                        {pendingCount} pending · {completedCount} done
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingProject(proj);
                        setIsProjectModalOpen(true);
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                      title="Edit project"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Delete project "${proj.name}"?`)) {
                          deleteProject(proj.id);
                        }
                      }}
                      className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title="Delete project"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Classification & Financial Status */}
                <div className="my-2.5">
                  {isClient ? (
                    <div className="p-3 rounded-2xl bg-cyan-500/[0.05] border border-cyan-500/20 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-cyan-300 flex items-center gap-1">
                          <Briefcase className="w-3.5 h-3.5" />
                          <span>{proj.clientName || 'Client Project'}</span>
                        </span>
                        <span className="font-mono font-bold text-white">
                          {fmtMoney(financials.contractValue, proj.currency)}
                        </span>
                      </div>

                      {/* Collection progress */}
                      <div className="w-full bg-white/[0.06] h-1.5 rounded-full overflow-hidden">
                        <div
                          style={{ width: `${financials.collectionRate}%` }}
                          className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-300"
                        />
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                        <span className="text-emerald-400">
                          {fmtMoney(financials.totalPaid, proj.currency)} paid ({financials.collectionRate}%)
                        </span>
                        <span>
                          {fmtMoney(financials.totalPending, proj.currency)} pending
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-white/[0.03] border border-white/5 text-[10px] font-mono text-slate-400">
                      <span>Personal Initiative</span>
                    </div>
                  )}
                </div>

                {/* Task Progress Bar */}
                <div className="w-full bg-white/[0.06] h-1.5 rounded-full overflow-hidden my-3">
                  <div
                    style={{ width: `${pct}%`, backgroundColor: proj.color }}
                    className="h-full rounded-full transition-all duration-300"
                  />
                </div>
              </div>

              {/* Actions & Sprints Management */}
              <div className="pt-3 border-t border-white/[0.06] flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedProjectId(proj.id);
                    setEditingTask(null);
                    setIsTaskModalOpen(true);
                  }}
                  className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Task</span>
                </button>

                {isClient && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setManagingFinanceProject(proj);
                    }}
                    className="px-2.5 py-1 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-bold flex items-center gap-1 cursor-pointer transition-all"
                  >
                    <Layers className="w-3 h-3" />
                    <span>Sprints ({proj.sprints?.length || 0})</span>
                  </button>
                )}

                <div className="text-xs text-slate-400 font-mono font-bold">
                  {pct}% done
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Tags Section ─────────────────────────────────────────── */}
      <div className="stagger-3 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 sm:p-7 shadow-2xl space-y-5">
        <div className="flex items-center gap-2.5">
          <TagIcon className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300">
            Categorical Tags ({tags.filter((t) => !t.deleted).length})
          </h2>
        </div>

        {/* Tag Creator Form */}
        <form onSubmit={handleAddTag} className="flex items-center gap-2.5 flex-wrap">
          <input
            type="text"
            value={newTagName}
            onChange={(e) => setNewTagName(e.target.value)}
            placeholder="New tag label..."
            className="px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
          />
          <input
            type="color"
            value={newTagColor}
            onChange={(e) => setNewTagColor(e.target.value)}
            className="w-10 h-10 p-1 rounded-xl border border-white/10 bg-white/[0.04] cursor-pointer"
            title="Pick tag accent color"
          />
          <button
            type="submit"
            className="btn-primary !px-4 !py-2.5 !text-xs !rounded-xl cursor-pointer"
          >
            Create Tag
          </button>
        </form>

        {/* Existing Tags Chips */}
        <div className="flex items-center gap-2 flex-wrap pt-2">
          {tags.filter((tg) => !tg.deleted).map((tg) => {
            const tagTaskCount = tasks.filter((t) => !t.deleted && t.tags?.includes(tg.id) && !t.completed).length;
            return (
              <div
                key={tg.id}
                style={{
                  backgroundColor: `${tg.color}15`,
                  borderColor: `${tg.color}35`,
                  color: tg.color,
                }}
                onClick={() => {
                  setSelectedTagId(tg.id);
                  setActiveView('tasks');
                }}
                className="px-3.5 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-2 cursor-pointer hover:scale-105 transition-all shadow-xs"
                title={`Filter tasks by #${tg.name}`}
              >
                <span>#{tg.name}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
                  {tagTaskCount}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm(`Delete tag #${tg.name}?`)) {
                      deleteTag(tg.id);
                    }
                  }}
                  className="hover:text-rose-400 cursor-pointer ml-1 text-slate-400 transition-colors"
                >
                  ×
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sprints & Payments Management Modal */}
      {managingFinanceProject && (
        <ProjectFinanceModal
          project={managingFinanceProject}
          isOpen={Boolean(managingFinanceProject)}
          onClose={() => setManagingFinanceProject(null)}
          onSaveProject={async (updated) => {
            await updateProject(updated.id, updated);
            setManagingFinanceProject(updated);
          }}
        />
      )}
    </div>
  );
};

export default ProjectsView;
