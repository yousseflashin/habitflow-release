// HabitFlow — Project Financials, Sprints & Client Payment Reconciliation Modal
// Allows tracking sprints with expected income, logging payments, and
// automatically passing collected income into the Money Treasury & Executive Wallet.

import React, { useState, useMemo } from 'react';
import { Project, ProjectSprint, ProjectPayment } from '../../types';
import {
  computeProjectFinancials,
  depositProjectPaymentToMoney,
  getStoredMoneyState,
} from '../../domain/projectMoneyBridge';
import { fmtMoney } from '../../domain/moneyStatsService';
import {
  X,
  Plus,
  DollarSign,
  Briefcase,
  CheckCircle2,
  Clock,
  Layers,
  TrendingUp,
  Landmark,
  FileCheck,
  Calendar,
  AlertCircle,
} from 'lucide-react';

interface ProjectFinanceModalProps {
  project: Project;
  isOpen: boolean;
  onClose: () => void;
  onSaveProject: (updated: Project) => Promise<void>;
}

export const ProjectFinanceModal: React.FC<ProjectFinanceModalProps> = ({
  project,
  isOpen,
  onClose,
  onSaveProject,
}) => {
  const [activeTab, setActiveTab] = useState<'sprints' | 'payments' | 'new_payment'>('sprints');

  // Sprints state
  const sprints = project.sprints || [];
  const payments = project.payments || [];

  // New sprint form state
  const [newSprintName, setNewSprintName] = useState('');
  const [newSprintIncome, setNewSprintIncome] = useState<number>(0);
  const [newSprintDueDate, setNewSprintDueDate] = useState('');
  const [showAddSprint, setShowAddSprint] = useState(false);

  // New payment form state
  const [paymentTitle, setPaymentTitle] = useState('');
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().slice(0, 10));
  const [paymentSprintId, setPaymentSprintId] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'received' | 'invoiced' | 'expected'>('received');
  const [selectedAccountId, setSelectedAccountId] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');

  // Available money accounts
  const moneyAccounts = useMemo(() => {
    return getStoredMoneyState().accounts.filter((a) => !a.deleted);
  }, [isOpen]);

  // Financial summary
  const financials = useMemo(() => {
    return computeProjectFinancials(project);
  }, [project]);

  if (!isOpen) return null;

  const handleCreateSprint = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSprintName.trim()) return;

    const newSprint: ProjectSprint = {
      id: 'sp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      projectId: project.id,
      name: newSprintName.trim(),
      expectedIncome: Number(newSprintIncome) || 0,
      dueDate: newSprintDueDate || undefined,
      status: 'planned',
      paymentStatus: 'pending',
    };

    const updated: Project = {
      ...project,
      sprints: [...sprints, newSprint],
      // If contractValue was 0 or undefined, update contractValue to reflect sprints sum
      contractValue: Math.max(project.contractValue || 0, (project.contractValue || 0) + (Number(newSprintIncome) || 0)),
      updatedAt: new Date().toISOString(),
    };

    await onSaveProject(updated);
    setNewSprintName('');
    setNewSprintIncome(0);
    setNewSprintDueDate('');
    setShowAddSprint(false);
  };

  const handleUpdateSprintStatus = async (
    sprintId: string,
    status: ProjectSprint['status'],
    paymentStatus?: ProjectSprint['paymentStatus']
  ) => {
    const updatedSprints = sprints.map((s) => {
      if (s.id === sprintId) {
        return {
          ...s,
          status,
          paymentStatus: paymentStatus || s.paymentStatus,
        };
      }
      return s;
    });

    const updated: Project = {
      ...project,
      sprints: updatedSprints,
      updatedAt: new Date().toISOString(),
    };

    await onSaveProject(updated);
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentTitle.trim() || paymentAmount <= 0) return;

    const res = depositProjectPaymentToMoney(project, {
      title: paymentTitle.trim(),
      amount: Number(paymentAmount),
      currency: project.currency || 'USD',
      date: paymentDate,
      status: paymentStatus,
      sprintId: paymentSprintId || undefined,
      accountId: selectedAccountId || undefined,
      notes: paymentNotes.trim() || undefined,
    });

    await onSaveProject(res.updatedProject);
    setPaymentTitle('');
    setPaymentAmount(0);
    setPaymentNotes('');
    setActiveTab('payments');
  };

  const handleQuickReceiveSprint = (sprint: ProjectSprint) => {
    setPaymentSprintId(sprint.id);
    setPaymentTitle(`${sprint.name} Milestone Payout`);
    setPaymentAmount(sprint.expectedIncome);
    setPaymentStatus('received');
    if (moneyAccounts.length > 0 && !selectedAccountId) {
      setSelectedAccountId(moneyAccounts[0].id);
    }
    setActiveTab('new_payment');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="glass rounded-[2rem] border border-white/10 w-full max-w-2xl shadow-2xl overflow-hidden my-auto relative text-white flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 border-b border-white/[0.08] flex items-center justify-between bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div
              style={{ backgroundColor: `${project.color}25`, color: project.color, borderColor: `${project.color}50` }}
              className="w-11 h-11 rounded-2xl flex items-center justify-center border shadow-xs"
            >
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white tracking-tight">{project.name}</h2>
                {project.clientName && (
                  <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold font-mono">
                    Client: {project.clientName}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Sprints, deliverables &amp; direct money treasury reconciliation
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Financial KPI Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-5 border-b border-white/[0.06] bg-white/[0.01]">
          <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
            <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block mb-1">Contract Value</span>
            <div className="text-base sm:text-lg font-black text-white font-mono">
              {fmtMoney(financials.contractValue, project.currency)}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-500/[0.08] border border-emerald-500/20">
            <span className="text-[10px] text-emerald-400 font-mono uppercase tracking-wider block mb-1">Received (Paid)</span>
            <div className="text-base sm:text-lg font-black text-emerald-300 font-mono">
              {fmtMoney(financials.totalPaid, project.currency)}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-cyan-500/[0.08] border border-cyan-500/20">
            <span className="text-[10px] text-cyan-400 font-mono uppercase tracking-wider block mb-1">Pending Inflow</span>
            <div className="text-base sm:text-lg font-black text-cyan-300 font-mono">
              {fmtMoney(financials.totalPending, project.currency)}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-indigo-500/[0.08] border border-indigo-500/20">
            <span className="text-[10px] text-indigo-400 font-mono uppercase tracking-wider block mb-1">Collection Rate</span>
            <div className="text-base sm:text-lg font-black text-indigo-300 font-mono">
              {financials.collectionRate}%
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-white/[0.06]">
          <button
            onClick={() => setActiveTab('sprints')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              activeTab === 'sprints'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Sprints &amp; Milestones ({sprints.length})
          </button>
          <button
            onClick={() => setActiveTab('payments')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              activeTab === 'payments'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Payments History ({payments.length})
          </button>
          <button
            onClick={() => setActiveTab('new_payment')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              activeTab === 'new_payment'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            + Record Payment
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* TAB 1: Sprints & Milestones */}
          {activeTab === 'sprints' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Project Sprints &amp; Deliverables</h3>
                  <p className="text-[11px] text-slate-400">Attach expected incomes to phases and deposit to wallet upon completion</p>
                </div>
                <button
                  onClick={() => setShowAddSprint(!showAddSprint)}
                  className="px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{showAddSprint ? 'Cancel' : 'Add Sprint'}</span>
                </button>
              </div>

              {/* Add Sprint Inline Form */}
              {showAddSprint && (
                <form onSubmit={handleCreateSprint} className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3 animate-fadeIn">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <div className="sm:col-span-1">
                      <label className="block text-[10px] text-slate-400 font-mono mb-1">Sprint Name *</label>
                      <input
                        type="text"
                        required
                        value={newSprintName}
                        onChange={(e) => setNewSprintName(e.target.value)}
                        placeholder="e.g. Sprint 1: MVP Design"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 font-mono mb-1">Expected Income ($) *</label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        required
                        value={newSprintIncome || ''}
                        onChange={(e) => setNewSprintIncome(parseFloat(e.target.value) || 0)}
                        placeholder="e.g. 3500"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 font-mono mb-1">Target Due Date</label>
                      <input
                        type="date"
                        value={newSprintDueDate}
                        onChange={(e) => setNewSprintDueDate(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <button type="submit" className="btn-primary !px-4 !py-1.5 !text-xs !rounded-xl">
                      Save Sprint
                    </button>
                  </div>
                </form>
              )}

              {/* Sprints List */}
              {sprints.length === 0 ? (
                <div className="text-center py-10 border border-dashed border-white/10 rounded-2xl p-6">
                  <Layers className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p className="text-xs text-slate-400">No sprints defined for this project yet.</p>
                  <p className="text-[11px] text-slate-500 mt-1">Break your work into billable milestones to track cashflow.</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {sprints.map((sprint) => {
                    const isPaid = sprint.paymentStatus === 'paid';
                    return (
                      <div
                        key={sprint.id}
                        className={`p-4 rounded-2xl border transition-all ${
                          isPaid
                            ? 'border-emerald-500/30 bg-emerald-500/[0.04]'
                            : 'border-white/[0.08] bg-white/[0.02]'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-white">{sprint.name}</h4>
                              <span
                                className={`text-[10px] font-mono px-2 py-0.5 rounded-full uppercase font-bold ${
                                  isPaid
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                    : sprint.paymentStatus === 'invoiced'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                    : 'bg-white/5 text-slate-400 border border-white/10'
                                }`}
                              >
                                {sprint.paymentStatus}
                              </span>
                            </div>
                            <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                              <span className="font-mono text-cyan-300 font-bold">
                                {fmtMoney(sprint.expectedIncome, project.currency)}
                              </span>
                              {sprint.dueDate && (
                                <span className="flex items-center gap-1 font-mono text-[11px]">
                                  <Calendar className="w-3 h-3 text-slate-500" />
                                  <span>{sprint.dueDate}</span>
                                </span>
                              )}
                              {sprint.paidDate && (
                                <span className="text-emerald-400 font-mono text-[11px]">
                                  Paid on {sprint.paidDate}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Quick Actions */}
                          <div className="flex items-center gap-2">
                            {/* Sprint progress selector */}
                            <select
                              value={sprint.status}
                              onChange={(e) => handleUpdateSprintStatus(sprint.id, e.target.value as any)}
                              className="px-2 py-1 rounded-xl bg-slate-900 border border-white/10 text-[11px] text-slate-300 font-mono"
                            >
                              <option value="planned">Planned</option>
                              <option value="in_progress">In Progress</option>
                              <option value="completed">Completed</option>
                              <option value="delivered">Delivered</option>
                            </select>

                            {!isPaid && (
                              <button
                                type="button"
                                onClick={() => handleQuickReceiveSprint(sprint)}
                                className="px-3 py-1 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                              >
                                <DollarSign className="w-3.5 h-3.5" />
                                <span>Receive Payment</span>
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Payments History */}
          {activeTab === 'payments' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Payment Ledger</h3>
                  <p className="text-[11px] text-slate-400">All registered disbursements and receipts linked to the Treasury</p>
                </div>
                <button
                  onClick={() => setActiveTab('new_payment')}
                  className="px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Payment</span>
                </button>
              </div>

              {payments.length === 0 ? (
                <div className="text-center py-10 border border-dashed border-white/10 rounded-2xl p-6">
                  <Landmark className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p className="text-xs text-slate-400">No payments logged for this project yet.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {payments.map((p) => (
                    <div
                      key={p.id}
                      className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/[0.08] flex items-center justify-between"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-white">{p.title}</h4>
                          <span
                            className={`text-[9px] font-mono px-2 py-0.2 rounded-full uppercase font-bold ${
                              p.status === 'received'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : p.status === 'invoiced'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : 'bg-white/5 text-slate-400 border border-white/10'
                            }`}
                          >
                            {p.status}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                          Date: {p.date} {p.notes ? `• ${p.notes}` : ''}
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="text-sm font-black text-emerald-400 font-mono">
                          +{fmtMoney(p.amount, p.currency || project.currency)}
                        </span>
                        {p.transactionId && (
                          <span className="block text-[9px] text-cyan-400 font-mono">
                            Synced to Wallet
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: New Payment Form */}
          {activeTab === 'new_payment' && (
            <form onSubmit={handleRecordPayment} className="space-y-4 max-w-lg mx-auto p-4 rounded-2xl bg-white/[0.02] border border-white/10 animate-fadeIn">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Record Project Payment / Invoice</span>
              </h3>

              <div>
                <label className="block text-[10px] text-slate-400 font-mono mb-1">Payment Title *</label>
                <input
                  type="text"
                  required
                  value={paymentTitle}
                  onChange={(e) => setPaymentTitle(e.target.value)}
                  placeholder="e.g. Deposit Retainer, Sprint 1 Payout"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Amount ($) *</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={paymentAmount || ''}
                    onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                    placeholder="e.g. 5000"
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Payment Date *</label>
                  <input
                    type="date"
                    required
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Status</label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="received">Received (Deposited)</option>
                    <option value="invoiced">Invoiced (Awaiting)</option>
                    <option value="expected">Expected / Planned</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Linked Sprint</label>
                  <select
                    value={paymentSprintId}
                    onChange={(e) => setPaymentSprintId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="">None (General Project Payment)</option>
                    {sprints.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} (${s.expectedIncome})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {paymentStatus === 'received' && (
                <div className="p-3 rounded-xl bg-emerald-500/[0.08] border border-emerald-500/20 space-y-2">
                  <label className="block text-[10px] text-emerald-300 font-mono font-bold flex items-center gap-1.5">
                    <Landmark className="w-3.5 h-3.5" />
                    <span>Deposit into Wallet / Treasury Account:</span>
                  </label>
                  <select
                    value={selectedAccountId}
                    onChange={(e) => setSelectedAccountId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-400"
                  >
                    <option value="">Do not deposit to wallet account</option>
                    {moneyAccounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.name} ({fmtMoney(acc.balance, acc.currency)})
                      </option>
                    ))}
                  </select>
                  <p className="text-[10px] text-slate-400">
                    When selected, this directly deposits funds into your wallet balance and logs an income transaction in the Money Matrix.
                  </p>
                </div>
              )}

              <div>
                <label className="block text-[10px] text-slate-400 font-mono mb-1">Notes / Wire Reference</label>
                <input
                  type="text"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  placeholder="e.g. Wire transfer ref #84920"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('sprints')}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary !px-5 !py-2 !text-xs !rounded-xl"
                >
                  Record &amp; Sync Payment
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
