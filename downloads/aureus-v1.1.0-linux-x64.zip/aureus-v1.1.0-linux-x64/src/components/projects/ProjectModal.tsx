import React, { useState } from 'react';
import { Project, ProjectKind } from '../../types';
import { useApp } from '../../context/AppContext';
import { IconHelper } from '../common/IconHelper';
import { X, Check, Folder, Briefcase, User, DollarSign } from 'lucide-react';

const PROJECT_ICONS = ['folder', 'briefcase', 'user', 'heart', 'code', 'book', 'star', 'target'];

const PROJECT_COLORS = [
  '#3B82F6', // Blue
  '#10B981', // Emerald
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#F97316', // Orange
  '#06B6D4', // Cyan
  '#64748B', // Slate
  '#6366F1', // Indigo
];

export const ProjectModal: React.FC = () => {
  const {
    editingProject,
    setEditingProject,
    setIsProjectModalOpen,
    createProject,
    updateProject,
  } = useApp();

  const [name, setName] = useState(editingProject?.name || '');
  const [kind, setKind] = useState<ProjectKind>(editingProject?.kind || 'personal');
  const [clientName, setClientName] = useState(editingProject?.clientName || '');
  const [contractValue, setContractValue] = useState<number>(editingProject?.contractValue || 0);
  const [currency, setCurrency] = useState(editingProject?.currency || 'USD');
  const [color, setColor] = useState(editingProject?.color || '#3B82F6');
  const [icon, setIcon] = useState(editingProject?.icon || (editingProject?.kind === 'client' ? 'briefcase' : 'folder'));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const payload: Partial<Project> = {
      name: name.trim(),
      color,
      icon,
      kind,
      clientName: kind === 'client' ? clientName.trim() : undefined,
      contractValue: kind === 'client' && contractValue > 0 ? contractValue : undefined,
      currency,
    };

    if (editingProject) {
      await updateProject(editingProject.id, payload);
    } else {
      await createProject(payload);
    }

    handleClose();
  };

  const handleClose = () => {
    setEditingProject(null);
    setIsProjectModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-hidden animate-fadeIn">
      <div className="glass rounded-[2rem] border border-white/10 w-full max-w-xl sm:max-w-2xl shadow-2xl flex flex-col max-h-[90vh] sm:max-h-[85vh] my-auto relative text-white">
        {/* 1. STICKY HEADER */}
        <div className="shrink-0 p-5 sm:px-7 sm:py-5 border-b border-white/[0.08] flex items-center justify-between bg-white/[0.02]">
          <div className="flex items-center gap-3.5">
            <div
              style={{ backgroundColor: `${color}25`, color, borderColor: `${color}50` }}
              className="w-11 h-11 rounded-2xl flex items-center justify-center border shadow-sm shrink-0 transition-colors"
            >
              <IconHelper name={icon} className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-tight">
                {editingProject ? 'Edit Project' : 'New Project'}
              </h2>
              <p className="text-xs text-slate-400">Personal initiatives &amp; client contracts with cashflow tracking</p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 2. FORM & SCROLLABLE CONTENT BODY */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden">
          <div className="flex-1 min-h-0 overflow-y-auto p-5 sm:p-7 space-y-5">
            {/* Project Type: Personal vs Client */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Project Classification
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setKind('personal');
                    if (icon === 'briefcase') setIcon('folder');
                  }}
                  className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                    kind === 'personal'
                      ? 'border-indigo-500 bg-indigo-500/15 text-white shadow-brand-glow'
                      : 'border-white/10 bg-white/[0.02] text-slate-300 hover:text-white hover:bg-white/[0.05]'
                  }`}
                >
                  <div className={`p-2 rounded-xl ${kind === 'personal' ? 'bg-indigo-500/30 text-indigo-300' : 'bg-white/5 text-slate-300'}`}>
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">Personal Initiative</div>
                    <div className="text-[10px] text-slate-300">Goals, habits, self-directed</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setKind('client');
                    if (icon === 'folder') setIcon('briefcase');
                  }}
                  className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                    kind === 'client'
                      ? 'border-cyan-500 bg-cyan-500/15 text-white shadow-cyan-glow'
                      : 'border-white/10 bg-white/[0.02] text-slate-300 hover:text-white hover:bg-white/[0.05]'
                  }`}
                >
                  <div className={`p-2 rounded-xl ${kind === 'client' ? 'bg-cyan-500/30 text-cyan-300' : 'bg-white/5 text-slate-300'}`}>
                    <Briefcase className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">Client / Commercial</div>
                    <div className="text-[10px] text-slate-300">Contracts, sprints, income</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Project Name */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Project Title *
              </label>
              <input
                type="text"
                required
                autoFocus
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Mobile Engine, Apex Redesign, FinOps"
                className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 hover:border-white/20 text-white placeholder:text-zinc-400 text-sm font-semibold focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 transition-all"
              />
            </div>

            {/* Client Specific Fields */}
            {kind === 'client' && (
              <div className="p-4 rounded-2xl bg-cyan-500/[0.05] border border-cyan-500/20 space-y-4 animate-fadeIn">
                <div className="flex items-center gap-2 text-xs font-bold text-cyan-300 uppercase tracking-wider">
                  <DollarSign className="w-4 h-4 text-cyan-400" />
                  <span>Commercial Terms &amp; Expected Revenue</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">Client / Company Name *</label>
                    <input
                      type="text"
                      required={kind === 'client'}
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      placeholder="e.g. Acme Corp, Starlight Media"
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">Contract / Total Value</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-mono">$</span>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={contractValue || ''}
                        onChange={(e) => setContractValue(parseFloat(e.target.value) || 0)}
                        placeholder="e.g. 10000"
                        className="w-full pl-7 pr-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Billing Currency</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="CAD">CAD ($)</option>
                    <option value="AUD">AUD ($)</option>
                  </select>
                </div>
              </div>
            )}

            {/* Color Accent */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Color Accent
              </label>
              <div className="flex items-center gap-2.5 flex-wrap">
                {PROJECT_COLORS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    style={{ backgroundColor: c }}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-transform cursor-pointer ${
                      color === c ? 'ring-2 ring-white scale-110 shadow-lg' : 'opacity-70 hover:opacity-100'
                    }`}
                  >
                    {color === c && <Check className="w-4 h-4 text-white stroke-[3]" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Icon Symbol */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Icon Symbol
              </label>
              <div className="grid grid-cols-4 gap-2">
                {PROJECT_ICONS.map((ic) => (
                  <button
                    key={ic}
                    type="button"
                    onClick={() => setIcon(ic)}
                    className={`p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                      icon === ic
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-sm'
                        : 'bg-white/[0.03] border border-white/10 text-slate-300 hover:text-white hover:bg-white/[0.08] hover:border-white/20'
                    }`}
                  >
                    <IconHelper name={ic} className="w-5 h-5" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 3. STICKY FOOTER (ALWAYS VISIBLE - NEVER HIDDEN BEHIND SCROLL) */}
          <div className="shrink-0 px-6 py-4 border-t border-white/[0.08] bg-[#0c0f17]/95 backdrop-blur-md flex items-center justify-between">
            <div className="text-[11px] text-zinc-500 font-mono hidden sm:block">
              Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-semibold">Enter</kbd> to save
            </div>
            <div className="flex items-center gap-3 ml-auto">
              <button
                type="button"
                onClick={handleClose}
                className="px-5 py-2.5 rounded-xl text-xs font-semibold text-zinc-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary !px-6 !py-2.5 !text-xs !rounded-xl font-bold"
              >
                {editingProject ? 'Save Changes' : 'Create Project'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProjectModal;
