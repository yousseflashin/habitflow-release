import React, { useState } from 'react';
import { Project } from '../../types';
import { useApp } from '../../context/AppContext';
import { IconHelper } from '../common/IconHelper';
import { X, Check, Folder } from 'lucide-react';

const PROJECT_ICONS = ['folder', 'briefcase', 'user', 'heart', 'code', 'book', 'star', 'target'];

const PROJECT_COLORS = [
  '#3B82F6', // Blue
  '#10B981', // Emerald
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#F59E0B', // Amber
  '#F97316', // Orange
  '#06B6D4', // Cyan
  '#64748B', // Slate
];

export const ProjectModal: React.FC = () => {
  const {
    editingProject,
    setEditingProject,
    setIsProjectModalOpen,
    createProject,
    updateProject,
  } = useApp();

  const [name, setName] = useState(editingProject?.name || '');
  const [color, setColor] = useState(editingProject?.color || '#3B82F6');
  const [icon, setIcon] = useState(editingProject?.icon || 'folder');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingProject) {
      await updateProject(editingProject.id, {
        name: name.trim(),
        color,
        icon,
      });
    } else {
      await createProject({
        name: name.trim(),
        color,
        icon,
      });
    }

    handleClose();
  };

  const handleClose = () => {
    setEditingProject(null);
    setIsProjectModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="glass rounded-[2rem] border border-white/10 w-full max-w-md shadow-2xl overflow-hidden my-auto relative">
        <div className="p-6 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              style={{ backgroundColor: `${color}20`, color, borderColor: `${color}40` }}
              className="w-10 h-10 rounded-2xl flex items-center justify-center border shadow-glow-sm"
            >
              <IconHelper name={icon} className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-tight">
                {editingProject ? 'Edit Project' : 'New Project'}
              </h2>
              <p className="text-xs text-slate-400">Organize and group related tasks</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Project Name *
            </label>
            <input
              type="text"
              required
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Mobile Engine, Health, FinOps"
              className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Color Accent
            </label>
            <div className="flex items-center gap-2.5 flex-wrap">
              {PROJECT_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  style={{ backgroundColor: c }}
                  className={`w-8 h-8 rounded-full flex items-center justify-center transition-transform cursor-pointer ${
                    color === c ? 'ring-2 ring-white scale-110 shadow-lg' : 'opacity-70 hover:opacity-100'
                  }`}
                >
                  {color === c && <Check className="w-4 h-4 text-white stroke-[3]" />}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Icon Symbol
            </label>
            <div className="grid grid-cols-4 gap-2">
              {PROJECT_ICONS.map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setIcon(ic)}
                  className={`p-2.5 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                    icon === ic
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-glow-sm'
                      : 'bg-white/[0.02] border border-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  <IconHelper name={ic} className="w-5 h-5" />
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/5">
            <button
              type="button"
              onClick={handleClose}
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 shadow-glow-sm transition-all active:scale-95 cursor-pointer"
            >
              {editingProject ? 'Save Changes' : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
