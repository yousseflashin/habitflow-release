import React from 'react';
import { HabitDayCell } from '../../domain/habitService';

interface HabitGridProps {
  cells: HabitDayCell[];
  habitColor: string;
  cellSize?: number; // Size in px (default 14)
  gap?: number;
  showDaysOfWeek?: boolean;
  onCellClick?: (dateStr: string) => void;
  isQuit?: boolean;
}

export const HabitGrid: React.FC<HabitGridProps> = ({
  cells,
  habitColor,
  cellSize = 16,
  gap = 4,
  showDaysOfWeek = false,
  onCellClick,
  isQuit,
}) => {
  return (
    <div className="flex flex-wrap gap-1 items-center">
      {cells.map((cell) => {
        let bgStyle: React.CSSProperties = {};
        let borderClass = 'border-transparent';

        if (cell.isFuture) {
          bgStyle = { backgroundColor: 'transparent', opacity: 0.15 };
          borderClass = 'border-dashed border-slate-700/50';
        } else if (!cell.isInSchedule) {
          bgStyle = { backgroundColor: 'rgba(148, 163, 184, 0.08)' };
        } else if (cell.isRelapse) {
          // Slipped day for quit habits — always red, stands out from missed/clean
          bgStyle = { backgroundColor: '#EF4444', opacity: 0.85, boxShadow: '0 0 6px #EF444455' };
        } else if (cell.intensity === 0) {
          bgStyle = { backgroundColor: 'rgba(148, 163, 184, 0.12)' };
        } else {
          // Calculate opacity/color shade based on intensity 1..4
          const opacities = [0.25, 0.5, 0.75, 1.0];
          const alpha = opacities[cell.intensity - 1] || 1.0;
          bgStyle = {
            backgroundColor: habitColor,
            opacity: alpha,
            boxShadow: cell.completed ? `0 0 8px ${habitColor}66` : 'none',
          };
        }

        let statusLabel: string;
        if (cell.isRelapse) {
          statusLabel = 'Slipped';
        } else if (cell.completed) {
          statusLabel = cell.count > 0 ? `Completed (${cell.count}/${cell.target})` : 'Completed';
        } else if (cell.count > 0) {
          statusLabel = `${cell.count}/${cell.target}`;
        } else {
          statusLabel = 'Missed';
        }
        const tooltip = `${cell.date} • ${statusLabel}${cell.isToday ? ' (Today)' : ''}`;

        return (
          <button
            key={cell.date}
            type="button"
            title={tooltip}
            onClick={() => onCellClick && onCellClick(cell.date)}
            disabled={cell.isFuture}
            style={{
              width: `${cellSize}px`,
              height: `${cellSize}px`,
              borderRadius: cellSize > 18 ? '6px' : '4px',
              ...bgStyle,
            }}
            className={`transition-all duration-150 relative group cursor-pointer hover:scale-115 active:scale-95 border ${borderClass} ${
              cell.isToday ? 'ring-2 ring-white/60 dark:ring-white/80 ring-offset-1 ring-offset-slate-900' : ''
            }`}
          >
            {cell.isToday && cell.intensity === 0 && (
              <span className="absolute inset-0 m-auto w-1 h-1 rounded-full bg-slate-400" />
            )}
          </button>
        );
      })}
    </div>
  );
};
