import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { HabitCard } from './HabitCard';
import { HabitService } from '../../domain/habitService';
import { HabitCategory, HabitFrequencyType } from '../../types';
import { Flame, Plus, Trophy, Sparkles, Search, Shield, ArrowUpDown } from 'lucide-react';

export const HabitsView: React.FC = () => {
  const { habits, habitLogs, habitRelapses, setIsHabitModalOpen } = useApp();
  const [filterType, setFilterType] = useState<HabitFrequencyType | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState<HabitCategory | 'all'>('all');
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<'order' | 'streak' | 'consistency' | 'name'>('order');

  const filteredHabits = useMemo(() => {
    let result = habits;

    // Search filter
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (h) => h.name.toLowerCase().includes(q) || h.description?.toLowerCase().includes(q)
      );
    }

    // Category filter
    if (categoryFilter !== 'all') {
      result = result.filter((h) => h.category === categoryFilter);
    }

    // Frequency filter
    if (filterType !== 'all') {
      result = result.filter((h) => h.frequency.type === filterType);
    }

    // Sorting
    return [...result].sort((a, b) => {
      if (sortBy === 'streak') {
        const statsA = HabitService.calculateStats(a, habitLogs, habitRelapses);
        const statsB = HabitService.calculateStats(b, habitLogs, habitRelapses);
        return statsB.currentStreak - statsA.currentStreak;
      }
      if (sortBy === 'consistency') {
        const statsA = HabitService.calculateStats(a, habitLogs, habitRelapses);
        const statsB = HabitService.calculateStats(b, habitLogs, habitRelapses);
        return statsB.completionRate30Days - statsA.completionRate30Days;
      }
      if (sortBy === 'name') {
        return a.name.localeCompare(b.name);
      }
      return (a.order || 0) - (b.order || 0);
    });
  }, [habits, habitLogs, habitRelapses, filterType, categoryFilter, search, sortBy]);

  // Aggregate Habit statistics
  const summary = useMemo(() => {
    let longestStreak = 0;
    let sumConsistency = 0;
    let quitCount = 0;
    let gainCount = 0;

    for (const h of habits) {
      if (h.category === 'quit') quitCount++;
      else gainCount++;

      const stats = HabitService.calculateStats(h, habitLogs, habitRelapses);
      if (stats.currentStreak > longestStreak) longestStreak = stats.currentStreak;
      sumConsistency += stats.completionRate30Days;
    }

    const avgConsistency = habits.length > 0 ? Math.round(sumConsistency / habits.length) : 0;

    return {
      total: habits.length,
      gainCount,
      quitCount,
      longestStreak,
      avgConsistency,
    };
  }, [habits, habitLogs, habitRelapses]);

  return (
    <div className="space-y-6 pb-16 max-w-5xl mx-auto select-none">
      {/* Header with Executive Metrics Banner */}
      <div className="glass rounded-[2rem] p-6 sm:p-7 border border-white/[0.08] shadow-brand-lg flex flex-col md:flex-row md:items-center justify-between gap-5 relative overflow-hidden stagger-1">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/[0.05] rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-1">
          <div className="inline-flex items-center gap-1.5 badge-brand mb-1">
            <Flame className="w-3 h-3 text-cyan-400" />
            <span>Discipline Registry &amp; Streaks</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">Habit Architecture</h1>
          <p className="text-xs text-zinc-400">
            Precision habit compounding with dual-mode tracking: positive build &amp; harmful cessation.
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-3 flex-wrap sm:flex-nowrap">
          <div className="px-3.5 py-2 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center gap-2.5">
            <Trophy className="w-4 h-4 text-cyan-400" />
            <div>
              <div className="text-[10px] uppercase font-bold text-zinc-500">Longest Streak</div>
              <div className="text-sm font-black text-white tabular-nums font-mono">{summary.longestStreak} days</div>
            </div>
          </div>

          <div className="px-3.5 py-2 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-[10px] uppercase font-bold text-zinc-500">Consistency</div>
              <div className="text-sm font-black text-white tabular-nums font-mono">{summary.avgConsistency}%</div>
            </div>
          </div>

          <button
            onClick={() => setIsHabitModalOpen(true)}
            className="btn-primary px-4 py-2 text-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Habit</span>
          </button>
        </div>
      </div>

      {/* Toolbar: Search, Category Chips, Frequency Tabs, and Sort */}
      <div className="glass rounded-2xl p-3 sm:p-4 space-y-3 border border-white/[0.07] shadow-brand-md stagger-2">
        <div className="flex flex-col sm:flex-row items-center gap-2.5">
          {/* Search bar */}
          <div className="relative flex-1 w-full">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search habits by title or core motivation..."
              className="w-full pl-9 pr-4 py-2 bg-white/[0.03] border border-white/[0.08] rounded-xl text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-cyan-400/40"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
            {[
              { id: 'all', label: `All (${habits.length})` },
              { id: 'gain', label: `Build (${summary.gainCount})`, icon: Flame },
              { id: 'quit', label: `Quit (${summary.quitCount})`, icon: Shield },
            ].map((cat) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.id}
                  onClick={() => setCategoryFilter(cat.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                    categoryFilter === cat.id
                      ? 'bg-white/[0.1] text-white border border-white/[0.14] shadow-brand-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {Icon && <Icon className="w-3 h-3" />}
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* Sort By Select */}
          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <ArrowUpDown className="w-3.5 h-3.5 text-zinc-500 hidden sm:block" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full sm:w-auto px-3 py-2 bg-[#0E1118] border border-white/[0.08] rounded-xl text-xs text-zinc-300 focus:outline-none focus:border-cyan-400/40 cursor-pointer"
            >
              <option value="order">Default Order</option>
              <option value="streak">Longest Streak</option>
              <option value="consistency">Highest Consistency</option>
              <option value="name">Alphabetical</option>
            </select>
          </div>
        </div>

        {/* Frequency Sub-tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-2 border-t border-white/[0.06]">
          {[
            { id: 'all', label: 'All Cadences' },
            { id: 'daily', label: 'Daily' },
            { id: 'weekdays', label: 'Weekdays' },
            { id: 'times_per_week', label: 'Times / Week' },
            { id: 'custom_days', label: 'Custom Days' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id as any)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer ${
                filterType === tab.id
                  ? 'bg-white/[0.08] text-white font-bold'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Habits Grid */}
      {filteredHabits.length === 0 ? (
        <div className="text-center py-12 rounded-3xl border border-dashed border-white/10 bg-white/[0.01] p-8">
          <Flame className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-white">No habits registered</h3>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto mt-1 mb-4">
            {search
              ? 'No habits match your active search terms.'
              : 'Compound your discipline day after day. Launch your first habit below.'}
          </p>
          <button
            onClick={() => setIsHabitModalOpen(true)}
            className="btn-primary px-4 py-2 text-xs font-bold"
          >
            Create Habit
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 stagger-3">
          {filteredHabits.map((habit) => (
            <HabitCard key={habit.id} habit={habit} gridDaysCount={30} />
          ))}
        </div>
      )}
    </div>
  );
};

export default HabitsView;
