// Aureus Habit Card — Consistency Engine, Heatmap & Streak Tracker

import React, { useMemo } from 'react';
import { Habit } from '../../types';
import { useApp } from '../../context/AppContext';
import { HabitService } from '../../domain/habitService';
import { IconHelper } from '../common/IconHelper';
import { HabitGrid } from './HabitGrid';
import {
  Flame,
  Shield,
  Plus,
  Minus,
  Check,
  Edit2,
  Trash2,
  AlertTriangle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { format } from 'date-fns';

interface HabitCardProps {
  habit: Habit;
  gridDaysCount?: number;
}

export const HabitCard: React.FC<HabitCardProps> = ({ habit, gridDaysCount = 14 }) => {
  const {
    habitLogs,
    habitRelapses,
    toggleHabitDay,
    incrementHabitDay,
    decrementHabitDay,
    recordHabitRelapse,
    clearHabitRelapse,
    setViewingHabitDetail,
    setEditingHabit,
    setIsHabitModalOpen,
  } = useApp();

  const todayStr = useMemo(() => format(new Date(), 'yyyy-MM-dd'), []);
  const todayLog = habitLogs.get(`${habit.id}_${todayStr}`);
  const todayCount = todayLog && !todayLog.deleted ? todayLog.count : 0;
  const isCompletedToday = todayLog && !todayLog.deleted ? todayLog.completed : false;
  const isQuit = habit.category === 'quit';

  // Check if relapse today (Quit habits)
  const isRelapsedToday = useMemo(() => {
    return Array.from(habitRelapses.values()).some(
      (r) => r.habitId === habit.id && r.date === todayStr && !r.deleted
    );
  }, [habitRelapses, habit.id, todayStr]);

  const stats = useMemo(() => {
    return HabitService.calculateStats(habit, habitLogs, habitRelapses);
  }, [habit, habitLogs, habitRelapses]);

  const gridCells = useMemo(() => {
    return HabitService.generateGridCells(habit, habitLogs, habitRelapses, gridDaysCount);
  }, [habit, habitLogs, habitRelapses, gridDaysCount]);

  const frequencyLabel = useMemo(() => {
    if (isQuit) return 'Abstinence & recovery protocol';
    switch (habit.frequency.type) {
      case 'daily':
        return 'Daily rhythm';
      case 'weekdays':
        return 'Weekdays (Mon-Fri)';
      case 'times_per_week':
        return `${habit.frequency.targetDaysPerWeek || 3}x weekly cadence`;
      case 'custom_days': {
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        return (habit.frequency.customDays || []).map((d) => dayNames[d]).join(', ');
      }
      default:
        return 'Daily';
    }
  }, [habit.frequency, isQuit]);

  const isMultiStep = !isQuit && (habit.targetCount || 1) > 1;

  const accentRing = isQuit && isRelapsedToday
    ? 'ring-1 ring-rose-500/40 bg-[#140b0e]'
    : isCompletedToday
    ? 'ring-1 ring-amber-400/30'
    : '';

  return (
    <div
      className={`rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] hover:border-white/20 p-5 flex flex-col justify-between group relative transition-all duration-200 shadow-2xl ${accentRing}`}
    >
      <div>
        {/* Category Badge for Quit habits */}
        {isQuit && (
          <div className="absolute top-4 right-4 px-2.5 py-0.5 rounded-full bg-rose-500/15 text-rose-300 text-[10px] font-bold uppercase tracking-wider border border-rose-500/30">
            QUIT PROTOCOL
          </div>
        )}

        {/* Top Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div
            className="flex items-center gap-3.5 cursor-pointer flex-1 min-w-0"
            onClick={() => setViewingHabitDetail(habit)}
          >
            <div
              style={{
                backgroundColor: `${habit.color}20`,
                color: habit.color,
                borderColor: `${habit.color}40`,
              }}
              className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border transition-transform group-hover:scale-105"
            >
              <IconHelper name={habit.icon} className="w-6 h-6" />
            </div>

            <div className="min-w-0 flex-1">
              <h3 className="text-base font-bold text-white truncate group-hover:text-amber-300 transition-colors">
                {habit.name}
              </h3>
              <p className="text-xs text-slate-400 truncate mt-0.5 font-normal">
                {frequencyLabel}
              </p>
            </div>
          </div>

          {!isQuit && stats.currentStreak > 0 && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-400/10 text-amber-300 border border-amber-400/25 shrink-0">
              <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>{stats.currentStreak}d</span>
            </div>
          )}

          {isQuit && stats.currentStreak > 0 && !isRelapsedToday && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 shrink-0">
              <Shield className="w-3.5 h-3.5" />
              <span>{stats.currentStreak}d clean</span>
            </div>
          )}

          <button
            onClick={() => {
              setEditingHabit(habit);
              setIsHabitModalOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
            title="Edit habit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
        </div>

        {/* Habit Grid / Heatmap */}
        <div className="my-3 py-1">
          <HabitGrid
            cells={gridCells}
            habitColor={habit.color}
            cellSize={gridDaysCount > 14 ? 14 : 18}
            onCellClick={(dateStr) => {
              if (!isQuit) {
                toggleHabitDay(habit.id, dateStr);
              } else {
                const relapsedOnDate = Array.from(habitRelapses.values()).some(
                  (r) => r.habitId === habit.id && r.date === dateStr && !r.deleted
                );
                if (relapsedOnDate) {
                  clearHabitRelapse(habit.id, dateStr);
                } else {
                  recordHabitRelapse(habit.id, undefined, `Slipped on ${dateStr}`);
                }
              }
            }}
            isQuit={isQuit}
          />
        </div>
      </div>

      {/* Card Footer: Today Progress & Quick Actions */}
      <div className="pt-3 mt-2 border-t border-white/[0.06] flex items-center justify-between gap-2 flex-wrap">
        <div className="text-xs font-medium text-slate-400 font-mono">
          {isQuit
            ? isRelapsedToday
              ? '⚠ Relapsed today'
              : `${stats.currentStreak}d streak · ${stats.relapseCount || 0} slips${
                  habit.quitDetails?.costPerDay
                    ? ` · $${stats.totalCompletions * habit.quitDetails.costPerDay} saved`
                    : ''
                }`
            : `${stats.completionRate30Days}% 30d consistency`}
        </div>

        <div>
          {isQuit ? (
            <div className="flex items-center gap-2">
              {!isRelapsedToday && (
                <button
                  onClick={() => {
                    if (confirm('Record a relapse event?')) {
                      const trigger = prompt('What was the context or trigger? (optional)') || undefined;
                      recordHabitRelapse(habit.id, trigger);
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold border border-rose-500/30 text-rose-300 hover:bg-rose-500/10 flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Log Slip</span>
                </button>
              )}
              <div className="px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/25">
                {stats.currentStreak === 0 ? 'Restart today' : '✓ Clean today'}
              </div>
            </div>
          ) : isMultiStep ? (
            <div className="flex items-center gap-1 bg-white/[0.04] p-1 rounded-xl border border-white/10">
              <button
                onClick={() => decrementHabitDay(habit.id, todayStr)}
                disabled={todayCount === 0}
                className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/10 disabled:opacity-30 transition-all cursor-pointer"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>

              <span className="text-xs font-bold px-2 text-white min-w-[40px] text-center font-mono">
                {todayCount}/{habit.targetCount}
              </span>

              <button
                onClick={() => incrementHabitDay(habit.id, todayStr)}
                style={{
                  backgroundColor: isCompletedToday ? habit.color : undefined,
                  color: isCompletedToday ? '#07080B' : undefined,
                }}
                className={`w-7 h-7 flex items-center justify-center rounded-lg transition-all cursor-pointer ${
                  isCompletedToday ? 'shadow-glow-sm font-bold' : 'text-slate-300 hover:bg-white/10'
                }`}
              >
                {isCompletedToday ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : <Plus className="w-3.5 h-3.5" />}
              </button>
            </div>
          ) : (
            <button
              onClick={() => toggleHabitDay(habit.id, todayStr)}
              style={{
                backgroundColor: isCompletedToday ? habit.color : 'transparent',
                borderColor: isCompletedToday ? habit.color : `${habit.color}50`,
                color: isCompletedToday ? '#07080B' : habit.color,
              }}
              className="px-4 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition-all duration-200 active:scale-95 cursor-pointer shadow-xs"
            >
              <Check className={`w-3.5 h-3.5 ${isCompletedToday ? 'stroke-[3]' : ''}`} />
              <span>{isCompletedToday ? 'Done' : 'Complete'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Reminder count indicator */}
      {habit.reminders && habit.reminders.filter((r) => r.enabled).length > 0 && (
        <div className="absolute top-4 left-16 flex items-center gap-1 text-[10px] text-slate-400 font-mono">
          <Clock className="w-2.5 h-2.5" />
          <span>{habit.reminders.filter((r) => r.enabled).length}</span>
        </div>
      )}
    </div>
  );
};

export default HabitCard;