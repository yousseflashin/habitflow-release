import React, { useState, useEffect } from 'react';
import { Habit, HabitFrequencyType, HabitCategory, Reminder } from '../../types';
import { useApp } from '../../context/AppContext';
import { IconHelper } from '../common/IconHelper';
import { X, Check, Plus, Trash2, DollarSign, Shield, Flame, Sparkles } from 'lucide-react';
import { format } from 'date-fns';

const AVAILABLE_ICONS = [
  'flame',
  'droplet',
  'book',
  'dumbbell',
  'code',
  'moon',
  'heart',
  'coffee',
  'smile',
  'target',
  'sparkles',
  'zap',
  'sun',
  'shield',
  'briefcase',
  'layers',
];

const AVAILABLE_COLORS = [
  { name: 'Emerald', hex: '#10B981' },
  { name: 'Cyan', hex: '#06B6D4' },
  { name: 'Blue', hex: '#3B82F6' },
  { name: 'Violet', hex: '#8B5CF6' },
  { name: 'Pink', hex: '#EC4899' },
  { name: 'Coral', hex: '#F97316' },
  { name: 'Amber', hex: '#F59E0B' },
  { name: 'Red', hex: '#EF4444' },
];

export const HabitFormModal: React.FC = () => {
  const { editingHabit, setEditingHabit, setIsHabitModalOpen, createHabit, updateHabit } = useApp();

  const [name, setName] = useState(editingHabit?.name || '');
  const [description, setDescription] = useState(editingHabit?.description || '');
  const [icon, setIcon] = useState(editingHabit?.icon || 'flame');
  const [color, setColor] = useState(editingHabit?.color || '#10B981');
  const [category, setCategory] = useState<HabitCategory>(editingHabit?.category || 'gain');
  const [costPerDay, setCostPerDay] = useState<string>(
    editingHabit?.quitDetails?.costPerDay !== undefined ? String(editingHabit.quitDetails.costPerDay) : ''
  );
  const [freqType, setFreqType] = useState<HabitFrequencyType>(editingHabit?.frequency.type || 'daily');
  const [targetDaysPerWeek, setTargetDaysPerWeek] = useState(editingHabit?.frequency.targetDaysPerWeek || 3);
  const [customDays, setCustomDays] = useState<number[]>(editingHabit?.frequency.customDays || [1, 2, 3, 4, 5]);
  const [targetCount, setTargetCount] = useState(editingHabit?.targetCount || 1);
  const [targetUnit, setTargetUnit] = useState(editingHabit?.targetUnit || 'times');
  const [reminders, setReminders] = useState<Reminder[]>(editingHabit?.reminders || []);
  const [startDate, setStartDate] = useState(editingHabit?.startDate || format(new Date(), 'yyyy-MM-dd'));

  // Auto-switch icon/color defaults when toggling category if creating new
  useEffect(() => {
    if (editingHabit) return;
    if (category === 'quit') {
      setIcon('shield');
      setColor('#EF4444');
    } else {
      setIcon('flame');
      setColor('#10B981');
    }
  }, [category, editingHabit]);

  const toggleCustomDay = (dayIndex: number) => {
    if (customDays.includes(dayIndex)) {
      if (customDays.length > 1) {
        setCustomDays(customDays.filter((d) => d !== dayIndex));
      }
    } else {
      setCustomDays([...customDays, dayIndex].sort());
    }
  };

  const addReminder = () => {
    const newReminder: Reminder = {
      id: 'rem_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      time: '09:00',
      enabled: true,
      label: '',
    };
    setReminders([...reminders, newReminder]);
  };

  const updateReminder = (index: number, updates: Partial<Reminder>) => {
    const next = [...reminders];
    next[index] = { ...next[index], ...updates };
    setReminders(next);
  };

  const removeReminder = (index: number) => {
    setReminders(reminders.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const parsedCost = costPerDay.trim() ? parseFloat(costPerDay) : undefined;

    const payload: Partial<Habit> = {
      name: name.trim(),
      description: description.trim(),
      icon,
      color,
      category,
      quitDetails:
        category === 'quit'
          ? {
              ...editingHabit?.quitDetails,
              costPerDay: !isNaN(parsedCost as number) ? parsedCost : undefined,
            }
          : undefined,
      frequency: {
        type: freqType,
        targetDaysPerWeek: freqType === 'times_per_week' ? targetDaysPerWeek : undefined,
        customDays: freqType === 'custom_days' ? customDays : undefined,
      },
      targetCount: Math.max(1, Number(targetCount) || 1),
      targetUnit: targetUnit.trim() || (category === 'quit' ? 'days' : 'times'),
      reminders,
      startDate,
    };

    if (editingHabit) {
      await updateHabit(editingHabit.id, payload);
    } else {
      await createHabit(payload);
    }

    handleClose();
  };

  const handleClose = () => {
    setEditingHabit(null);
    setIsHabitModalOpen(false);
  };

  const dayNames = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="glass rounded-[2rem] border border-white/10 w-full max-w-lg shadow-2xl overflow-hidden my-auto relative">
        {/* Modal Header */}
        <div className="p-6 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div
              style={{ backgroundColor: `${color}20`, color, borderColor: `${color}40` }}
              className="w-11 h-11 rounded-2xl flex items-center justify-center border shadow-glow-sm"
            >
              <IconHelper name={icon} className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-tight">
                {editingHabit ? 'Edit Habit' : 'Create New Habit'}
              </h2>
              <p className="text-xs text-slate-400">Configure cadence, rewards, and milestones</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Category Switcher */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Habit Objective
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-white/[0.03] border border-white/5">
              <button
                type="button"
                onClick={() => setCategory('gain')}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  category === 'gain'
                    ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 shadow-glow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>Build Habit (Gain)</span>
              </button>
              <button
                type="button"
                onClick={() => setCategory('quit')}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  category === 'quit'
                    ? 'bg-gradient-to-r from-rose-500 to-red-600 text-white shadow-glow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Quit Habit (Sober / Clean)</span>
              </button>
            </div>
          </div>

          {/* Name */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Habit Name *
            </label>
            <input
              type="text"
              required
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={category === 'gain' ? 'e.g. Morning 20m Meditation' : 'e.g. Quit Vaping / Smoking'}
              className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>

          {/* Quit Habit Cost Tracker */}
          {category === 'quit' && (
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Estimated Daily Cost Saved ($)</span>
                </label>
                <span className="text-[10px] text-slate-500">Optional financial tracker</span>
              </div>
              <input
                type="number"
                step="0.5"
                min="0"
                value={costPerDay}
                onChange={(e) => setCostPerDay(e.target.value)}
                placeholder="e.g. 15.00 for pack of cigarettes or takeout"
                className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
              <p className="text-[11px] text-slate-400">
                Aureus will calculate your cumulative money saved in real-time on your clean streak cards.
              </p>
            </div>
          )}

          {/* Description */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Motivation / Core Why
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Boost focus, discipline, and physical longevity"
              className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>

          {/* Icon Picker */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Icon Symbol
            </label>
            <div className="grid grid-cols-8 gap-2">
              {AVAILABLE_ICONS.map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setIcon(ic)}
                  className={`p-2 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                    icon === ic
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-glow-sm scale-105'
                      : 'bg-white/[0.03] text-slate-400 hover:text-white border border-white/5'
                  }`}
                >
                  <IconHelper name={ic} className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>

          {/* Color Palette */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Atmospheric Color
            </label>
            <div className="flex items-center gap-2.5 overflow-x-auto py-1">
              {AVAILABLE_COLORS.map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  onClick={() => setColor(c.hex)}
                  style={{ backgroundColor: c.hex }}
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-transform cursor-pointer ${
                    color === c.hex ? 'ring-2 ring-white scale-110 shadow-lg' : 'opacity-70 hover:opacity-100'
                  }`}
                >
                  {color === c.hex && <Check className="w-4 h-4 text-white stroke-[3]" />}
                </button>
              ))}
            </div>
          </div>

          {/* Schedule Frequency */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Frequency Cadence
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'daily', label: 'Every Day' },
                { id: 'weekdays', label: 'Weekdays' },
                { id: 'times_per_week', label: 'X / Week' },
                { id: 'custom_days', label: 'Custom' },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFreqType(f.id as HabitFrequencyType)}
                  className={`py-2 px-2.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    freqType === f.id
                      ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 border-transparent shadow-glow-sm'
                      : 'bg-white/[0.03] text-slate-400 border-white/5 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {freqType === 'times_per_week' && (
              <div className="mt-3 flex items-center gap-2">
                <span className="text-xs text-slate-400">Target:</span>
                <input
                  type="number"
                  min="1"
                  max="7"
                  value={targetDaysPerWeek}
                  onChange={(e) => setTargetDaysPerWeek(Number(e.target.value))}
                  className="w-16 px-2 py-1 rounded-lg bg-white/[0.04] border border-white/10 text-sm font-bold text-center text-white"
                />
                <span className="text-xs text-slate-400">days per week</span>
              </div>
            )}

            {freqType === 'custom_days' && (
              <div className="mt-3 flex items-center justify-between gap-1">
                {dayNames.map((name, idx) => {
                  const isSelected = customDays.includes(idx);
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => toggleCustomDay(idx)}
                      className={`w-9 h-9 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-500 text-slate-950 shadow-glow-sm'
                          : 'bg-white/[0.03] text-slate-400 border border-white/5 hover:text-white'
                      }`}
                    >
                      {name}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Target Count & Unit */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Target Quantity
              </label>
              <input
                type="number"
                min="1"
                value={targetCount}
                onChange={(e) => setTargetCount(Math.max(1, Number(e.target.value)))}
                className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Target Unit
              </label>
              <input
                type="text"
                value={targetUnit}
                onChange={(e) => setTargetUnit(e.target.value)}
                placeholder="times, mins, pages, glasses"
                className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
            </div>
          </div>

          {/* Reminders */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Scheduled Reminders
            </label>
            <div className="space-y-2">
              {reminders.map((reminder, index) => (
                <div key={reminder.id} className="flex items-center gap-2">
                  <input
                    type="time"
                    value={reminder.time}
                    onChange={(e) => updateReminder(index, { time: e.target.value })}
                    className="px-3 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                  <input
                    type="text"
                    value={reminder.label || ''}
                    onChange={(e) => updateReminder(index, { label: e.target.value })}
                    placeholder="Reminder label (optional)"
                    className="flex-1 px-3 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                  <button
                    type="button"
                    onClick={() => removeReminder(index)}
                    className="p-2 rounded-xl text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={addReminder}
              className="mt-2.5 flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/[0.03] hover:bg-white/[0.07] border border-white/5 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Reminder Time</span>
            </button>
          </div>

          {/* Start Date */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Tracking Inception Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>

          {/* Modal Actions */}
          <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/5">
            <button
              type="button"
              onClick={handleClose}
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 shadow-glow-sm transition-all active:scale-95 cursor-pointer"
            >
              {editingHabit ? 'Update Habit' : 'Confirm & Launch Habit'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
