import React, { useState, useEffect } from 'react';
import { Habit, HabitFrequencyType, HabitCategory, Reminder } from '../../types';
import { useApp } from '../../context/AppContext';
import { IconHelper } from '../common/IconHelper';
import { X, Check, Plus, Trash2, DollarSign, Shield, Flame, Sparkles, Clock, Calendar } from 'lucide-react';
import { format } from 'date-fns';

const AVAILABLE_ICONS = [
  'flame',
  'droplet',
  'book',
  'dumbbell',
  'code',
  'moon',
  'heart',
  'coffee',
  'smile',
  'target',
  'sparkles',
  'zap',
  'sun',
  'shield',
  'briefcase',
  'layers',
];

const AVAILABLE_COLORS = [
  { name: 'Emerald', hex: '#10B981' },
  { name: 'Cyan', hex: '#06B6D4' },
  { name: 'Blue', hex: '#3B82F6' },
  { name: 'Indigo', hex: '#6366F1' },
  { name: 'Violet', hex: '#8B5CF6' },
  { name: 'Pink', hex: '#EC4899' },
  { name: 'Orange', hex: '#F97316' },
  { name: 'Red', hex: '#EF4444' },
];

export const HabitFormModal: React.FC = () => {
  const { editingHabit, setEditingHabit, setIsHabitModalOpen, createHabit, updateHabit } = useApp();

  const [name, setName] = useState(editingHabit?.name || '');
  const [description, setDescription] = useState(editingHabit?.description || '');
  const [icon, setIcon] = useState(editingHabit?.icon || 'flame');
  const [color, setColor] = useState(editingHabit?.color || '#10B981');
  const [category, setCategory] = useState<HabitCategory>(editingHabit?.category || 'gain');
  const [costPerDay, setCostPerDay] = useState<string>(
    editingHabit?.quitDetails?.costPerDay !== undefined ? String(editingHabit.quitDetails.costPerDay) : ''
  );
  const [freqType, setFreqType] = useState<HabitFrequencyType>(editingHabit?.frequency.type || 'daily');
  const [targetDaysPerWeek, setTargetDaysPerWeek] = useState(editingHabit?.frequency.targetDaysPerWeek || 3);
  const [customDays, setCustomDays] = useState<number[]>(editingHabit?.frequency.customDays || [1, 2, 3, 4, 5]);
  const [targetCount, setTargetCount] = useState(editingHabit?.targetCount || 1);
  const [targetUnit, setTargetUnit] = useState(editingHabit?.targetUnit || 'times');
  const [reminders, setReminders] = useState<Reminder[]>(editingHabit?.reminders || []);
  const [startDate, setStartDate] = useState(editingHabit?.startDate || format(new Date(), 'yyyy-MM-dd'));

  // Auto-switch icon/color defaults when toggling category if creating new
  useEffect(() => {
    if (editingHabit) return;
    if (category === 'quit') {
      setIcon('shield');
      setColor('#EF4444');
    } else {
      setIcon('flame');
      setColor('#10B981');
    }
  }, [category, editingHabit]);

  const toggleCustomDay = (dayIndex: number) => {
    if (customDays.includes(dayIndex)) {
      if (customDays.length > 1) {
        setCustomDays(customDays.filter((d) => d !== dayIndex));
      }
    } else {
      setCustomDays([...customDays, dayIndex].sort());
    }
  };

  const addReminder = () => {
    const newReminder: Reminder = {
      id: 'rem_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      time: '09:00',
      enabled: true,
      label: '',
    };
    setReminders([...reminders, newReminder]);
  };

  const updateReminder = (index: number, updates: Partial<Reminder>) => {
    const next = [...reminders];
    next[index] = { ...next[index], ...updates };
    setReminders(next);
  };

  const removeReminder = (index: number) => {
    setReminders(reminders.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const parsedCost = costPerDay.trim() ? parseFloat(costPerDay) : undefined;

    const payload: Partial<Habit> = {
      name: name.trim(),
      description: description.trim(),
      icon,
      color,
      category,
      quitDetails:
        category === 'quit'
          ? {
              ...editingHabit?.quitDetails,
              costPerDay: !isNaN(parsedCost as number) ? parsedCost : undefined,
            }
          : undefined,
      frequency: {
        type: freqType,
        targetDaysPerWeek: freqType === 'times_per_week' ? targetDaysPerWeek : undefined,
        customDays: freqType === 'custom_days' ? customDays : undefined,
      },
      targetCount: Math.max(1, Number(targetCount) || 1),
      targetUnit: targetUnit.trim() || (category === 'quit' ? 'days' : 'times'),
      reminders,
      startDate,
    };

    if (editingHabit) {
      await updateHabit(editingHabit.id, payload);
    } else {
      await createHabit(payload);
    }

    handleClose();
  };

  const handleClose = () => {
    setEditingHabit(null);
    setIsHabitModalOpen(false);
  };

  const dayNames = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-hidden animate-fadeIn">
      <div className="glass rounded-[2rem] border border-white/10 w-full max-w-2xl sm:max-w-3xl shadow-2xl flex flex-col max-h-[90vh] sm:max-h-[85vh] my-auto relative text-white">
        {/* 1. STICKY HEADER */}
        <div className="shrink-0 p-5 sm:px-7 sm:py-5 border-b border-white/[0.08] flex items-center justify-between bg-white/[0.02]">
          <div className="flex items-center gap-3.5">
            <div
              style={{ backgroundColor: `${color}25`, color, borderColor: `${color}50` }}
              className="w-11 h-11 rounded-2xl flex items-center justify-center border shadow-xs transition-colors shrink-0"
            >
              <IconHelper name={icon} className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-tight">
                {editingHabit ? 'Edit Habit' : 'Create New Habit'}
              </h2>
              <p className="text-xs text-slate-400">Configure frequency, tracking unit &amp; milestones</p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 2. FORM & SCROLLABLE CONTENT BODY */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden">
          <div className="flex-1 min-h-0 overflow-y-auto p-5 sm:p-7 space-y-5">
            {/* Objective Switcher */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Habit Intent
              </label>
              <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-white/[0.03] border border-white/5">
                <button
                  type="button"
                  onClick={() => setCategory('gain')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    category === 'gain'
                      ? 'bg-emerald-500 text-slate-950 font-black shadow-emerald-glow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Flame className="w-4 h-4" />
                  <span>Build a Habit (Positive)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCategory('quit')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    category === 'quit'
                      ? 'bg-rose-500 text-white font-black shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  <span>Break a Habit (Quit / Clean)</span>
                </button>
              </div>
            </div>

            {/* Habit Name */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Habit Title *
              </label>
              <input
                type="text"
                required
                autoFocus
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={category === 'gain' ? 'e.g. Morning 20m Focused Meditation' : 'e.g. Quit Nicotine & Smoking'}
                className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 hover:border-white/20 text-white placeholder:text-zinc-400 text-sm font-semibold focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 transition-all"
              />
            </div>

            {/* Motivation (Optional) */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Motivation &amp; Purpose (Optional)
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. Boost cognitive stamina, cardiovascular longevity, and calm"
                className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 hover:border-white/20 text-white placeholder:text-zinc-400 text-xs focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 transition-all"
              />
            </div>

            {/* Quit Financial Tracker */}
            {category === 'quit' && (
              <div className="p-4 rounded-2xl bg-rose-500/[0.05] border border-rose-500/20 space-y-2 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-rose-300 uppercase tracking-wider flex items-center gap-1.5">
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                    <span>Estimated Daily Money Saved ($)</span>
                  </label>
                  <span className="text-[10px] text-slate-400">Auto-calculated in Treasury</span>
                </div>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  value={costPerDay}
                  onChange={(e) => setCostPerDay(e.target.value)}
                  placeholder="e.g. 15.00"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-rose-400"
                />
              </div>
            )}

            {/* Two-Column Grid: Left: Visual Identity (Icon/Color), Right: Frequency & Goals */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
              {/* Left Column: Icon & Color Identity */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.08] space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                    Icon Symbol
                  </label>
                  <div className="grid grid-cols-8 gap-1.5">
                    {AVAILABLE_ICONS.map((ic) => (
                      <button
                        key={ic}
                        type="button"
                        onClick={() => setIcon(ic)}
                        className={`p-2 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                          icon === ic
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm scale-105'
                            : 'bg-white/[0.03] text-slate-400 hover:text-white border border-white/5'
                        }`}
                      >
                        <IconHelper name={ic} className="w-4 h-4" />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                    Accent Color
                  </label>
                  <div className="flex items-center gap-2 overflow-x-auto py-1">
                    {AVAILABLE_COLORS.map((c) => (
                      <button
                        key={c.hex}
                        type="button"
                        onClick={() => setColor(c.hex)}
                        style={{ backgroundColor: c.hex }}
                        className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform cursor-pointer ${
                          color === c.hex ? 'ring-2 ring-white scale-110 shadow-lg' : 'opacity-70 hover:opacity-100'
                        }`}
                      >
                        {color === c.hex && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Frequency & Target Goal */}
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.08] space-y-4">
                {/* Frequency Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                    Frequency
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {[
                      { id: 'daily', label: 'Every Day' },
                      { id: 'weekdays', label: 'Weekdays' },
                      { id: 'times_per_week', label: 'X / Week' },
                      { id: 'custom_days', label: 'Custom' },
                    ].map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setFreqType(f.id as HabitFrequencyType)}
                        className={`py-2 px-1 text-center rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          freqType === f.id
                            ? 'bg-indigo-600 text-white border-transparent shadow-brand-sm'
                            : 'bg-white/[0.03] text-slate-400 border-white/5 hover:text-white'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>

                  {freqType === 'times_per_week' && (
                    <div className="mt-2.5 flex items-center gap-2">
                      <span className="text-xs text-slate-400 font-mono">Target:</span>
                      <input
                        type="number"
                        min="1"
                        max="7"
                        value={targetDaysPerWeek}
                        onChange={(e) => setTargetDaysPerWeek(Number(e.target.value))}
                        className="w-14 px-2 py-1 rounded-lg bg-slate-900 border border-white/10 text-xs font-bold text-center text-white font-mono"
                      />
                      <span className="text-xs text-slate-400">days / week</span>
                    </div>
                  )}

                  {freqType === 'custom_days' && (
                    <div className="mt-2.5 flex items-center justify-between gap-1">
                      {dayNames.map((name, idx) => {
                        const isSelected = customDays.includes(idx);
                        return (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => toggleCustomDay(idx)}
                            className={`w-8 h-8 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-cyan-500 text-slate-950 font-black'
                                : 'bg-white/[0.03] text-slate-400 border border-white/5 hover:text-white'
                            }`}
                          >
                            {name}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Target Count & Unit */}
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Target Goal
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={targetCount}
                      onChange={(e) => setTargetCount(Math.max(1, Number(e.target.value)))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Target Unit
                    </label>
                    <input
                      type="text"
                      value={targetUnit}
                      onChange={(e) => setTargetUnit(e.target.value)}
                      placeholder="times, mins, glasses"
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Scheduled Reminders */}
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.08] space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Scheduled Reminders</span>
                </label>
                <button
                  type="button"
                  onClick={addReminder}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-white/[0.04] hover:bg-white/[0.08] border border-white/5 text-cyan-300 cursor-pointer transition-colors"
                >
                  <Plus className="w-3 h-3" />
                  <span>Add Reminder</span>
                </button>
              </div>

              {reminders.length > 0 && (
                <div className="space-y-2">
                  {reminders.map((reminder, index) => (
                    <div key={reminder.id} className="flex items-center gap-2">
                      <input
                        type="time"
                        value={reminder.time}
                        onChange={(e) => updateReminder(index, { time: e.target.value })}
                        className="px-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                      />
                      <input
                        type="text"
                        value={reminder.label || ''}
                        onChange={(e) => updateReminder(index, { label: e.target.value })}
                        placeholder="Label (optional)"
                        className="flex-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-cyan-400"
                      />
                      <button
                        type="button"
                        onClick={() => removeReminder(index)}
                        className="p-1.5 rounded-xl text-slate-400 hover:text-rose-400 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Start Date */}
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                <span>Tracking Start Date</span>
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full sm:w-60 px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          {/* 3. STICKY FOOTER (ALWAYS VISIBLE) */}
          <div className="shrink-0 px-6 py-4 border-t border-white/[0.08] bg-[#0c0f17]/95 backdrop-blur-md flex items-center justify-between">
            <div className="text-[11px] text-zinc-400 font-mono hidden sm:block">
              Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-semibold">Enter</kbd> to save
            </div>
            <div className="flex items-center gap-3 ml-auto">
              <button
                type="button"
                onClick={handleClose}
                className="px-5 py-2.5 rounded-xl text-xs font-semibold text-zinc-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary !px-6 !py-2.5 !text-xs !rounded-xl font-bold"
              >
                {editingHabit ? 'Save Changes' : 'Create Habit'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default HabitFormModal;
