// Aureus Habit Detail Modal — In-Depth Analysis, 365-Day Heatmap & Relapse Log

import React, { useMemo, useState } from 'react';
import { Habit, HabitLog } from '../../types';
import { useApp } from '../../context/AppContext';
import { HabitService } from '../../domain/habitService';
import { IconHelper } from '../common/IconHelper';
import { HabitGrid } from './HabitGrid';
import {
  X,
  Calendar,
  CheckCircle2,
  Edit2,
  Trash2,
  Plus,
  Minus,
  MessageSquare,
  ShieldCheck,
  Flame,
  Shield,
  Sparkles,
} from 'lucide-react';
import { format } from 'date-fns';

interface HabitDetailModalProps {
  habit: Habit;
  onClose: () => void;
}

export const HabitDetailModal: React.FC<HabitDetailModalProps> = ({ habit, onClose }) => {
  const {
    habitLogs,
    habitRelapses,
    setHabitDayCount,
    toggleHabitDay,
    recordHabitRelapse,
    clearHabitRelapse,
    setEditingHabit,
    setIsHabitModalOpen,
    deleteHabit,
  } = useApp();

  const [selectedDate, setSelectedDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
  const [selectedNote, setSelectedNote] = useState<string>('');

  const stats = useMemo(() => {
    return HabitService.calculateStats(habit, habitLogs, habitRelapses);
  }, [habit, habitLogs, habitRelapses]);

  const habitRelapseList = useMemo(() => {
    return Array.from(habitRelapses.values())
      .filter((r) => r.habitId === habit.id && !r.deleted)
      .sort(
        (a, b) =>
          new Date(b.timestamp || b.date).getTime() -
          new Date(a.timestamp || a.date).getTime()
      );
  }, [habitRelapses, habit.id]);

  // Full 365-day grid cells
  const yearGridCells = useMemo(() => {
    return HabitService.generateGridCells(habit, habitLogs, habitRelapses, 365);
  }, [habit, habitLogs, habitRelapses]);

  const selectedLog = useMemo(() => {
    return habitLogs.get(`${habit.id}_${selectedDate}`);
  }, [habitLogs, habit.id, selectedDate]);

  const handleSaveLog = (newCount: number, notes?: string) => {
    setHabitDayCount(habit.id, selectedDate, newCount, notes);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="rounded-3xl bg-[#0c0e14] border border-white/[0.1] w-full max-w-4xl shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-white/[0.07] bg-white/[0.01]">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div
                style={{ backgroundColor: `${habit.color}20`, color: habit.color, borderColor: `${habit.color}40` }}
                className="w-13 h-13 rounded-2xl flex items-center justify-center border text-2xl shrink-0"
              >
                <IconHelper name={habit.icon} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-black text-white tracking-tight">{habit.name}</h2>
                  {habit.category === 'quit' && (
                    <span className="px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-300 text-[10px] font-bold uppercase border border-rose-500/30">
                      Quit Protocol
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{habit.description || 'Continuous practice protocol'}</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  setEditingHabit(habit);
                  setIsHabitModalOpen(true);
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                title="Edit habit"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  if (confirm('Delete this habit?')) {
                    deleteHabit(habit.id);
                    onClose();
                  }
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                title="Delete habit"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Stats Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
            <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4 text-center">
              <div className="text-3xl font-black text-amber-300 tabular-nums">
                {stats.currentStreak}
                <span className="text-xs font-normal text-slate-400 ml-0.5">d</span>
              </div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                {habit.category === 'quit' ? 'Current Clean Streak' : 'Current Streak'}
              </div>
            </div>
            <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4 text-center">
              <div className="text-3xl font-black text-white tabular-nums">
                {stats.bestStreak}
                <span className="text-xs font-normal text-slate-400 ml-0.5">d</span>
              </div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                {habit.category === 'quit' ? 'Best Clean Streak' : 'Best Streak'}
              </div>
            </div>
            <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4 text-center">
              <div className="text-3xl font-black text-emerald-400 tabular-nums">
                {stats.completionRate30Days}%
              </div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                30d Consistency
              </div>
            </div>
            <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4 text-center">
              <div className="text-3xl font-black text-white tabular-nums">
                {habit.category === 'quit' ? stats.relapseCount || 0 : stats.totalCompletions}
              </div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                {habit.category === 'quit' ? 'Total Slips' : 'Completions'}
              </div>
            </div>
          </div>

          {/* Optional Financial Savings Banner */}
          {habit.category === 'quit' && habit.quitDetails?.costPerDay && (
            <div className="p-4 rounded-2xl bg-amber-400/10 border border-amber-400/25 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Capital Preserved
                </div>
                <div className="text-xs text-slate-300 mt-0.5">
                  Financial savings accrued by sustaining this quit protocol:
                </div>
              </div>
              <div className="text-2xl font-black text-amber-300 font-mono">
                ${(stats.totalCompletions * habit.quitDetails.costPerDay).toLocaleString()}
              </div>
            </div>
          )}

          {/* 365-Day Activity Grid */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              <span>365-Day Consistency Heatmap</span>
            </h3>
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
              <HabitGrid
                cells={yearGridCells}
                habitColor={habit.color}
                cellSize={10}
                onCellClick={(dateStr) => {
                  if (habit.category === 'quit') {
                    const relapseExists = Array.from(habitRelapses.values()).some(
                      (r) => r.habitId === habit.id && r.date === dateStr && !r.deleted
                    );
                    if (relapseExists) {
                      clearHabitRelapse(habit.id, dateStr);
                    } else {
                      recordHabitRelapse(habit.id, undefined, `Slipped on ${dateStr}`);
                    }
                  } else {
                    toggleHabitDay(habit.id, dateStr);
                  }
                }}
                isQuit={habit.category === 'quit'}
              />
            </div>
          </div>

          {/* Day Detail Log Editor */}
          <div className="rounded-2xl bg-white/[0.02] border border-white/[0.06] p-4 sm:p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => {
                    setSelectedDate(e.target.value);
                    setSelectedNote('');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-white/[0.05] border border-white/10 text-xs text-white focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                />
              </div>
              <div className="text-xs font-mono text-slate-400">
                {selectedLog ? (selectedLog.completed ? '✓ Completed' : 'Pending') : 'No record'}
              </div>
            </div>

            {habit.category === 'quit' ? (
              <QuitDayControls
                habit={habit}
                date={selectedDate}
                selectedLog={selectedLog}
                onSetCount={handleSaveLog}
              />
            ) : habit.targetCount && habit.targetCount > 1 ? (
              <MultiStepControls
                habit={habit}
                date={selectedDate}
                selectedLog={selectedLog}
                onSave={handleSaveLog}
              />
            ) : (
              <SimpleDayControls
                habit={habit}
                date={selectedDate}
                selectedLog={selectedLog}
                onToggle={() => toggleHabitDay(habit.id, selectedDate)}
              />
            )}

            {/* Note input */}
            <div className="flex items-center gap-2 pt-1">
              <MessageSquare className="w-4 h-4 text-slate-500 shrink-0" />
              <input
                type="text"
                value={selectedNote}
                onChange={(e) => setSelectedNote(e.target.value)}
                placeholder="Log a reflection or note for this date..."
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && selectedNote.trim()) {
                    handleSaveLog(selectedLog?.count || 0, selectedNote.trim());
                    setSelectedNote('');
                  }
                }}
                className="flex-1 px-3.5 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400/50"
              />
              {selectedNote.trim() && (
                <button
                  onClick={() => {
                    handleSaveLog(selectedLog?.count || 0, selectedNote.trim());
                    setSelectedNote('');
                  }}
                  className="btn-primary !px-4 !py-2 !text-xs !rounded-xl"
                >
                  Save
                </button>
              )}
            </div>
          </div>

          {/* Relapse Event History for Quit Habits */}
          {habit.category === 'quit' && (
            <div className="rounded-2xl bg-white/[0.02] border border-white/[0.06] p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Slip &amp; Relapse Log ({habitRelapseList.length})
                </h4>
                <button
                  onClick={() => {
                    const trigger = prompt('What was the environment or trigger? (e.g. Social, Fatigue, Stress)');
                    if (trigger !== null) {
                      recordHabitRelapse(habit.id, trigger || undefined);
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/10 text-rose-300 border border-rose-500/30 hover:bg-rose-500/20 transition-all flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Slip</span>
                </button>
              </div>

              {habitRelapseList.length === 0 ? (
                <p className="text-xs text-slate-500 py-2">Pristine record. Zero relapses logged.</p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {habitRelapseList.map((r) => (
                    <div
                      key={r.id}
                      className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-rose-400 font-mono">{r.date}</span>
                        {r.trigger && (
                          <span className="ml-2 px-2 py-0.5 rounded bg-white/10 text-slate-300 text-[10px] font-semibold">
                            {r.trigger}
                          </span>
                        )}
                        {r.notes && <p className="text-[11px] text-slate-400 mt-0.5">{r.notes}</p>}
                      </div>
                      <button
                        onClick={() => clearHabitRelapse(habit.id, r.date)}
                        className="text-slate-400 hover:text-rose-400 p-1 cursor-pointer transition-colors"
                        title="Remove slip record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Sub-components for day controls ────────────────────────────────

interface SimpleDayControlsProps {
  habit: Habit;
  date: string;
  selectedLog?: HabitLog | undefined;
  onToggle: () => void;
}

const SimpleDayControls: React.FC<SimpleDayControlsProps> = ({ habit, selectedLog, onToggle }) => {
  const completed = selectedLog?.completed || false;
  return (
    <div className="flex items-center gap-3">
      <button
        onClick={onToggle}
        style={{
          backgroundColor: completed ? habit.color : 'transparent',
          borderColor: completed ? habit.color : `${habit.color}60`,
          color: completed ? '#07080B' : habit.color,
        }}
        className="px-4 py-2 rounded-xl text-xs font-bold border flex items-center gap-2 transition-all active:scale-95 cursor-pointer shadow-xs"
      >
        <CheckCircle2 className="w-4 h-4" />
        <span>{completed ? '✓ Completed' : 'Mark Completed'}</span>
      </button>
      {completed && <span className="text-xs text-slate-400 font-mono">Click to toggle off</span>}
    </div>
  );
};

interface MultiStepControlsProps {
  habit: Habit;
  date: string;
  selectedLog?: HabitLog | undefined;
  onSave: (count: number, notes?: string) => void;
}

const MultiStepControls: React.FC<MultiStepControlsProps> = ({ habit, selectedLog, onSave }) => {
  const currentCount = selectedLog?.count || 0;
  const target = habit.targetCount || 1;
  const completed = currentCount >= target;

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={() => onSave(Math.max(0, currentCount - 1))}
        disabled={currentCount === 0}
        className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/10 disabled:opacity-30 transition-all cursor-pointer"
      >
        <Minus className="w-4 h-4" />
      </button>
      <span className="text-xs font-bold px-3 min-w-[48px] text-center text-white font-mono">
        {currentCount}/{target}
      </span>
      <button
        onClick={() => onSave(currentCount + 1)}
        style={{
          backgroundColor: completed ? habit.color : undefined,
          color: completed ? '#07080B' : undefined,
        }}
        className="w-8 h-8 flex items-center justify-center rounded-lg transition-all text-slate-300 hover:bg-white/10 cursor-pointer"
      >
        {completed ? <CheckCircle2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
      </button>
      <button
        onClick={() => onSave(0)}
        className="px-2.5 py-1 rounded-lg text-[10px] text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
      >
        Reset
      </button>
    </div>
  );
};

interface QuitDayControlsProps {
  habit: Habit;
  date: string;
  selectedLog?: HabitLog | undefined;
  onSetCount: (count: number, notes?: string) => void;
}

const QuitDayControls: React.FC<QuitDayControlsProps> = ({ habit, date, selectedLog, onSetCount }) => {
  const { recordHabitRelapse, clearHabitRelapse } = useApp();
  const completed = selectedLog?.completed || false;

  const handleToggle = () => {
    if (completed) {
      onSetCount(0);
      recordHabitRelapse(habit.id, undefined, `Slipped on ${date}`);
    } else {
      onSetCount(1);
      clearHabitRelapse(habit.id, date);
    }
  };

  return (
    <div className="flex items-center gap-3">
      <button
        onClick={handleToggle}
        style={{
          backgroundColor: completed ? '#10B981' : 'transparent',
          borderColor: completed ? '#10B981' : '#10B98160',
          color: completed ? '#07080B' : '#10B981',
        }}
        className="px-4 py-2 rounded-xl text-xs font-bold border flex items-center gap-2 transition-all active:scale-95 cursor-pointer"
      >
        <ShieldCheck className="w-4 h-4" />
        <span>{completed ? '✓ Clean Day — Click to mark slip' : 'Mark Clean Day'}</span>
      </button>
      <span className="text-xs text-slate-400">
        {completed ? 'Sustained streak credit' : 'Record zero slips'}
      </span>
    </div>
  );
};

export default HabitDetailModal;