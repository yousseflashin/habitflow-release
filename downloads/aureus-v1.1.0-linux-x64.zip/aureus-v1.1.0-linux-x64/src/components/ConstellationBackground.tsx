// Aureus Luxury Low-Poly Constellation Mesh
// Geometric triangulated origami network with golden ambient depth.
// Zero GC allocations during animation loop, batched vector drawing, locked 120 FPS.

import React, { useEffect, useRef } from 'react';

interface MeshPoint {
  bx: number;
  by: number;
  jx: number;
  jy: number;
  phase: number;
  drift: number;
  r: number;
}

interface MeshTri {
  p: [number, number, number];
  baseShade: number;
  phase: number;
}

interface MeshEdge {
  a: number;
  b: number;
}

// 24 pre-allocated imperial gold / champagne facet colors
// Eliminates per-frame CanvasGradient allocations and string parsing
const DARK_FACET_PALETTE: string[] = [];
for (let i = 0; i < 24; i++) {
  const norm = i / 23;
  const hue = 38 + norm * 8; // Imperial gold hue (38-46 deg)
  const sat = 70 + norm * 15;
  const light = 44 + norm * 20;
  const alpha = 0.022 + norm * 0.048; // Subtle luxury translucency
  DARK_FACET_PALETTE.push(
    `hsla(${hue.toFixed(1)}, ${sat.toFixed(1)}%, ${light.toFixed(1)}%, ${alpha.toFixed(4)})`
  );
}

const LIGHT_FACET_PALETTE: string[] = [];
for (let i = 0; i < 24; i++) {
  const norm = i / 23;
  const hue = 36 + norm * 8;
  const sat = 55 + norm * 15;
  const light = 62 + norm * 18;
  const alpha = 0.028 + norm * 0.042;
  LIGHT_FACET_PALETTE.push(
    `hsla(${hue.toFixed(1)}, ${sat.toFixed(1)}%, ${light.toFixed(1)}%, ${alpha.toFixed(4)})`
  );
}

export const ConstellationBackground: React.FC<{ className?: string }> = ({
  className = 'absolute inset-0',
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf = 0;
    let pts: MeshPoint[] = [];
    let tris: MeshTri[] = [];
    let primaryEdges: MeshEdge[] = [];
    let diagonalEdges: MeshEdge[] = [];
    let xCoords = new Float32Array(0);
    let yCoords = new Float32Array(0);
    let w = 0;
    let h = 0;
    let isDark = true;

    // Pre-rendered golden celestial node glow sprite (reused forever, 0 runtime allocation)
    const darkSprite = document.createElement('canvas');
    darkSprite.width = darkSprite.height = 32;
    const dsctx = darkSprite.getContext('2d')!;
    const dg = dsctx.createRadialGradient(16, 16, 0, 16, 16, 16);
    dg.addColorStop(0, 'rgba(255, 245, 200, 0.95)');
    dg.addColorStop(0.2, 'rgba(240, 196, 101, 0.45)');
    dg.addColorStop(0.55, 'rgba(212, 160, 52, 0.14)');
    dg.addColorStop(1, 'rgba(212, 160, 52, 0)');
    dsctx.fillStyle = dg;
    dsctx.fillRect(0, 0, 32, 32);

    const lightSprite = document.createElement('canvas');
    lightSprite.width = lightSprite.height = 32;
    const lsctx = lightSprite.getContext('2d')!;
    const lg = lsctx.createRadialGradient(16, 16, 0, 16, 16, 16);
    lg.addColorStop(0, 'rgba(212, 160, 52, 0.9)');
    lg.addColorStop(0.25, 'rgba(180, 130, 40, 0.35)');
    lg.addColorStop(0.6, 'rgba(160, 110, 30, 0.1)');
    lg.addColorStop(1, 'rgba(160, 110, 30, 0)');
    lsctx.fillStyle = lg;
    lsctx.fillRect(0, 0, 32, 32);

    const build = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = rect.width;
      h = rect.height;
      if (w === 0 || h === 0) return;

      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      isDark = !document.documentElement.classList.contains('light');

      // Grid spacing adjusted for balanced density
      const spacing = Math.max(60, Math.min(90, w / 18));
      const cols = Math.ceil(w / spacing) + 1;
      const rows = Math.ceil(h / spacing) + 1;

      pts = [];
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          pts.push({
            bx: c * spacing,
            by: r * spacing,
            jx: (Math.random() - 0.5) * spacing * 0.65,
            jy: (Math.random() - 0.5) * spacing * 0.65,
            phase: Math.random() * Math.PI * 2,
            drift: 5 + Math.random() * 8,
            r: 0.65 + Math.random() * 0.75,
          });
        }
      }

      // Pre-allocate coordinate typed arrays
      xCoords = new Float32Array(pts.length);
      yCoords = new Float32Array(pts.length);

      const idx = (c: number, r: number) => r * cols + c;

      tris = [];
      primaryEdges = [];
      diagonalEdges = [];
      const edgeSet = new Set<string>();

      const addEdge = (p1: number, p2: number, isDiagonal: boolean) => {
        const key = p1 < p2 ? `${p1}-${p2}` : `${p2}-${p1}`;
        if (!edgeSet.has(key)) {
          edgeSet.add(key);
          if (isDiagonal) {
            diagonalEdges.push({ a: p1, b: p2 });
          } else {
            primaryEdges.push({ a: p1, b: p2 });
          }
        }
      };

      for (let r = 0; r < rows - 1; r++) {
        for (let c = 0; c < cols - 1; c++) {
          const a = idx(c, r);
          const b = idx(c + 1, r);
          const d = idx(c, r + 1);
          const e = idx(c + 1, r + 1);

          // Alternating diagonal triangulation creates faceted low-poly origami geometry
          const flip = (c + r) % 2 === 0;
          const cells: [number, number, number][] = flip
            ? [[a, b, d], [b, e, d]]
            : [[a, b, e], [a, e, d]];

          for (const [p1, p2, p3] of cells) {
            tris.push({
              p: [p1, p2, p3],
              baseShade: Math.floor(Math.random() * 24),
              phase: Math.random() * Math.PI * 2,
            });
          }

          // Quad sides + diagonals
          addEdge(a, b, false);
          addEdge(a, d, false);
          addEdge(b, e, false);
          addEdge(d, e, false);
          addEdge(a, e, true);
          addEdge(b, d, true);
        }
      }
    };

    const draw = (time: number) => {
      // 1. Velvet Obsidian & Imperial Dusk background gradient
      const bg = ctx.createLinearGradient(0, 0, w, h);
      if (isDark) {
        bg.addColorStop(0, '#060709');
        bg.addColorStop(0.35, '#080a11');
        bg.addColorStop(0.7, '#0c0e17');
        bg.addColorStop(1, '#07080b');
      } else {
        bg.addColorStop(0, '#faf8f5');
        bg.addColorStop(0.35, '#f5f1ea');
        bg.addColorStop(0.7, '#eee8dc');
        bg.addColorStop(1, '#f8f5ee');
      }
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // 2. Compute live drifting vertex positions
      const len = pts.length;
      for (let i = 0; i < len; i++) {
        const p = pts[i];
        xCoords[i] = p.bx + p.jx + Math.sin(time * 0.00035 + p.phase) * p.drift;
        yCoords[i] = p.by + p.jy + Math.cos(time * 0.00028 + p.phase * 1.25) * p.drift;
      }

      // 3. Render low-poly origami triangle faces with faceted ambient gold shimmer
      const palette = isDark ? DARK_FACET_PALETTE : LIGHT_FACET_PALETTE;
      const triLen = tris.length;
      for (let i = 0; i < triLen; i++) {
        const tri = tris[i];
        const [p1, p2, p3] = tri.p;
        const shade = Math.floor(
          (tri.baseShade + Math.sin(time * 0.00045 + tri.phase) * 4.5 + 24) % 24
        );
        ctx.fillStyle = palette[shade];
        ctx.beginPath();
        ctx.moveTo(xCoords[p1], yCoords[p1]);
        ctx.lineTo(xCoords[p2], yCoords[p2]);
        ctx.lineTo(xCoords[p3], yCoords[p3]);
        ctx.closePath();
        ctx.fill();
      }

      // 4. Hairline web links (batched single stroke per group for ultra-high FPS)
      ctx.lineWidth = 0.55;

      // Primary quad boundaries
      ctx.strokeStyle = isDark ? 'rgba(240, 196, 101, 0.12)' : 'rgba(160, 120, 50, 0.14)';
      ctx.beginPath();
      const pLen = primaryEdges.length;
      for (let i = 0; i < pLen; i++) {
        const e = primaryEdges[i];
        ctx.moveTo(xCoords[e.a], yCoords[e.a]);
        ctx.lineTo(xCoords[e.b], yCoords[e.b]);
      }
      ctx.stroke();

      // Diagonal interior strands
      ctx.strokeStyle = isDark ? 'rgba(240, 196, 101, 0.06)' : 'rgba(160, 120, 50, 0.07)';
      ctx.beginPath();
      const dLen = diagonalEdges.length;
      for (let i = 0; i < dLen; i++) {
        const e = diagonalEdges[i];
        ctx.moveTo(xCoords[e.a], yCoords[e.a]);
        ctx.lineTo(xCoords[e.b], yCoords[e.b]);
      }
      ctx.stroke();

      // 5. Star node dots & soft celestial halos
      const sprite = isDark ? darkSprite : lightSprite;
      for (let i = 0; i < len; i++) {
        const p = pts[i];
        const pulse = 1 + Math.sin(time * 0.0018 + p.phase) * 0.22;
        const size = p.r * 5 * pulse;
        ctx.drawImage(sprite, xCoords[i] - size, yCoords[i] - size, size * 2, size * 2);
      }

      // Crisp node core points (single batched fill call)
      ctx.fillStyle = isDark ? 'rgba(255, 245, 220, 0.95)' : 'rgba(140, 100, 30, 0.9)';
      ctx.beginPath();
      for (let i = 0; i < len; i++) {
        const p = pts[i];
        ctx.moveTo(xCoords[i] + p.r, yCoords[i]);
        ctx.arc(xCoords[i], yCoords[i], p.r, 0, Math.PI * 2);
      }
      ctx.fill();

      raf = requestAnimationFrame(draw);
    };

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    build();

    if (reduced) {
      draw(0);
      cancelAnimationFrame(raf);
    } else {
      raf = requestAnimationFrame(draw);
    }

    // Pause when tab is inactive to preserve 100% CPU/GPU resources
    const handleVisibility = () => {
      if (document.hidden) {
        cancelAnimationFrame(raf);
      } else if (!reduced) {
        raf = requestAnimationFrame(draw);
      }
    };

    const observer = new MutationObserver(() => {
      isDark = !document.documentElement.classList.contains('light');
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class'],
    });

    window.addEventListener('resize', build);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      window.removeEventListener('resize', build);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      aria-hidden="true"
    />
  );
};

export default ConstellationBackground;
