// HabitFlow — Minimalist Celestial Constellation Canvas
// Refined, uncluttered ambient starlight network with serene cool depth.
// Zero GC runtime allocations, batched vector drawing, silky 120 FPS.

import React, { useEffect, useRef } from 'react';

interface MeshPoint {
  bx: number;
  by: number;
  jx: number;
  jy: number;
  phase: number;
  drift: number;
  r: number;
}

interface MeshTri {
  p: [number, number, number];
  baseShade: number;
  phase: number;
}

interface MeshEdge {
  a: number;
  b: number;
}

// 24 pre-allocated cool twilight/indigo/cyan facet colors (zero gold/yellow)
const DARK_FACET_PALETTE: string[] = [];
for (let i = 0; i < 24; i++) {
  const norm = i / 23;
  const hue = 222 + norm * 18; // Serene deep slate/indigo/cyan (222-240 deg)
  const sat = 45 + norm * 20;
  const light = 35 + norm * 18;
  const alpha = 0.008 + norm * 0.020; // Ultra-subtle, airy translucency
  DARK_FACET_PALETTE.push(
    `hsla(${hue.toFixed(1)}, ${sat.toFixed(1)}%, ${light.toFixed(1)}%, ${alpha.toFixed(4)})`
  );
}

const LIGHT_FACET_PALETTE: string[] = [];
for (let i = 0; i < 24; i++) {
  const norm = i / 23;
  const hue = 215 + norm * 15;
  const sat = 30 + norm * 15;
  const light = 70 + norm * 15;
  const alpha = 0.010 + norm * 0.018;
  LIGHT_FACET_PALETTE.push(
    `hsla(${hue.toFixed(1)}, ${sat.toFixed(1)}%, ${light.toFixed(1)}%, ${alpha.toFixed(4)})`
  );
}

export const ConstellationBackground: React.FC<{ className?: string }> = ({
  className = 'absolute inset-0',
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf = 0;
    let pts: MeshPoint[] = [];
    let tris: MeshTri[] = [];
    let edges: MeshEdge[] = [];
    let xCoords = new Float32Array(0);
    let yCoords = new Float32Array(0);
    let w = 0;
    let h = 0;
    let isDark = true;

    // Pre-rendered starlight node glow sprite (cyan/indigo celestial tint, zero gold)
    const darkSprite = document.createElement('canvas');
    darkSprite.width = darkSprite.height = 32;
    const dsctx = darkSprite.getContext('2d')!;
    const dg = dsctx.createRadialGradient(16, 16, 0, 16, 16, 16);
    dg.addColorStop(0, 'rgba(240, 248, 255, 0.95)');
    dg.addColorStop(0.2, 'rgba(129, 140, 248, 0.40)');
    dg.addColorStop(0.55, 'rgba(56, 189, 248, 0.10)');
    dg.addColorStop(1, 'rgba(56, 189, 248, 0)');
    dsctx.fillStyle = dg;
    dsctx.fillRect(0, 0, 32, 32);

    const lightSprite = document.createElement('canvas');
    lightSprite.width = lightSprite.height = 32;
    const lsctx = lightSprite.getContext('2d')!;
    const lg = lsctx.createRadialGradient(16, 16, 0, 16, 16, 16);
    lg.addColorStop(0, 'rgba(99, 102, 241, 0.85)');
    lg.addColorStop(0.25, 'rgba(59, 130, 246, 0.20)');
    lg.addColorStop(0.6, 'rgba(56, 189, 248, 0.06)');
    lg.addColorStop(1, 'rgba(56, 189, 248, 0)');
    lsctx.fillStyle = lg;
    lsctx.fillRect(0, 0, 32, 32);

    const build = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = rect.width;
      h = rect.height;
      if (w === 0 || h === 0) return;

      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      isDark = !document.documentElement.classList.contains('light');

      // Increased spacing: 180px - 260px makes the canvas uncluttered, peaceful, and uncrowded
      const spacing = Math.max(180, Math.min(260, w / 8));
      const cols = Math.ceil(w / spacing) + 1;
      const rows = Math.ceil(h / spacing) + 1;

      pts = [];
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          pts.push({
            bx: c * spacing,
            by: r * spacing,
            jx: (Math.random() - 0.5) * spacing * 0.45,
            jy: (Math.random() - 0.5) * spacing * 0.45,
            phase: Math.random() * Math.PI * 2,
            drift: 3 + Math.random() * 5,
            r: 0.55 + Math.random() * 0.55,
          });
        }
      }

      xCoords = new Float32Array(pts.length);
      yCoords = new Float32Array(pts.length);

      const idx = (c: number, r: number) => r * cols + c;

      tris = [];
      edges = [];
      const edgeSet = new Set<string>();

      const addEdge = (p1: number, p2: number) => {
        const key = p1 < p2 ? `${p1}-${p2}` : `${p2}-${p1}`;
        if (!edgeSet.has(key)) {
          edgeSet.add(key);
          edges.push({ a: p1, b: p2 });
        }
      };

      for (let r = 0; r < rows - 1; r++) {
        for (let c = 0; c < cols - 1; c++) {
          const a = idx(c, r);
          const b = idx(c + 1, r);
          const d = idx(c, r + 1);
          const e = idx(c + 1, r + 1);

          const flip = (c + r) % 2 === 0;
          const cells: [number, number, number][] = flip
            ? [[a, b, d], [b, e, d]]
            : [[a, b, e], [a, e, d]];

          for (const [p1, p2, p3] of cells) {
            tris.push({
              p: [p1, p2, p3],
              baseShade: Math.floor(Math.random() * 24),
              phase: Math.random() * Math.PI * 2,
            });
          }

          addEdge(a, b);
          addEdge(a, d);
          addEdge(b, e);
          addEdge(d, e);
          if (flip) {
            addEdge(b, d);
          } else {
            addEdge(a, e);
          }
        }
      }
    };

    const draw = (time: number) => {
      // 1. Serene Obsidian & Midnight Slate background gradient
      const bg = ctx.createLinearGradient(0, 0, w, h);
      if (isDark) {
        bg.addColorStop(0, '#07080c');
        bg.addColorStop(0.4, '#090c14');
        bg.addColorStop(0.8, '#0b0f1a');
        bg.addColorStop(1, '#08090e');
      } else {
        bg.addColorStop(0, '#f8fafc');
        bg.addColorStop(0.4, '#f1f5f9');
        bg.addColorStop(0.8, '#e2e8f0');
        bg.addColorStop(1, '#f8fafc');
      }
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // 2. Compute smooth drifting positions
      const len = pts.length;
      for (let i = 0; i < len; i++) {
        const p = pts[i];
        xCoords[i] = p.bx + p.jx + Math.sin(time * 0.00020 + p.phase) * p.drift;
        yCoords[i] = p.by + p.jy + Math.cos(time * 0.00018 + p.phase * 1.2) * p.drift;
      }

      // 3. Render low-density triangles with calm twilight shading
      const palette = isDark ? DARK_FACET_PALETTE : LIGHT_FACET_PALETTE;
      const triLen = tris.length;
      for (let i = 0; i < triLen; i++) {
        const tri = tris[i];
        const [p1, p2, p3] = tri.p;
        const shade = Math.floor(
          (tri.baseShade + Math.sin(time * 0.00025 + tri.phase) * 2.5 + 24) % 24
        );
        ctx.fillStyle = palette[shade];
        ctx.beginPath();
        ctx.moveTo(xCoords[p1], yCoords[p1]);
        ctx.lineTo(xCoords[p2], yCoords[p2]);
        ctx.lineTo(xCoords[p3], yCoords[p3]);
        ctx.closePath();
        ctx.fill();
      }

      // 4. Subtle, delicate connecting threads
      ctx.beginPath();
      const edgeLen = edges.length;
      for (let i = 0; i < edgeLen; i++) {
        const e = edges[i];
        ctx.moveTo(xCoords[e.a], yCoords[e.a]);
        ctx.lineTo(xCoords[e.b], yCoords[e.b]);
      }
      ctx.strokeStyle = isDark
        ? 'rgba(147, 197, 253, 0.035)'
        : 'rgba(99, 102, 241, 0.035)';
      ctx.lineWidth = 0.65;
      ctx.stroke();

      // 5. Starlight node glows (cool starlight sprite, uncrowded)
      const sprite = isDark ? darkSprite : lightSprite;
      for (let i = 0; i < len; i++) {
        const x = xCoords[i];
        const y = yCoords[i];
        const p = pts[i];
        const pulse = 0.85 + Math.sin(time * 0.0005 + p.phase) * 0.15;
        const size = p.r * 10 * pulse;
        ctx.drawImage(sprite, x - size / 2, y - size / 2, size, size);
      }

      // 6. Crisp node core points
      ctx.fillStyle = isDark ? 'rgba(230, 240, 255, 0.85)' : 'rgba(99, 102, 241, 0.8)';
      ctx.beginPath();
      for (let i = 0; i < len; i++) {
        const p = pts[i];
        ctx.moveTo(xCoords[i] + p.r, yCoords[i]);
        ctx.arc(xCoords[i], yCoords[i], p.r, 0, Math.PI * 2);
      }
      ctx.fill();

      raf = requestAnimationFrame(draw);
    };

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    build();

    if (reduced) {
      draw(0);
      cancelAnimationFrame(raf);
    } else {
      raf = requestAnimationFrame(draw);
    }

    const handleVisibility = () => {
      if (document.hidden) {
        cancelAnimationFrame(raf);
      } else if (!reduced) {
        raf = requestAnimationFrame(draw);
      }
    };

    const observer = new MutationObserver(() => {
      isDark = !document.documentElement.classList.contains('light');
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class'],
    });

    window.addEventListener('resize', build);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      window.removeEventListener('resize', build);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      aria-hidden="true"
    />
  );
};

export default ConstellationBackground;
