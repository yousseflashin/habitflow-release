// Aureus Product Landing — Executive Whole-Life Architecture Presentation

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Download,
  Smartphone,
  Monitor,
  Globe,
  Sparkles,
  CheckCircle2,
  Flame,
  Shield,
  Dumbbell,
  Brain,
  Zap,
  Lock,
  RefreshCw,
  ArrowRight,
  Terminal,
  Activity,
  Award,
} from 'lucide-react';

interface ProductLandingViewProps {
  onEnterApp?: () => void;
}

export const ProductLandingView: React.FC<ProductLandingViewProps> = ({ onEnterApp }) => {
  const { setActiveView } = useApp();
  const [copiedCurl, setCopiedCurl] = useState(false);

  const handleOpenApp = () => {
    if (onEnterApp) {
      onEnterApp();
    } else {
      setActiveView('today');
    }
  };

  const copyFedoraCommand = () => {
    navigator.clipboard.writeText('curl -fsSL https://raw.githubusercontent.com/yousseflashin/habitflow/main/scripts/habitflow-desktop.sh | bash');
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#07080B] text-slate-100 font-sans selection:bg-amber-400/30 selection:text-amber-300 pb-24">
      {/* ── Top Navbar ─────────────────────────────────────────── */}
      <nav className="sticky top-0 z-50 bg-[#07080B]/80 backdrop-blur-xl border-b border-white/[0.07] px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-b from-[#F0C465] to-[#D4A034] text-slate-950 font-black text-lg flex items-center justify-center shadow-glow-sm">
              A
            </div>
            <div>
              <div className="font-black text-white text-lg tracking-tight">Aureus</div>
              <div className="text-[10px] font-bold text-amber-300 uppercase tracking-widest -mt-1">
                Executive OS
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveView('downloads')}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-xs font-bold text-slate-200 hover:text-white transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Downloads</span>
            </button>

            <button
              onClick={handleOpenApp}
              className="btn-primary !px-5 !py-2.5 !text-xs !rounded-xl !shadow-glow-sm inline-flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <span>Launch Vault</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </nav>

      {/* ── Hero Section ───────────────────────────────────────── */}
      <section className="relative px-6 pt-20 pb-24 overflow-hidden">
        <div className="max-w-4xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/25 text-amber-300 text-xs font-bold uppercase tracking-widest mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Executive Whole-Life System</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight text-white leading-tight">
            Elevate Your Habits, Body, Mind &amp; Wealth.
          </h1>

          <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Aureus unites tasks, habit consistency, physical conditioning, financial capital, and life balance into a single local-first private operating system.
          </p>

          <div className="pt-6 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => setActiveView('downloads')}
              className="btn-primary !px-7 !py-3.5 !text-xs !rounded-2xl !shadow-glow-sm flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Get Android &amp; Desktop Builds</span>
            </button>

            <button
              onClick={handleOpenApp}
              className="px-7 py-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-200 text-xs font-bold flex items-center gap-2 transition-all cursor-pointer active:scale-95"
            >
              <Globe className="w-4 h-4 text-amber-400" />
              <span>Open Web Vault</span>
            </button>
          </div>
        </div>
      </section>

      {/* ── Platform Download Cards ────────────────────────────── */}
      <section id="downloads" className="px-6 py-16 bg-[#0c0e14]/60 border-y border-white/[0.06]">
        <div className="max-w-6xl mx-auto space-y-12">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center justify-center gap-2">
              <Download className="w-4 h-4" />
              <span>Platform Access</span>
            </div>
            <h2 className="text-3xl font-black text-white tracking-tight">
              Aureus Across Your Ecosystem
            </h2>
            <p className="text-xs text-slate-400">
              Native applications for Android and Fedora Linux with local SQLite/IndexedDB caching.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* 1. Android */}
            <div className="rounded-3xl bg-[#0c0e14] border border-white/[0.08] hover:border-white/20 p-6 flex flex-col justify-between shadow-2xl transition-all">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400">
                    <Smartphone className="w-6 h-6" />
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold uppercase">
                    Android APK
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-black text-white">Android Client</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Native touch client with precision reminder notifications and local storage.
                  </p>
                </div>

                <ul className="space-y-2 text-xs text-slate-400 pt-2 border-t border-white/[0.05]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Exact offline reminder alarms</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Interactive muscle &amp; radar matrix</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Instant background sync</span>
                  </li>
                </ul>
              </div>

              <div className="pt-6">
                <a
                  href="https://raw.githubusercontent.com/yousseflashin/habitflow-release/main/downloads/aureus-v1.1.0-android.apk"
                  download="aureus-v1.1.0-android.apk"
                  className="btn-primary !w-full !py-3 !text-xs !rounded-xl !shadow-glow-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download APK (v1.1.0)</span>
                </a>
                <div className="text-[10px] text-center text-slate-500 mt-2 font-mono">
                  Android 7.0+ (API 24+)
                </div>
              </div>
            </div>

            {/* 2. Fedora Linux Desktop */}
            <div className="rounded-3xl bg-[#0c0e14] border border-amber-400/30 p-6 flex flex-col justify-between shadow-2xl transition-all">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-amber-400/10 border border-amber-400/25 flex items-center justify-center text-amber-300">
                    <Monitor className="w-6 h-6" />
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-300 text-[10px] font-bold uppercase">
                    Fedora Desktop
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-black text-white">Fedora Desktop</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Native Electron desktop application with keyboard shortcuts and background daemon.
                  </p>
                </div>

                <ul className="space-y-2 text-xs text-slate-400 pt-2 border-t border-white/[0.05]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>GNOME / KDE application launcher</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Embedded database sync daemon</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Raycast-style Command Palette</span>
                  </li>
                </ul>
              </div>

              <div className="pt-6 space-y-2">
                <a
                  href="https://raw.githubusercontent.com/yousseflashin/habitflow-release/main/downloads/aureus-v1.1.0-linux-x64.zip"
                  download="aureus-v1.1.0-linux-x64.zip"
                  className="btn-primary !w-full !py-3 !text-xs !rounded-xl !shadow-glow-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Linux Zip (v1.1.0)</span>
                </a>
                <button
                  onClick={copyFedoraCommand}
                  className="w-full py-2.5 px-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 text-slate-300 font-mono text-[11px] flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <Terminal className="w-3.5 h-3.5 text-amber-400" />
                  <span>{copiedCurl ? 'Copied Command!' : './habitflow.sh launcher'}</span>
                </button>
              </div>
            </div>

            {/* 3. Progressive Web App */}
            <div className="rounded-3xl bg-[#0c0e14] border border-white/[0.08] hover:border-white/20 p-6 flex flex-col justify-between shadow-2xl transition-all">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-sky-500/10 border border-sky-500/25 flex items-center justify-center text-sky-400">
                    <Globe className="w-6 h-6" />
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-400 text-[10px] font-bold uppercase">
                    PWA Ready
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-black text-white">Browser Vault</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Zero-install web experience running entirely in browser IndexedDB with zero cloud dependency.
                  </p>
                </div>

                <ul className="space-y-2 text-xs text-slate-400 pt-2 border-t border-white/[0.05]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span>Complete offline mode support</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span>Real-time local storage caching</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span>Tablet, phone &amp; desktop adaptive</span>
                  </li>
                </ul>
              </div>

              <div className="pt-6">
                <button
                  onClick={handleOpenApp}
                  className="w-full py-3 px-4 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <span>Open Web Vault Now</span>
                  <ArrowRight className="w-4 h-4 text-amber-400" />
                </button>
                <div className="text-[10px] text-center text-slate-500 mt-2">
                  Instant launch into your life dashboard
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Feature Matrix ─────────────────────────────────────── */}
      <section className="px-6 py-20 max-w-6xl mx-auto space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Multi-Dimensional Architecture
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Designed for Whole-Life Mastery
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/10 border border-amber-400/25 text-amber-300 flex items-center justify-center">
              <Dumbbell className="w-5 h-5" />
            </div>
            <h3 className="text-base font-black text-white">Physical &amp; Muscle Mapping</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Interactive anatomical matrix tracking physical volume and conditioning across major muscle groups.
            </p>
          </div>

          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 flex items-center justify-center">
              <Activity className="w-5 h-5" />
            </div>
            <h3 className="text-base font-black text-white">Life Equilibrium Radar</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Equilibrium radar visualizing balance across Body, Mind, Spirit, Financial Treasury, and Personal Missions.
            </p>
          </div>

          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-sky-500/10 border border-sky-500/25 text-sky-400 flex items-center justify-center">
              <Brain className="w-5 h-5" />
            </div>
            <h3 className="text-base font-black text-white">Cognitive Focus &amp; Sleep</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Log deep work sessions, cognitive clarity, mental endurance, and restorative sleep metrics.
            </p>
          </div>

          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/25 text-rose-300 flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-base font-black text-white">Quit Protocols &amp; Slips</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              First-class slip logging preserving clean days, savings metrics, and streak resilience without erasing history.
            </p>
          </div>

          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/25 text-purple-300 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-base font-black text-white">Spiritual &amp; Mindful Rhythms</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Cultivate daily meditation, gratitude journaling, stillness, and value-based alignment.
            </p>
          </div>

          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/10 border border-amber-400/25 text-amber-300 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="text-base font-black text-white">100% Offline Vault Storage</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              All state writes instantly to client IndexedDB. Full privacy with zero lock-in, with optional cloud sync.
            </p>
          </div>
        </div>
      </section>

      {/* ── Footer ─────────────────────────────────────────────── */}
      <footer className="max-w-6xl mx-auto px-6 pt-12 border-t border-white/[0.07] text-center text-xs text-slate-500">
        <p>© 2026 Aureus. Local-first whole-life architecture.</p>
      </footer>
    </div>
  );
};

export default ProductLandingView;