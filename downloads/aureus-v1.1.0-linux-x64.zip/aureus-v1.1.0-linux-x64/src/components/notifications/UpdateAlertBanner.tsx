// Aureus — Floating In-App Update Alert Banner
// Alerts the user whenever a newer version is discovered in the release manifest.

import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  updateChecker,
  AppUpdateCheckResult,
  detectPlatform,
  packageFor,
} from '../../domain/releaseService';
import {
  Sparkles,
  Download,
  X,
  ExternalLink,
  ArrowRight,
  ShieldAlert,
  Clock,
} from 'lucide-react';

export const UpdateAlertBanner: React.FC = () => {
  const { setActiveView } = useApp();
  const [updateInfo, setUpdateInfo] = useState<AppUpdateCheckResult | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Start periodic background checks
    updateChecker.startPeriodicCheck(20 * 60 * 1000); // Check every 20 minutes

    const unsubscribe = updateChecker.subscribe((res) => {
      if (res.updateAvailable && res.latestVersion) {
        // Check if user permanently dismissed this exact version
        const lastDismissed = typeof localStorage !== 'undefined'
          ? localStorage.getItem('aureus_dismissed_update_v')
          : null;

        if (lastDismissed !== res.latestVersion) {
          setUpdateInfo(res);
          setDismissed(false);
        }
      } else {
        setUpdateInfo(null);
      }
    });

    return unsubscribe;
  }, []);

  if (!updateInfo || !updateInfo.updateAvailable || dismissed) {
    return null;
  }

  const latest = updateInfo.release;
  const version = updateInfo.latestVersion || 'Latest';
  const thisPlatform = detectPlatform();
  const matchedPkg = packageFor(updateInfo.manifest, version, thisPlatform);

  const handleDismissSession = () => {
    setDismissed(true);
  };

  const handleDismissForever = () => {
    if (typeof localStorage !== 'undefined' && updateInfo.latestVersion) {
      localStorage.setItem('aureus_dismissed_update_v', updateInfo.latestVersion);
    }
    setDismissed(true);
  };

  const handleOpenSettings = () => {
    setActiveView('settings');
    setDismissed(true);
  };

  return (
    <aside
      aria-label="Software Update Alert"
      className="fixed bottom-20 sm:bottom-6 right-4 left-4 sm:left-auto sm:w-[440px] z-[9998] pointer-events-none animate-bounceIn"
    >
      <div className="pointer-events-auto rounded-3xl bg-[#0c0f17]/95 border border-amber-400/40 p-5 shadow-2xl backdrop-blur-2xl ring-1 ring-amber-400/20 text-white flex flex-col gap-3.5">
        {/* Header: Icon, Version Badge & Dismiss */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/15 border border-amber-400/30 text-amber-300 flex items-center justify-center shrink-0 shadow-glow-sm">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  Update Available
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  v{updateInfo.installedVersion} → v{version}
                </span>
              </div>
              <h4 className="text-sm font-black text-white truncate mt-0.5">
                Aureus v{version} is Ready
              </h4>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDismissSession}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Dismiss for now"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Highlight Summary */}
        <p className="text-xs text-slate-300 leading-relaxed">
          {latest?.highlight || 'A new build with enhanced features, security improvements, and optimizations is ready.'}
        </p>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/[0.08]">
          <button
            type="button"
            onClick={handleDismissForever}
            className="text-[11px] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            Skip this version
          </button>

          <div className="flex items-center gap-2">
            {matchedPkg && (
              <a
                href={matchedPkg.downloadUrl}
                download
                className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" />
                <span>Quick Download</span>
              </a>
            )}

            <button
              type="button"
              onClick={handleOpenSettings}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-glow-sm"
            >
              <span>View &amp; Track</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default UpdateAlertBanner;
