// Aureus Chronos — In-App Floating Meeting Alert & Notification Banner
// Works across Web, Electron Desktop, and Mobile to guarantee notifications even if OS permissions are muted.

import React, { useState, useEffect } from 'react';
import { notificationManager, ScheduledNotificationItem } from '../../native/notificationService';
import { soundFx } from '../../utils/soundEffects';
import { Bell, Video, X, Clock, ExternalLink, Calendar } from 'lucide-react';

interface ActiveAlert {
  item: ScheduledNotificationItem;
  id: string;
  title: string;
  body: string;
  url?: string;
  timeStr: string;
}

export const MeetingAlertBanner: React.FC = () => {
  const [alerts, setAlerts] = useState<ActiveAlert[]>([]);

  useEffect(() => {
    const unsubscribe = notificationManager.onNotificationTriggered((item) => {
      // Play harmonic chime
      soundFx.playMeetingChime();

      const newAlert: ActiveAlert = {
        item,
        id: `${item.id}_${Date.now()}`,
        title: item.title,
        body: item.body,
        url: item.url,
        timeStr: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setAlerts((prev) => [newAlert, ...prev.slice(0, 2)]); // Keep max 3 alerts
    });

    return unsubscribe;
  }, []);

  const dismissAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  const snoozeAlert = (alert: ActiveAlert) => {
    dismissAlert(alert.id);
    // Re-trigger in 5 minutes
    setTimeout(() => {
      soundFx.playMeetingChime();
      setAlerts((prev) => [
        {
          ...alert,
          id: `${alert.item.id}_snooze_${Date.now()}`,
          title: `⏰ Snoozed: ${alert.title}`,
        },
        ...prev,
      ]);
    }, 5 * 60 * 1000);
  };

  if (alerts.length === 0) return null;

  return (
    <aside aria-label="Meeting Alerts" className="fixed top-4 right-4 left-4 sm:left-auto sm:w-[420px] z-[9999] space-y-3 pointer-events-none">
      {alerts.map((alert) => {
        const isMeeting = alert.item.targetType === 'meeting';
        const hasUrl = !!alert.url && (alert.url.startsWith('http://') || alert.url.startsWith('https://'));

        return (
          <div
            key={alert.id}
            className="pointer-events-auto rounded-3xl bg-[#0e121b]/95 border border-amber-400/40 p-4 sm:p-5 shadow-2xl backdrop-blur-xl animate-bounceIn flex flex-col gap-3 text-white ring-1 ring-amber-400/20"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-2xl bg-amber-400/15 border border-amber-400/30 text-amber-300 flex items-center justify-center shrink-0 animate-pulse">
                  {isMeeting ? <Calendar className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                      {isMeeting ? 'Meeting Reminder' : 'Reminder'}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {alert.timeStr}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-white truncate mt-1">
                    {alert.title}
                  </h4>
                </div>
              </div>

              <button
                type="button"
                onClick={() => dismissAlert(alert.id)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {alert.body && (
              <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed pl-1">
                {alert.body}
              </p>
            )}

            <div className="flex items-center gap-2 pt-1 border-t border-white/[0.08]">
              {hasUrl && (
                <a
                  href={alert.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => dismissAlert(alert.id)}
                  className="btn-primary !py-2 !px-3 !text-xs !rounded-xl flex-1 flex items-center justify-center gap-1.5 cursor-pointer !shadow-glow-sm"
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Join Meeting</span>
                  <ExternalLink className="w-3 h-3 opacity-70" />
                </a>
              )}

              <button
                type="button"
                onClick={() => snoozeAlert(alert)}
                className="py-2 px-3 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-bold text-slate-300 transition-colors cursor-pointer"
              >
                Snooze 5m
              </button>

              <button
                type="button"
                onClick={() => dismissAlert(alert.id)}
                className="py-2 px-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 text-xs font-bold text-slate-400 hover:text-white transition-colors cursor-pointer ml-auto"
              >
                Dismiss
              </button>
            </div>
          </div>
        );
      })}
    </aside>
  );
};
