import React from 'react';
import {
  Flame,
  Droplet,
  Book,
  Dumbbell,
  Code,
  Moon,
  Heart,
  Coffee,
  CheckCircle2,
  Smile,
  Target,
  Sparkles,
  Zap,
  Sun,
  Shield,
  Briefcase,
  User,
  Folder,
  Tag,
  Calendar,
  Layers,
  LucideProps,
} from 'lucide-react';

interface IconHelperProps extends LucideProps {
  name: string;
}

export const IconHelper: React.FC<IconHelperProps> = ({ name, ...props }) => {
  switch (name?.toLowerCase()) {
    case 'flame':
    case 'fire':
      return <Flame {...props} />;
    case 'droplet':
    case 'water':
      return <Droplet {...props} />;
    case 'book':
    case 'reading':
      return <Book {...props} />;
    case 'dumbbell':
    case 'exercise':
    case 'workout':
      return <Dumbbell {...props} />;
    case 'code':
    case 'coding':
      return <Code {...props} />;
    case 'moon':
    case 'sleep':
      return <Moon {...props} />;
    case 'heart':
    case 'health':
      return <Heart {...props} />;
    case 'coffee':
      return <Coffee {...props} />;
    case 'smile':
      return <Smile {...props} />;
    case 'target':
      return <Target {...props} />;
    case 'sparkles':
      return <Sparkles {...props} />;
    case 'zap':
      return <Zap {...props} />;
    case 'sun':
      return <Sun {...props} />;
    case 'shield':
      return <Shield {...props} />;
    case 'briefcase':
    case 'work':
      return <Briefcase {...props} />;
    case 'user':
    case 'personal':
      return <User {...props} />;
    case 'folder':
      return <Folder {...props} />;
    case 'tag':
      return <Tag {...props} />;
    case 'calendar':
      return <Calendar {...props} />;
    case 'layers':
      return <Layers {...props} />;
    default:
      return <CheckCircle2 {...props} />;
  }
};
