import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { TaskItem } from './TaskItem';
import { TaskQuickAdd } from './TaskQuickAdd';
import { TaskService } from '../../domain/taskService';
import { Priority, Task } from '../../types';
import {
  CheckSquare,
  Plus,
  Search,
  X,
} from 'lucide-react';

type TaskTab = 'all' | 'today' | 'upcoming' | 'someday' | 'completed';
type TaskSort = 'default' | 'dueDate' | 'priority' | 'title';

export const TasksView: React.FC = () => {
  const {
    tasks,
    projects,
    tags,
    selectedProjectId,
    setSelectedProjectId,
    selectedPriority,
    setSelectedPriority,
    selectedTagId,
    setSelectedTagId,
    setIsTaskModalOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<TaskTab>('all');
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<TaskSort>('default');

  // Counts for tabs
  const tabCounts = useMemo(() => {
    let allActive = 0;
    let todayOverdue = 0;
    let upcoming = 0;
    let someday = 0;
    let completed = 0;

    for (const t of tasks) {
      if (t.completed) {
        completed++;
      } else {
        allActive++;
        if (TaskService.isDueToday(t) || TaskService.isOverdue(t)) todayOverdue++;
        if (TaskService.isUpcoming(t)) upcoming++;
        if (!t.dueDate) someday++;
      }
    }

    return { allActive, todayOverdue, upcoming, someday, completed };
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    let result = tasks.filter((task) => {
      // 1. Search Query
      if (search.trim()) {
        const query = search.toLowerCase();
        const matchTitle = task.title.toLowerCase().includes(query);
        const matchDesc = task.description?.toLowerCase().includes(query);
        if (!matchTitle && !matchDesc) return false;
      }

      // 2. Project Filter
      if (selectedProjectId && task.projectId !== selectedProjectId) {
        return false;
      }

      // 3. Priority Filter
      if (selectedPriority && task.priority !== selectedPriority) {
        return false;
      }

      // 4. Tag Filter
      if (selectedTagId && !task.tags?.includes(selectedTagId)) {
        return false;
      }

      // 5. Tab Filter
      if (activeTab === 'completed') {
        return task.completed;
      }

      // Active tabs ignore completed tasks
      if (task.completed) return false;

      if (activeTab === 'today') {
        return TaskService.isDueToday(task) || TaskService.isOverdue(task);
      } else if (activeTab === 'upcoming') {
        return TaskService.isUpcoming(task);
      } else if (activeTab === 'someday') {
        return !task.dueDate;
      }

      return true;
    });

    // Sort order
    if (sortBy === 'dueDate') {
      result = [...result].sort((a, b) => {
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return a.dueDate.localeCompare(b.dueDate);
      });
    } else if (sortBy === 'priority') {
      const order: Record<Priority, number> = { p1: 1, p2: 2, p3: 3, p4: 4 };
      result = [...result].sort((a, b) => order[a.priority] - order[b.priority]);
    } else if (sortBy === 'title') {
      result = [...result].sort((a, b) => a.title.localeCompare(b.title));
    }

    return result;
  }, [tasks, activeTab, search, selectedProjectId, selectedPriority, selectedTagId, sortBy]);

  const activeProject = useMemo(() => {
    return projects.find((p) => p.id === selectedProjectId);
  }, [projects, selectedProjectId]);

  const activeTag = useMemo(() => {
    return tags.find((t) => t.id === selectedTagId);
  }, [tags, selectedTagId]);

  return (
    <div className="space-y-6 pb-16 max-w-5xl mx-auto select-none">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 stagger-1">
        <div>
          <div className="inline-flex items-center gap-1.5 badge-brand mb-1">
            <CheckSquare className="w-3 h-3" />
            <span>Task Registry</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2.5">
            {activeProject ? (
              <span className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full shadow-xs" style={{ backgroundColor: activeProject.color }} />
                <span>{activeProject.name}</span>
              </span>
            ) : (
              'All Tasks'
            )}
          </h1>
        </div>

        <button
          onClick={() => setIsTaskModalOpen(true)}
          className="btn-primary px-4 py-2 text-xs flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Task</span>
        </button>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="glass rounded-2xl p-3 sm:p-4 space-y-3 border border-white/[0.07] shadow-brand-md stagger-2">
        <div className="flex flex-col sm:flex-row items-center gap-2.5">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search deliverables, tags, notes..."
              className="w-full pl-9 pr-4 py-2 bg-white/[0.03] border border-white/[0.08] rounded-xl text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-cyan-400/40"
            />
          </div>

          {/* Project Dropdown Filter */}
          <select
            value={selectedProjectId || ''}
            onChange={(e) => setSelectedProjectId(e.target.value || null)}
            className="w-full sm:w-auto px-3 py-2 bg-[#0E1118] border border-white/[0.08] rounded-xl text-xs text-zinc-300 focus:outline-none focus:border-cyan-400/40 cursor-pointer"
          >
            <option value="">All Projects</option>
            <option value="inbox">Inbox</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>

          {/* Priority Dropdown Filter */}
          <select
            value={selectedPriority || ''}
            onChange={(e) => setSelectedPriority((e.target.value as Priority) || null)}
            className="w-full sm:w-auto px-3 py-2 bg-[#0E1118] border border-white/[0.08] rounded-xl text-xs text-zinc-300 focus:outline-none focus:border-cyan-400/40 cursor-pointer"
          >
            <option value="">All Priorities</option>
            <option value="p1">P1 Urgent</option>
            <option value="p2">P2 High</option>
            <option value="p3">P3 Medium</option>
            <option value="p4">P4 Low</option>
          </select>

          {/* Sort By Select */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as TaskSort)}
            className="w-full sm:w-auto px-3 py-2 bg-[#0E1118] border border-white/[0.08] rounded-xl text-xs text-zinc-300 focus:outline-none focus:border-cyan-400/40 cursor-pointer"
          >
            <option value="default">Default Order</option>
            <option value="dueDate">Due Date</option>
            <option value="priority">Priority</option>
            <option value="title">Title (A-Z)</option>
          </select>
        </div>

        {/* Active Filter Pills (if any) */}
        {(selectedProjectId || selectedPriority || selectedTagId) && (
          <div className="flex items-center gap-2 flex-wrap pt-1 text-xs">
            <span className="text-zinc-500 text-[11px] font-medium">Filtered by:</span>
            {activeProject && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-white/[0.06] border border-white/[0.1] text-zinc-200 text-[11px]">
                <span>Project: {activeProject.name}</span>
                <button
                  onClick={() => setSelectedProjectId(null)}
                  className="hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {selectedPriority && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-[11px] font-semibold">
                <span>Priority: {selectedPriority.toUpperCase()}</span>
                <button
                  onClick={() => setSelectedPriority(null)}
                  className="hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {activeTag && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-[#38BDF8]/15 border border-[#38BDF8]/30 text-[#38BDF8] text-[11px] font-semibold">
                <span>Tag: #{activeTag.name}</span>
                <button
                  onClick={() => setSelectedTagId(null)}
                  className="hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
          </div>
        )}

        {/* View Tabs with live counts */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1 border-t border-white/[0.06]">
          {[
            { id: 'all', label: `All Active (${tabCounts.allActive})` },
            { id: 'today', label: `Today & Overdue (${tabCounts.todayOverdue})` },
            { id: 'upcoming', label: `Upcoming (${tabCounts.upcoming})` },
            { id: 'someday', label: `No Date (${tabCounts.someday})` },
            { id: 'completed', label: `Completed (${tabCounts.completed})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white/[0.1] text-white border border-white/[0.14] shadow-aureus-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Inline Quick Add */}
      {activeTab !== 'completed' && <TaskQuickAdd />}

      {/* Task List */}
      <div className="space-y-2 stagger-3">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12 rounded-3xl border border-dashed border-white/10 bg-white/[0.01] p-8">
            <CheckSquare className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-white">No tasks matching criteria</h3>
            <p className="text-xs text-zinc-500 max-w-sm mx-auto mt-1 mb-4">
              {activeTab === 'completed'
                ? 'No completed tasks logged yet.'
                : 'No active tasks match current filter parameters. Add one above.'}
            </p>
            {activeTab !== 'completed' && (
              <button
                onClick={() => setIsTaskModalOpen(true)}
                className="btn-primary px-4 py-2 text-xs font-bold"
              >
                Create Task
              </button>
            )}
          </div>
        ) : (
          filteredTasks.map((task) => <TaskItem key={task.id} task={task} />)
        )}
      </div>
    </div>
  );
};

export default TasksView;
