import React, { useState, useMemo } from 'react';
import { Task, Priority, RecurrenceType, Subtask } from '../../types';
import { useApp } from '../../context/AppContext';
import { detectTaskConflicts } from '../../domain/scheduleConflictService';
import {
  X,
  Calendar,
  Plus,
  Trash2,
  Check,
  Repeat,
  CheckSquare,
  Tag,
  Folder,
  Clock,
  AlertTriangle,
  ArrowRight,
  DollarSign,
  Layers,
  Flag,
} from 'lucide-react';
import { format, addDays, nextSaturday, nextMonday } from 'date-fns';

export const TaskDetailModal: React.FC = () => {
  const {
    editingTask,
    setEditingTask,
    setIsTaskModalOpen,
    createTask,
    updateTask,
    projects,
    tags,
    meetings,
    tasks,
  } = useApp();

  const [title, setTitle] = useState(editingTask?.title || '');
  const [description, setDescription] = useState(editingTask?.description || '');
  const [priority, setPriority] = useState<Priority>(editingTask?.priority || 'p4');
  const [projectId, setProjectId] = useState<string>(editingTask?.projectId || 'inbox');
  const [sprintId, setSprintId] = useState<string>(editingTask?.sprintId || '');
  const [billableAmount, setBillableAmount] = useState<number>(editingTask?.billableAmount || 0);
  const [dueDate, setDueDate] = useState<string | null>(
    editingTask?.dueDate
      ? editingTask.dueDate.includes('T')
        ? editingTask.dueDate.split('T')[0]
        : editingTask.dueDate
      : format(new Date(), 'yyyy-MM-dd')
  );
  const [scheduledTime, setScheduledTime] = useState<string>(
    editingTask?.scheduledTime ||
      (editingTask?.dueDate?.includes('T') ? editingTask.dueDate.split('T')[1].slice(0, 5) : '')
  );
  const [recurrenceType, setRecurrenceType] = useState<RecurrenceType>(
    editingTask?.recurrence?.type || 'none'
  );
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>(editingTask?.tags || []);
  const [subtasks, setSubtasks] = useState<Subtask[]>(editingTask?.subtasks || []);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  // Selected project object
  const selectedProject = useMemo(() => {
    return projects.find((p) => p.id === projectId);
  }, [projects, projectId]);

  // Live schedule conflict detection
  const conflictInfo = useMemo(() => {
    return detectTaskConflicts(
      {
        id: editingTask?.id,
        title,
        dueDate,
        scheduledTime: scheduledTime || null,
      },
      meetings,
      tasks
    );
  }, [editingTask?.id, title, dueDate, scheduledTime, meetings, tasks]);

  const handleAddSubtask = () => {
    if (!newSubtaskTitle.trim()) return;
    const newSt: Subtask = {
      id: 'sub_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: newSubtaskTitle.trim(),
      completed: false,
    };
    setSubtasks([...subtasks, newSt]);
    setNewSubtaskTitle('');
  };

  const handleToggleSubtask = (stId: string) => {
    setSubtasks(
      subtasks.map((st) => (st.id === stId ? { ...st, completed: !st.completed } : st))
    );
  };

  const handleDeleteSubtask = (stId: string) => {
    setSubtasks(subtasks.filter((st) => st.id !== stId));
  };

  const toggleTag = (tagId: string) => {
    if (selectedTagIds.includes(tagId)) {
      setSelectedTagIds(selectedTagIds.filter((t) => t !== tagId));
    } else {
      setSelectedTagIds([...selectedTagIds, tagId]);
    }
  };

  const handleQuickDate = (type: 'today' | 'tomorrow' | 'weekend' | 'next_week' | 'clear') => {
    const today = new Date();
    if (type === 'today') setDueDate(format(today, 'yyyy-MM-dd'));
    else if (type === 'tomorrow') setDueDate(format(addDays(today, 1), 'yyyy-MM-dd'));
    else if (type === 'weekend') setDueDate(format(nextSaturday(today), 'yyyy-MM-dd'));
    else if (type === 'next_week') setDueDate(format(nextMonday(today), 'yyyy-MM-dd'));
    else if (type === 'clear') {
      setDueDate(null);
      setScheduledTime('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const payload: Partial<Task> = {
      title: title.trim(),
      description: description.trim(),
      priority,
      projectId,
      sprintId: sprintId || undefined,
      billableAmount: billableAmount > 0 ? billableAmount : undefined,
      tags: selectedTagIds,
      dueDate,
      scheduledTime: scheduledTime.trim() ? scheduledTime.trim() : null,
      recurrence: { type: recurrenceType },
      subtasks,
    };

    if (editingTask) {
      await updateTask(editingTask.id, payload);
    } else {
      await createTask(payload);
    }

    handleClose();
  };

  const handleClose = () => {
    setEditingTask(null);
    setIsTaskModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-hidden animate-fadeIn">
      <div className="glass rounded-[2rem] border border-white/10 w-full max-w-2xl sm:max-w-3xl shadow-2xl flex flex-col max-h-[90vh] sm:max-h-[85vh] my-auto relative text-white">
        {/* 1. STICKY HEADER */}
        <div className="shrink-0 p-5 sm:px-7 sm:py-5 border-b border-white/[0.08] flex items-center justify-between bg-white/[0.02]">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-tight">
                {editingTask ? 'Edit Task' : 'Create New Task'}
              </h2>
              <p className="text-xs text-slate-400">Context, schedule, priorities &amp; deliverables</p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 2. FORM & SCROLLABLE CONTENT BODY */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden">
          <div className="flex-1 min-h-0 overflow-y-auto p-5 sm:p-7 space-y-5">
            {/* Task Title */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Task Title *
              </label>
              <input
                type="text"
                required
                autoFocus
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Finalize Q4 high-impact architecture plan"
                className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 hover:border-white/20 text-white placeholder:text-zinc-400 text-sm font-semibold focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 transition-all"
              />
            </div>

            {/* Notes & Context */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Notes &amp; Context
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add deliverables, criteria, links or context..."
                className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 hover:border-white/20 text-white placeholder:text-zinc-400 text-xs focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 transition-all resize-none"
              />
            </div>

            {/* Two-Column Grid: Left: Project/Priority, Right: Schedule/Time */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
              {/* Left Column: Priority & Project */}
              <div className="space-y-4">
                {/* Priority Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                    <Flag className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Priority</span>
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { id: 'p1', label: 'P1 Urgent', active: 'border-rose-500 bg-rose-500/20 text-rose-300 font-bold shadow-sm' },
                      { id: 'p2', label: 'P2 High', active: 'border-amber-500 bg-amber-500/20 text-amber-300 font-bold shadow-sm' },
                      { id: 'p3', label: 'P3 Med', active: 'border-blue-500 bg-blue-500/20 text-blue-300 font-bold shadow-sm' },
                      { id: 'p4', label: 'P4 Low', active: 'border-slate-400 bg-slate-500/20 text-slate-200 font-bold' },
                    ].map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setPriority(p.id as Priority)}
                        className={`py-2 px-1 rounded-xl text-xs font-semibold border transition-all text-center cursor-pointer ${
                          priority === p.id
                            ? p.active
                            : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-white hover:bg-white/[0.05]'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Project Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                    <Folder className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Target Project</span>
                  </label>
                  <select
                    value={projectId}
                    onChange={(e) => {
                      setProjectId(e.target.value);
                      setSprintId('');
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 hover:border-white/20 text-white text-xs focus:outline-none focus:border-cyan-400"
                  >
                    <option value="inbox">📥 Inbox (Unassigned)</option>
                    {projects.map((proj) => (
                      <option key={proj.id} value={proj.id}>
                        {proj.kind === 'client' ? '💼' : '📁'} {proj.name} {proj.clientName ? `(${proj.clientName})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Recurrence Cadence */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                    <Repeat className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Repeat Cadence</span>
                  </label>
                  <select
                    value={recurrenceType}
                    onChange={(e) => setRecurrenceType(e.target.value as RecurrenceType)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/10 hover:border-white/20 text-white text-xs focus:outline-none focus:border-cyan-400"
                  >
                    <option value="none">Does not repeat</option>
                    <option value="daily">Daily</option>
                    <option value="weekdays">Weekdays (Mon-Fri)</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                  </select>
                </div>
              </div>

              {/* Right Column: Schedule, Time & Conflict */}
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.08] space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Target Due Date</span>
                    </label>
                    {dueDate && (
                      <button
                        type="button"
                        onClick={() => {
                          handleQuickDate('clear');
                        }}
                        className="text-[11px] text-rose-400 hover:text-rose-300 font-semibold cursor-pointer"
                      >
                        Clear date
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <input
                        type="date"
                        value={dueDate || ''}
                        onChange={(e) => setDueDate(e.target.value || null)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <input
                        type="time"
                        value={scheduledTime}
                        onChange={(e) => setScheduledTime(e.target.value)}
                        placeholder="HH:mm"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>

                  {/* Quick Preset Chips */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[
                      { id: 'today', label: 'Today' },
                      { id: 'tomorrow', label: 'Tomorrow' },
                      { id: 'weekend', label: 'Weekend' },
                      { id: 'next_week', label: 'Next Week' },
                    ].map((chip) => (
                      <button
                        key={chip.id}
                        type="button"
                        onClick={() => handleQuickDate(chip.id as any)}
                        className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-white/[0.03] hover:bg-white/[0.08] text-slate-300 hover:text-white border border-white/5 transition-colors cursor-pointer"
                      >
                        {chip.label}
                      </button>
                    ))}
                  </div>

                  {/* Real-time Schedule Conflict Warning */}
                  {conflictInfo.hasConflict && (
                    <div className="p-3 rounded-xl border border-rose-500/40 bg-rose-500/[0.08] text-rose-200 text-xs space-y-1.5 animate-fadeIn">
                      <div className="flex items-start gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                        <p className="font-semibold text-rose-300 text-[11px] leading-tight">
                          {conflictInfo.summaryMessage}
                        </p>
                      </div>
                      {conflictInfo.suggestedSlots.length > 0 && (
                        <div className="flex items-center gap-1.5 flex-wrap pt-1">
                          {conflictInfo.suggestedSlots.map((slot, i) => (
                            <button
                              key={i}
                              type="button"
                              onClick={() => setScheduledTime(slot.startTime)}
                              className="px-2 py-0.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-[10px] font-semibold flex items-center gap-1 transition-all cursor-pointer"
                            >
                              <ArrowRight className="w-2.5 h-2.5 text-cyan-400" />
                              <span>Shift to {slot.startTime}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Client Sprints & Billable Financials (Conditional) */}
            {selectedProject && (selectedProject.sprints?.length || selectedProject.kind === 'client') ? (
              <div className="p-4 rounded-2xl bg-cyan-500/[0.04] border border-cyan-500/20 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-cyan-300">
                  <span className="flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Project Sprint &amp; Commercial Billing</span>
                  </span>
                  {selectedProject.kind === 'client' && (
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      Client: {selectedProject.clientName || 'Assigned'}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {selectedProject.sprints && selectedProject.sprints.length > 0 && (
                    <div>
                      <label className="block text-[10px] text-slate-400 font-mono mb-1">Assigned Sprint / Milestone</label>
                      <select
                        value={sprintId}
                        onChange={(e) => setSprintId(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                      >
                        <option value="">No sprint assigned</option>
                        {selectedProject.sprints.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} ({s.status}) - ${s.expectedIncome}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">
                      Task Billable Amount ({selectedProject.currency || 'USD'})
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-mono">$</span>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={billableAmount || ''}
                        onChange={(e) => setBillableAmount(parseFloat(e.target.value) || 0)}
                        placeholder="0.00"
                        className="w-full pl-7 pr-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ) : null}

            {/* Subtasks Section */}
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.08] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Subtasks &amp; Checklists
                </span>
                {subtasks.length > 0 && (
                  <span className="text-[10px] font-mono text-cyan-400">
                    {subtasks.filter((s) => s.completed).length}/{subtasks.length} completed
                  </span>
                )}
              </div>

              {subtasks.length > 0 && (
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {subtasks.map((st) => (
                    <div
                      key={st.id}
                      className="flex items-center justify-between gap-2 p-2 rounded-xl bg-white/[0.02] border border-white/5"
                    >
                      <div className="flex items-center gap-2.5 flex-1 min-w-0">
                        <button
                          type="button"
                          onClick={() => handleToggleSubtask(st.id)}
                          className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 cursor-pointer ${
                            st.completed
                              ? 'bg-emerald-500 border-emerald-500 text-slate-950'
                              : 'border-white/20 hover:border-emerald-500'
                          }`}
                        >
                          {st.completed && <Check className="w-3 h-3 stroke-[3]" />}
                        </button>
                        <span className={`text-xs truncate ${st.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                          {st.title}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDeleteSubtask(st.id)}
                        className="text-slate-400 hover:text-rose-400 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newSubtaskTitle}
                  onChange={(e) => setNewSubtaskTitle(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddSubtask();
                    }
                  }}
                  placeholder="Add a subtask item..."
                  className="flex-1 px-3.5 py-2 rounded-xl bg-white/[0.04] border border-white/10 hover:border-white/20 text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="button"
                  onClick={handleAddSubtask}
                  className="px-3.5 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-white text-xs font-bold border border-white/10 cursor-pointer"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Context Tags */}
            {tags.length > 0 && (
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5" />
                  <span>Tags</span>
                </label>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {tags.map((tg) => {
                    const isSelected = selectedTagIds.includes(tg.id);
                    return (
                      <button
                        key={tg.id}
                        type="button"
                        onClick={() => toggleTag(tg.id)}
                        style={{
                          backgroundColor: isSelected ? `${tg.color}25` : undefined,
                          borderColor: isSelected ? tg.color : undefined,
                          color: isSelected ? tg.color : undefined,
                        }}
                        className={`px-3 py-1 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                          isSelected
                            ? 'font-bold shadow-xs'
                            : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-white hover:bg-white/[0.05]'
                        }`}
                      >
                        #{tg.name}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* 3. STICKY FOOTER (ALWAYS VISIBLE - NEVER HIDDEN BEHIND SCROLL) */}
          <div className="shrink-0 px-6 py-4 border-t border-white/[0.08] bg-[#0c0f17]/95 backdrop-blur-md flex items-center justify-between">
            <div className="text-[11px] text-zinc-500 font-mono hidden sm:block">
              Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-semibold">Enter</kbd> to save
            </div>
            <div className="flex items-center gap-3 ml-auto">
              <button
                type="button"
                onClick={handleClose}
                className="px-5 py-2.5 rounded-xl text-xs font-semibold text-zinc-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary !px-6 !py-2.5 !text-xs !rounded-xl font-bold"
              >
                {editingTask ? 'Save Changes' : 'Create Task'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TaskDetailModal;
