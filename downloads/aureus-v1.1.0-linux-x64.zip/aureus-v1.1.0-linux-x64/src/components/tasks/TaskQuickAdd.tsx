import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Plus, Calendar, Flag, Hash } from 'lucide-react';
import { format, addDays } from 'date-fns';
import { Priority } from '../../types';

export const TaskQuickAdd: React.FC = () => {
  const { createTask, projects } = useApp();
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<Priority>('p4');
  const [isFocused, setIsFocused] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    await createTask({
      title: title.trim(),
      priority,
      dueDate: format(new Date(), 'yyyy-MM-dd'),
    });

    setTitle('');
    setPriority('p4');
  };

  return (
    <form
      onSubmit={handleSubmit}
      className={`bg-white dark:bg-slate-900/90 border rounded-2xl p-2.5 sm:p-3 transition-all duration-200 shadow-xs ${
        isFocused
          ? 'border-emerald-500/60 ring-2 ring-emerald-500/10'
          : 'border-slate-200 dark:border-slate-800'
      }`}
    >
      <div className="flex items-center gap-2.5">
        <div className="w-6 h-6 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
          <Plus className="w-4 h-4" />
        </div>

        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder="Quick add task for Today... (press Enter)"
          className="flex-1 bg-transparent text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none"
        />

        <div className="flex items-center gap-1.5 shrink-0">
          {/* Quick Priority Toggle */}
          <button
            type="button"
            onClick={() => {
              const next: Record<Priority, Priority> = { p4: 'p1', p1: 'p2', p2: 'p3', p3: 'p4' };
              setPriority(next[priority]);
            }}
            className={`px-2 py-1 rounded-lg text-xs font-bold transition-colors ${
              priority === 'p1'
                ? 'bg-red-500/20 text-red-500'
                : priority === 'p2'
                ? 'bg-amber-500/20 text-amber-500'
                : priority === 'p3'
                ? 'bg-blue-500/20 text-blue-500'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Toggle priority (P1-P4)"
          >
            {priority.toUpperCase()}
          </button>

          <button
            type="submit"
            disabled={!title.trim()}
            className="px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-30 disabled:hover:bg-emerald-500 text-slate-950 font-bold text-xs transition-all cursor-pointer"
          >
            Add
          </button>
        </div>
      </div>
    </form>
  );
};
