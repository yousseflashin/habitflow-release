// Aureus Task Item — Tactile Executive Task Cell
// Micro-interactions, subtask checklist, priority indicators, and overdue handling.

import React, { useMemo } from 'react';
import { Task } from '../../types';
import { useApp } from '../../context/AppContext';
import { TaskService } from '../../domain/taskService';
import { Check, Calendar, Repeat, Tag, Edit2, Trash2, CheckSquare, Clock } from 'lucide-react';
import { format } from 'date-fns';

interface TaskItemProps {
  task: Task;
}

export const TaskItem: React.FC<TaskItemProps> = ({ task }) => {
  const {
    projects,
    tags,
    toggleTaskComplete,
    setEditingTask,
    setIsTaskModalOpen,
    deleteTask,
    updateTask,
  } = useApp();

  const isOverdue = useMemo(() => TaskService.isOverdue(task), [task]);
  const isToday = useMemo(() => TaskService.isDueToday(task), [task]);
  const subtaskProgress = useMemo(() => TaskService.getSubtaskProgress(task), [task]);

  const project = useMemo(() => {
    return projects.find((p) => p.id === task.projectId);
  }, [projects, task.projectId]);

  const taskTags = useMemo(() => {
    return tags.filter((tg) => task.tags?.includes(tg.id));
  }, [tags, task.tags]);

  const priorityColors = {
    p1: { border: 'border-rose-500/50', bg: 'bg-rose-500/15', text: 'text-rose-400', label: 'P1 Urgent' },
    p2: { border: 'border-amber-400/50', bg: 'bg-amber-400/15', text: 'text-amber-300', label: 'P2 High' },
    p3: { border: 'border-sky-400/50', bg: 'bg-sky-400/15', text: 'text-sky-300', label: 'P3 Medium' },
    p4: { border: 'border-white/10', bg: 'bg-white/5', text: 'text-slate-400', label: 'P4 Low' },
  };

  const pConfig = priorityColors[task.priority] || priorityColors.p4;

  const toggleSubtask = async (subtaskId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updatedSubtasks = task.subtasks.map((st) => {
      if (st.id === subtaskId) {
        return {
          ...st,
          completed: !st.completed,
          completedAt: !st.completed ? new Date().toISOString() : null,
        };
      }
      return st;
    });
    await updateTask(task.id, { subtasks: updatedSubtasks });
  };

  return (
    <div
      className={`group rounded-2xl border transition-all duration-200 p-3.5 sm:p-4 flex flex-col gap-2.5 ${
        task.completed
          ? 'bg-black/30 border-white/[0.04] opacity-55'
          : isOverdue
          ? 'bg-[#120b0e] border-rose-500/30 ring-1 ring-rose-500/20'
          : 'bg-[#0c0e14]/90 border-white/[0.08] hover:border-white/20 hover:bg-[#10131c]'
      }`}
    >
      <div className="flex items-start gap-3.5">
        {/* Tactile Checkbox */}
        <button
          type="button"
          onClick={() => toggleTaskComplete(task.id)}
          className={`mt-0.5 w-5 h-5 rounded-lg flex items-center justify-center shrink-0 border transition-all active:scale-90 cursor-pointer ${
            task.completed
              ? 'bg-amber-400 border-amber-400 text-slate-950 shadow-glow-sm'
              : 'border-white/20 hover:border-amber-400 hover:bg-white/[0.04] text-transparent'
          }`}
          title={task.completed ? 'Mark pending' : 'Mark complete'}
        >
          <Check className={`w-3.5 h-3.5 ${task.completed ? 'stroke-[3]' : 'opacity-0'}`} />
        </button>

        {/* Task Main Content */}
        <div
          className="flex-1 min-w-0 cursor-pointer"
          onClick={() => {
            setEditingTask(task);
            setIsTaskModalOpen(true);
          }}
        >
          <div className="flex items-center gap-2 flex-wrap">
            <span
              className={`text-sm font-semibold tracking-wide ${
                task.completed
                  ? 'line-through text-slate-500'
                  : 'text-white'
              }`}
            >
              {task.title}
            </span>

            {task.priority !== 'p4' && !task.completed && (
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${pConfig.border} ${pConfig.bg} ${pConfig.text}`}>
                {pConfig.label}
              </span>
            )}
          </div>

          {task.description && (
            <p className="text-xs text-slate-400 line-clamp-1 mt-1 font-normal">
              {task.description}
            </p>
          )}

          {/* Subtasks summary */}
          {task.subtasks && task.subtasks.length > 0 && (
            <div className="mt-2.5 pt-2 border-t border-white/[0.05] space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1.5 font-medium">
                  <CheckSquare className="w-3 h-3 text-amber-400" />
                  <span>Subtasks ({subtaskProgress.completed}/{subtaskProgress.total})</span>
                </span>
                <span className="font-mono text-[10px] text-slate-400">{subtaskProgress.percentage}%</span>
              </div>
              <div className="w-full bg-white/[0.06] h-1 rounded-full overflow-hidden">
                <div
                  className="bg-amber-400 h-full transition-all duration-300 rounded-full"
                  style={{ width: `${subtaskProgress.percentage}%` }}
                />
              </div>

              <div className="space-y-1 pt-1">
                {task.subtasks.slice(0, 3).map((st) => (
                  <div
                    key={st.id}
                    onClick={(e) => toggleSubtask(st.id, e)}
                    className="flex items-center gap-2 text-xs text-slate-300 hover:text-white cursor-pointer py-0.5 group/sub"
                  >
                    <div
                      className={`w-3.5 h-3.5 rounded border flex items-center justify-center transition-colors ${
                        st.completed
                          ? 'bg-amber-400 border-amber-400 text-slate-950'
                          : 'border-white/20 group-hover/sub:border-white/40'
                      }`}
                    >
                      {st.completed && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                    </div>
                    <span className={st.completed ? 'line-through text-slate-500 text-[11px]' : 'text-[11px]'}>
                      {st.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Metadata Badges */}
          <div className="flex items-center gap-2 flex-wrap mt-2.5 text-[11px]">
            {task.dueDate && (
              <span
                className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg font-mono text-[10px] font-semibold ${
                  task.completed
                    ? 'bg-white/[0.03] text-slate-500'
                    : isOverdue
                    ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                    : isToday
                    ? 'bg-amber-400/15 text-amber-300 border border-amber-400/30'
                    : 'bg-white/[0.04] text-slate-300 border border-white/[0.06]'
                }`}
              >
                <Calendar className="w-3 h-3" />
                <span>
                  {isToday ? 'Today' : isOverdue ? `Overdue (${task.dueDate})` : task.dueDate}
                </span>
              </span>
            )}

            {isOverdue && !task.completed && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  updateTask(task.id, { dueDate: format(new Date(), 'yyyy-MM-dd') });
                }}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-400/10 text-amber-300 hover:bg-amber-400/20 border border-amber-400/25 text-[10px] font-bold cursor-pointer transition-colors"
                title="Reschedule task to today"
              >
                <span>Move to Today</span>
              </button>
            )}

            {task.recurrence && task.recurrence.type !== 'none' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-purple-500/10 text-purple-300 border border-purple-500/25 font-mono text-[10px]">
                <Repeat className="w-3 h-3" />
                <span className="capitalize">{task.recurrence.type}</span>
              </span>
            )}

            {project && (
              <span
                style={{
                  backgroundColor: `${project.color}15`,
                  borderColor: `${project.color}35`,
                  color: project.color,
                }}
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg border text-[10px] font-bold"
              >
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: project.color }} />
                <span>{project.name}</span>
              </span>
            )}

            {taskTags.map((t) => (
              <span
                key={t.id}
                style={{
                  backgroundColor: `${t.color}15`,
                  borderColor: `${t.color}35`,
                  color: t.color,
                }}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg border text-[10px] font-bold"
              >
                <Tag className="w-2.5 h-2.5" />
                <span>#{t.name}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
          <button
            onClick={() => {
              setEditingTask(task);
              setIsTaskModalOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Edit task"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => deleteTask(task.id)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
            title="Delete task"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskItem;