// Aureus Capital — Treasury, Executive Wallet & Wealth Cockpit
// Local-first: persisted to IndexedDB/localStorage with CRDT compatibility.
// Features Multi-Range Cashflow (Monthly, Quarterly, Yearly, All-Time) with Planned & Realized Income/Expense Tracking.

import React, { useMemo, useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Plus,
  Trash2,
  Banknote,
  Landmark,
  PiggyBank,
  CreditCard,
  Bitcoin,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
  Sparkles,
  PieChart,
  DollarSign,
  ArrowRightLeft,
  X,
  ChevronLeft,
  ChevronRight,
  Calendar,
  Layers,
  Repeat,
  CheckCircle2,
  SlidersHorizontal,
  Clock,
  HardDrive,
  BarChart3,
  Shield,
  Zap,
  Briefcase,
} from 'lucide-react';
import {
  AssetType,
  MoneyAccount,
  MoneyAccountType,
  MoneyAsset,
  MoneyTransaction,
  TransactionType,
  TimeframeRange,
  WalletFlowItem,
} from '../../types';
import {
  computeRangeMoneyStats,
  computeFlowItemAmountForRange,
  computeWalletFlowSummary,
  getTimeframeRangeDates,
  fmtMoney,
} from '../../domain/moneyStatsService';
import { getProjectReceivablesSummary } from '../../domain/projectMoneyBridge';
import {
  subMonths,
  addMonths,
  subQuarters,
  addQuarters,
  subYears,
  addYears,
} from 'date-fns';

// ─── Storage ────────────────────────────────────────────────────────
const STORAGE_KEY = 'habitflow_money_v1';

interface MoneyState {
  accounts: MoneyAccount[];
  assets: MoneyAsset[];
  transactions: MoneyTransaction[];
  flowItems: WalletFlowItem[];
}

const DEFAULT_FLOW_ITEMS: WalletFlowItem[] = [
  {
    id: 'flow_salary',
    name: 'Executive Career Salary',
    type: 'income',
    amount: 6500,
    period: 'monthly',
    category: 'Career',
    enabled: true,
    notes: 'Direct corporate deposit',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'flow_advisory',
    name: 'Consulting & Advisory Retainer',
    type: 'income',
    amount: 1500,
    period: 'monthly',
    category: 'Advisory',
    enabled: true,
    notes: 'Private technology consulting',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'flow_dividends',
    name: 'Quarterly Portfolio Dividends',
    type: 'income',
    amount: 1200,
    period: 'quarterly',
    category: 'Investments',
    enabled: true,
    notes: 'Equity index payouts',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'flow_housing',
    name: 'Prime Residence Mortgage / Lease',
    type: 'expense',
    amount: 2200,
    period: 'monthly',
    category: 'Housing',
    enabled: true,
    notes: 'Primary residential commitment',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'flow_groceries',
    name: 'Culinary & Organic Provisions',
    type: 'expense',
    amount: 750,
    period: 'monthly',
    category: 'Food',
    enabled: true,
    notes: 'Household groceries & nutrition',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'flow_tech',
    name: 'Autonomous Cloud & Software Stack',
    type: 'expense',
    amount: 180,
    period: 'monthly',
    category: 'Software',
    enabled: true,
    notes: 'Cloud servers, AI APIs & software',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'flow_wellness',
    name: 'Athletics & Executive Health',
    type: 'expense',
    amount: 220,
    period: 'monthly',
    category: 'Wellness',
    enabled: true,
    notes: 'Athletic facility, training & recovery',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'flow_insurance',
    name: 'Annual Umbrella & Asset Protection',
    type: 'expense',
    amount: 1400,
    period: 'yearly',
    category: 'Insurance',
    enabled: true,
    notes: 'Annual premium liability & property',
    createdAt: new Date().toISOString(),
  },
];

function loadState(): MoneyState {
  if (typeof localStorage === 'undefined') return seedState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<MoneyState>;
      return {
        accounts: parsed.accounts && parsed.accounts.length > 0 ? parsed.accounts : seedState().accounts,
        assets: parsed.assets ?? [],
        transactions: parsed.transactions ?? [],
        flowItems: parsed.flowItems && parsed.flowItems.length > 0 ? parsed.flowItems : DEFAULT_FLOW_ITEMS,
      };
    }
  } catch {
    // Start fresh if corrupted
  }
  return seedState();
}

function saveState(state: MoneyState) {
  if (typeof localStorage === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

const now = () => new Date().toISOString();
const today = () => new Date().toISOString().slice(0, 10);
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

function seedState(): MoneyState {
  return {
    accounts: [
      {
        id: 'acc_primary',
        name: 'Aureus Black • Operating Wallet',
        type: 'bank',
        balance: 14500,
        currency: 'USD',
        color: '#F0C465',
        monthlyIncome: 8000,
        monthlyExpense: 3350,
        createdAt: now(),
        updatedAt: now(),
        deleted: false,
      },
      {
        id: 'acc_reserve',
        name: 'Sovereign Treasury Vault',
        type: 'cash',
        balance: 28000,
        currency: 'USD',
        color: '#10B981',
        createdAt: now(),
        updatedAt: now(),
        deleted: false,
      },
    ],
    assets: [],
    transactions: [],
    flowItems: DEFAULT_FLOW_ITEMS,
  };
}

// ─── Visual Tokens & Icons ──────────────────────────────────────────

const ACCOUNT_ICON: Record<MoneyAccountType, typeof Landmark> = {
  cash: Banknote,
  bank: Landmark,
  investment: PiggyBank,
  credit: CreditCard,
  debt: CreditCard,
};

const ASSET_ICON: Record<AssetType, typeof Bitcoin> = {
  stock: TrendingUp,
  etf: TrendingUp,
  crypto: Bitcoin,
  bond: Landmark,
  commodity: PiggyBank,
  other: Wallet,
};

function assetValue(a: MoneyAsset): number {
  return a.quantity * a.currentPrice;
}

function assetCost(a: MoneyAsset): number {
  return a.quantity * a.avgCost;
}

function fmt(n: number, currency = 'USD'): string {
  const abs = Math.abs(n);
  const str = abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const sign = n < 0 ? '−' : '';
  const sym = currency === 'EUR' ? '€' : currency === 'GBP' ? '£' : '$';
  return `${sign}${sym}${str}`;
}

type Tab = 'wallet' | 'overview' | 'accounts' | 'assets' | 'transactions';

export const MoneyPage: React.FC = () => {
  const { projects, setActiveView, setSelectedProjectId } = useApp();
  const [state, setState] = useState<MoneyState>(loadState);
  const [tab, setTab] = useState<Tab>('wallet');
  const [range, setRange] = useState<TimeframeRange>('monthly');
  const [refDate, setRefDate] = useState<Date>(new Date());

  // Listen for project payment deposits to auto-reload treasury
  useEffect(() => {
    const handleUpdate = () => {
      setState(loadState());
    };
    window.addEventListener('habitflow_money_updated', handleUpdate);
    return () => window.removeEventListener('habitflow_money_updated', handleUpdate);
  }, []);

  // Commercial client receivables & upcoming sprint cashflow pipeline
  const projectReceivables = useMemo(() => {
    return getProjectReceivablesSummary(projects);
  }, [projects]);

  // Modals
  const [showAccountForm, setShowAccountForm] = useState(false);
  const [showAssetForm, setShowAssetForm] = useState(false);
  const [showTxForm, setShowTxForm] = useState(false);
  const [showFlowForm, setShowFlowForm] = useState(false);
  const [flowStreamFilter, setFlowStreamFilter] = useState<'all' | 'income' | 'expense'>('all');

  const persist = (next: MoneyState) => {
    setState(next);
    saveState(next);
  };

  // Range Navigation controls
  const handlePrevRange = () => {
    if (range === 'monthly') setRefDate((d) => subMonths(d, 1));
    else if (range === 'quarterly') setRefDate((d) => subQuarters(d, 1));
    else if (range === 'yearly') setRefDate((d) => subYears(d, 1));
  };

  const handleNextRange = () => {
    if (range === 'monthly') setRefDate((d) => addMonths(d, 1));
    else if (range === 'quarterly') setRefDate((d) => addQuarters(d, 1));
    else if (range === 'yearly') setRefDate((d) => addYears(d, 1));
  };

  const handleCurrentRange = () => {
    setRefDate(new Date());
  };

  // Dynamic Range Analytics for Recorded Transactions
  const rangeStats = useMemo(() => {
    return computeRangeMoneyStats(state.transactions, range, refDate);
  }, [state.transactions, range, refDate]);

  // Dynamic Range Analytics for Planned Wallet Flow Streams
  const flowSummary = useMemo(() => {
    return computeWalletFlowSummary(state.flowItems || [], range);
  }, [state.flowItems, range]);

  // Overall Balance Totals
  const totals = useMemo(() => {
    const liveAccounts = state.accounts.filter((a) => !a.deleted);
    const liveAssets = state.assets.filter((a) => !a.deleted);

    const cash = liveAccounts
      .filter((a) => a.type !== 'credit' && a.type !== 'debt')
      .reduce((s, a) => s + a.balance, 0);

    const debt = liveAccounts
      .filter((a) => a.type === 'credit' || a.type === 'debt')
      .reduce((s, a) => s + Math.abs(a.balance), 0);

    const invested = liveAssets.reduce((s, a) => s + assetValue(a), 0);
    const cost = liveAssets.reduce((s, a) => s + assetCost(a), 0);

    return {
      cash,
      debt,
      invested,
      investedCost: cost,
      investedPnl: invested - cost,
      netWorth: cash + invested - debt,
    };
  }, [state.accounts, state.assets]);

  const TABS: Array<{ id: Tab; label: string; count?: number }> = [
    { id: 'wallet', label: 'Executive Wallet', count: (state.flowItems || []).filter((f) => f.enabled).length },
    { id: 'overview', label: 'Treasury Overview' },
    { id: 'accounts', label: 'Vault Accounts', count: state.accounts.filter((a) => !a.deleted).length },
    { id: 'assets', label: 'Portfolio Assets', count: state.assets.filter((a) => !a.deleted).length },
    { id: 'transactions', label: 'Ledger Journal', count: state.transactions.filter((t) => !t.deleted).length },
  ];

  // ── Mutations ────────────────────────────────────────────────────
  const addAccount = (a: Omit<MoneyAccount, 'id' | 'createdAt' | 'updatedAt' | 'deleted'>) =>
    persist({
      ...state,
      accounts: [...state.accounts, { ...a, id: uid(), createdAt: now(), updatedAt: now(), deleted: false }],
    });

  const removeAccount = (id: string) =>
    persist({ ...state, accounts: state.accounts.map((a) => (a.id === id ? { ...a, deleted: true } : a)) });

  const addAsset = (a: Omit<MoneyAsset, 'id' | 'createdAt' | 'updatedAt' | 'deleted'>) =>
    persist({
      ...state,
      assets: [...state.assets, { ...a, id: uid(), createdAt: now(), updatedAt: now(), deleted: false }],
    });

  const addTx = (t: Omit<MoneyTransaction, 'id' | 'createdAt' | 'updatedAt' | 'deleted'>) => {
    const tx: MoneyTransaction = { ...t, id: uid(), createdAt: now(), updatedAt: now(), deleted: false };
    const accounts = state.accounts.map((a) =>
      a.id === t.accountId ? { ...a, balance: a.balance + t.amount, updatedAt: now() } : a
    );
    persist({ ...state, accounts, transactions: [tx, ...state.transactions] });
  };

  const removeTx = (id: string) => {
    const tx = state.transactions.find((t) => t.id === id);
    if (!tx) return;
    const accounts = state.accounts.map((a) =>
      a.id === tx.accountId ? { ...a, balance: a.balance - tx.amount, updatedAt: now() } : a
    );
    persist({
      ...state,
      accounts,
      transactions: state.transactions.map((t) => (t.id === id ? { ...t, deleted: true, updatedAt: now() } : t)),
    });
  };

  // Flow Items mutations
  const addFlowItem = (item: Omit<WalletFlowItem, 'id' | 'createdAt'>) => {
    const newItem: WalletFlowItem = { ...item, id: uid(), createdAt: now() };
    persist({
      ...state,
      flowItems: [newItem, ...(state.flowItems || [])],
    });
  };

  const toggleFlowItem = (id: string) => {
    persist({
      ...state,
      flowItems: (state.flowItems || []).map((f) => (f.id === id ? { ...f, enabled: !f.enabled } : f)),
    });
  };

  const removeFlowItem = (id: string) => {
    persist({
      ...state,
      flowItems: (state.flowItems || []).filter((f) => f.id !== id),
    });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-24 animate-fadeIn">
      {/* ── Executive Header: Net Worth & Global Range Selector ─────────────── */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#161a24] to-[#0c0e14] border border-white/[0.08] p-6 sm:p-8 shadow-2xl stagger-1 space-y-6">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-cyan-300 text-[11px] font-bold uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" />
              <span>HabitFlow Treasury • Executive Wealth Matrix</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight flex items-center gap-3">
              <span>Treasury &amp; Cashflow Engine</span>
            </h1>
            <p className="text-sm text-slate-400 max-w-xl">
              Local-first wealth cockpit: multi-range cashflow budgeting, planned income vs expense streams, client project receivables, and liquidity management.
            </p>
          </div>

          {/* Action CTAs */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => setShowFlowForm(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-black transition-all flex items-center gap-2 cursor-pointer shadow-cyan-glow active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>+ Cashflow Stream</span>
            </button>
            <button
              onClick={() => setShowAccountForm(true)}
              className="px-4 py-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-200 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Plus className="w-4 h-4 text-cyan-400" />
              <span>+ Account</span>
            </button>
            <button
              onClick={() => setShowTxForm(true)}
              className="px-4 py-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-200 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <ArrowRightLeft className="w-4 h-4 text-emerald-400" />
              <span>Record Entry</span>
            </button>
          </div>
        </div>

        {/* ── Range Selector Sub-Bar (Monthly, Quarterly, Yearly, All-Time) ──────── */}
        <div className="pt-4 border-t border-white/[0.07] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center p-1 rounded-2xl bg-black/50 border border-white/[0.08]">
              {(['monthly', 'quarterly', 'yearly', 'all'] as TimeframeRange[]).map((r) => (
                <button
                  key={r}
                  onClick={() => setRange(r)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                    range === r
                      ? 'bg-indigo-600 text-white font-black shadow-md'
                      : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                  }`}
                >
                  {r === 'all' ? 'All-Time' : r}
                </button>
              ))}
            </div>

            {range !== 'all' && (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handlePrevRange}
                  className="p-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
                  title="Previous Period"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleCurrentRange}
                  className="px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 text-xs font-mono transition-all cursor-pointer"
                >
                  Current
                </button>
                <button
                  onClick={handleNextRange}
                  className="p-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
                  title="Next Period"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
              Active Timeframe Horizon
            </span>
            <span className="text-sm font-black text-cyan-300 font-mono">
              {rangeStats.label}
            </span>
          </div>
        </div>

        {/* ── Key Metrics Ribbon: Range Inflow, Outflow, Net, and Net Worth ─────── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
          {/* Net Worth */}
          <div className="space-y-1 bg-white/[0.02] p-3.5 rounded-2xl border border-white/[0.04]">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5 text-cyan-400" />
              <span>Total Net Worth</span>
            </div>
            <div className="text-2xl font-black text-white tabular-nums tracking-tight">
              {fmt(totals.netWorth)}
            </div>
            <div className="text-[11px] text-slate-400 font-mono truncate">
              {fmt(totals.cash)} liquid · {fmt(totals.invested)} equity
            </div>
          </div>

          {/* Planned Cashflow Range Inflow */}
          <div className="space-y-1 bg-white/[0.02] p-3.5 rounded-2xl border border-white/[0.04]">
            <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span>{rangeStats.label} Inflow</span>
            </div>
            <div className="text-2xl font-black text-emerald-400 tabular-nums tracking-tight">
              +{fmt(flowSummary.totalIncome)}
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              {fmt(flowSummary.monthlyRunrateIncome)}/mo normalized
            </div>
          </div>

          {/* Planned Cashflow Range Outflow */}
          <div className="space-y-1 bg-white/[0.02] p-3.5 rounded-2xl border border-white/[0.04]">
            <div className="text-[11px] font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
              <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
              <span>{rangeStats.label} Outflow</span>
            </div>
            <div className="text-2xl font-black text-rose-400 tabular-nums tracking-tight">
              −{fmt(flowSummary.totalExpense)}
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              {fmt(flowSummary.monthlyRunrateExpense)}/mo normalized
            </div>
          </div>

          {/* Planned Net Retained Margin */}
          <div className="space-y-1 bg-white/[0.02] p-3.5 rounded-2xl border border-white/[0.04]">
            <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>Net Surplus ({flowSummary.savingsRate}%)</span>
            </div>
            <div
              className={`text-2xl font-black tabular-nums tracking-tight ${
                flowSummary.netFlow >= 0 ? 'text-cyan-300' : 'text-rose-400'
              }`}
            >
              {flowSummary.netFlow >= 0 ? '+' : '−'}
              {fmt(flowSummary.netFlow)}
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              {flowSummary.netFlow >= 0 ? '+' : '−'}
              {fmt(flowSummary.monthlyRunrateNet)}/mo runway
            </div>
          </div>
        </div>
      </div>

      {/* ── Segmented Navigation Tabs ────────────────────────────── */}
      <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-black/40 backdrop-blur-md border border-white/[0.08] w-fit stagger-2 flex-wrap">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              tab === t.id
                ? 'bg-indigo-600 text-white font-black shadow-brand-sm'
                : 'text-slate-400 hover:text-slate-200 border border-transparent'
            }`}
          >
            <span>{t.label}</span>
            {t.count !== undefined && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  tab === t.id ? 'bg-white/20 text-white' : 'bg-white/5 text-slate-500'
                }`}
              >
                {t.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* ── TAB 1: EXECUTIVE WALLET (Monthly Income & Expense Engine) ──────────── */}
      {tab === 'wallet' && (
        <div className="space-y-6 stagger-3">
          {/* Digital Luxury Wallet Cards Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Wallet Cards &amp; Accounts</span>
                </span>
                <h2 className="text-xl font-black text-white">Digital Vault Accounts</h2>
              </div>
              <button
                onClick={() => setShowAccountForm(true)}
                className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ New Wallet</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {state.accounts
                .filter((a) => !a.deleted)
                .map((acc, index) => {
                  const isIndigo = index % 3 === 0;
                  const isEmerald = index % 3 === 1;

                  return (
                    <div
                      key={acc.id}
                      className={`relative rounded-3xl p-6 border shadow-2xl overflow-hidden flex flex-col justify-between min-h-[220px] transition-all duration-200 hover:-translate-y-1 group ${
                        isIndigo
                          ? 'bg-gradient-to-br from-[#121626] via-[#0d1220] to-[#090b14] border-indigo-500/30'
                          : isEmerald
                          ? 'bg-gradient-to-br from-[#0e1d17] via-[#0b1411] to-[#0c0e14] border-emerald-500/30'
                          : 'bg-gradient-to-br from-[#151922] via-[#0f121a] to-[#0c0e14] border-white/10'
                      }`}
                    >
                      {/* Decorative Background Glow */}
                      <div
                        className="absolute -right-12 -top-12 w-36 h-36 rounded-full blur-3xl opacity-20 pointer-events-none"
                        style={{ backgroundColor: acc.color || '#38bdf8' }}
                      />

                      {/* Card Top: Chip, Type & Brand */}
                      <div className="flex items-start justify-between relative z-10">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-7 rounded-md bg-gradient-to-tr from-cyan-200 to-indigo-400 border border-cyan-300/40 shadow-sm flex items-center justify-center">
                            <div className="w-5 h-3.5 border border-slate-900/40 rounded-xs" />
                          </div>
                          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">
                            {acc.type}
                          </span>
                        </div>
                        <span className="text-xs font-black text-cyan-300/80 tracking-widest font-mono">
                          HABITFLOW
                        </span>
                      </div>

                      {/* Card Middle: Balance */}
                      <div className="my-4 relative z-10">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                          {acc.name}
                        </span>
                        <div className="text-3xl font-black text-white tracking-tight tabular-nums mt-0.5">
                          {fmt(acc.balance, acc.currency)}
                        </div>
                      </div>

                      {/* Card Bottom: Planned Flow & Target Range Projections */}
                      <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between text-xs relative z-10 font-mono">
                        <div>
                          <span className="text-[9px] uppercase tracking-wider text-slate-400 block">
                            {range.toUpperCase()} INFLOW
                          </span>
                          <span className="font-bold text-emerald-400">
                            +{fmt(flowSummary.totalIncome, acc.currency)}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-[9px] uppercase tracking-wider text-slate-400 block">
                            {range.toUpperCase()} OUTFLOW
                          </span>
                          <span className="font-bold text-rose-400">
                            −{fmt(flowSummary.totalExpense, acc.currency)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* ── Client Projects & Sprint Receivables Inflow ────────────────── */}
          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/[0.06] pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/25 text-cyan-300 flex items-center justify-center">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase font-bold text-cyan-400 tracking-wider">Commercial Pipeline</span>
                  <h3 className="text-base font-bold text-white">Client Projects &amp; Sprint Receivables</h3>
                </div>
              </div>

              <button
                onClick={() => setActiveView('projects')}
                className="px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <span>Manage Client Projects</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5">
                <span className="text-[10px] text-slate-400 font-mono uppercase block mb-0.5">Total Client Contracts</span>
                <span className="text-xl font-black text-white font-mono">{fmt(projectReceivables.totalClientContractValue)}</span>
              </div>
              <div className="p-3.5 rounded-2xl bg-emerald-500/[0.06] border border-emerald-500/20">
                <span className="text-[10px] text-emerald-400 font-mono uppercase block mb-0.5">Realized Revenue (Collected)</span>
                <span className="text-xl font-black text-emerald-300 font-mono">{fmt(projectReceivables.totalCollectedRevenue)}</span>
              </div>
              <div className="p-3.5 rounded-2xl bg-cyan-500/[0.06] border border-cyan-500/20">
                <span className="text-[10px] text-cyan-400 font-mono uppercase block mb-0.5">Pending Sprint Receivables</span>
                <span className="text-xl font-black text-cyan-300 font-mono">{fmt(projectReceivables.totalPendingReceivables)}</span>
              </div>
            </div>

            {/* Upcoming Payouts / Sprint Inflows */}
            {projectReceivables.upcomingPayouts.length > 0 && (
              <div className="space-y-2 pt-2">
                <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">Upcoming Sprint Inflows</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {projectReceivables.upcomingPayouts.slice(0, 4).map((up) => (
                    <div
                      key={up.sprintId}
                      onClick={() => {
                        setSelectedProjectId(up.projectId);
                        setActiveView('projects');
                      }}
                      className="p-3 rounded-xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/5 hover:border-cyan-500/30 flex items-center justify-between cursor-pointer transition-all"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="text-xs font-bold text-white truncate">{up.sprintName}</div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">
                          {up.clientName || up.projectName} {up.dueDate ? `• Due ${up.dueDate}` : ''}
                        </div>
                      </div>
                      <span className="text-xs font-mono font-bold text-cyan-300 shrink-0">
                        +{fmtMoney(up.expectedIncome, up.currency)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* ── Cashflow Streams: Income & Expense Type Breakdown ─────────────── */}
          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.07] pb-4">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 flex items-center gap-1.5">
                  <Repeat className="w-3.5 h-3.5" />
                  <span>Planned Cashflow Engine</span>
                </span>
                <h3 className="text-xl font-black text-white mt-0.5">
                  Income Streams &amp; Expense Commitments
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  All stream amounts are scaled dynamically for the active horizon:{' '}
                  <span className="text-cyan-300 font-bold capitalize">{range}</span>.
                </p>
              </div>

              {/* Income/Expense Filter Tabs */}
              <div className="flex items-center gap-2">
                <div className="flex items-center p-1 rounded-xl bg-white/[0.03] border border-white/[0.08]">
                  <button
                    onClick={() => setFlowStreamFilter('all')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      flowStreamFilter === 'all'
                        ? 'bg-indigo-600 text-white font-black'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    All ({state.flowItems.length})
                  </button>
                  <button
                    onClick={() => setFlowStreamFilter('income')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      flowStreamFilter === 'income'
                        ? 'bg-emerald-500 text-white font-black'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Income Only
                  </button>
                  <button
                    onClick={() => setFlowStreamFilter('expense')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      flowStreamFilter === 'expense'
                        ? 'bg-rose-500 text-white font-black'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Expenses Only
                  </button>
                </div>

                <button
                  onClick={() => setShowFlowForm(true)}
                  className="px-3.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Stream</span>
                </button>
              </div>
            </div>

            {/* Stream Items List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {state.flowItems
                .filter((f) => {
                  if (flowStreamFilter === 'income') return f.type === 'income';
                  if (flowStreamFilter === 'expense') return f.type === 'expense';
                  return true;
                })
                .map((f) => {
                  const isIncome = f.type === 'income';
                  const scaledAmount = computeFlowItemAmountForRange(f, range);

                  return (
                    <div
                      key={f.id}
                      className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                        f.enabled
                          ? isIncome
                            ? 'bg-emerald-500/[0.04] border-emerald-500/25 hover:border-emerald-500/40'
                            : 'bg-rose-500/[0.04] border-rose-500/25 hover:border-rose-500/40'
                          : 'bg-white/[0.015] border-white/[0.06] opacity-50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <button
                          type="button"
                          onClick={() => toggleFlowItem(f.id)}
                          className={`w-8 h-8 rounded-xl border flex items-center justify-center shrink-0 transition-all cursor-pointer ${
                            f.enabled
                              ? isIncome
                                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                : 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                              : 'bg-white/5 border-white/10 text-slate-500'
                          }`}
                          title={f.enabled ? 'Click to pause' : 'Click to enable'}
                        >
                          {isIncome ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                        </button>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-black text-white truncate">{f.name}</span>
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/10 text-slate-300 uppercase font-mono font-bold">
                              {f.category}
                            </span>
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-300 capitalize font-mono">
                              {f.period}
                            </span>
                          </div>
                          {f.notes && (
                            <p className="text-[11px] text-slate-400 truncate mt-0.5">{f.notes}</p>
                          )}
                        </div>
                      </div>

                      <div className="text-right shrink-0 flex items-center gap-3">
                        <div>
                          <div
                            className={`text-sm font-black tabular-nums tracking-tight ${
                              isIncome ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            {isIncome ? '+' : '−'}
                            {fmt(scaledAmount)}
                          </div>
                          <span className="text-[10px] text-slate-500 font-mono block">
                            base {fmt(f.amount)}/{f.period.slice(0, 2)}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => removeFlowItem(f.id)}
                          className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                          title="Delete Stream"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* ── Cashflow Horizon Projections Table ───────────────────────────── */}
          <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 flex items-center gap-1.5">
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Runway &amp; Horizon Compounding</span>
              </span>
              <h3 className="text-xl font-black text-white mt-0.5">
                Cashflow Runway Across Multi-Range Horizons
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/[0.08] text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-3 px-4">Timeframe Range</th>
                    <th className="py-3 px-4 text-right">Inflow (Income)</th>
                    <th className="py-3 px-4 text-right">Outflow (Expense)</th>
                    <th className="py-3 px-4 text-right">Net Retained Surplus</th>
                    <th className="py-3 px-4 text-right">Savings Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04] font-mono">
                  {/* Monthly Row */}
                  <tr className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-blue-400" />
                      <span>Monthly Horizon (1 Month)</span>
                    </td>
                    <td className="py-3.5 px-4 text-right text-emerald-400 font-bold">
                      +{fmt(flowSummary.monthlyRunrateIncome)}
                    </td>
                    <td className="py-3.5 px-4 text-right text-rose-400 font-bold">
                      −{fmt(flowSummary.monthlyRunrateExpense)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-black text-cyan-300">
                      +{fmt(flowSummary.monthlyRunrateNet)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-slate-300">
                      {flowSummary.savingsRate}%
                    </td>
                  </tr>

                  {/* Quarterly Row */}
                  <tr className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-cyan-400" />
                      <span>Quarterly Horizon (3 Months)</span>
                    </td>
                    <td className="py-3.5 px-4 text-right text-emerald-400 font-bold">
                      +{fmt(flowSummary.monthlyRunrateIncome * 3)}
                    </td>
                    <td className="py-3.5 px-4 text-right text-rose-400 font-bold">
                      −{fmt(flowSummary.monthlyRunrateExpense * 3)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-black text-cyan-300">
                      +{fmt(flowSummary.monthlyRunrateNet * 3)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-slate-300">
                      {flowSummary.savingsRate}%
                    </td>
                  </tr>

                  {/* Yearly Row */}
                  <tr className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      <span>Yearly Horizon (12 Months / 1 Year)</span>
                    </td>
                    <td className="py-3.5 px-4 text-right text-emerald-400 font-bold">
                      +{fmt(flowSummary.monthlyRunrateIncome * 12)}
                    </td>
                    <td className="py-3.5 px-4 text-right text-rose-400 font-bold">
                      −{fmt(flowSummary.monthlyRunrateExpense * 12)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-black text-cyan-300">
                      +{fmt(flowSummary.monthlyRunrateNet * 12)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-slate-300">
                      {flowSummary.savingsRate}%
                    </td>
                  </tr>

                  {/* 5-Year Horizon Row */}
                  <tr className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-purple-400" />
                      <span>5-Year Long Horizon (60 Months)</span>
                    </td>
                    <td className="py-3.5 px-4 text-right text-emerald-400 font-bold">
                      +{fmt(flowSummary.monthlyRunrateIncome * 60)}
                    </td>
                    <td className="py-3.5 px-4 text-right text-rose-400 font-bold">
                      −{fmt(flowSummary.monthlyRunrateExpense * 60)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-black text-cyan-300">
                      +{fmt(flowSummary.monthlyRunrateNet * 60)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-slate-300">
                      {flowSummary.savingsRate}%
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 2: TREASURY OVERVIEW ──────────────────────────────── */}
      {tab === 'overview' && (
        <div className="space-y-6 stagger-3">
          {/* Asset Allocation & Performance Bento */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Holdings List */}
            <div className="lg:col-span-2 rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-cyan-400" />
                  <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                    Active Holdings &amp; Positions
                  </h2>
                </div>
                <button
                  onClick={() => setShowAssetForm(true)}
                  className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Position</span>
                </button>
              </div>

              {state.assets.filter((a) => !a.deleted).length === 0 ? (
                <div className="p-8 text-center rounded-2xl border border-dashed border-white/10 text-slate-400 text-xs space-y-2">
                  <PiggyBank className="w-8 h-8 text-slate-600 mx-auto" />
                  <p>No investment positions logged yet.</p>
                  <button
                    onClick={() => setShowAssetForm(true)}
                    className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 text-xs font-bold"
                  >
                    Log First Asset
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {state.assets
                    .filter((a) => !a.deleted)
                    .map((a) => {
                      const Icon = ASSET_ICON[a.type];
                      const pnl = assetValue(a) - assetCost(a);
                      const pct = assetCost(a) > 0 ? (pnl / assetCost(a)) * 100 : 0;
                      return (
                        <div
                          key={a.id}
                          className="flex items-center gap-4 rounded-2xl border border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.04] px-4 py-3.5 transition-all group"
                        >
                          <div className="w-10 h-10 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-cyan-300 shrink-0">
                            <Icon className="w-5 h-5" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-sm tracking-wide">{a.symbol}</span>
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-white/10 text-slate-300 uppercase">
                                {a.type}
                              </span>
                              <span className="text-xs text-slate-400 truncate">{a.name}</span>
                            </div>
                            <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                              {a.quantity} units @ {fmt(a.currentPrice, a.currency)}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-white tabular-nums text-sm">
                              {fmt(assetValue(a), a.currency)}
                            </div>
                            <div
                              className={`text-[11px] tabular-nums font-semibold flex items-center justify-end gap-0.5 ${
                                pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
                              }`}
                            >
                              {pnl >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                              <span>
                                {pnl >= 0 ? '+' : '−'}
                                {Math.abs(pct).toFixed(1)}% ({fmt(pnl, a.currency)})
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>

            {/* Account Balances Summary Card */}
            <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Landmark className="w-4 h-4 text-emerald-400" />
                    <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                      Vault Liquidity
                    </h2>
                  </div>
                  <button
                    onClick={() => setShowAccountForm(true)}
                    className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>

                {state.accounts.filter((a) => !a.deleted).length === 0 ? (
                  <p className="text-xs text-slate-500 py-6 text-center">No accounts configured.</p>
                ) : (
                  <div className="space-y-2">
                    {state.accounts
                      .filter((a) => !a.deleted)
                      .map((a) => {
                        const Icon = ACCOUNT_ICON[a.type];
                        const isDebt = a.type === 'credit' || a.type === 'debt';
                        return (
                          <div
                            key={a.id}
                            className="flex items-center justify-between p-3 rounded-xl border border-white/[0.05] bg-white/[0.02]"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs"
                                style={{ backgroundColor: `${a.color}20`, color: a.color }}
                              >
                                <Icon className="w-3.5 h-3.5" />
                              </div>
                              <div className="truncate">
                                <div className="text-xs font-bold text-white truncate">{a.name}</div>
                                <div className="text-[10px] text-slate-500 capitalize">{a.type}</div>
                              </div>
                            </div>
                            <div
                              className={`text-xs font-bold tabular-nums ${
                                isDebt ? 'text-rose-400' : 'text-slate-100'
                              }`}
                            >
                              {fmt(isDebt ? -Math.abs(a.balance) : a.balance, a.currency)}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-white/[0.07] text-[11px] text-slate-400 flex items-center justify-between font-mono">
                <span>Total Liquid Reserve</span>
                <span className="font-bold text-white">{fmt(totals.cash)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 3: VAULT ACCOUNTS ─────────────────────────────────── */}
      {tab === 'accounts' && (
        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-4 stagger-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300">
              Configured Accounts &amp; Wallets
            </h2>
            <button
              onClick={() => setShowAccountForm(true)}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Account</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {state.accounts
              .filter((a) => !a.deleted)
              .map((a) => {
                const Icon = ACCOUNT_ICON[a.type];
                const isDebt = a.type === 'credit' || a.type === 'debt';
                return (
                  <div
                    key={a.id}
                    className="p-5 rounded-2xl border border-white/[0.08] bg-white/[0.02] flex flex-col justify-between gap-4"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                          style={{ backgroundColor: `${a.color}20`, color: a.color }}
                        >
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-bold text-white text-sm">{a.name}</h3>
                          <span className="text-[10px] text-slate-400 uppercase font-mono">{a.type}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          if (confirm(`Remove account "${a.name}"?`)) removeAccount(a.id);
                        }}
                        className="p-1 rounded-lg text-slate-500 hover:text-rose-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="pt-3 border-t border-white/[0.06]">
                      <span className="text-[10px] text-slate-500 uppercase font-mono">Current Balance</span>
                      <div
                        className={`text-2xl font-black tabular-nums tracking-tight ${
                          isDebt ? 'text-rose-400' : 'text-white'
                        }`}
                      >
                        {fmt(isDebt ? -Math.abs(a.balance) : a.balance, a.currency)}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ── TAB 4: PORTFOLIO ASSETS ───────────────────────────────── */}
      {tab === 'assets' && (
        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-4 stagger-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300">
              Holdings &amp; Securities
            </h2>
            <button
              onClick={() => setShowAssetForm(true)}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-400/10 hover:bg-emerald-400/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Position</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {state.assets
              .filter((a) => !a.deleted)
              .map((a) => {
                const Icon = ASSET_ICON[a.type];
                const pnl = assetValue(a) - assetCost(a);
                const pct = assetCost(a) > 0 ? (pnl / assetCost(a)) * 100 : 0;
                return (
                  <div
                    key={a.id}
                    className="p-5 rounded-2xl border border-white/[0.08] bg-white/[0.02] flex flex-col justify-between gap-4"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-amber-300 shrink-0">
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-white text-sm">{a.symbol}</h3>
                            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-white/10 text-slate-300 uppercase">
                              {a.type}
                            </span>
                          </div>
                          <span className="text-xs text-slate-400 truncate">{a.name}</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-white/[0.06] flex items-end justify-between font-mono">
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase">Position Value</span>
                        <div className="text-xl font-black text-white tabular-nums">
                          {fmt(assetValue(a), a.currency)}
                        </div>
                      </div>
                      <div
                        className={`text-xs font-bold tabular-nums ${
                          pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {pnl >= 0 ? '+' : '−'}
                        {fmt(pnl, a.currency)} ({pct.toFixed(1)}%)
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ── TAB 5: LEDGER JOURNAL (Filtered by Active Range) ──────── */}
      {tab === 'transactions' && (
        <div className="rounded-3xl bg-[#0c0e14]/90 border border-white/[0.08] p-6 shadow-2xl space-y-4 stagger-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.07] pb-4">
            <div>
              <h2 className="text-xl font-black text-white">Ledger Journal</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Showing recorded transactions for{' '}
                <span className="text-cyan-300 font-bold font-mono">{rangeStats.label}</span>.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowTxForm(true)}
                className="btn-primary !px-4 !py-2 !text-xs !rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Record Transaction</span>
              </button>
            </div>
          </div>

          {/* Range Summary Bar */}
          <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] flex items-center justify-between text-xs font-mono flex-wrap gap-3">
            <span className="text-slate-400">
              Period Total ({rangeStats.transactionCount} entries):
            </span>
            <div className="flex items-center gap-4">
              <span className="text-emerald-400 font-bold">Inflow: +{fmt(rangeStats.income)}</span>
              <span className="text-rose-400 font-bold">Outflow: −{fmt(rangeStats.expense)}</span>
              <span className="text-cyan-300 font-black">Net: {fmt(rangeStats.netCashflow)}</span>
            </div>
          </div>

          {state.transactions
            .filter((t) => !t.deleted)
            .filter((t) => {
              if (range === 'all') return true;
              return t.date >= rangeStats.start && t.date <= rangeStats.end;
            }).length === 0 ? (
            <p className="text-xs text-slate-500 py-10 text-center">
              No transactions recorded in {rangeStats.label}.
            </p>
          ) : (
            <div className="space-y-2">
              {state.transactions
                .filter((t) => !t.deleted)
                .filter((t) => {
                  if (range === 'all') return true;
                  return t.date >= rangeStats.start && t.date <= rangeStats.end;
                })
                .map((t) => {
                  const isPositive = t.amount > 0;
                  const acc = state.accounts.find((a) => a.id === t.accountId);
                  return (
                    <div
                      key={t.id}
                      className="p-3.5 rounded-xl border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.04] transition-all flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            isPositive
                              ? 'bg-emerald-500/15 text-emerald-400'
                              : 'bg-rose-500/15 text-rose-400'
                          }`}
                        >
                          {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs font-bold text-white truncate">
                            {t.note || (isPositive ? 'Income Credit' : 'Expense Debit')}
                          </h4>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {t.date} · {acc?.name || 'General Ledger'}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span
                          className={`text-sm font-black tabular-nums font-mono ${
                            isPositive ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isPositive ? '+' : '−'}
                          {fmt(t.amount, t.currency)}
                        </span>
                        <button
                          onClick={() => {
                            if (confirm('Delete this ledger entry?')) removeTx(t.id);
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      )}

      {/* ── MODAL: Add Cashflow Stream ─────────────────────────────── */}
      {showFlowForm && (
        <MoneyForm
          title="New Cashflow Stream"
          fields={[
            { key: 'name', label: 'Stream Name', type: 'text', required: true, placeholder: 'e.g. Consulting, Rent, Groceries' },
            { key: 'type', label: 'Flow Type', type: 'select', options: ['income', 'expense'] },
            { key: 'amount', label: 'Base Amount', type: 'number', required: true, placeholder: '1500.00' },
            { key: 'period', label: 'Billing Period / Frequency', type: 'select', options: ['monthly', 'quarterly', 'yearly'] },
            { key: 'category', label: 'Category', type: 'text', placeholder: 'Career, Housing, Software, Food' },
            { key: 'notes', label: 'Notes / Description', type: 'text', placeholder: 'Optional notes' },
          ]}
          onSubmit={(v) => {
            addFlowItem({
              name: v.name!,
              type: (v.type as 'income' | 'expense') || 'income',
              amount: parseFloat(v.amount || '0'),
              period: (v.period as 'monthly' | 'quarterly' | 'yearly') || 'monthly',
              category: v.category || 'General',
              enabled: true,
              notes: v.notes,
            });
            setShowFlowForm(false);
          }}
          onClose={() => setShowFlowForm(false)}
        />
      )}

      {/* ── MODAL: Add Vault Account ───────────────────────────────── */}
      {showAccountForm && (
        <MoneyForm
          title="New Vault Account"
          fields={[
            { key: 'name', label: 'Account Name', type: 'text', required: true, placeholder: 'e.g. Primary Checking' },
            { key: 'type', label: 'Type', type: 'select', options: ['cash', 'bank', 'investment', 'credit', 'debt'] },
            { key: 'balance', label: 'Opening Balance', type: 'number', required: true, placeholder: '0.00' },
            { key: 'currency', label: 'Currency', type: 'text', placeholder: 'USD' },
            { key: 'color', label: 'Accent Color', type: 'color' },
          ]}
          onSubmit={(v) => {
            addAccount({
              name: v.name!,
              type: (v.type as MoneyAccountType) || 'bank',
              balance: parseFloat(v.balance || '0'),
              currency: v.currency || 'USD',
              color: v.color || '#F0C465',
            });
            setShowAccountForm(false);
          }}
          onClose={() => setShowAccountForm(false)}
        />
      )}

      {/* ── MODAL: Add Portfolio Asset ─────────────────────────────── */}
      {showAssetForm && (
        <MoneyForm
          title="New Portfolio Position"
          fields={[
            { key: 'symbol', label: 'Ticker Symbol', type: 'text', required: true, placeholder: 'NVDA, BTC, VOO' },
            { key: 'name', label: 'Asset Name', type: 'text', placeholder: 'NVIDIA Corporation' },
            { key: 'type', label: 'Asset Class', type: 'select', options: ['stock', 'etf', 'crypto', 'bond', 'commodity', 'other'] },
            { key: 'quantity', label: 'Holding Quantity', type: 'number', required: true, placeholder: '10' },
            { key: 'avgCost', label: 'Average Cost Basis / Unit', type: 'number', required: true, placeholder: '120.00' },
            { key: 'currentPrice', label: 'Current Market Price / Unit', type: 'number', required: true, placeholder: '135.50' },
            { key: 'currency', label: 'Currency', type: 'text', placeholder: 'USD' },
          ]}
          onSubmit={(v) => {
            addAsset({
              symbol: v.symbol!.toUpperCase(),
              name: v.name || v.symbol!,
              type: (v.type as AssetType) || 'stock',
              quantity: parseFloat(v.quantity || '0'),
              avgCost: parseFloat(v.avgCost || '0'),
              currentPrice: parseFloat(v.currentPrice || '0'),
              currency: v.currency || 'USD',
            });
            setShowAssetForm(false);
          }}
          onClose={() => setShowAssetForm(false)}
        />
      )}

      {/* ── MODAL: Record Ledger Entry ─────────────────────────────── */}
      {showTxForm && (
        <MoneyForm
          title="Record Ledger Entry"
          fields={[
            {
              key: 'accountId',
              label: 'Account',
              type: 'select',
              options: state.accounts.filter((a) => !a.deleted).map((a) => a.id),
              optionLabels: state.accounts.filter((a) => !a.deleted).map((a) => a.name),
              required: true,
            },
            { key: 'type', label: 'Entry Type', type: 'select', options: ['expense', 'income', 'transfer', 'buy', 'sell', 'dividend'] },
            { key: 'amount', label: 'Amount', type: 'number', required: true, placeholder: '50.00' },
            { key: 'currency', label: 'Currency', type: 'text', placeholder: 'USD' },
            { key: 'date', label: 'Posting Date', type: 'date' },
            { key: 'note', label: 'Memo / Description', type: 'text', placeholder: 'Coffee, salary, subscription' },
          ]}
          onSubmit={(v) => {
            const type = (v.type as TransactionType) || 'expense';
            let amount = parseFloat(v.amount || '0');
            if (type === 'expense') amount = -Math.abs(amount);
            else amount = Math.abs(amount);
            addTx({
              accountId: v.accountId!,
              type,
              amount,
              currency: v.currency || 'USD',
              date: v.date || today(),
              note: v.note,
            });
            setShowTxForm(false);
          }}
          onClose={() => setShowTxForm(false)}
        />
      )}
    </div>
  );
};

// ─── Modal Form Helper Component ─────────────────────────────────────

interface MoneyFormField {
  key: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'date' | 'color';
  required?: boolean;
  placeholder?: string;
  options?: string[];
  optionLabels?: string[];
}

const MoneyForm: React.FC<{
  title: string;
  fields: MoneyFormField[];
  onSubmit: (values: Record<string, string>) => void;
  onClose: () => void;
}> = ({ title, fields, onSubmit, onClose }) => {
  const [values, setValues] = useState<Record<string, string>>({});
  const set = (k: string, v: string) => setValues((prev) => ({ ...prev, [k]: v }));
  const missing = fields.filter((f) => f.required && !values[f.key]?.trim());

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl bg-[#0c0e14] border border-white/[0.1] shadow-2xl p-6 sm:p-7 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
          <h3 className="text-base font-black text-white">{title}</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (missing.length === 0) onSubmit(values);
          }}
          className="space-y-4"
        >
          {fields.map((f) => (
            <div key={f.key} className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">
                {f.label} {f.required && <span className="text-cyan-400">*</span>}
              </label>

              {f.type === 'select' ? (
                <select
                  value={values[f.key] ?? f.options?.[0] ?? ''}
                  onChange={(e) => set(f.key, e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white text-xs focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                >
                  {f.options?.map((opt, i) => (
                    <option key={opt} value={opt} className="bg-slate-900 text-white">
                      {f.optionLabels?.[i] ?? opt}
                    </option>
                  ))}
                </select>
              ) : f.type === 'color' ? (
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={values[f.key] ?? '#38BDF8'}
                    onChange={(e) => set(f.key, e.target.value)}
                    className="w-10 h-10 rounded-xl border border-white/10 bg-transparent cursor-pointer"
                  />
                  <span className="text-xs text-slate-400 font-mono">
                    {values[f.key] ?? '#38BDF8'}
                  </span>
                </div>
              ) : (
                <input
                  type={f.type}
                  value={values[f.key] ?? ''}
                  onChange={(e) => set(f.key, e.target.value)}
                  placeholder={f.placeholder}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                />
              )}
            </div>
          ))}

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/[0.08]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 text-xs font-bold transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={missing.length > 0}
              className="btn-primary !px-5 !py-2 !text-xs !rounded-xl disabled:opacity-50"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MoneyPage;
