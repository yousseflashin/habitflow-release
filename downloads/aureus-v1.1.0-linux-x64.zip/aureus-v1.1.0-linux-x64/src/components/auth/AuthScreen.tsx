// Aureus Auth & Vault Gateway — Executive Login, Registration & Session Unlock
// Shown on app launch or session lock when not authenticated.

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  LogIn,
  UserPlus,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import ConstellationBackground from '../ConstellationBackground';

interface AuthScreenProps {
  onUnlock: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onUnlock }) => {
  const { loginUser, registerUser } = useApp();

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState(() => (typeof localStorage !== 'undefined' ? localStorage.getItem('aureus_user_email') || '' : ''));
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;

    setIsLoading(true);
    setMessage(null);

    const action = mode === 'login' ? loginUser : registerUser;
    const res = await action(email.trim(), password);
    setIsLoading(false);

    if (res.success) {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('aureus_user_email', email.trim());
      }
      setMessage({
        text: mode === 'login' ? 'Vault unlocked. Synchronizing database...' : 'Account created. Vault initialized.',
        type: 'success',
      });
      setTimeout(() => {
        onUnlock();
      }, 500);
    } else {
      setMessage({
        text: res.error || (mode === 'login' ? 'Invalid credentials.' : 'Registration failed.'),
        type: 'error',
      });
    }
  };

  const handleGuestContinue = () => {
    onUnlock();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#07080B] text-slate-100 overflow-y-auto selection:bg-indigo-500/25 selection:text-indigo-200">
      {/* Ambient background */}
      <ConstellationBackground className="fixed inset-0 w-full h-full pointer-events-none" />

      <div className="w-full max-w-md relative z-10 py-8 animate-fadeIn">
        {/* Brand Cover Photo Banner */}
        <div className="relative w-full h-44 sm:h-52 rounded-3xl overflow-hidden mb-6 border border-white/10 shadow-2xl group stagger-1">
          <img
            src="/cover.jpg"
            alt="HabitFlow Cover"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c0e14] via-black/40 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-b from-indigo-500 to-cyan-500 text-white font-black text-sm flex items-center justify-center shadow-brand-sm">
                H
              </div>
              <div>
                <h1 className="text-lg font-black text-white tracking-tight leading-none">
                  HabitFlow Vault
                </h1>
                <p className="text-[10px] text-cyan-400 font-mono font-bold uppercase tracking-wider mt-1">
                  Whole-Life Sync &amp; Security
                </p>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-[10px] text-cyan-300 font-mono">
              Offline First
            </span>
          </div>
        </div>

        {/* Auth Card */}
        <div className="rounded-3xl bg-[#0c0e14]/95 border border-white/[0.09] p-6 sm:p-8 shadow-2xl space-y-6 stagger-2">
          {/* Segmented Mode Selector */}
          <div className="grid grid-cols-2 gap-1 p-1 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setMessage(null);
              }}
              className={`py-2 text-center text-xs font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'login'
                  ? 'bg-indigo-600 text-white shadow-brand-sm'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setMessage(null);
              }}
              className={`py-2 text-center text-xs font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'register'
                  ? 'bg-indigo-600 text-white shadow-brand-sm'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              Create Account
            </button>
          </div>

          {/* Feedback alert */}
          {message && (
            <div
              className={`p-3 rounded-2xl text-xs font-semibold flex items-center gap-2.5 ${
                message.type === 'success'
                  ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
                  : 'bg-rose-500/10 border border-rose-500/30 text-rose-300'
              }`}
            >
              {message.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{message.text}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Account Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="email"
                  required
                  autoComplete="email"
                  autoFocus
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-11 py-3 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 transition-all font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white p-1 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary !w-full !py-3.5 !text-xs !rounded-xl !shadow-glow-sm flex items-center justify-center gap-2 cursor-pointer mt-2 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{mode === 'login' ? 'Authenticating...' : 'Creating Vault...'}</span>
                </>
              ) : (
                <>
                  {mode === 'login' ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                  <span>{mode === 'login' ? 'Sign In & Unlock Vault' : 'Create Synced Account'}</span>
                </>
              )}
            </button>
          </form>

          {/* Continue in Offline Mode */}
          <div className="pt-4 border-t border-white/[0.06] text-center space-y-3 stagger-3">
            <button
              type="button"
              onClick={handleGuestContinue}
              className="w-full py-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/10 text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <span>Continue in Local Offline Vault (Guest Mode)</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
            </button>
            <p className="text-[10px] text-slate-500 leading-relaxed max-w-xs mx-auto">
              Aureus stores your tasks, habits, and measurements offline in local IndexedDB. You can connect a sync account anytime from settings.
            </p>
          </div>
        </div>

        {/* Footer info */}
        <div className="text-center mt-6 text-slate-500 text-[11px] flex items-center justify-center gap-1.5 stagger-4">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>Zero tracking · Encrypted transport · Local-first</span>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;