import React, { useMemo, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AnalyticsService } from '../../domain/analyticsService';
import { computeMoneyStats, fmtMoney } from '../../domain/moneyStatsService';
import { useLifeProfile } from '../lifestyle/lifeModelAdapter';
import { BodyMuscleMap } from '../lifestyle/BodyMuscleMap';
import { LifeAttributeRadar } from '../lifestyle/LifeAttributeRadar';
import { ContributionCalendar } from '../lifestyle/ContributionCalendar';
import { IconHelper } from '../common/IconHelper';
import {
  BarChart3,
  Flame,
  CheckCircle2,
  Trophy,
  TrendingUp,
  Percent,
  Clock,
  Layers,
  Wallet,
  PiggyBank,
  ArrowUpRight,
  ArrowDownRight,
  Activity as ActivityIcon,
  ChevronRight,
  Sparkles,
  Calendar,
  Zap,
} from 'lucide-react';

const STORAGE_KEY = 'habitflow_money_v1';

export const StatisticsView: React.FC = () => {
  const { tasks, habits, habitLogs, habitRelapses, setActiveView, setViewingHabitDetail } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'habits' | 'finances'>('all');

  const analytics = useMemo(() => {
    return AnalyticsService.calculateOverview(tasks, habits, habitLogs, habitRelapses);
  }, [tasks, habits, habitLogs, habitRelapses]);

  const { profile } = useLifeProfile(habits, habitLogs, habitRelapses);

  const moneyStats = useMemo(() => {
    if (typeof localStorage === 'undefined') return null;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return computeMoneyStats(parsed.accounts ?? [], parsed.assets ?? [], parsed.transactions ?? []);
      }
    } catch {}
    return null;
  }, []);

  const totalWeeklyActions = useMemo(() => {
    return analytics.weeklyActivity.reduce(
      (acc, d) => acc + d.habitsCompleted + d.tasksCompleted,
      0
    );
  }, [analytics.weeklyActivity]);

  const maxDailyActions = useMemo(() => {
    return Math.max(1, ...analytics.weeklyActivity.map((d) => d.habitsCompleted + d.tasksCompleted));
  }, [analytics.weeklyActivity]);

  return (
    <div className="space-y-8 pb-20 max-w-6xl mx-auto animate-fadeIn select-none">
      {/* 1. HERO HEADER */}
      <div className="stagger-1 relative rounded-3xl bg-[#0c0e14]/90 p-6 sm:p-10 border border-white/[0.08] overflow-hidden shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/25 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Intelligence Analytics</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Performance &amp; Equilibrium
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-xl">
              Cross-domain intelligence synthesized from your daily actions, biological progression, and habit streaks.
            </p>
          </div>

          {/* Quick Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-white/[0.04] border border-white/5 self-start md:self-auto">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-indigo-600 text-white font-black shadow-brand-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('habits')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'habits'
                  ? 'bg-indigo-600 text-white font-black shadow-brand-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Habit Deep-Dive
            </button>
            {moneyStats && (
              <button
                onClick={() => setActiveTab('finances')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'finances'
                    ? 'bg-indigo-600 text-white font-black shadow-brand-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Wealth Matrix
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 2. TOP 4 RADIANT KPI CARDS */}
      <div className="stagger-2 grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Longest Active Streak */}
        <div className="rounded-3xl bg-[#0c0e14]/90 p-5 border border-white/[0.08] hover:border-cyan-400/30 transition-all group relative overflow-hidden shadow-2xl">
          <div className="flex items-center justify-between text-cyan-400 mb-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">Current Streak</span>
            <div className="p-2 rounded-xl bg-cyan-400/10 border border-cyan-400/25">
              <Flame className="w-4 h-4 fill-cyan-400" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">
            {analytics.habits.longestCurrentStreak} <span className="text-xs font-semibold text-slate-400">days</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Leading discipline chain</p>
        </div>

        {/* Average Consistency */}
        <div className="rounded-3xl bg-[#0c0e14]/90 p-5 border border-white/[0.08] hover:border-emerald-400/30 transition-all group relative overflow-hidden shadow-2xl">
          <div className="flex items-center justify-between text-emerald-400 mb-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">Consistency</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">
            {analytics.habits.averageConsistencyRate}%
          </div>
          <p className="text-[11px] text-slate-400 mt-1">30-day compliance score</p>
        </div>

        {/* Tasks Completed */}
        <div className="rounded-3xl bg-[#0c0e14]/90 p-5 border border-white/[0.08] hover:border-cyan-400/30 transition-all group relative overflow-hidden shadow-2xl">
          <div className="flex items-center justify-between text-cyan-400 mb-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">Completed Tasks</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">
            {analytics.tasks.completed}{' '}
            <span className="text-xs font-normal text-slate-400">/ {analytics.tasks.total}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">All-time resolved items</p>
        </div>

        {/* All-Time Best */}
        <div className="rounded-3xl bg-[#0c0e14]/90 p-5 border border-white/[0.08] hover:border-amber-400/30 transition-all group relative overflow-hidden shadow-2xl">
          <div className="flex items-center justify-between text-amber-300 mb-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">Personal Best</span>
            <div className="p-2 rounded-xl bg-amber-400/10 border border-amber-400/25">
              <Trophy className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">
            {analytics.habits.bestOverallStreak} <span className="text-xs font-semibold text-slate-400">days</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Highest record achieved</p>
        </div>
      </div>

      {/* 3. 7-DAY COMPLETION VELOCITY CHART */}
      {(activeTab === 'all' || activeTab === 'habits') && (
        <div className="stagger-3 rounded-3xl bg-[#0c0e14]/90 p-6 sm:p-8 border border-white/[0.08] shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-amber-400/10 border border-amber-400/25 text-amber-300">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-black text-white tracking-tight">7-Day Execution Velocity</h2>
                <p className="text-xs text-slate-400">
                  {totalWeeklyActions} total actions completed this past week
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs font-bold">
              <span className="flex items-center gap-2 text-slate-300">
                <span className="w-3 h-3 rounded-md bg-gradient-to-t from-amber-600 to-amber-400 shadow-glow-sm" />
                <span>Habits</span>
              </span>
              <span className="flex items-center gap-2 text-slate-300">
                <span className="w-3 h-3 rounded-md bg-gradient-to-t from-cyan-600 to-blue-500 shadow-glow-sm" />
                <span>Tasks</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end h-56 pt-8 pb-3 border-b border-white/5">
            {analytics.weeklyActivity.map((day) => {
              const habitHeightPct = Math.min(100, Math.round((day.habitsCompleted / maxDailyActions) * 100));
              const taskHeightPct = Math.min(100, Math.round((day.tasksCompleted / maxDailyActions) * 100));
              const isToday = day.dayLabel === 'Today';

              return (
                <div key={day.date} className="flex flex-col items-center gap-2.5 h-full justify-end group">
                  <div className="w-full max-w-[42px] flex items-end justify-center gap-1.5 h-44 bg-white/[0.02] hover:bg-white/[0.05] rounded-2xl p-1.5 relative transition-all border border-white/5">
                    {/* Hover Tooltip */}
                    <div className="absolute -top-12 bg-slate-900 border border-white/10 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-30 shadow-2xl flex items-center gap-2">
                      <span className="text-amber-300">{day.habitsCompleted}h</span>
                      <span className="text-slate-500">•</span>
                      <span className="text-cyan-400">{day.tasksCompleted}t</span>
                    </div>

                    {/* Habit Bar */}
                    <div
                      style={{ height: `${Math.max(4, habitHeightPct)}%` }}
                      className="w-1/2 bg-gradient-to-t from-indigo-600 to-cyan-400 rounded-lg transition-all duration-500 min-h-[6px] shadow-cyan-glow"
                    />
                    {/* Task Bar */}
                    <div
                      style={{ height: `${Math.max(4, taskHeightPct)}%` }}
                      className="w-1/2 bg-gradient-to-t from-cyan-600 to-blue-500 rounded-lg transition-all duration-500 min-h-[6px] shadow-glow-sm"
                    />
                  </div>

                  <span
                    className={`text-[11px] font-bold tracking-wider ${
                      isToday ? 'text-amber-300 font-black' : 'text-slate-400'
                    }`}
                  >
                    {day.dayLabel}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. VISUAL BENTO: MUSCLE DEVELOPMENT + LIFE ATTRIBUTES */}
      {activeTab === 'all' && (
        <div className="stagger-4 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Anatomical Muscle Map */}
          <div className="rounded-3xl bg-[#0c0e14]/90 p-6 sm:p-8 border border-white/[0.08] shadow-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400">
                  <ActivityIcon className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-black text-white">Anatomical Muscle Map</h2>
                  <p className="text-xs text-slate-400">89-muscle physical development tracker</p>
                </div>
              </div>
            </div>

            <div className="flex-1 flex items-center justify-center py-2">
              <BodyMuscleMap
                levels={profile.muscles}
                inProgress={profile.inProgressMuscles}
                health={profile.dimensions.health}
                spirit={profile.dimensions.spirit}
                intelligence={profile.attributes.intelligence}
                height={420}
              />
            </div>
          </div>

          {/* 14-Factor Equilibrium Radar */}
          <div className="rounded-3xl bg-[#0c0e14]/90 p-6 sm:p-8 border border-white/[0.08] shadow-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-400/10 border border-amber-400/25 text-amber-300">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-black text-white">Equilibrium Radar</h2>
                  <p className="text-xs text-slate-400">14-factor holistic life balance</p>
                </div>
              </div>
            </div>

            <div className="flex-1 flex items-center justify-center py-2">
              <LifeAttributeRadar attributes={profile.attributes} size={360} />
            </div>
          </div>
        </div>
      )}

      {/* 5. 52-WEEK ACTIVITY CONTRIBUTION HEATMAP */}
      {activeTab === 'all' && (
        <div className="stagger-5 rounded-3xl bg-[#0c0e14]/90 p-6 sm:p-8 border border-white/[0.08] shadow-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-400/10 border border-amber-400/25 text-amber-300">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-black text-white">52-Week Contribution Matrix</h2>
                <p className="text-xs text-slate-400">Yearly execution frequency and density</p>
              </div>
            </div>
            <button
              onClick={() => setActiveView('calendar')}
              className="text-xs text-amber-300 hover:text-amber-200 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>View Agenda</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <ContributionCalendar days={profile.days} weeks={52} onSelectDate={() => setActiveView('calendar')} />
        </div>
      )}

      {/* 6. HABIT LEADERBOARD BREAKDOWN */}
      {(activeTab === 'all' || activeTab === 'habits') && (
        <div className="stagger-5 rounded-3xl bg-[#0c0e14]/90 p-6 sm:p-8 border border-white/[0.08] shadow-2xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-400/10 border border-amber-400/25 text-amber-300">
                <Flame className="w-4 h-4 fill-amber-400" />
              </div>
              <div>
                <h2 className="text-base font-black text-white">Habit Performance Matrix</h2>
                <p className="text-xs text-slate-400">Consistency rankings and active streaks</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {analytics.habits.habitBreakdown.map((h) => {
              const rawHabit = habits.find((item) => item.id === h.habitId);

              return (
                <div
                  key={h.habitId}
                  onClick={() => rawHabit && setViewingHabitDetail(rawHabit)}
                  className="p-4 rounded-2xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/5 hover:border-white/10 transition-all flex items-center justify-between gap-4 cursor-pointer group"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div
                      style={{ backgroundColor: `${h.color}20`, color: h.color, borderColor: `${h.color}40` }}
                      className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border shadow-xs group-hover:scale-105 transition-transform"
                    >
                      <IconHelper name={h.icon} className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-white truncate group-hover:text-amber-300 transition-colors">
                        {h.habitName}
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-2">
                        <span>{h.totalCompletions} total logs</span>
                        <span>•</span>
                        <span className="text-amber-400 font-semibold">{h.currentStreak}d streak</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end shrink-0">
                    <div className="text-xs font-bold text-amber-300">{h.completionRate30d}%</div>
                    <div className="w-16 h-1.5 rounded-full bg-white/10 overflow-hidden mt-1">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full"
                        style={{ width: `${Math.min(100, h.completionRate30d)}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 7. FINANCIAL WEALTH MATRIX */}
      {(activeTab === 'all' || activeTab === 'finances') && moneyStats && (
        <div className="stagger-5 rounded-3xl bg-[#0c0e14]/90 p-6 sm:p-8 border border-white/[0.08] shadow-2xl space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-400/10 border border-amber-400/25 text-amber-300">
                <Wallet className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-black text-white">Financial Matrix &amp; Flow</h2>
                <p className="text-xs text-slate-400">Portfolio allocation, cash reserves, and monthly burn</p>
              </div>
            </div>
            <button
              onClick={() => setActiveView('money')}
              className="text-xs text-amber-300 hover:text-amber-200 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>Manage Positions</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
              <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1">Total Net Worth</div>
              <div className="text-2xl font-black text-white tabular-nums">{fmtMoney(moneyStats.netWorth)}</div>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
              <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1">Invested Assets</div>
              <div className="text-2xl font-black text-cyan-400 tabular-nums">{fmtMoney(moneyStats.invested)}</div>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
              <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1">Monthly Inflow</div>
              <div className="text-2xl font-black text-emerald-400 tabular-nums">{fmtMoney(moneyStats.income)}</div>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
              <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1">Monthly Outflow</div>
              <div className="text-2xl font-black text-rose-400 tabular-nums">{fmtMoney(moneyStats.expense)}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StatisticsView;
