// Aureus Command Palette — Raycast-Style Executive Command Dispatcher

import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { AppView } from '../../types';
import {
  Search,
  CheckSquare,
  Flame,
  Calendar,
  Folder,
  BarChart3,
  Plus,
  Sun,
  Moon,
  X,
  ArrowRight,
  Activity,
  Wallet,
  Download,
  Sparkles,
  Command,
} from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setIsCommandPaletteOpen,
    tasks,
    habits,
    projects,
    setActiveView,
    setSelectedProjectId,
    setEditingTask,
    setIsTaskModalOpen,
    setEditingHabit,
    setIsHabitModalOpen,
    setViewingHabitDetail,
    toggleTheme,
  } = useApp();

  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isCommandPaletteOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isCommandPaletteOpen]);

  // Search Results aggregation
  const results = useMemo(() => {
    const q = query.toLowerCase().trim();
    const list: Array<{
      id: string;
      title: string;
      subtitle?: string;
      category: string;
      icon: any;
      color?: string;
      action: () => void;
    }> = [];

    // System Navigation Commands
    const navCommands: Array<{ title: string; view: AppView; icon: any }> = [
      { title: 'Open Life Command Center', view: 'lifestyle', icon: Activity },
      { title: 'Open Today Dashboard', view: 'today', icon: Sparkles },
      { title: 'Open Tasks & Checklists', view: 'tasks', icon: CheckSquare },
      { title: 'Open Habits & Streaks', view: 'habits', icon: Flame },
      { title: 'Open Chronos Calendar', view: 'calendar', icon: Calendar },
      { title: 'Open Projects & Architecture', view: 'projects', icon: Folder },
      { title: 'Open Treasury & Wealth Cockpit', view: 'money', icon: Wallet },
      { title: 'Open Performance Analytics', view: 'stats', icon: BarChart3 },
      { title: 'Open Download Center', view: 'downloads', icon: Download },
    ];

    for (const cmd of navCommands) {
      if (!q || cmd.title.toLowerCase().includes(q)) {
        list.push({
          id: 'nav_' + cmd.view,
          title: cmd.title,
          category: 'Navigation',
          icon: cmd.icon,
          action: () => {
            setActiveView(cmd.view);
            setIsCommandPaletteOpen(false);
          },
        });
      }
    }

    // Quick Action Commands
    if (!q || 'create new task'.includes(q) || 'add task'.includes(q)) {
      list.push({
        id: 'action_new_task',
        title: 'Create New Task',
        subtitle: 'Schedule a task with priority, due date, and subtasks',
        category: 'Actions',
        icon: Plus,
        action: () => {
          setEditingTask(null);
          setIsTaskModalOpen(true);
          setIsCommandPaletteOpen(false);
        },
      });
    }

    if (!q || 'create new habit'.includes(q) || 'add habit'.includes(q)) {
      list.push({
        id: 'action_new_habit',
        title: 'Create New Habit',
        subtitle: 'Configure daily/weekly target, quit protocol, and heatmap',
        category: 'Actions',
        icon: Flame,
        action: () => {
          setEditingHabit(null);
          setIsHabitModalOpen(true);
          setIsCommandPaletteOpen(false);
        },
      });
    }

    if (!q || 'theme toggle dark light'.includes(q)) {
      list.push({
        id: 'action_toggle_theme',
        title: 'Toggle Theme (Dark / Light Mode)',
        category: 'System',
        icon: Sun,
        action: () => {
          toggleTheme();
          setIsCommandPaletteOpen(false);
        },
      });
    }

    // Tasks Matches
    for (const t of tasks.filter((t) => !t.deleted)) {
      if (q && (t.title.toLowerCase().includes(q) || t.description?.toLowerCase().includes(q))) {
        list.push({
          id: 'task_' + t.id,
          title: t.title,
          subtitle: `Task • ${t.dueDate || 'No date'} • ${t.priority.toUpperCase()}`,
          category: 'Tasks',
          icon: CheckSquare,
          action: () => {
            setEditingTask(t);
            setIsTaskModalOpen(true);
            setIsCommandPaletteOpen(false);
          },
        });
      }
    }

    // Habits Matches
    for (const h of habits.filter((h) => !h.deleted)) {
      if (q && (h.name.toLowerCase().includes(q) || h.description?.toLowerCase().includes(q))) {
        list.push({
          id: 'habit_' + h.id,
          title: h.name,
          subtitle: `Habit • ${h.targetCount} ${h.targetUnit} • ${h.frequency.type}`,
          category: 'Habits',
          icon: Flame,
          color: h.color,
          action: () => {
            setViewingHabitDetail(h);
            setIsCommandPaletteOpen(false);
          },
        });
      }
    }

    // Projects Matches
    for (const p of projects.filter((p) => !p.deleted)) {
      if (q && p.name.toLowerCase().includes(q)) {
        list.push({
          id: 'proj_' + p.id,
          title: `Project: ${p.name}`,
          category: 'Projects',
          icon: Folder,
          color: p.color,
          action: () => {
            setSelectedProjectId(p.id);
            setActiveView('tasks');
            setIsCommandPaletteOpen(false);
          },
        });
      }
    }

    return list.slice(0, 10);
  }, [
    query,
    tasks,
    habits,
    projects,
    setActiveView,
    setSelectedProjectId,
    setIsTaskModalOpen,
    setIsHabitModalOpen,
    setViewingHabitDetail,
    toggleTheme,
    setEditingTask,
    setEditingHabit,
    setIsCommandPaletteOpen,
  ]);

  if (!isCommandPaletteOpen) return null;

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(1, results.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + results.length) % Math.max(1, results.length));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (results[selectedIndex]) {
        results[selectedIndex].action();
      }
    } else if (e.key === 'Escape') {
      setIsCommandPaletteOpen(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 pt-16 sm:pt-24 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn"
      onClick={() => setIsCommandPaletteOpen(false)}
    >
      <div
        className="w-full max-w-xl rounded-3xl bg-[#0c0e14] border border-white/[0.1] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Box */}
        <div className="p-4 sm:p-5 border-b border-white/[0.07] flex items-center gap-3.5 bg-white/[0.01]">
          <Search className="w-5 h-5 text-amber-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Type a command, navigate views, search tasks & habits..."
            className="flex-1 bg-transparent text-sm text-white placeholder:text-slate-500 focus:outline-none tracking-wide"
          />
          <kbd className="px-2 py-1 rounded-lg bg-white/[0.06] border border-white/10 text-[10px] font-mono text-slate-400">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="p-2 max-h-80 overflow-y-auto space-y-1">
          {results.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">No matching commands or entries.</div>
          ) : (
            results.map((item, idx) => {
              const Icon = item.icon;
              const isSelected = idx === selectedIndex;

              return (
                <button
                  key={item.id}
                  onClick={item.action}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-amber-400/[0.1] border border-amber-400/30 text-amber-300'
                      : 'border border-transparent text-slate-300 hover:bg-white/[0.03]'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div
                      style={{ color: item.color }}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                        isSelected ? 'bg-amber-400/20 border-amber-400/40 text-amber-300' : 'bg-white/[0.04] border-white/10 text-slate-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate tracking-wide">{item.title}</div>
                      {item.subtitle && (
                        <div className="text-[10px] text-slate-500 truncate mt-0.5">{item.subtitle}</div>
                      )}
                    </div>
                  </div>

                  <span
                    className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-full shrink-0 font-mono ${
                      isSelected ? 'bg-amber-400/20 text-amber-300' : 'bg-white/[0.05] text-slate-500'
                    }`}
                  >
                    {item.category}
                  </span>
                </button>
              );
            })
          )}
        </div>

        {/* Keyboard hints footer */}
        <div className="p-3 border-t border-white/[0.06] bg-black/40 flex items-center justify-between text-[10px] text-slate-500 font-mono">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>esc Dismiss</span>
          </div>
          <span className="flex items-center gap-1 text-amber-400/70">
            <Command className="w-3 h-3" />
            <span>Aureus Dispatcher</span>
          </span>
        </div>
      </div>
    </div>
  );
};

export default CommandPalette;