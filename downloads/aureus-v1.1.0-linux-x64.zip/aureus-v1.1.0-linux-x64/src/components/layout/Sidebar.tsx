import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { AppView } from '../../types';
import { updateChecker } from '../../domain/releaseService';
import {
  Sparkles,
  CheckSquare,
  Flame,
  Calendar,
  Folder,
  BarChart3,
  Plus,
  ChevronRight,
  User,
  Activity,
  Download,
  Wallet,
  Cloud,
  HardDrive,
  Settings,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const {
    activeView,
    setActiveView,
    projects,
    tasks,
    selectedProjectId,
    setSelectedProjectId,
    setIsProjectModalOpen,
    setEditingProject,
    setIsAccountModalOpen,
    syncManager,
  } = useApp();

  const [hasUpdate, setHasUpdate] = useState(false);

  useEffect(() => {
    return updateChecker.subscribe((res) => {
      setHasUpdate(res.updateAvailable);
    });
  }, []);

  const navItems: Array<{ id: AppView; label: string; icon: any; count?: number; hasBadge?: boolean }> = [
    { id: 'lifestyle', label: 'Life Pulse', icon: Activity },
    { id: 'today', label: 'Today', icon: Sparkles },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare, count: tasks.filter((t) => !t.completed).length },
    { id: 'habits', label: 'Habits', icon: Flame },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'projects', label: 'Projects', icon: Folder, count: projects.length },
    { id: 'money', label: 'Wealth Matrix', icon: Wallet },
    { id: 'stats', label: 'Intelligence', icon: BarChart3 },
    { id: 'downloads', label: 'Downloads', icon: Download },
    { id: 'settings', label: 'Settings', icon: Settings, hasBadge: hasUpdate },
  ];

  const isAuthenticated = syncManager.dbClient.isAuthenticated();

  return (
    <aside className="w-64 h-screen glass border-r border-white/[0.07] flex flex-col justify-between shrink-0 p-4 select-none hidden md:flex transition-colors relative z-20">
      <div className="space-y-6">
        {/* Brand Header */}
        <div className="flex items-center gap-3 px-2 py-1.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-b from-indigo-500 via-indigo-600 to-cyan-500 flex items-center justify-center text-white font-black text-sm shadow-[0_2px_12px_rgba(99,102,241,0.35)] border border-white/20">
            <span className="font-display font-black tracking-tight">H</span>
          </div>
          <div>
            <div className="font-display font-black text-white text-base tracking-tight flex items-center gap-1.5">
              <span>HabitFlow</span>
            </div>
            <p className="text-[10px] text-zinc-400 font-semibold tracking-widest uppercase flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#38bdf8]" />
              <span>Executive Life OS</span>
            </p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveView(item.id);
                  if (item.id === 'tasks') setSelectedProjectId(null);
                }}
                className={`relative w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-500/18 via-cyan-500/10 to-transparent text-indigo-300 border border-indigo-500/30 shadow-[0_2px_12px_rgba(99,102,241,0.12)]'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[0.04] border border-transparent'
                }`}
              >
                {/* Active indicator bar */}
                {isActive && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-4 rounded-r-full bg-cyan-400 shadow-[0_0_8px_#38bdf8]" />
                )}
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span className={isActive ? 'font-bold text-white' : ''}>{item.label}</span>
                </div>

                {item.hasBadge && (
                  <span className="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-cyan-400 text-slate-950 uppercase tracking-wider animate-pulse">
                    Update
                  </span>
                )}

                {item.count !== undefined && item.count > 0 && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive
                        ? 'bg-indigo-500/25 text-indigo-200 border border-indigo-500/35'
                        : 'bg-white/[0.05] text-zinc-400 border border-white/[0.05]'
                    }`}
                  >
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Projects Fast List */}
        <div className="space-y-2 pt-3 border-t border-white/[0.06]">
          <div className="flex items-center justify-between px-3 text-[10px] font-bold uppercase tracking-wider text-zinc-500">
            <span>Projects</span>
            <button
              onClick={() => {
                setEditingProject(null);
                setIsProjectModalOpen(true);
              }}
              className="hover:text-cyan-400 transition-colors p-1 cursor-pointer text-zinc-400"
              title="Add Project"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-0.5 max-h-48 overflow-y-auto pr-1">
            {projects.map((p) => {
              const count = tasks.filter((t) => t.projectId === p.id && !t.completed).length;
              const isSelected = activeView === 'tasks' && selectedProjectId === p.id;

              return (
                <button
                  key={p.id}
                  onClick={() => {
                    setSelectedProjectId(p.id);
                    setActiveView('tasks');
                  }}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-white/[0.08] text-white border border-white/10'
                      : 'text-zinc-400 hover:text-white hover:bg-white/[0.03]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <span
                      style={{ backgroundColor: p.color }}
                      className="w-2 h-2 rounded-full shrink-0 shadow-xs"
                    />
                    <span className="truncate">{p.name}</span>
                  </div>

                  {count > 0 && (
                    <span className="text-[10px] text-zinc-500 font-mono font-bold">{count}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer: Cloud Sync & Account */}
      <div className="pt-3 border-t border-white/[0.06]">
        <button
          onClick={() => setActiveView('settings')}
          className="w-full p-2.5 rounded-2xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.06] hover:border-white/[0.12] transition-all flex items-center justify-between text-left group shadow-xs cursor-pointer"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative shrink-0">
              <img
                src="/avatar.png"
                alt="Avatar"
                className="w-8 h-8 rounded-full object-cover border border-cyan-400/40 ring-2 ring-indigo-500/20 group-hover:scale-105 transition-transform"
              />
              <span className={`absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full border border-[#090d16] ${
                isAuthenticated ? 'bg-emerald-400 shadow-[0_0_6px_#10b981]' : 'bg-zinc-400'
              }`} />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-white truncate group-hover:text-cyan-300 transition-colors">
                Account & Vault
              </div>
              <div className="text-[10px] text-zinc-400 flex items-center gap-1.5">
                {isAuthenticated ? (
                  <>
                    <Cloud className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400 font-medium">Cloud Synced</span>
                  </>
                ) : (
                  <>
                    <HardDrive className="w-3 h-3 text-zinc-400" />
                    <span>Local Vault</span>
                  </>
                )}
              </div>
            </div>
          </div>
          <ChevronRight className="w-3.5 h-3.5 text-zinc-500 group-hover:text-white group-hover:translate-x-0.5 transition-all" />
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
