import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { BottomNav } from './BottomNav';
import { CommandPalette } from './CommandPalette';
import { TodayView } from '../today/TodayView';
import { TasksView } from '../tasks/TasksView';
import { HabitsView } from '../habits/HabitsView';
import { SharedCalendarView } from '../calendar/SharedCalendarView';
import { ProjectsView } from '../projects/ProjectsView';
import { StatisticsView } from '../stats/StatisticsView';
import { LifeCommandCenterView } from '../lifestyle/LifeCommandCenterView';
import { DownloadsPage } from '../downloads/DownloadsPage';
import { MoneyPage } from '../money/MoneyPage';
import { HabitDetailModal } from '../habits/HabitDetailModal';
import { HabitFormModal } from '../habits/HabitFormModal';
import { TaskDetailModal } from '../tasks/TaskDetailModal';
import { ProjectModal } from '../projects/ProjectModal';
import { AccountModal } from '../account/AccountModal';
import { MeetingModal } from '../calendar/MeetingModal';
import { MeetingAlertBanner } from '../notifications/MeetingAlertBanner';
import { UpdateAlertBanner } from '../notifications/UpdateAlertBanner';
import { SettingsPage } from '../settings/SettingsPage';

export const AppShell: React.FC = () => {
  const {
    activeView,
    isTaskModalOpen,
    isHabitModalOpen,
    isProjectModalOpen,
    isAccountModalOpen,
    isMeetingModalOpen,
    setIsMeetingModalOpen,
    editingMeeting,
    setEditingMeeting,
    viewingHabitDetail,
    setViewingHabitDetail,
  } = useApp();

  const renderActiveView = () => {
    switch (activeView) {
      case 'today':
        return <TodayView />;
      case 'tasks':
        return <TasksView />;
      case 'habits':
        return <HabitsView />;
      case 'calendar':
        return <SharedCalendarView />;
      case 'projects':
        return <ProjectsView />;
      case 'stats':
        return <StatisticsView />;
      case 'lifestyle':
        return <LifeCommandCenterView />;
      case 'downloads':
        return <DownloadsPage />;
      case 'money':
        return <MoneyPage />;
      case 'settings':
      case 'account':
        return <SettingsPage />;
      default:
        return <TodayView />;
    }
  };

  return (
    <div className="h-screen overflow-hidden text-slate-100 flex flex-row font-sans antialiased transition-colors selection:bg-indigo-500/25 selection:text-indigo-200">
      {/* Desktop Navigation Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-0 h-screen">
        <Header />

        {/* Full-bleed scroll container: the scrollbar sits at the viewport edge */}
        <main className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden w-full">
          <div
            key={activeView}
            className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 animate-view"
          >
            {renderActiveView()}
          </div>
        </main>

        {/* Mobile Touch Bottom Navigation */}
        <BottomNav />
      </div>

      {/* Modal Layers */}
      {isTaskModalOpen && <TaskDetailModal />}
      {isHabitModalOpen && <HabitFormModal />}
      {isProjectModalOpen && <ProjectModal />}
      {viewingHabitDetail && (
        <HabitDetailModal
          habit={viewingHabitDetail}
          onClose={() => setViewingHabitDetail(null)}
        />
      )}
      {isAccountModalOpen && <AccountModal />}
      {isMeetingModalOpen && (
        <MeetingModal
          isOpen={isMeetingModalOpen}
          onClose={() => {
            setIsMeetingModalOpen(false);
            setEditingMeeting(null);
          }}
          meeting={editingMeeting}
        />
      )}
      <CommandPalette />
      <MeetingAlertBanner />
      <UpdateAlertBanner />
    </div>
  );
};
