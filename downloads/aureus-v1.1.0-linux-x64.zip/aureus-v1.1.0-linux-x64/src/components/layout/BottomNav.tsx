import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AppView } from '../../types';
import {
  Activity,
  Sparkles,
  CheckSquare,
  Flame,
  Calendar,
  Folder,
  BarChart3,
  User,
  Wallet,
  Download,
  Settings,
  Menu,
  X,
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeView, setActiveView, tasks, setIsAccountModalOpen } = useApp();
  const [isMoreOpen, setIsMoreOpen] = useState(false);

  const mainTabs: Array<{ id: AppView; label: string; icon: any; count?: number }> = [
    { id: 'lifestyle', label: 'Life Pulse', icon: Activity },
    { id: 'today', label: 'Today', icon: Sparkles },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare, count: tasks.filter((t) => !t.completed).length },
    { id: 'habits', label: 'Habits', icon: Flame },
  ];

  const moreItems: Array<{ id: AppView; label: string; description: string; icon: any }> = [
    { id: 'calendar', label: 'Calendar', description: 'Schedule & Deadlines', icon: Calendar },
    { id: 'projects', label: 'Projects', description: 'Organization & Tags', icon: Folder },
    { id: 'money', label: 'Wealth Matrix', description: 'Accounts & Portfolio', icon: Wallet },
    { id: 'stats', label: 'Intelligence', description: 'Analytics & Trends', icon: BarChart3 },
    { id: 'downloads', label: 'Downloads', description: 'Linux & Android Apps', icon: Download },
    { id: 'settings', label: 'Settings', description: 'Updates, Sync & Preferences', icon: Settings },
  ];

  const isMoreActive = moreItems.some((item) => item.id === activeView);

  return (
    <>
      {/* "More" Drawer Overlay */}
      {isMoreOpen && (
        <div
          onClick={() => setIsMoreOpen(false)}
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md md:hidden animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute bottom-0 inset-x-0 glass-modal border-t border-white/[0.1] rounded-t-[2rem] p-5 pb-8 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-b from-indigo-500 to-cyan-500 text-white flex items-center justify-center font-black text-xs shadow-brand-sm">
                  H
                </div>
                <h3 className="font-bold text-white text-sm">HabitFlow Apps</h3>
              </div>
              <button
                onClick={() => setIsMoreOpen(false)}
                className="p-1.5 rounded-xl text-zinc-400 hover:text-white hover:bg-white/[0.06] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {moreItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setIsMoreOpen(false);
                      if (item.id === 'account') {
                        setIsAccountModalOpen(true);
                      } else {
                        setActiveView(item.id);
                      }
                    }}
                    className={`flex items-start gap-3 p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                      isActive
                        ? 'border-indigo-500/40 bg-indigo-500/10 text-cyan-300'
                        : 'border-white/[0.06] bg-white/[0.02] hover:border-white/[0.12] text-zinc-300'
                    }`}
                  >
                    <div className="p-2 rounded-xl bg-white/[0.04] text-cyan-400 shrink-0 border border-white/[0.05]">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate">{item.label}</div>
                      <div className="text-[10px] text-zinc-400 truncate">{item.description}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Main Touch Bottom Navigation Bar */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-[#08090C]/90 backdrop-blur-2xl border-t border-white/[0.08] md:hidden pb-safe px-3 py-1.5 flex items-center justify-between shadow-2xl">
        {mainTabs.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`flex-1 flex flex-col items-center justify-center py-1 rounded-2xl transition-all relative cursor-pointer ${
                isActive
                  ? 'text-cyan-400 font-bold'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : ''}`} />
                {item.count !== undefined && item.count > 0 && (
                  <span className="absolute -top-1 -right-2 w-4 h-4 rounded-full bg-cyan-400 text-black text-[9px] font-black flex items-center justify-center shadow-brand-sm">
                    {item.count}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight">{item.label}</span>
            </button>
          );
        })}

        {/* More Tab */}
        <button
          onClick={() => setIsMoreOpen(true)}
          className={`flex-1 flex flex-col items-center justify-center py-1 rounded-2xl transition-all relative cursor-pointer ${
            isMoreActive
              ? 'text-cyan-400 font-bold'
              : 'text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <div className="relative">
            <Menu className={`w-5 h-5 ${isMoreActive ? 'stroke-[2.5]' : ''}`} />
            {isMoreActive && (
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-cyan-400" />
            )}
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">More</span>
        </button>
      </nav>
    </>
  );
};

export default BottomNav;
