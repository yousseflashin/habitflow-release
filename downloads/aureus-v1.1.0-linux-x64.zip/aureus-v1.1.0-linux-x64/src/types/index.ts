// Unified Domain and Application Types for Aureus

export type Priority = 'p1' | 'p2' | 'p3' | 'p4'; // p1: Urgent (Red), p2: High (Orange), p3: Medium (Blue), p4: Low (Gray)

export type RecurrenceType = 'none' | 'daily' | 'weekdays' | 'weekly' | 'monthly' | 'custom';

export interface RecurrenceRule {
  type: RecurrenceType;
  interval?: number; // e.g. every 2 weeks
  daysOfWeek?: number[]; // 0=Sun, 1=Mon, ..., 6=Sat
  endDate?: string; // ISO date
}

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
  completedAt?: string | null;
}

export interface Reminder {
  id: string;
  time: string; // 'HH:mm' 24h format
  daysOfWeek?: number[]; // 0=Sun, 1=Mon, ..., 6=Sat (empty or undefined = every day of schedule)
  enabled: boolean;
  label?: string;
}

export interface TaskAlarm {
  id: string;
  date?: string; // 'YYYY-MM-DD'
  time: string; // 'HH:mm'
  offsetMinutes?: number; // e.g. 0 for on-time, 15 for 15m before, 60 for 1h before
  isRepeating?: boolean;
  enabled: boolean;
  label?: string;
}

export interface MeetingReminder {
  id: string;
  minutesBefore: number; // 0 for at start time, 5, 10, 15, 30, 60 (1h), 1440 (1d)
  enabled: boolean;
}

export interface Meeting {
  id: string;
  title: string;
  description?: string;
  date: string; // 'YYYY-MM-DD'
  startTime: string; // 'HH:mm' e.g. '09:30'
  endTime: string; // 'HH:mm' e.g. '10:30'
  allDay?: boolean;
  location?: string; // Meeting link (Google Meet, Zoom, Teams) or physical location
  color?: string; // Hex color code
  reminders: MeetingReminder[];
  attendees?: string[];
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
  version: number;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  priority: Priority;
  projectId: string; // 'inbox' or project UUID
  sprintId?: string; // Optional sprint linkage
  billableAmount?: number; // Optional billable income attached to task completion
  tags: string[];
  startDate?: string | null; // 'YYYY-MM-DD'
  dueDate: string | null; // 'YYYY-MM-DD' or 'YYYY-MM-DDTHH:mm'
  scheduledTime?: string | null; // Optional 'HH:mm' specific time slot on due date
  reminderTime?: string | null; // legacy single reminder field for backward-compatibility
  reminders: Reminder[]; // Unlimited task reminders
  alarms: TaskAlarm[]; // Local alarms
  recurrence?: RecurrenceRule;
  subtasks: Subtask[];
  completed: boolean;
  completedAt: string | null;
  isArchived: boolean;
  order: number;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
  version: number;
}

export type HabitCategory = 'gain' | 'quit'; // Gain = build/increase (Exercise, Water), Quit = break/reduce (Smoking, Social media)

export type HabitFrequencyType = 'daily' | 'weekdays' | 'times_per_week' | 'custom_days';

export interface HabitFrequency {
  type: HabitFrequencyType;
  targetDaysPerWeek?: number; // e.g., 3, 4, 5 times a week
  customDays?: number[]; // [1, 3, 5] for Mon, Wed, Fri
}

export interface HabitQuitDetails {
  whyQuit?: string;
  costPerDay?: number; // Optional money saved per day
  unitName?: string; // e.g. "cigarettes", "hours on TikTok", "sugary drinks"
  relapseCount?: number;
  lastRelapseDate?: string;
}

export interface Habit {
  id: string;
  name: string;
  description?: string;
  category: HabitCategory; // 'gain' | 'quit'
  icon: string; // e.g. 'dumbbell', 'book', 'droplet', 'code', 'moon', 'flame', 'heart', 'coffee', 'ban', 'shield'
  color: string; // Hex color code
  frequency: HabitFrequency;
  targetCount: number; // For Gain habits: e.g. 1 session or 8 glasses. For Quit habits: max allowed threshold or 0.
  targetUnit: string; // "times", "glasses", "mins", "pages", "cigs", "hours"
  reminderTime?: string | null; // Legacy single reminder
  reminders: Reminder[]; // Unlimited habit reminders
  startDate: string; // 'YYYY-MM-DD'
  quitDetails?: HabitQuitDetails;
  archived: boolean;
  order: number;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
  version: number;
}

export interface HabitLog {
  id: string; // `${habitId}_${date}`
  habitId: string;
  date: string; // 'YYYY-MM-DD'
  count: number;
  target: number;
  completed: boolean; // For Gain: count >= target. For Quit: successfully stayed clean on that date.
  notes?: string;
  updatedAt: string;
  deleted: boolean;
}

export interface HabitRelapseLog {
  id: string; // `${habitId}_relapse_${timestamp}`
  habitId: string;
  date: string; // 'YYYY-MM-DD'
  timestamp: string; // ISO 8601
  notes?: string;
  trigger?: string; // Reason or trigger e.g. "Stress", "Boredom", "Social event"
  updatedAt: string;
  deleted: boolean;
}

export type ProjectKind = 'personal' | 'client';

export interface ProjectSprint {
  id: string;
  projectId: string;
  name: string;
  expectedIncome: number;
  dueDate?: string; // 'YYYY-MM-DD'
  status: 'planned' | 'in_progress' | 'completed' | 'delivered';
  paymentStatus: 'pending' | 'invoiced' | 'paid';
  paidAmount?: number;
  paidDate?: string;
  accountId?: string; // target wallet/account to receive payment
  notes?: string;
}

export interface ProjectPayment {
  id: string;
  projectId: string;
  sprintId?: string;
  title: string;
  amount: number;
  currency: string;
  date: string; // 'YYYY-MM-DD'
  status: 'expected' | 'invoiced' | 'received';
  accountId?: string; // Links to MoneyAccount
  transactionId?: string; // Created in Money transactions
  notes?: string;
  createdAt: string;
}

export interface Project {
  id: string;
  name: string;
  color: string;
  icon: string;
  isFavorite: boolean;
  archived: boolean;
  order: number;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
  // Client & Money Integration
  kind?: ProjectKind;
  clientName?: string;
  currency?: string;
  contractValue?: number; // total expected budget/contract
  sprints?: ProjectSprint[];
  payments?: ProjectPayment[];
}

export interface Tag {
  id: string;
  name: string;
  color: string;
  createdAt: string;
  deleted: boolean;
}

export interface UserSession {
  userId: string;
  email: string;
  token: string;
  isAuthenticated: boolean;
  cloudSyncUrl?: string;
  lastCloudSync?: string;
}

export interface UserSettings {
  deviceId: string;
  deviceName: string;
  deviceType: 'desktop' | 'mobile';
  theme: 'dark' | 'light' | 'system';
  soundEffects: boolean;
  confettiEffects: boolean;
  hapticFeedback: boolean;
  weekStartsOnMonday: boolean;
  peerServerPort: number;
  autoSyncLocalLan: boolean;
  cloudSyncEnabled: boolean;
  cloudApiUrl: string;
}

export type AppView = 'today' | 'tasks' | 'habits' | 'calendar' | 'projects' | 'stats' | 'account' | 'settings' | 'lifestyle' | 'money' | 'downloads';

export type HabitTimeframeView = 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface HabitStats {
  currentStreak: number; // For gain: consecutive successful days. For quit: consecutive clean days.
  bestStreak: number;
  totalCompletions: number; // For gain: total completions. For quit: total clean days.
  completionRate30Days: number;
  completionRateYear: number;
  activeDaysCount: number;
  missedDaysCount: number;
  totalUnitsTracked: number;
  relapseCount?: number; // For quit habits
  totalRelapsesAllTime?: number;
  daysSinceLastRelapse?: number;
}

// ═══════════════════════════════════════════════════════════════════════════
// Whole-Life Lifestyle Manager
//
// The authoritative model lives in src/domain/lifeProgressService.ts (Activity,
// AttributeKey, dimensions, scoring). These declarations exist only so the
// persistence/sync layer and React components can name those shapes without
// importing domain logic into the DB layer.
// ═══════════════════════════════════════════════════════════════════════════

/** The four primary whole-life dimensions. */
export type LifeDimension = 'body' | 'health' | 'intelligence' | 'spirit';

export type Theme = 'dark' | 'light';

/**
 * A user-defined area of life. Deliberately open-ended: the built-in defaults are
 * Physical / Health / Mind / Spiritual / Personal Development / Productivity, but `type` is a
 * free string so the user can define what matters to them (see requirement 9).
 * The four whole-life dimensions (body/health/intelligence/spirit) are a separate concept and
 * live in src/domain/lifeProgressService.ts.
 */
export type LifestyleAreaType = string;

export interface LifestyleArea {
  id: string;
  name: string;
  description?: string;
  type: LifestyleAreaType;
  icon: string;
  color: string;
  order: number;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
}

/** Per-attribute weights. Should sum to ~1 across the four dimensions. */
export interface MetricWeights {
  body: number;
  health: number;
  intelligence: number;
  spirit: number;
}

/** A measurable metric inside a LifestyleArea. */
export interface LifestyleMetric {
  id: string;
  areaId: string;
  name: string;
  description?: string;
  unit: string;
  target?: number;
  targetUnit?: string;
  /** 'negative' = harmful habit; resisting it scores as positive progress. */
  category: 'positive' | 'negative';
  icon: string;
  color: string;
  weights: MetricWeights;
  /** Optional ceiling on how much this metric can add in one day. */
  maxDailyContribution?: number;
  order: number;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
  version: number;
}

/** Body/Health/Intelligence/Spirit contribution recorded against a habit log. */
export interface HabitAttributes {
  body: number;
  health: number;
  intelligence: number;
  spirit: number;
}

export interface UserXP {
  userId: string;
  level: number;
  currentXP: number;
  xpPerLevel: number;
  lastUpdated: string;
  createdAt: string;
}

/** A notable moment in the user's history (milestone, relapse, record). */
export interface TimelineEvent {
  id: string;
  label: string;
  kind:
    | 'milestone'
    | 'habit_completion'
    | 'habit_relapse'
    | 'task_complete'
    | 'attribute_change'
    | 'level_up';
  timestamp: string;
  metadata?: Record<string, unknown>;
}

export interface BodyMeasurement {
  id: string;
  userId: string;
  date: string;
  value: number;
  unit: string;
  label: string;
  muscleGroupId?: string;
  createdAt: string;
  updatedAt: string;
}

/** One downloadable artifact for one platform at one version. */
export interface DownloadPackage {
  platform: 'android' | 'windows' | 'linux';
  fileName: string;
  downloadUrl: string;
  fileSize: string;
  sha256?: string;
  installHint?: string;
}

/** One published version: metadata + every package built for it. */
export interface ChangelogEntry {
  version: string;
  date: string; // 'YYYY-MM-DD'
  highlight: string;
  notes: string[];
  downloads: DownloadPackage[];
}

/** Shape of public/releases.json — the single source of truth for the download center. */
export interface ReleaseManifest {
  appName: string;
  releases: ChangelogEntry[];
}

/** Update state as surfaced to the UI. */
export interface SystemUpdate {
  currentVersion: string;
  latestVersion: string;
  isUpdateAvailable: boolean;
  lastChecked: string | null;
}

// ─────────────────────────────────────────────────────────────────────
// Money management
// ─────────────────────────────────────────────────────────────────────

export type MoneyAccountType = 'cash' | 'bank' | 'investment' | 'credit' | 'debt';
export type AssetType = 'stock' | 'etf' | 'crypto' | 'bond' | 'commodity' | 'other';
export type TimeframeRange = 'monthly' | 'quarterly' | 'yearly' | 'all';

/** A wallet/brokerage account holding cash and positions. */
export interface MoneyAccount {
  id: string;
  name: string;
  type: MoneyAccountType;
  /** Cash balance in the account's currency. Negative = owed (credit/debt). */
  balance: number;
  currency: string;
  color: string;
  monthlyIncome?: number;
  monthlyExpense?: number;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
}

/** Recurring/planned wallet income or expense item */
export interface WalletFlowItem {
  id: string;
  name: string;
  type: 'income' | 'expense';
  amount: number;
  period: 'monthly' | 'quarterly' | 'yearly';
  category: string;
  accountId?: string;
  enabled: boolean;
  notes?: string;
  createdAt: string;
}

/** A held asset (stock/ETF/crypto/...) across accounts. */
export interface MoneyAsset {
  id: string;
  symbol: string;
  name: string;
  type: AssetType;
  /** Units held. */
  quantity: number;
  /** Average buy price per unit, in currency. */
  avgCost: number;
  /** Current price per unit, in currency. */
  currentPrice: number;
  currency: string;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
}

export type TransactionType = 'income' | 'expense' | 'transfer' | 'buy' | 'sell' | 'dividend';

/** A money movement. Signed amount for income/expense, absolute for trades. */
export interface MoneyTransaction {
  id: string;
  accountId: string;
  type: TransactionType;
  /** Positive = money in, negative = money out. */
  amount: number;
  currency: string;
  date: string; // 'YYYY-MM-DD'
  note?: string;
  /** For buy/sell: the asset traded, and units. */
  assetId?: string;
  assetQuantity?: number;
  createdAt: string;
  updatedAt: string;
  deleted: boolean;
}
