// IndexedDB Wrapper with Graceful In-Memory / LocalStorage Fallback

const DB_NAME = 'aureus_habitflow_db';
const DB_VERSION = 3;

export class LocalDb {
  private db: IDBDatabase | null = null;
  private memoryFallback: Map<string, Map<string, any>> = new Map();
  private isFallback: boolean = false;

  public async init(): Promise<void> {
    if (typeof indexedDB === 'undefined') {
      this.isFallback = true;
      this.initFallback();
      return;
    }

    try {
      this.db = await new Promise<IDBDatabase>((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = (e: IDBVersionChangeEvent) => {
          const db = req.result;
          if (!db.objectStoreNames.contains('operations')) {
            const opStore = db.createObjectStore('operations', { keyPath: 'operationId' });
            opStore.createIndex('deviceId', 'deviceId', { unique: false });
            opStore.createIndex('revision', 'revision', { unique: false });
            opStore.createIndex('entityType', 'entityType', { unique: false });
            opStore.createIndex('entityId', 'entityId', { unique: false });
            opStore.createIndex('timestamp', 'timestamp', { unique: false });
          }
          if (!db.objectStoreNames.contains('tasks')) {
            const taskStore = db.createObjectStore('tasks', { keyPath: 'id' });
            taskStore.createIndex('projectId', 'projectId', { unique: false });
            taskStore.createIndex('dueDate', 'dueDate', { unique: false });
            taskStore.createIndex('completed', 'completed', { unique: false });
          }
          if (!db.objectStoreNames.contains('habits')) {
            db.createObjectStore('habits', { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains('habit_logs')) {
            const logStore = db.createObjectStore('habit_logs', { keyPath: 'id' });
            logStore.createIndex('habitId', 'habitId', { unique: false });
            logStore.createIndex('date', 'date', { unique: false });
            logStore.createIndex('habit_date', ['habitId', 'date'], { unique: true });
          }
          if (!db.objectStoreNames.contains('habit_relapses')) {
            const relStore = db.createObjectStore('habit_relapses', { keyPath: 'id' });
            relStore.createIndex('habitId', 'habitId', { unique: false });
            relStore.createIndex('date', 'date', { unique: false });
          }
          if (!db.objectStoreNames.contains('projects')) {
            db.createObjectStore('projects', { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains('tags')) {
            db.createObjectStore('tags', { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains('meetings')) {
            const meetingStore = db.createObjectStore('meetings', { keyPath: 'id' });
            meetingStore.createIndex('date', 'date', { unique: false });
          }
          if (!db.objectStoreNames.contains('meta')) {
            db.createObjectStore('meta', { keyPath: 'key' });
          }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    } catch (err) {
      console.warn('IndexedDB unavailable, falling back to memory/localStorage', err);
      this.isFallback = true;
      this.initFallback();
    }
  }

  private initFallback(): void {
    const stores = ['operations', 'tasks', 'habits', 'habit_logs', 'habit_relapses', 'projects', 'tags', 'meetings', 'meta'];
    for (const store of stores) {
      if (!this.memoryFallback.has(store)) {
        this.memoryFallback.set(store, new Map());
      }
    }
    if (typeof localStorage !== 'undefined') {
      try {
        for (const store of stores) {
          const raw = localStorage.getItem(`aureus_${store}`);
          if (raw) {
            const items = JSON.parse(raw);
            const map = this.memoryFallback.get(store)!;
            for (const item of items) {
              const key = item.operationId || item.id || item.key;
              if (key) map.set(key, item);
            }
          }
        }
      } catch (e) {}
    }
  }

  private syncFallbackToLocalStorage(storeName: string): void {
    if (typeof localStorage !== 'undefined') {
      try {
        const map = this.memoryFallback.get(storeName);
        if (map) {
          const array = Array.from(map.values());
          localStorage.setItem(`aureus_${storeName}`, JSON.stringify(array));
        }
      } catch (e) {}
    }
  }

  public async get<T>(storeName: string, key: string): Promise<T | null> {
    if (this.isFallback || !this.db) {
      const map = this.memoryFallback.get(storeName);
      return map ? (map.get(key) as T) || null : null;
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  public async getAll<T>(storeName: string): Promise<T[]> {
    if (this.isFallback || !this.db) {
      const map = this.memoryFallback.get(storeName);
      return map ? Array.from(map.values()) as T[] : [];
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  public async put<T extends Record<string, any>>(storeName: string, value: T): Promise<void> {
    if (this.isFallback || !this.db) {
      const map = this.memoryFallback.get(storeName);
      if (map) {
        const key = value.operationId || value.id || value.key;
        if (key) {
          map.set(key, value);
          this.syncFallbackToLocalStorage(storeName);
        }
      }
      return;
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.put(value);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  public async putBatch<T extends Record<string, any>>(storeName: string, values: T[]): Promise<void> {
    if (values.length === 0) return;
    if (this.isFallback || !this.db) {
      const map = this.memoryFallback.get(storeName);
      if (map) {
        for (const val of values) {
          const key = val.operationId || val.id || val.key;
          if (key) map.set(key, val);
        }
        this.syncFallbackToLocalStorage(storeName);
      }
      return;
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      for (const val of values) {
        store.put(val);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  public async delete(storeName: string, key: string): Promise<void> {
    if (this.isFallback || !this.db) {
      const map = this.memoryFallback.get(storeName);
      if (map) {
        map.delete(key);
        this.syncFallbackToLocalStorage(storeName);
      }
      return;
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  public async clearAll(): Promise<void> {
    if (this.isFallback || !this.db) {
      for (const [_, map] of this.memoryFallback.entries()) {
        map.clear();
      }
      if (typeof localStorage !== 'undefined') {
        const keys = ['operations', 'tasks', 'habits', 'habit_logs', 'habit_relapses', 'projects', 'tags', 'meta'];
        for (const k of keys) {
          localStorage.removeItem(`aureus_${k}`);
        }
      }
      return;
    }

    const stores = ['operations', 'tasks', 'habits', 'habit_logs', 'habit_relapses', 'projects', 'tags', 'meta'];
    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(stores, 'readwrite');
      for (const s of stores) {
        tx.objectStore(s).clear();
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}

export const localDb = new LocalDb();
