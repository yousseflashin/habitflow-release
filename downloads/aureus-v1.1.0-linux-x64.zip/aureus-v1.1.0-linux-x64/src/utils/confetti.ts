// Confetti Particle Burst for Major Habit / Task Completions

import confetti from 'canvas-confetti';

export function fireConfettiBurst() {
  try {
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 },
      colors: ['#10B981', '#3B82F6', '#F59E0B', '#EC4899', '#8B5CF6'],
      disableForReducedMotion: true,
    });
  } catch (e) {
    // Canvas context fallback
  }
}

export function fireMilestoneConfetti() {
  try {
    const end = Date.now() + 600;
    const interval: any = setInterval(() => {
      if (Date.now() > end) {
        return clearInterval(interval);
      }
      confetti({
        startVelocity: 30,
        spread: 360,
        ticks: 60,
        origin: {
          x: Math.random(),
          y: Math.random() - 0.2,
        },
        colors: ['#10B981', '#3B82F6', '#F59E0B', '#EC4899', '#8B5CF6'],
        disableForReducedMotion: true,
      });
    }, 150);
  } catch (e) {}
}
