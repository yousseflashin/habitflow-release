-- ============================================================
-- MonsterASP Microsoft SQL Server Schema for Productivity Suite
-- Direct DB sync architecture — no Next.js, no event sourcing.
-- Conflict resolution: Last-Write-Wins on `updatedAt` (ISO 8601),
-- tiebreak by `deviceId` lexicographic ordering.
-- Deletes: soft-delete via `deleted=1, deletedBy=deviceId`.
-- ============================================================

-- 1. Users Table (authentication only — not an entity in sync)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        UserId VARCHAR(64) PRIMARY KEY,
        Email NVARCHAR(256) NOT NULL UNIQUE,
        PasswordHash NVARCHAR(256) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX IX_Users_Email ON Users(Email);
END;

-- 2. Devices Table (tracks which devices are syncing)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Devices')
BEGIN
    CREATE TABLE Devices (
        DeviceId VARCHAR(64) PRIMARY KEY,
        UserId VARCHAR(64) NOT NULL,
        DeviceName NVARCHAR(128) NOT NULL,
        DeviceType VARCHAR(32) NOT NULL DEFAULT 'desktop',
        LastSyncAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        HighestRevision INT NOT NULL DEFAULT 0,
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_Devices_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_Devices_UserId ON Devices(UserId);
END;

-- 3. Projects
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Projects')
BEGIN
    CREATE TABLE Projects (
        ProjectId VARCHAR(64) PRIMARY KEY,
        UserId VARCHAR(64) NOT NULL,
        Name NVARCHAR(256) NOT NULL,
        Color VARCHAR(32) NOT NULL DEFAULT '#10B981',
        Icon VARCHAR(64) NOT NULL DEFAULT 'folder',
        IsFavorite BIT NOT NULL DEFAULT 0,
        Archived BIT NOT NULL DEFAULT 0,
        [Order] INT NOT NULL DEFAULT 0,
        CreatedAt NVARCHAR(32) NOT NULL,
        UpdatedAt NVARCHAR(32) NOT NULL,
        Deleted BIT NOT NULL DEFAULT 0,
        DeletedBy VARCHAR(64) NULL,
        DeviceId VARCHAR(64) NOT NULL,
        CONSTRAINT FK_Projects_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_Projects_User ON Projects(UserId, Deleted);
END;

-- 4. Tags
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Tags')
BEGIN
    CREATE TABLE Tags (
        TagId VARCHAR(64) PRIMARY KEY,
        UserId VARCHAR(64) NOT NULL,
        Name NVARCHAR(128) NOT NULL,
        Color VARCHAR(32) NOT NULL DEFAULT '#6B7280',
        CreatedAt NVARCHAR(32) NOT NULL,
        Deleted BIT NOT NULL DEFAULT 0,
        DeletedBy VARCHAR(64) NULL,
        DeviceId VARCHAR(64) NOT NULL,
        CONSTRAINT FK_Tags_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_Tags_User ON Tags(UserId, Deleted);
END;

-- 5. Tasks
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Tasks')
BEGIN
    CREATE TABLE Tasks (
        TaskId VARCHAR(64) PRIMARY KEY,
        UserId VARCHAR(64) NOT NULL,
        DeviceId VARCHAR(64) NOT NULL,
        Title NVARCHAR(512) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        Priority VARCHAR(16) NOT NULL DEFAULT 'p4',
        ProjectId VARCHAR(64) NOT NULL DEFAULT 'inbox',
        Tags NVARCHAR(MAX) NULL, -- JSON array of tag IDs
        StartDate VARCHAR(32) NULL,
        DueDate VARCHAR(32) NULL,
        ReminderTime VARCHAR(32) NULL,
        Reminders NVARCHAR(MAX) NULL, -- JSON array
        Alarms NVARCHAR(MAX) NULL, -- JSON array
        Recurrence NVARCHAR(MAX) NULL, -- JSON or NULL
        Subtasks NVARCHAR(MAX) NULL, -- JSON array
        Completed BIT NOT NULL DEFAULT 0,
        CompletedAt NVARCHAR(32) NULL,
        IsArchived BIT NOT NULL DEFAULT 0,
        [Order] INT NOT NULL DEFAULT 0,
        CreatedAt NVARCHAR(32) NOT NULL,
        UpdatedAt NVARCHAR(32) NOT NULL,
        Deleted BIT NOT NULL DEFAULT 0,
        DeletedBy VARCHAR(64) NULL,
        Version INT NOT NULL DEFAULT 1,
        CONSTRAINT FK_Tasks_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_Tasks_User_Due ON Tasks(UserId, DueDate, Completed);
    CREATE INDEX IX_Tasks_User_Project ON Tasks(UserId, ProjectId);
END;

-- 6. Habits
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Habits')
BEGIN
    CREATE TABLE Habits (
        HabitId VARCHAR(64) PRIMARY KEY,
        UserId VARCHAR(64) NOT NULL,
        DeviceId VARCHAR(64) NOT NULL,
        Name NVARCHAR(256) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        Category VARCHAR(16) NOT NULL DEFAULT 'gain',
        Icon VARCHAR(64) NOT NULL DEFAULT 'flame',
        Color VARCHAR(32) NOT NULL DEFAULT '#10B981',
        FrequencyType VARCHAR(32) NOT NULL DEFAULT 'daily',
        TargetCount INT NOT NULL DEFAULT 1,
        TargetUnit VARCHAR(32) NOT NULL DEFAULT 'times',
        Frequency NVARCHAR(MAX) NULL, -- JSON: { type, targetDaysPerWeek, customDays }
        Reminders NVARCHAR(MAX) NULL, -- JSON array
        StartDate VARCHAR(32) NOT NULL,
        QuitDetails NVARCHAR(MAX) NULL, -- JSON
        Archived BIT NOT NULL DEFAULT 0,
        [Order] INT NOT NULL DEFAULT 0,
        CreatedAt NVARCHAR(32) NOT NULL,
        UpdatedAt NVARCHAR(32) NOT NULL,
        Deleted BIT NOT NULL DEFAULT 0,
        DeletedBy VARCHAR(64) NULL,
        Version INT NOT NULL DEFAULT 1,
        CONSTRAINT FK_Habits_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_Habits_User ON Habits(UserId, Deleted);
END;

-- 7. HabitLogs (per habit per day — isolated from habit definition)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'HabitLogs')
BEGIN
    CREATE TABLE HabitLogs (
        LogId VARCHAR(128) PRIMARY KEY, -- `${habitId}_${date}`
        UserId VARCHAR(64) NOT NULL,
        HabitId VARCHAR(64) NOT NULL,
        Date VARCHAR(16) NOT NULL, -- 'YYYY-MM-DD'
        Count INT NOT NULL DEFAULT 0,
        Target INT NOT NULL DEFAULT 1,
        Completed BIT NOT NULL DEFAULT 0,
        Notes NVARCHAR(MAX) NULL,
        UpdatedAt NVARCHAR(32) NOT NULL,
        Deleted BIT NOT NULL DEFAULT 0,
        DeletedBy VARCHAR(64) NULL,
        DeviceId VARCHAR(64) NOT NULL,
        CONSTRAINT FK_HabitLogs_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_HabitLogs_User_Habit_Date ON HabitLogs(UserId, HabitId, Date);
END;

-- 8. HabitRelapses
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'HabitRelapses')
BEGIN
    CREATE TABLE HabitRelapses (
        RelapseId VARCHAR(128) PRIMARY KEY, -- `${habitId}_relapse_${timestamp}`
        UserId VARCHAR(64) NOT NULL,
        HabitId VARCHAR(64) NOT NULL,
        Date VARCHAR(16) NOT NULL,
        Timestamp NVARCHAR(32) NOT NULL,
        Notes NVARCHAR(MAX) NULL,
        [Trigger] NVARCHAR(256) NULL, -- Trigger is T-SQL reserved word — must be quoted
        UpdatedAt NVARCHAR(32) NOT NULL,
        Deleted BIT NOT NULL DEFAULT 0,
        DeletedBy VARCHAR(64) NULL,
        DeviceId VARCHAR(64) NOT NULL,
        CONSTRAINT FK_HabitRelapses_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_HabitRelapses_User_Habit ON HabitRelapses(UserId, HabitId);
END;

-- 9. Settings (per-device, per-user key-value)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Settings')
BEGIN
    CREATE TABLE Settings (
        SettingKey VARCHAR(128) PRIMARY KEY, -- `${deviceId}_${key}`
        UserId VARCHAR(64) NOT NULL,
        DeviceId VARCHAR(64) NOT NULL,
        [Key] NVARCHAR(128) NOT NULL,
        ValueJson NVARCHAR(MAX) NOT NULL,
        UpdatedAt NVARCHAR(32) NOT NULL,
        CONSTRAINT FK_Settings_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_Settings_User_Device ON Settings(UserId, DeviceId);
END;

-- 10. Reminders (task/habit reminders — local alarm scheduling data)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Reminders')
BEGIN
    CREATE TABLE Reminders (
        ReminderId VARCHAR(128) PRIMARY KEY, -- `${entityType}_${entityId}_${reminderId}`
        UserId VARCHAR(64) NOT NULL,
        DeviceId VARCHAR(64) NOT NULL,
        EntityType VARCHAR(32) NOT NULL, -- 'task' or 'habit'
        EntityId VARCHAR(64) NOT NULL,
        Time VARCHAR(16) NOT NULL, -- 'HH:mm'
        DaysOfWeek NVARCHAR(64) NULL, -- JSON array of ints, NULL = every day
        Enabled BIT NOT NULL DEFAULT 1,
        Label NVARCHAR(128) NULL,
        OffsetMinutes INT NULL, -- For task alarms: minutes before
        UpdatedAt NVARCHAR(32) NOT NULL,
        Deleted BIT NOT NULL DEFAULT 0,
        DeletedBy VARCHAR(64) NULL,
        CONSTRAINT FK_Reminders_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_Reminders_User_Entity ON Reminders(UserId, EntityType, EntityId);
END;

-- 11. Money Manager Tables
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'MoneyAccounts')
BEGIN
    CREATE TABLE MoneyAccounts (
        AccountId VARCHAR(64) PRIMARY KEY,
        UserId VARCHAR(64) NOT NULL,
        Name NVARCHAR(256) NOT NULL,
        Type VARCHAR(32) NOT NULL,
        Balance DECIMAL(19, 4) NOT NULL,
        Currency CHAR(3) NOT NULL,
        Color VARCHAR(7) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        Deleted BIT NOT NULL DEFAULT 0,
        CONSTRAINT FK_Accounts_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_MoneyAccounts_UserId ON MoneyAccounts(UserId);
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'MoneyAssets')
BEGIN
    CREATE TABLE MoneyAssets (
        AssetId VARCHAR(64) PRIMARY KEY,
        UserId VARCHAR(64) NOT NULL,
        Symbol VARCHAR(16) NOT NULL,
        Name NVARCHAR(256) NOT NULL,
        Type VARCHAR(32) NOT NULL,
        Quantity DECIMAL(19, 8) NOT NULL,
        AvgCost DECIMAL(19, 4) NOT NULL,
        CurrentPrice DECIMAL(19, 4) NOT NULL,
        Currency CHAR(3) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        Deleted BIT NOT NULL DEFAULT 0,
        CONSTRAINT FK_Assets_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
    CREATE INDEX IX_MoneyAssets_UserId ON MoneyAssets(UserId);
    CREATE INDEX IX_MoneyAssets_Symbol ON MoneyAssets(UserId, Symbol);
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'MoneyTransactions')
BEGIN
    CREATE TABLE MoneyTransactions (
        TransactionId VARCHAR(64) PRIMARY KEY,
        UserId VARCHAR(64) NOT NULL,
        AccountId VARCHAR(64) NOT NULL,
        Type VARCHAR(32) NOT NULL,
        Amount DECIMAL(19, 4) NOT NULL,
        Currency CHAR(3) NOT NULL,
        TransactionDate DATE NOT NULL,
        Note NVARCHAR(MAX),
        AssetId VARCHAR(64),
        AssetQuantity DECIMAL(19, 8),
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        Deleted BIT NOT NULL DEFAULT 0,
        CONSTRAINT FK_Transactions_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE,
        CONSTRAINT FK_Transactions_Accounts FOREIGN KEY (AccountId) REFERENCES MoneyAccounts(AccountId) ON DELETE CASCADE
    );
    CREATE INDEX IX_MoneyTransactions_UserId ON MoneyTransactions(UserId);
    CREATE INDEX IX_MoneyTransactions_User_Date ON MoneyTransactions(UserId, TransactionDate);
    CREATE INDEX IX_MoneyTransactions_Asset ON MoneyTransactions(AssetId);
END;
