import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import fs from 'node:fs'
import { fileURLToPath } from 'url'
import path from 'path'

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig(({ mode }) => ({
  base: './', // Relative asset paths so the built bundle works over file:// in Electron
  plugins: [
    tailwindcss(),
    react(),
    // Stamp the app version into the bundle so releaseService can detect
    // "update available" (window.aureusVersion is set from this constant).
    {
      name: 'inject-app-version',
      transformIndexHtml(html) {
        const pkg = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'package.json'), 'utf8'));
        return html.replace(
          '</head>',
          `  <script>window.aureusVersion = ${JSON.stringify(pkg.version)};</script>\n  </head>`
        );
      },
    },
  ],
  define: {
    // Fallback used by releaseService.currentAppVersion() when no native stamp exists
    'import.meta.env.VITE_APP_VERSION': JSON.stringify(
      JSON.parse(fs.readFileSync(path.resolve(__dirname, 'package.json'), 'utf8')).version
    ),
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5173,
    host: true,
    proxy: {
      // During Vite dev, forward API calls to the Next.js API server (same-origin behavior)
      '/api': {
        target: process.env.VITE_PROXY_TARGET || 'http://localhost:3457',
        changeOrigin: true,
      },
    },
  },
}));
