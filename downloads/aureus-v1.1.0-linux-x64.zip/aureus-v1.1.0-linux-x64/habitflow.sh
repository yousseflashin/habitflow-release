#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
ELECTRON="$DIR/node_modules/.bin/electron"
if [ -x "$ELECTRON" ]; then
  exec "$ELECTRON" "$DIR/desktop/main.cjs"
else
  echo "Electron not installed yet — run ./install.sh first."
  exit 1
fi
